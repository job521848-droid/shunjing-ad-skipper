package app.shunjing.skipper.ui;

import app.shunjing.skipper.data.Preset;

/**
 * 三档模式各自的视觉色。不是随便挑的三种颜色，而是「冷静 → 平衡 → 进攻」的递进：
 * 安静是偏冷的蓝，均衡是品牌青绿，极速是暖橙红。桌面图标、守护核心、分段条、徽标
 * 全部用同一套色，切换时才有一致的"整体换挡"感。
 */
public final class Accent {
    /** 安静：冷蓝，克制。 */
    public static final int QUIET = 0xFF5FA8FF;
    public static final int QUIET_END = 0xFF8FD3FF;
    /** 均衡：品牌青绿。 */
    public static final int BALANCED = 0xFF4EF2D0;
    public static final int BALANCED_END = 0xFF68C8F5;
    /** 极速：暖橙，带灼热感。 */
    public static final int FAST = 0xFFFF8A5C;
    public static final int FAST_END = 0xFFFFC16B;
    /** 自定义：琥珀，表示"你自己调的"。 */
    public static final int CUSTOM = 0xFFFFCC66;
    public static final int CUSTOM_END = 0xFFFFE0A3;

    private Accent() { }

    public static int of(Preset.Mode mode) {
        if (mode == Preset.Mode.SAFE) return QUIET;
        if (mode == Preset.Mode.FAST) return FAST;
        if (mode == Preset.Mode.CUSTOM) return CUSTOM;
        return BALANCED;
    }

    public static int endOf(Preset.Mode mode) {
        if (mode == Preset.Mode.SAFE) return QUIET_END;
        if (mode == Preset.Mode.FAST) return FAST_END;
        if (mode == Preset.Mode.CUSTOM) return CUSTOM_END;
        return BALANCED_END;
    }

    /** 同色系的低透明度版本，用于发光、描边、底色。 */
    public static int alpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | ((alpha & 0xFF) << 24);
    }

    /** 档位序号：0/1/2，自定义按 1 处理。用于"三层递进"的刻度显示。 */
    public static int level(Preset.Mode mode) {
        if (mode == Preset.Mode.SAFE) return 0;
        if (mode == Preset.Mode.FAST) return 2;
        return 1;
    }
}
