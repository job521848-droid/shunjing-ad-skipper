package app.shunjing.skipper.service;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.content.pm.ServiceInfo;
import android.view.accessibility.AccessibilityManager;

import java.util.List;

public final class StatusUtils {
    private StatusUtils() { }

    public static boolean isAccessibilityEnabled(Context context) {
        AccessibilityManager manager = (AccessibilityManager) context.getSystemService(Context.ACCESSIBILITY_SERVICE);
        if (manager == null) return false;
        List<AccessibilityServiceInfo> services = manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        for (AccessibilityServiceInfo info : services) {
            ServiceInfo service = info.getResolveInfo() != null ? info.getResolveInfo().serviceInfo : null;
            if (service != null && context.getPackageName().equals(service.packageName)
                    && AdSkipService.class.getName().equals(service.name)) return true;
        }
        return false;
    }
}
