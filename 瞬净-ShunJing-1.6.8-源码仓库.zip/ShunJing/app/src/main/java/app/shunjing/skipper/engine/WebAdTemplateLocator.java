package app.shunjing.skipper.engine;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * v1.5.1 — WebView 模板广告（穿山甲 / 优量汇 / 广点通）的关闭键定位。
 *
 * <p>现场形态（com.xiaoyang.ydxy / 校园跑，59 个节点全部 {@code c=0}）：
 * 整页只有一层 WebView，SDK 用 H5 模板把广告画成图片，无障碍层拿不到任何语义：
 * <pre>
 *   顶部大图         #26 [0,141 → 1272,1100]
 *   内容卡片         #27 [0,1096 → 1272,1817]
 *   卡片顶部条       #32 [0,1100 → 1272,1331]
 *     左：反馈       #34/#35「反馈」 [14,1177 → 171,1257]
 *     右：纯图片     #36 [1057,1114 → 1260,1317] → #37 → #38 Image [1130,1194 → 1183,1240]
 * </pre>
 *
 * <p>为什么现成规则全打不中：整棵树没有「关闭 / ×」字样，文字规则无从匹配；
 * {@link OverlayCloseLocator} 要求「居中卡片」，而这里的卡片是通栏满宽 1272px，直接被排除；
 * {@link LayoutAnchorRule} 要求控件可点击，这里全是 {@code c=0}。
 *
 * <p>唯一稳定可信的信号是模板自带的对偶版式：<b>「反馈」在左、关闭在右，两者垂直中心对齐、
 * 左右大致对称</b>。这是《广告法》"广告应当显著标明关闭标志"与各 SDK 模板共同固化下来的位置，
 * 跨穿山甲 / 优量汇 / 广点通都成立，而且它描述的是"两个按钮的关系"，不是一个模糊的坐标。
 *
 * <p>安全边界（任何一条不满足都不返回候选）：
 * <ul>
 *   <li>敏感页 / 受保护包 / 桌面硬锁 —— 与引擎独立复核，不依赖调用方。</li>
 *   <li>页面不得出现支付 / 密码 / 验证码 / 授权 / 下单等实质决定类动作词。</li>
 *   <li>必须真的存在 WebView，且页面存在「广告」角标文字或广告模板 id
 *       （ad-container / render-view / tt_ …）—— 单靠"有反馈按钮"不算。</li>
 *   <li>候选必须与「反馈」同排（垂直中心差 ≤ 4.5%H）、位于右半屏、无文字、小尺寸、
 *       近似正方形；多层包围盒只取最内层叶子。</li>
 *   <li>同排出现两个以上互相独立的候选时返回 null —— 歧义不猜。</li>
 * </ul>
 *
 * <p>本类只回答"点哪里"，不负责"要不要点"：广告上下文由调用方
 * {@link AdDecisionEngine} 提供，且它只在所有文字规则都落空后才会用到本类。
 */
public final class WebAdTemplateLocator {

    /** 出现这些词说明当前页面在要求用户做实质决定，绝不代点。 */
    private static final String[] DANGEROUS = {
            "支付", "付款", "转账", "充值", "提现", "密码", "验证码", "授权", "登录", "注册",
            "同意", "允许", "拒绝", "卸载", "删除", "格式化", "恢复出厂", "购买", "下单",
            "确认订单", "开通", "订阅", "扣费", "签约", "实名", "扫一扫", "扫码", "二维码"
    };

    /** 模板左侧的举报入口，只用来定位，绝不点击。 */
    private static final String[] FEEDBACK_WORDS = {"反馈", "举报", "广告反馈", "反馈举报"};

    /** 关闭图标上可能带的描述；出现其它描述（更多 / 分享 / 静音）直接排除。 */
    private static final String[] CLOSE_WORDS = {"关闭", "叉", "取消", "close", "dismiss", "exit", "skip"};

    /** 广告模板 id 家族，用于确认"这确实是模板广告页"。 */
    private static final String[] TEMPLATE_IDS = {
            "ad-container", "ad_container", "adcontainer", "render-view", "render_view",
            "adview", "ad_view", "tt_", "pangolin", "gdt_", "ksad", "beizi", "mimo"
    };

    /** 与锚点同排的垂直容差。 */
    private static final float ROW_TOL = 0.045f;
    /** 候选必须在屏幕右半侧。 */
    private static final float SIDE_MIN_X = 0.55f;
    /** 候选自身尺寸区间（相对屏宽）。 */
    private static final float ICON_MIN_W = 0.016f, ICON_MAX_W = 0.110f;
    private static final float ICON_MIN_H = 0.011f, ICON_MAX_H = 0.110f;
    /** 单个候选的面积上限：超过就是容器，不是按钮。 */
    private static final float ICON_MAX_AREA = 0.020f;
    private static final float ASPECT_MIN = 0.40f, ASPECT_MAX = 2.60f;
    /** 候选右边缘距屏幕右边缘的上限：模板把它贴在角落。 */
    private static final float RIGHT_EDGE_MAX = 0.12f;
    /** 反馈锚点必须是一小段文字，不能是整块可点区域。 */
    private static final float ANCHOR_MAX_AREA = 0.04f;

    private static final int MIN_SCORE = 74;
    /** 与第二名的分差小于该值时视为歧义，不点。 */
    private static final int MIN_MARGIN = 8;

    public static final class Hit {
        public final int nodeIndex;
        public final int score;
        public final String reason;

        Hit(int nodeIndex, int score, String reason) {
            this.nodeIndex = nodeIndex;
            this.score = score;
            this.reason = reason;
        }
    }

    private WebAdTemplateLocator() { }

    public static Hit find(ScreenModel screen, int width, int height) {
        if (screen == null || screen.nodes.isEmpty()) return null;
        if (AdDecisionEngine.isSensitive(screen)) return null;
        if (AdDecisionEngine.isProtectedPackage(screen.packageName)) return null;
        if (AdDecisionEngine.isLauncherPackage(screen.packageName)) return null;
        if (hasDangerousAction(screen)) return null;
        if (!hasWebView(screen)) return null;
        if (!looksLikeTemplateAd(screen)) return null;

        int w = width > 0 ? width : inferWidth(screen);
        int h = height > 0 ? height : inferHeight(screen);
        if (w <= 0 || h <= 0) return null;

        for (NodeModel anchor : feedbackAnchors(screen, w, h)) {
            float anchorCy = (anchor.top + anchor.bottom) / 2f;
            float anchorCx = (anchor.left + anchor.right) / 2f;
            List<Hit> row = new ArrayList<>();
            for (NodeModel node : screen.nodes) {
                if (!isCloseIcon(node, anchorCy, w, h)) continue;
                row.add(new Hit(node.index, score(node, anchorCx, anchorCy, w, h),
                        "WebView 模板广告 · 反馈对偶关闭键"));
            }
            Hit pick = pickLeaf(row, screen);
            if (pick != null && pick.score >= MIN_SCORE) return pick;
        }
        return null;
    }

    /** 只保留最内层的叶子盒（#36 → #37 → #38 这类三层包围盒只点最里面那个）。 */
    private static Hit pickLeaf(List<Hit> row, ScreenModel screen) {
        if (row.isEmpty()) return null;
        List<Hit> leaves = new ArrayList<>();
        for (Hit hit : row) {
            NodeModel n = screen.nodes.get(hit.nodeIndex);
            boolean wrapsSmaller = false;
            for (Hit other : row) {
                if (other == hit) continue;
                NodeModel o = screen.nodes.get(other.nodeIndex);
                if (o.index == n.index) continue;
                boolean contains = n.left <= o.left && n.top <= o.top
                        && n.right >= o.right && n.bottom >= o.bottom;
                if (contains && o.area() < n.area()) { wrapsSmaller = true; break; }
            }
            if (!wrapsSmaller) leaves.add(hit);
        }
        if (leaves.isEmpty()) return null;
        Hit best = null;
        for (Hit hit : leaves) {
            if (best == null || hit.score > best.score
                    || (hit.score == best.score
                    && screen.nodes.get(hit.nodeIndex).area()
                    < screen.nodes.get(best.nodeIndex).area())) {
                best = hit;
            }
        }
        int second = Integer.MIN_VALUE;
        for (Hit hit : leaves) {
            if (hit == best) continue;
            second = Math.max(second, hit.score);
        }
        // 两个同样像关闭按钮的独立控件（例如"关闭"+"更多"）时宁可不点。
        if (second != Integer.MIN_VALUE && best.score - second < MIN_MARGIN) return null;
        return best;
    }

    private static List<NodeModel> feedbackAnchors(ScreenModel screen, int w, int h) {
        List<NodeModel> anchors = new ArrayList<>();
        long maxArea = (long) (w * (long) h * ANCHOR_MAX_AREA);
        for (NodeModel node : screen.nodes) {
            if (!node.visible || node.password || !node.hasBounds()) continue;
            String text = node.normalizedText();
            if (text.isEmpty() || text.length() > 8) continue;
            if (!containsAny(text, FEEDBACK_WORDS)) continue;
            if (node.area() > maxArea) continue;
            // 锚点本身必须落在左侧（模板固定：左反馈、右关闭）。
            if (node.left > w * 0.45f) continue;
            anchors.add(node);
        }
        return anchors;
    }

    private static boolean isCloseIcon(NodeModel node, float anchorCy, int w, int h) {
        if (!node.visible || node.password || !node.hasBounds()) return false;
        if (!node.normalizedText().isEmpty()) return false;      // 有文字是 CTA / 反馈
        String desc = node.normalizedDescription();
        if (!desc.isEmpty() && !looksLikeClose(desc)) return false;

        int bw = node.right - node.left, bh = node.bottom - node.top;
        if (bw < w * ICON_MIN_W || bw > w * ICON_MAX_W) return false;
        if (bh < h * ICON_MIN_H || bh > h * ICON_MAX_H) return false;
        float aspect = bw / (float) bh;
        if (aspect < ASPECT_MIN || aspect > ASPECT_MAX) return false;
        if ((long) bw * bh > (long) (w * (long) h * ICON_MAX_AREA)) return false;

        float cx = (node.left + node.right) / 2f;
        float cy = (node.top + node.bottom) / 2f;
        if (cx < w * SIDE_MIN_X) return false;
        if (w - node.right > w * RIGHT_EDGE_MAX) return false;
        // 必须与「反馈」同一排 —— 这是整条规则的核心。
        return Math.abs(cy - anchorCy) <= h * ROW_TOL;
    }

    private static int score(NodeModel icon, float anchorCx, float anchorCy, int w, int h) {
        int value = 70;
        float cx = (icon.left + icon.right) / 2f;
        float cy = (icon.top + icon.bottom) / 2f;
        if (Math.abs(cy - anchorCy) <= h * 0.012f) value += 12;   // 严格同排
        // 左右镜像对称：反馈离左边缘多少，关闭就该离右边缘多少。
        if (Math.abs((w - cx) - anchorCx) <= w * 0.05f) value += 8;
        if (w - icon.right <= w * 0.045f) value += 5;             // 紧贴右边缘
        if (isImage(icon.className)) value += 5;
        if (looksLikeClose(icon.normalizedDescription())) value += 10;
        String id = icon.viewId.toLowerCase(Locale.ROOT);
        if (id.contains("close") || id.contains("ad_close")) value += 10;
        return value;
    }

    /** 页面真的是一层 WebView 吗？（模板广告都是 H5 渲染） */
    private static boolean hasWebView(ScreenModel screen) {
        for (NodeModel node : screen.nodes) {
            if (node.visible && node.className.toLowerCase(Locale.ROOT).contains("webview")) return true;
        }
        return false;
    }

    /** 「广告」角标（法定标识）或模板 id 家族，至少命中一个。 */
    private static boolean looksLikeTemplateAd(ScreenModel screen) {
        for (NodeModel node : screen.nodes) {
            if (!node.visible) continue;
            String text = node.normalizedText();
            if (text.equals("广告") || text.equals("ad") || text.equals("广告·")
                    || (text.startsWith("广告") && text.length() <= 4)) return true;
            String value = (node.viewId + " " + node.className).toLowerCase(Locale.ROOT);
            for (String id : TEMPLATE_IDS) if (value.contains(id)) return true;
        }
        return false;
    }

    private static boolean hasDangerousAction(ScreenModel screen) {
        for (NodeModel n : screen.nodes) {
            String value = n.normalizedText() + n.normalizedDescription();
            if (value.isEmpty()) continue;
            for (String word : DANGEROUS) if (value.contains(word)) return true;
        }
        return false;
    }

    private static boolean looksLikeClose(String desc) {
        for (String word : CLOSE_WORDS) if (desc.contains(word)) return true;
        return false;
    }

    private static boolean isImage(String className) {
        String c = className == null ? "" : className.toLowerCase(Locale.ROOT);
        return c.endsWith("imageview") || c.endsWith("imagebutton") || c.endsWith("image")
                || c.contains("appcompatimage");
    }

    private static boolean containsAny(String value, String[] needles) {
        for (String needle : needles) if (value.contains(needle)) return true;
        return false;
    }

    private static int inferWidth(ScreenModel screen) {
        int value = 0;
        for (NodeModel n : screen.nodes) if (n.visible) value = Math.max(value, n.right);
        return value;
    }

    private static int inferHeight(ScreenModel screen) {
        int value = 0;
        for (NodeModel n : screen.nodes) if (n.visible) value = Math.max(value, n.bottom);
        return value;
    }
}
