package app.shunjing.skipper.data;

/**
 * 临时暂停的纯计算部分（1.6.2）。
 *
 * <p>为什么单独一个类：暂停的难点不在 UI，而在"到点没有"这件事要在四个地方被问 ——
 * 无障碍事件入口、扫描、点击校验、通知文案。四处各写一遍 {@code until > now}
 * 迟早会有一处写成 {@code >=}，表现就是"设了 15 分钟，第 15 分钟还在跳"。
 *
 * <p>这里只做时间算术，不碰 SharedPreferences，所以能被 JVM 单元测试直接覆盖。
 */
public final class Pause {

    public static final long MINUTE = 60_000L;

    private Pause() { }

    /** 暂停是否仍在生效。到点那一毫秒即视为结束。 */
    public static boolean active(long now, long until) {
        return until > now;
    }

    /** 剩余毫秒；未暂停时为 0，不会是负数。 */
    public static long remaining(long now, long until) {
        return until > now ? until - now : 0L;
    }

    /** 从 now 起暂停 minutes 分钟；0 或负数表示恢复（返回 0）。 */
    public static long until(long now, int minutes) {
        if (minutes <= 0) return 0L;
        return now + minutes * MINUTE;
    }

    /**
     * 人读的剩余时间。向上取整：剩 12 分 01 秒说「13 分钟」比说「12 分钟」诚实，
     * 因为用户看到 12 分钟时会以为马上到点，结果又等了一分钟。
     */
    public static String label(long remainingMs) {
        if (remainingMs <= 0L) return "";
        if (remainingMs < MINUTE) return "不到 1 分钟";
        long minutes = (remainingMs + MINUTE - 1) / MINUTE;
        if (minutes < 60L) return minutes + " 分钟";
        long hours = minutes / 60L;
        long rest = minutes % 60L;
        return rest == 0L ? hours + " 小时" : hours + " 小时 " + rest + " 分钟";
    }
}
