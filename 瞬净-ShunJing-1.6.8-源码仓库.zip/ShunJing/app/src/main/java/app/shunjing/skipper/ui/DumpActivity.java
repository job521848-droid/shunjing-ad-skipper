package app.shunjing.skipper.ui;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import app.shunjing.skipper.R;
import app.shunjing.skipper.data.DumpStore;
import app.shunjing.skipper.data.Prefs;
import app.shunjing.skipper.engine.Diagnosis;
import app.shunjing.skipper.engine.PageDump;
import app.shunjing.skipper.service.CaptureIntents;

/** Capture list + trigger controls. */
public final class DumpActivity extends BaseActivity {
    public static final String EXTRA_FILE = "dump_file";

    private Prefs prefs;
    private DumpStore store;
    private DumpAdapter adapter;
    private final List<Row> rows = new ArrayList<>();
    private boolean receiverRegistered = false;
    /** v1.5.6: 逐条读快照 + 跑引擎放到后台，主线程只负责把结果贴上去。 */
    private final java.util.concurrent.ExecutorService analysisExecutor =
            java.util.concurrent.Executors.newSingleThreadExecutor();
    private int reloadToken = 0;
    private TextView emptyHint;

    private final BroadcastReceiver savedReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (CaptureIntents.ACTION_DUMP_SAVED.equals(intent.getAction())) reload();
        }
    };

    private static final class Row {
        final DumpStore.Meta meta;
        final Diagnosis diagnosis;
        /** v1.5.6: 列表先出来，诊断结果在后台算完再填 —— 否则打开这一页要卡好几秒。 */
        final boolean pending;
        Row(DumpStore.Meta meta, Diagnosis diagnosis, boolean pending) {
            this.meta = meta;
            this.diagnosis = diagnosis;
            this.pending = pending;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        store = new DumpStore(this);
        // v1.5.7: 原来是「LinearLayout 顶上一堆卡片 + 底下 ListView 占权重」。
        // 卡片高度是固定的，屏幕一矮（或字体调大）就把 ListView 压成 0 高，
        // 而 LinearLayout 本身不会滚，于是下面的滑块和记录全都看不到、也滑不动。
        // 改成 ListView + header：卡片跟着列表一起滚，页面上任何位置都能上下滑。
        LinearLayout headerBox = new LinearLayout(this);
        headerBox.setOrientation(LinearLayout.VERTICAL);
        headerBox.setPadding(0, Ui.dp(this, 14), 0, 0);
        headerBox.addView(Ui.header(this, "智能诊断中心", "抓取跳过不了的广告现场，分析原因并给出修复方案", true));

        LinearLayout intro = Ui.card(this);
        intro.addView(Ui.caption(this, "CAPTURE  /  LOCAL AI DIAGNOSIS"));
        intro.addView(Ui.text(this, "遇到跳过不了的广告，先留下现场", 17, getColor(R.color.text_primary)));
        intro.addView(Ui.text(this,
                "内置离线诊断引擎会复现识别过程，告诉你「为什么没跳过」，并生成经过回验的关闭词 / 控件 ID / 布局锚点规则，一键采纳即可生效。诊断过程不联网。",
                13, getColor(R.color.text_secondary)));
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button next = Ui.primary(this, "抓取下一屏");
        next.setOnClickListener(v -> {
            sendBroadcast(CaptureIntents.capture(this, CaptureIntents.MODE_NEXT));
            Toast.makeText(this, "切回广告页面即自动抓取", Toast.LENGTH_LONG).show();
        });
        actions.addView(next, rowParams(1f));
        Button now = Ui.secondary(this, "抓取当前页");
        now.setOnClickListener(v -> {
            sendBroadcast(CaptureIntents.capture(this, CaptureIntents.MODE_NOW));
            Toast.makeText(this, "正在读取当前窗口…", Toast.LENGTH_SHORT).show();
        });
        actions.addView(now, rowParams(1f));
        LinearLayout.LayoutParams actionsParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        actionsParams.setMargins(0, Ui.dp(this, 12), 0, 0);
        intro.addView(actions, actionsParams);
        intro.addView(Ui.text(this,
                "提示：也可下拉通知栏，用「抓取当前页」直接在广告页面抓取，不用切回本应用。",
                12, getColor(R.color.text_secondary)));
        headerBox.addView(intro);

        LinearLayout toggles = Ui.card(this);
        toggles.addView(Ui.caption(this, "分享与隐私"));
        addToggle(toggles, "导出报告时脱敏", "分享给 AI 前隐藏页面文字，只保留控件结构、ID 与坐标",
                "mask_export", false);
        headerBox.addView(toggles);

        // ------------------------------------------------------------ 自动清理
        LinearLayout retention = Ui.card(this);
        retention.addView(Ui.caption(this, "自动清理"));
        retention.addView(Ui.text(this,
                "只保留最近几条，多了自动删（立即生效，删除不可恢复）。日志和抓取攒太多时，"
                        + "打开这一页要逐条读文件、重新分析，就会明显卡顿。",
                13, getColor(R.color.text_secondary)));
        addRetentionSlider(retention, "触发日志", Prefs.LOG_KEEP_MIN, Prefs.LOG_KEEP_MAX, 5,
                prefs.logKeepLimit(), " 条", value -> prefs.setLogKeepLimit(value));
        addRetentionSlider(retention, "页面抓取", DumpStore.KEEP_MIN, DumpStore.KEEP_MAX, 1,
                prefs.dumpKeepLimit(), " 份", value -> {
                    prefs.setDumpKeepLimit(value);
                    store.setKeepLimit(value);
                    store.pruneNow();
                    reload();
                });
        headerBox.addView(retention);

        LinearLayout listHeader = new LinearLayout(this);
        listHeader.setGravity(Gravity.CENTER_VERTICAL);
        listHeader.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 6));
        listHeader.addView(Ui.caption(this, "抓取记录"), new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button logs = Ui.secondary(this, "点击日志");
        logs.setMinHeight(Ui.dp(this, 34));
        logs.setTextSize(12);
        logs.setOnClickListener(v -> startActivity(new Intent(this, LogsActivity.class)));
        LinearLayout.LayoutParams logParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        logParams.setMargins(0, 0, Ui.dp(this, 8), 0);
        listHeader.addView(logs, logParams);
        Button clear = Ui.secondary(this, "清空");
        clear.setMinHeight(Ui.dp(this, 34));
        clear.setTextSize(12);
        clear.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("清空抓取记录")
                .setMessage("将删除本机保存的全部页面快照，此操作不可恢复。")
                .setNegativeButton("取消", null)
                .setPositiveButton("清空", (d, w) -> { store.clear(); reload(); }).show());
        listHeader.addView(clear);
        headerBox.addView(listHeader);

        // 空状态的提示放在列表末尾（headers 之后），有记录时隐藏。
        emptyHint = Ui.text(this,
                "还没有抓取记录\n\n跳过不了时，用上方按钮抓取，或开启自动留样\n通知栏也提供一键抓取",
                14, getColor(R.color.text_secondary));
        emptyHint.setGravity(Gravity.CENTER);
        emptyHint.setPadding(0, Ui.dp(this, 36), 0, Ui.dp(this, 36));
        headerBox.addView(emptyHint);

        ListView list = new ListView(this);
        list.setBackgroundResource(R.drawable.bg_screen);
        list.setPadding(Ui.dp(this, 20), 0, Ui.dp(this, 20), Ui.dp(this, 20));
        list.setClipToPadding(false);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setVerticalScrollBarEnabled(false);
        list.addHeaderView(headerBox, null, false);
        adapter = new DumpAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> {
            int index = position - list.getHeaderViewsCount();
            if (index < 0 || index >= rows.size()) return;
            Intent detail = new Intent(this, DumpDetailActivity.class);
            detail.putExtra(EXTRA_FILE, rows.get(index).meta.file.getAbsolutePath());
            startActivity(detail);
        });
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            int index = position - list.getHeaderViewsCount();
            if (index < 0 || index >= rows.size()) return false;
            File file = rows.get(index).meta.file;
            new AlertDialog.Builder(this).setTitle("删除快照")
                    .setMessage("删除这条页面快照？")
                    .setNegativeButton("取消", null)
                    .setPositiveButton("删除", (d, w) -> { store.delete(file); reload(); }).show();
            return true;
        });
        setContentView(list);
    }

    private LinearLayout.LayoutParams rowParams(float weight) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        p.setMargins(Ui.dp(this, 3), 0, Ui.dp(this, 3), 0);
        return p;
    }

    private void addToggle(LinearLayout parent, String title, String description, String key, boolean fallback) {
        Switch toggle = new Switch(this);
        toggle.setText(title);
        toggle.setTextSize(15);
        toggle.setTextColor(getColor(R.color.text_primary));
        toggle.setChecked(prefs.preferences().getBoolean(key, fallback));
        toggle.setOnCheckedChangeListener((b, checked) ->
                prefs.preferences().edit().putBoolean(key, checked).apply());
        parent.addView(toggle, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView detail = Ui.text(this, description, 12, getColor(R.color.text_secondary));
        detail.setPadding(0, 0, 0, Ui.dp(this, 8));
        parent.addView(detail);
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerSavedReceiver();
        reload();
    }

    @Override
    protected void onDestroy() {
        if (receiverRegistered) {
            try { unregisterReceiver(savedReceiver); } catch (RuntimeException ignored) { }
            receiverRegistered = false;
        }
        analysisExecutor.shutdownNow();
        super.onDestroy();
    }

    // API < 33 has no 3-arg overload; the legacy branch only receives this app's explicit broadcasts.
    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    private void registerSavedReceiver() {
        if (receiverRegistered) return;
        IntentFilter filter = new IntentFilter(CaptureIntents.ACTION_DUMP_SAVED);
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(savedReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(savedReceiver, filter);
            }
            receiverRegistered = true;
        } catch (RuntimeException ignored) { }
    }

    /** 列表先出来，诊断结果在后台逐条填；超过上限的旧快照在这里就地删掉。 */
    private void reload() {
        store.setKeepLimit(prefs.dumpKeepLimit());
        store.pruneNow();
        final List<DumpStore.Meta> metas = store.list();
        rows.clear();
        for (DumpStore.Meta meta : metas) rows.add(new Row(meta, null, true));
        adapter.notifyDataSetChanged();
        if (emptyHint != null) emptyHint.setVisibility(metas.isEmpty() ? View.VISIBLE : View.GONE);
        final int token = ++reloadToken;
        if (metas.isEmpty()) return;
        analysisExecutor.execute(() -> {
            final List<Diagnosis> results = new ArrayList<>(metas.size());
            for (DumpStore.Meta meta : metas) {
                PageDump dump = store.load(meta);
                results.add(dump == null ? null : DiagnosisHelper.analyze(DumpActivity.this, dump));
            }
            runOnUiThread(() -> {
                if (token != reloadToken || isFinishing() || isDestroyed()) return;
                for (int i = 0; i < rows.size() && i < results.size(); i++) {
                    rows.set(i, new Row(rows.get(i).meta, results.get(i), false));
                }
                adapter.notifyDataSetChanged();
            });
        });
    }

    /**
     * 一行「标题 + 当前值 + 滑块」。只在松手时写回，拖动过程只更新数字，
     * 避免每动一格都重算列表。
     */
    private void addRetentionSlider(LinearLayout parent, String title, int min, int max, int step,
                                    int value, String unit, java.util.function.IntConsumer onChange) {
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(0, Ui.dp(this, 12), 0, 0);
        TextView name = Ui.text(this, title, 15, getColor(R.color.text_primary));
        head.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView valueText = Ui.text(this, value + unit, 13, getColor(R.color.cyan));
        head.addView(valueText);
        parent.addView(head);

        SeekBar bar = new SeekBar(this);
        bar.setMax((max - min) / step);
        bar.setProgress((value - min) / step);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                valueText.setText((min + progress * step) + unit);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                onChange.accept(min + seekBar.getProgress() * step);
            }
        });
        parent.addView(bar);
    }

    private String appLabel(String pkg) {
        try {
            return getPackageManager().getApplicationLabel(
                    getPackageManager().getApplicationInfo(pkg, 0)).toString();
        } catch (PackageManager.NameNotFoundException e) {
            return pkg;
        }
    }

    private final class DumpAdapter extends BaseAdapter {
        @Override public int getCount() { return rows.size(); }
        @Override public Row getItem(int position) { return rows.get(position); }
        @Override public long getItemId(int position) { return rows.get(position).meta.time; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Row row = getItem(position);
            LinearLayout card = Ui.card(DumpActivity.this);
            LinearLayout line = new LinearLayout(DumpActivity.this);
            line.setGravity(Gravity.CENTER_VERTICAL);
            TextView label = Ui.text(DumpActivity.this, appLabel(row.meta.packageName), 16,
                    getColor(R.color.text_primary));
            label.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
            line.addView(label, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            String time = new SimpleDateFormat("MM-dd HH:mm:ss", Locale.CHINA)
                    .format(new Date(row.meta.time));
            line.addView(Ui.text(DumpActivity.this, time, 11, getColor(R.color.text_secondary)));
            card.addView(line);

            String verdict = row.pending ? "分析中…"
                    : row.diagnosis == null ? "快照已损坏" : row.diagnosis.verdictLabel();
            int color = row.pending ? getColor(R.color.text_secondary) : verdictColor(row.diagnosis);
            TextView badge = Ui.text(DumpActivity.this, verdict, 12, color);
            badge.setBackground(Ui.badge(DumpActivity.this, color));
            badge.setPadding(Ui.dp(DumpActivity.this, 10), Ui.dp(DumpActivity.this, 4),
                    Ui.dp(DumpActivity.this, 10), Ui.dp(DumpActivity.this, 4));
            LinearLayout.LayoutParams badgeParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            badgeParams.setMargins(0, Ui.dp(DumpActivity.this, 6), 0, Ui.dp(DumpActivity.this, 4));
            card.addView(badge, badgeParams);

            String source = new PageDump("", row.meta.time, row.meta.packageName, "", "",
                    row.meta.source, 0, 0, false, null).sourceLabel();
            card.addView(Ui.text(DumpActivity.this,
                    row.meta.packageName + "  ·  " + row.meta.nodeCount + " 控件  ·  " + source
                            + "  ·  点击诊断 ›",
                    11, getColor(R.color.text_secondary)));
            LinearLayout wrapper = new LinearLayout(DumpActivity.this);
            wrapper.addView(card);
            return wrapper;
        }

        private int verdictColor(Diagnosis diagnosis) {
            if (diagnosis == null) return getColor(R.color.text_secondary);
            switch (diagnosis.verdict) {
                case SKIPPABLE: return getColor(R.color.cyan);
                case PROTECTED:
                case REWARDED: return getColor(R.color.blue);
                case MASTER_OFF:
                case APP_DISABLED:
                case NOT_CLICKABLE: return getColor(R.color.warning);
                default: return getColor(R.color.danger);
            }
        }
    }
}
