package app.shunjing.skipper.engine;

/**
 * v1.5.1 — 「点了关闭，反而被拽走」的兜底。
 *
 * <p>WebView 模板广告、H5 落地页这类页面整棵树都是 {@code c=0}，关闭键只能按坐标点。
 * 坐标是几何推断出来的，不是语义确认的：万一模板把"更多 / 广告详情"放在了同一个位置，
 * 我们这一点就会跳去落地页或第三方应用，用户感知就是"它替我点了广告"。
 *
 * <p>所以只对<b>低置信度点击</b>（WebView 模板定位、坐标盲点）开一个 2.2 秒的观察窗：
 * 窗口内若前台换了包，立刻按返回，把用户送回广告页。真正可点击、靠文字命中的
 * 关闭按钮不进这个窗口 —— 那类点击是确定的，不该被二次干预。
 *
 * <p>安全边界：
 * <ul>
 *   <li>跳到桌面（用户按了 Home）不算误跳，不回退；</li>
 *   <li>用户 0.9 秒内自己点过屏幕 —— 那是用户主动操作，绝不抢；</li>
 *   <li>同一波最多退 1 次，两次之间至少间隔 8 秒，避免和目标 App 拉锯；</li>
 *   <li>只记录包名，不读页面内容，不涉及任何敏感信息。</li>
 * </ul>
 */
public final class ClickOutcomeGuard {

    private static final long WINDOW_MS = 2_200L;
    private static final long COOLDOWN_MS = 8_000L;
    private static final long USER_CLICK_GRACE_MS = 900L;
    private static final int MAX_REVERTS = 1;

    private String packageName = "";
    private long armedAt = 0L;
    private long lastRevertAt = 0L;
    private int reverts = 0;

    /** 在"刚点了一个不确定的关闭目标"之后调用。 */
    public void arm(String pkg, long now) {
        if (pkg == null || pkg.isEmpty()) return;
        packageName = pkg;
        armedAt = now;
    }

    public boolean armed() { return armedAt > 0L; }

    public String armedPackage() { return packageName; }

    public void disarm() { armedAt = 0L; }

    public boolean shouldRevert(String newPackage, long now, long lastUserClickAt) {
        if (armedAt <= 0L || newPackage == null || newPackage.isEmpty()) return false;
        if (now - armedAt > WINDOW_MS) { armedAt = 0L; return false; }
        if (newPackage.equals(packageName)) return false;
        if (AdDecisionEngine.isLauncherPackage(newPackage)) return false;
        if (lastUserClickAt > 0L && now - lastUserClickAt <= USER_CLICK_GRACE_MS) {
            armedAt = 0L;
            return false;
        }
        if (reverts >= MAX_REVERTS && now - lastRevertAt < COOLDOWN_MS) {
            armedAt = 0L;
            return false;
        }
        reverts++;
        lastRevertAt = now;
        armedAt = 0L;
        return true;
    }
}
