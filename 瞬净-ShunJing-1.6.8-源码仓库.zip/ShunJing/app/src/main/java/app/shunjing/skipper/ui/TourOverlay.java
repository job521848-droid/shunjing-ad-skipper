package app.shunjing.skipper.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

import app.shunjing.skipper.R;
import app.shunjing.skipper.data.Prefs;

/**
 * 首页聚光灯导览（1.6.8）。
 *
 * <p>1.6.6 是"整页卡片讲六页"，像说明书；1.6.7 改成"指着控件讲"。
 * 1.6.8 把灯光本身做成了主角：
 *
 * <ul>
 *   <li>洞不是"跳"过去的，是被弹簧牵着滑过去的（中段轻微过冲再收住）；</li>
 *   <li>描边上有一道流光沿边框绕行，四角挂着 HUD 角标；</li>
 *   <li>换步时从洞的边缘炸出一圈冲击波和十几颗光尘，洞被重新"勾勒"一遍；</li>
 *   <li>开场时一条扫描带从屏幕顶扫到底，把整页"点亮"；</li>
 *   <li>洞与说明卡之间有三颗光点循环流动，像数据在传输；</li>
 *   <li>每步一声极轻的上行"嗒"+ 一次短触感，音高随进度升高。</li>
 * </ul>
 *
 * <p>这些效果全部由一条 30fps 的帧循环驱动，只在有洞时跑；系统开了「移除动画」
 * 则整层退化成静态描边，不闪不跳。
 *
 * <p>几条不动的底线：只高亮真实存在的控件（{@code GONE} 的整步跳过）、
 * 自动把目标滚进视野、点暗区/洞/下一步都能前进、返回键与「跳过」随时退出、
 * 点击不透传给首页控件（引导途中误触总开关会让后面的说明全对不上）。
 */
public final class TourOverlay extends FrameLayout {

    /** 关闭回调：看完、跳过、返回键都会调用，调用方据此落盘「已看过」。 */
    public interface Listener {
        void onClosed();
    }

    /** 压暗层：接近不透明，留一点底图让人知道"这还是刚才那个首页"。 */
    private static final int DIM_COLOR = 0xDE070C14;

    private final Context ctx;
    private final int accent;
    private final ScrollView scroll;
    private final Map<String, View> targets;
    private final Listener listener;
    private final Prefs prefs;

    private final List<TourScript.Step> steps = new ArrayList<>();

    private final SpotlightView spot;
    private final LinearLayout bubble;
    private final TextView tagView;
    private final TextView titleView;
    private final TextView bodyView;
    private final LinearLayout linesBox;
    private final TextView hintView;
    private final BoundedScrollView innerScroll;
    private final LinearLayout dots;
    private final Button prev;
    private final Button next;

    private int index;
    private boolean closing;
    private boolean rendered;

    private int bubbleWidth = -1;
    private boolean remeasure = true;
    private int followToken;
    private boolean holeSpring;

    public TourOverlay(Context context, int accent, ScrollView scroll,
                       Map<String, View> targets, Listener listener) {
        super(context);
        this.ctx = context;
        this.accent = accent;
        this.scroll = scroll;
        this.targets = targets;
        this.listener = listener;
        this.prefs = new Prefs(context);

        setClickable(true);

        // ---------------------------------------------------------------- 灯光层
        spot = new SpotlightView(context, accent);
        spot.setClickable(true);
        // 点空白处 = 下一步。比"必须精确点按钮"宽容，也不会误触到首页。
        spot.setOnClickListener(v -> advance());
        addView(spot, new LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ---------------------------------------------------------------- 说明卡
        bubble = new LinearLayout(context);
        bubble.setOrientation(LinearLayout.VERTICAL);
        bubble.setBackground(bubbleBackground());
        bubble.setElevation(dp(18));
        bubble.setClickable(true);
        bubble.setOnClickListener(v -> { });
        bubble.setAlpha(0f);
        addView(bubble, new LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout head = new LinearLayout(context);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        tagView = Ui.caption(context, "");
        head.addView(tagView, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView skip = Ui.text(context, "跳过", 13, context.getColor(R.color.text_secondary));
        skip.setPadding(dp(10), dp(6), 0, dp(6));
        skip.setOnClickListener(v -> close());
        head.addView(skip);
        bubble.addView(head);

        titleView = Ui.text(context, "", 19, context.getColor(R.color.text_primary));
        titleView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titleView.setPadding(0, dp(8), 0, 0);
        bubble.addView(titleView);

        bodyView = Ui.text(context, "", 13, context.getColor(R.color.text_secondary));
        bodyView.setPadding(0, dp(7), 0, 0);

        linesBox = new LinearLayout(context);
        linesBox.setOrientation(LinearLayout.VERTICAL);
        linesBox.setPadding(0, dp(4), 0, 0);

        hintView = Ui.text(context, "", 11.5f, context.getColor(R.color.text_secondary));
        GradientDrawable hintBg = new GradientDrawable();
        hintBg.setColor(alpha(accent, 18));
        hintBg.setCornerRadius(dp(10));
        hintView.setBackground(hintBg);
        hintView.setPadding(dp(11), dp(9), dp(11), dp(9));
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hintParams.topMargin = dp(12);

        // 正文装在带高度上限的容器里：小屏 + 大字号时正文自己滚，
        // 进度点和按钮永远留在屏幕上 —— 按钮被挤出屏幕等于引导走不下去。
        LinearLayout inner = new LinearLayout(context);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.addView(bodyView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        inner.addView(linesBox, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        inner.addView(hintView, hintParams);

        innerScroll = new BoundedScrollView(context);
        innerScroll.setVerticalScrollBarEnabled(false);
        innerScroll.setClipToPadding(false);
        innerScroll.addView(inner, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        bubble.addView(innerScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        dots = new LinearLayout(context);
        dots.setOrientation(LinearLayout.HORIZONTAL);
        dots.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams dotsParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dotsParams.topMargin = dp(14);
        bubble.addView(dots, dotsParams);

        LinearLayout actions = new LinearLayout(context);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams actionsParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        actionsParams.topMargin = dp(10);
        bubble.addView(actions, actionsParams);

        prev = Ui.secondary(context, "上一步");
        prev.setTextSize(13.5f);
        prev.setMinHeight(dp(44));
        prev.setOnClickListener(v -> {
            if (index > 0) render(index - 1, true);
        });
        LinearLayout.LayoutParams prevParams = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        prevParams.rightMargin = dp(8);
        actions.addView(prev, prevParams);

        next = Ui.primary(context, "下一步");
        next.setTextSize(13.5f);
        next.setMinHeight(dp(44));
        next.setOnClickListener(v -> advance());
        actions.addView(next, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1.5f));
    }

    // ---------------------------------------------------------------- 生命周期

    /**
     * 显示。
     *
     * <p>先把 {@code GONE} 的步骤过滤掉：未授权时首页没有「临时暂停」，
     * 没装完时也没有「去开启」——指着一块空白讲只会让人困惑。
     */
    public void show() {
        if (rendered) return;
        rendered = true;
        post(() -> {
            if (!isAttachedToWindow()) return;
            buildSteps();
            if (steps.isEmpty()) {
                close();
                return;
            }
            Feedback.tourOpen(ctx, prefs);
            spot.openScan();
            render(0, true);
            if (Motion.reduced(ctx)) {
                setAlpha(1f);
                bubble.setAlpha(1f);
                return;
            }
            setAlpha(0f);
            animate().alpha(1f).setDuration(Motion.duration(ctx, 220L)).start();
        });
    }

    /** 过滤出这一步真的有东西可以指。 */
    private void buildSteps() {
        steps.clear();
        for (TourScript.Step step : TourScript.steps()) {
            if (step.target == null || resolve(step.target) != null) steps.add(step);
        }
    }

    private View resolve(String key) {
        if (targets == null || key == null) return null;
        View view = targets.get(key);
        if (view == null || !view.isShown()) return null;
        return view.getWidth() > 0 && view.getHeight() > 0 ? view : null;
    }

    private View targetOf(int stepIndex) {
        if (stepIndex < 0 || stepIndex >= steps.size()) return null;
        return resolve(steps.get(stepIndex).target);
    }

    public boolean isClosing() {
        return closing;
    }

    /** 返回键也走这里：先淡出，再从父容器摘掉。 */
    public void close() {
        if (closing) return;
        closing = true;
        animate().cancel();
        bubble.animate().cancel();
        next.animate().cancel();
        spot.stop();
        if (Motion.reduced(ctx)) {
            detach();
            return;
        }
        animate().alpha(0f)
                .setDuration(Motion.duration(ctx, 180L))
                .withEndAction(this::detach)
                .start();
    }

    private void detach() {
        ViewParent parent = getParent();
        if (parent instanceof ViewGroup) ((ViewGroup) parent).removeView(this);
        if (listener != null) listener.onClosed();
    }

    private void advance() {
        if (closing) return;
        if (index >= steps.size() - 1) close();
        else render(index + 1, true);
    }

    // ---------------------------------------------------------------- 渲染

    private void render(int to, boolean animate) {
        index = to;
        TourScript.Step step = steps.get(index);

        tagView.setText(String.format(Locale.US, "%02d / %02d · %s",
                index + 1, steps.size(), step.tag));
        titleView.setText(step.title);
        bodyView.setText(step.body);

        linesBox.removeAllViews();
        for (String line : step.lines) linesBox.addView(lineRow(line));
        linesBox.setVisibility(step.lines.isEmpty() ? View.GONE : View.VISIBLE);

        boolean hasHint = step.hint != null && !step.hint.isEmpty();
        hintView.setText(hasHint ? step.hint : "");
        hintView.setVisibility(hasHint ? View.VISIBLE : View.GONE);

        prev.setVisibility(index == 0 ? View.GONE : View.VISIBLE);
        next.setText(index == steps.size() - 1 ? "知道了" : "下一步");
        updateDots();

        remeasure = true;
        if (to > 0) {
            // 声音和触感都在 Feedback 里，受「音效 / 触感」两个开关控制；
            // 这里再调一次系统触感会和它叠成双击。
            Feedback.tourStep(ctx, prefs, index, steps.size());
        }

        post(() -> {
            if (!isAttachedToWindow()) return;
            // 需要滚动时不播弹簧：让滚动本身带着洞走，人眼才不会看到两段运动。
            boolean scrolled = scrollToTarget();
            holeSpring = !scrolled;
            layoutBubble(animate);
            if (scrolled) followScroll();
            if (animate) {
                popBubble();
                staggerIn(titleView, 0);
                staggerIn(bodyView, 45);
                staggerIn(hintView, 90);
                pulseNext();
            } else {
                bubble.setAlpha(1f);
                bubble.setScaleX(1f);
                bubble.setScaleY(1f);
            }
        });
    }

    /**
     * 把目标滚进视野。
     *
     * <p>竖屏首页比一屏长，目标可能在下面。滚动的落点不是"刚好露出来"，而是
     * 可视区 62% 处 —— 上方留出的空白刚好够放气泡，不用把气泡压在洞上。
     *
     * @return 是否真的产生了滚动（有滚动时洞跟着走，不再单独播位移动画）
     */
    private boolean scrollToTarget() {
        View target = targetOf(index);
        if (target == null || scroll == null) return false;
        int viewHeight = scroll.getHeight();
        if (viewHeight <= 0) return false;

        int[] scrollLoc = new int[2];
        int[] targetLoc = new int[2];
        scroll.getLocationInWindow(scrollLoc);
        target.getLocationInWindow(targetLoc);

        int pad = dp(18);
        int usable = viewHeight - pad * 2;
        int height = target.getHeight();
        int wantTop = height > usable * 0.72f
                ? scrollLoc[1] + pad
                : scrollLoc[1] + pad + (int) (usable * 0.62f) - height / 2;

        int delta = targetLoc[1] - wantTop;
        if (Math.abs(delta) < dp(6)) return false;
        scroll.smoothScrollTo(0, Math.max(0, scroll.getScrollY() + delta));
        return true;
    }

    /**
     * 短时跟随：smoothScroll 是异步的，滚动过程中目标每帧都在动。
     * 用 800ms 的逐帧重排代替滚动监听 —— 不抢 ScrollView 的回调，也不会和别处冲突。
     */
    private void followScroll() {
        final int token = ++followToken;
        final long end = SystemClock.uptimeMillis() + 800L;
        postOnAnimation(new Runnable() {
            @Override public void run() {
                // 连点「下一步」时上一轮跟随会作废，避免两个循环同时改位置。
                if (closing || token != followToken || !isAttachedToWindow()) return;
                layoutBubble(false);
                if (SystemClock.uptimeMillis() < end) postOnAnimation(this);
            }
        });
    }

    // ---------------------------------------------------------------- 定位

    /** 当前步骤要高亮的矩形（overlay 坐标）。目标不可见时返回 null，此时整页压暗。 */
    private RectF holeRect() {
        View target = targetOf(index);
        if (target == null) return null;

        int[] targetLoc = new int[2];
        int[] baseLoc = new int[2];
        target.getLocationInWindow(targetLoc);
        getLocationInWindow(baseLoc);

        float pad = dp(6);
        float left = targetLoc[0] - baseLoc[0] - pad;
        float top = targetLoc[1] - baseLoc[1] - pad;
        RectF rect = new RectF(left, top,
                left + target.getWidth() + pad * 2,
                top + target.getHeight() + pad * 2);

        // 裁到可视区：目标被 ScrollView 截掉一半时，洞不能画到状态栏或屏幕外。
        rect.left = Math.max(dp(2), rect.left);
        rect.right = Math.min(getWidth() - dp(2), rect.right);
        rect.top = Math.max(dp(2), rect.top);
        rect.bottom = Math.min(getHeight() - dp(2), rect.bottom);

        if (rect.width() < dp(24) || rect.height() < dp(24)) return null;
        return rect;
    }

    private void layoutBubble(boolean animate) {
        int width = getWidth();
        int height = getHeight();
        if (width <= 0 || height <= 0) return;

        int wantWidth = Math.min(width - dp(40), dp(520));
        if (wantWidth != bubbleWidth) {
            bubbleWidth = wantWidth;
            remeasure = true;
            FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) bubble.getLayoutParams();
            params.width = wantWidth;
            params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            params.leftMargin = (width - wantWidth) / 2;
            params.topMargin = 0;
            bubble.setLayoutParams(params);
        }
        if (remeasure || bubble.getMeasuredHeight() == 0) {
            innerScroll.setMaxHeight(Math.max(dp(120), (int) (height * 0.40f)));
            bubble.measure(MeasureSpec.makeMeasureSpec(wantWidth, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
            remeasure = false;
        }
        int bubbleHeight = bubble.getMeasuredHeight();

        RectF hole = holeRect();
        float top;
        if (hole == null) {
            // 没有具体控件：整页压暗，卡片居中。
            top = Math.max(dp(20), (height - bubbleHeight) / 2f);
        } else {
            float gap = dp(16);
            // 用"放下之后还剩多少空"来判断，而不是"能不能放下"：
            // 刚好能塞下会贴着状态栏，看起来像页面出了问题。
            float aboveRoom = hole.top - dp(12) - bubbleHeight - gap;
            float belowRoom = height - dp(12) - hole.bottom - gap - bubbleHeight;
            float prefer = dp(10);
            if (aboveRoom >= prefer && aboveRoom >= belowRoom) {
                top = hole.top - gap - bubbleHeight;
            } else if (belowRoom >= prefer) {
                top = hole.bottom + gap;
            } else if (aboveRoom > belowRoom) {
                top = Math.max(dp(10), hole.top - gap - bubbleHeight);
            } else {
                top = Math.min(height - dp(12) - bubbleHeight, hole.bottom + gap);
            }
        }

        if (animate && !Motion.reduced(ctx)) {
            bubble.animate().cancel();
            bubble.animate().translationY(top)
                    .setDuration(Motion.duration(ctx, 320L))
                    .setInterpolator(new DecelerateInterpolator(1.4f))
                    .start();
        } else {
            bubble.setTranslationY(top);
        }

        spot.moveTo(hole, animate && holeSpring);
        int left = (width - wantWidth) / 2;
        spot.setBubble(new RectF(left, top, left + wantWidth, top + bubbleHeight));
    }

    /**
     * 说明卡弹入：轻微缩一下再撑开，配合洞一起"翻页"。
     *
     * <p>刻意用三个独立的 ObjectAnimator 而不是 {@code bubble.animate()}：
     * ViewPropertyAnimator 是同一个实例，改 scale 会顺手掐掉正在跑的 translationY，
     * 卡片就会在换步时"啪"地跳一下。
     */
    private void popBubble() {
        if (Motion.reduced(ctx)) {
            bubble.setAlpha(1f);
            bubble.setScaleX(1f);
            bubble.setScaleY(1f);
            return;
        }
        bubble.setAlpha(0f);
        bubble.setScaleX(0.945f);
        bubble.setScaleY(0.945f);
        long duration = Motion.duration(ctx, 340L);
        android.animation.TimeInterpolator spring = new OvershootInterpolator(1.25f);
        android.animation.ObjectAnimator sx =
                android.animation.ObjectAnimator.ofFloat(bubble, "scaleX", 0.945f, 1f);
        android.animation.ObjectAnimator sy =
                android.animation.ObjectAnimator.ofFloat(bubble, "scaleY", 0.945f, 1f);
        android.animation.ObjectAnimator fade =
                android.animation.ObjectAnimator.ofFloat(bubble, "alpha", 0f, 1f);
        for (android.animation.ObjectAnimator anim :
                new android.animation.ObjectAnimator[]{sx, sy, fade}) {
            anim.setDuration(duration);
            anim.setInterpolator(spring);
            anim.start();
        }
    }

    /** 文案逐段上浮，像被一条一条写上去，而不是整块替换。 */
    private void staggerIn(View view, long delay) {
        if (view == null) return;
        if (Motion.reduced(ctx)) {
            view.setAlpha(1f);
            view.setTranslationY(0f);
            return;
        }
        view.animate().cancel();
        view.setAlpha(0f);
        view.setTranslationY(dp(7));
        view.animate().alpha(1f).translationY(0f)
                .setStartDelay(Motion.duration(ctx, delay))
                .setDuration(Motion.duration(ctx, 220L))
                .setInterpolator(new DecelerateInterpolator(1.7f))
                .start();
    }

    /** 主按钮闲着时会轻轻顶一下，提示"下一步在这儿"。 */
    private void pulseNext() {
        if (Motion.reduced(ctx)) return;
        next.animate().cancel();
        next.setScaleX(1f);
        next.setScaleY(1f);
        next.animate().scaleX(1.035f).scaleY(1.035f)
                .setStartDelay(520L)
                .setDuration(200L)
                .setInterpolator(new DecelerateInterpolator(1.6f))
                .withEndAction(() -> next.animate().scaleX(1f).scaleY(1f)
                        .setDuration(240L).start())
                .start();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        bubbleWidth = -1;
        remeasure = true;
        if (rendered) post(() -> layoutBubble(false));
    }

    // ---------------------------------------------------------------- 小部件

    private GradientDrawable bubbleBackground() {
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF1A2A42, 0xFF13203A});
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), alpha(accent, 140));
        return bg;
    }

    private View lineRow(String line) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);

        View dot = new View(ctx);
        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.OVAL);
        shape.setColor(alpha(accent, 180));
        dot.setBackground(shape);
        LinearLayout.LayoutParams dotParams = new LinearLayout.LayoutParams(dp(5), dp(5));
        dotParams.topMargin = dp(7);
        dotParams.rightMargin = dp(9);
        row.addView(dot, dotParams);

        TextView text = Ui.text(ctx, line, 12.5f, ctx.getColor(R.color.text_secondary));
        row.addView(text, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.topMargin = dp(9);
        row.setLayoutParams(params);
        return row;
    }

    private void updateDots() {
        dots.removeAllViews();
        for (int i = 0; i < steps.size(); i++) {
            View dot = new View(ctx);
            boolean active = i == index;
            GradientDrawable shape = new GradientDrawable();
            shape.setCornerRadius(dp(3));
            shape.setColor(active ? accent : alpha(ctx.getColor(R.color.text_secondary), 70));
            dot.setBackground(shape);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    dp(active ? 15 : 6), dp(6));
            params.rightMargin = dp(5);
            dots.addView(dot, params);
        }
    }

    // ---------------------------------------------------------------- 灯光

    /**
     * 压暗层 + 聚光灯。
     *
     * <p>压暗用一条 EVEN_ODD 的 Path（整屏矩形 + 圆角洞）一次画完，而不是 CLEAR 混合模式：
     * 后者要求软件绘制层，全屏重绘会掉帧；Path 方式在硬件加速下正常，描边也能直接叠加。
     *
     * <p>所有动效由一条自驱帧循环推进（约 30fps，够顺滑又省电）：呼吸、流光相位、
     * 洞的弹簧位移、冲击波、光尘、开场扫描。没有洞时循环自动停。
     */
    private static final class SpotlightView extends View {

        private final Paint dimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint trailPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint cornerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint shockPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint dustPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint innerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint linkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint scanPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint scanLinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        private final Path path = new Path();
        private final Path borderPath = new Path();
        private final PathMeasure measure = new PathMeasure();
        private final RectF hole = new RectF();
        private final RectF fromRect = new RectF();
        private final RectF toRect = new RectF();
        private final RectF bubble = new RectF();
        private final RectF tmp = new RectF();
        private final RectF glowRect = new RectF();
        private final float[] pos = new float[2];
        private final List<Dust> dust = new ArrayList<>();

        private final int accent;
        private final float radius;
        private final float density;
        private final boolean calm;

        private boolean hasHole;
        private boolean hasBubble;
        private boolean moving;
        private long moveStart;
        private float moveT = 1f;
        private float pulse = 1f;
        private float holo;
        private float shockT = 1f;
        private float scanT = 1f;
        private long lastFrame;
        private long lastDraw;
        private boolean ticking;
        private LinearGradient scanShader;
        private android.graphics.RadialGradient spotShader;
        private final Matrix scanMatrix = new Matrix();

        SpotlightView(Context context, int accent) {
            super(context);
            this.accent = accent;
            density = context.getResources().getDisplayMetrics().density;
            radius = dp(16);
            calm = Motion.reduced(context);

            dimPaint.setColor(DIM_COLOR);
            fillPaint.setColor(alpha(accent, 12));
            ringPaint.setStyle(Paint.Style.STROKE);
            ringPaint.setStrokeWidth(dp(2));
            ringPaint.setColor(alpha(accent, 235));
            ringPaint.setStrokeJoin(Paint.Join.ROUND);
            glowPaint.setStyle(Paint.Style.STROKE);
            glowPaint.setColor(accent);
            trailPaint.setColor(Color.WHITE);
            cornerPaint.setStyle(Paint.Style.STROKE);
            cornerPaint.setStrokeWidth(dp(2.6f));
            cornerPaint.setStrokeCap(Paint.Cap.SQUARE);
            cornerPaint.setColor(accent);
            shockPaint.setStyle(Paint.Style.STROKE);
            shockPaint.setColor(accent);
            dustPaint.setColor(accent);
            linkPaint.setColor(accent);
            linkPaint.setStrokeWidth(dp(1.4f));
            linkPaint.setStrokeCap(Paint.Cap.ROUND);
            scanPaint.setStyle(Paint.Style.FILL);
            scanLinePaint.setStyle(Paint.Style.FILL);
            scanLinePaint.setColor(alpha(accent, 150));
            innerPaint.setStyle(Paint.Style.STROKE);
            innerPaint.setStrokeWidth(dp(1.2f));
            innerPaint.setColor(0x42FFFFFF);
        }

        // ------------------------------------------------------------ 外部接口

        /**
         * 把洞移到新位置。spring=true 时用弹簧插值滑过去（中段轻微过冲），
         * false 时直接落位（滚动跟随用，避免和滚动本身叠成两段运动）。
         */
        void moveTo(RectF rect, boolean spring) {
            if (rect == null) {
                if (!hasHole) return;
                hasHole = false;
                moving = false;
                invalidate();
                return;
            }
            if (!hasHole) {
                hasHole = true;
                if (calm) {
                    hole.set(rect);
                    fromRect.set(rect);
                } else {
                    // 第一次出现：从目标中心的一个小点张开，像聚光灯被推开。
                    float cx = rect.centerX();
                    float cy = rect.centerY();
                    float half = Math.min(rect.width(), rect.height()) * 0.12f;
                    fromRect.set(cx - half, cy - half, cx + half, cy + half);
                    hole.set(fromRect);
                    toRect.set(rect);
                    moveStart = SystemClock.uptimeMillis();
                    moveT = 0f;
                    moving = true;
                }
                burst(rect);
                kick();
                return;
            }
            if (hole.equals(rect)) return;

            if (!spring || calm) {
                hole.set(rect);
                fromRect.set(rect);
                moving = false;
                invalidate();
                kick();
                return;
            }
            fromRect.set(hole);
            toRect.set(rect);
            moveStart = SystemClock.uptimeMillis();
            moveT = 0f;
            moving = true;
            burst(rect);
            kick();
        }

        void setBubble(RectF rect) {
            if (rect == null) {
                if (!hasBubble) return;
                hasBubble = false;
                invalidate();
                return;
            }
            if (hasBubble && bubble.equals(rect)) return;
            hasBubble = true;
            bubble.set(rect);
            invalidate();
        }

        /** 开场扫描：一条光带从上到下走一遍，把页面"点亮"。 */
        void openScan() {
            if (calm) return;
            scanT = 0f;
            kick();
        }

        void stop() {
            ticking = false;
            removeCallbacks(frame);
        }

        // ------------------------------------------------------------ 帧循环

        private void kick() {
            // 静态模式只需要画一次，开了循环反而白白重绘整屏。
            if (calm) {
                invalidate();
                return;
            }
            if (ticking) return;
            ticking = true;
            lastFrame = 0L;
            lastDraw = 0L;
            postOnAnimation(frame);
        }

        private final Runnable frame = new Runnable() {
            @Override public void run() {
                if (!ticking || !isAttachedToWindow()) {
                    ticking = false;
                    return;
                }
                boolean busy = hasHole || shockT < 1f || scanT < 1f;
                if (!busy) {
                    ticking = false;
                    return;
                }
                long now = SystemClock.uptimeMillis();
                float dt = lastFrame == 0L ? 0.016f
                        : Math.min(0.05f, (now - lastFrame) / 1000f);
                lastFrame = now;

                // 限到约 30fps：流光和呼吸在这个频率下已经够顺，重绘少一半。
                if (now - lastDraw < 28L) {
                    postOnAnimation(this);
                    return;
                }
                lastDraw = now;

                if (!calm) {
                    holo = (holo + dt * 0.42f) % 1f;
                    pulse = 0.5f + 0.5f * (float) Math.sin(now / 1000.0 * 2.4);
                } else {
                    pulse = 1f;
                }

                if (moving) {
                    moveT = Math.min(1f, (now - moveStart) / 360f);
                    float k = Motion.spring(moveT);
                    hole.set(
                            fromRect.left + (toRect.left - fromRect.left) * k,
                            fromRect.top + (toRect.top - fromRect.top) * k,
                            fromRect.right + (toRect.right - fromRect.right) * k,
                            fromRect.bottom + (toRect.bottom - fromRect.bottom) * k);
                    if (moveT >= 1f) moving = false;
                }
                if (shockT < 1f) shockT = Math.min(1f, shockT + dt / 0.52f);
                if (scanT < 1f) scanT = Math.min(1f, scanT + dt / 0.95f);
                for (int i = dust.size() - 1; i >= 0; i--) {
                    Dust d = dust.get(i);
                    d.t += dt / 0.62f;
                    if (d.t >= 1f) dust.remove(i);
                }

                invalidate();
                postOnAnimation(this);
            }
        };

        /** 换步时炸开：一圈冲击波 + 十几颗沿法线飞出的光尘。 */
        private void burst(RectF rect) {
            if (calm) return;
            shockT = 0f;
            dust.clear();
            Random random = new Random(System.nanoTime());
            int count = 12;
            for (int i = 0; i < count; i++) {
                float x;
                float y;
                int side = i % 4;
                if (side == 0) {
                    x = rect.left + random.nextFloat() * rect.width();
                    y = rect.top;
                } else if (side == 1) {
                    x = rect.right;
                    y = rect.top + random.nextFloat() * rect.height();
                } else if (side == 2) {
                    x = rect.left + random.nextFloat() * rect.width();
                    y = rect.bottom;
                } else {
                    x = rect.left;
                    y = rect.top + random.nextFloat() * rect.height();
                }
                float nx = x - rect.centerX();
                float ny = y - rect.centerY();
                float len = (float) Math.hypot(nx, ny);
                if (len < 1f) len = 1f;
                float dist = dp(34) + random.nextFloat() * dp(66);
                Dust d = new Dust();
                d.x = x;
                d.y = y;
                d.dx = nx / len * dist;
                d.dy = ny / len * dist;
                d.r = dp(1.1f) + random.nextFloat() * dp(1.9f);
                d.t = random.nextFloat() * 0.12f;
                dust.add(d);
            }
        }

        private static final class Dust {
            float x, y, dx, dy, r, t;
        }

        // ------------------------------------------------------------ 绘制

        @Override
        protected void onDraw(Canvas canvas) {
            int w = getWidth();
            int h = getHeight();

            path.reset();
            path.setFillType(Path.FillType.EVEN_ODD);
            path.addRect(0, 0, w, h, Path.Direction.CW);
            if (hasHole) path.addRoundRect(hole, radius, radius, Path.Direction.CW);
            canvas.drawPath(path, dimPaint);

            if (!hasHole) {
                drawScan(canvas, w, h);
                return;
            }

            drawGlow(canvas);
            drawCorners(canvas);
            if (!calm) {
                drawFlow(canvas);
                drawShock(canvas);
                drawDust(canvas);
            }
            drawLink(canvas);
            drawScan(canvas, w, h);
        }

        /** 洞内的聚光提亮 + 内侧玻璃高光 + 外发光 + 主描边。 */
        private void drawGlow(Canvas canvas) {
            // 洞内用径向渐变：中心亮、边缘淡，看起来是"光打进来"，而不是"罩了层色"。
            if (spotShader == null || !glowRect.equals(hole)) {
                glowRect.set(hole);
                float reach = Math.max(hole.width(), hole.height()) * 0.62f;
                if (reach < dp(1)) reach = dp(1);
                spotShader = new android.graphics.RadialGradient(
                        hole.centerX(), hole.centerY(), reach,
                        new int[]{alpha(accent, 30), alpha(accent, 6)},
                        new float[]{0f, 1f}, Shader.TileMode.CLAMP);
                fillPaint.setShader(spotShader);
            }
            canvas.drawRoundRect(hole, radius, radius, fillPaint);

            // 边框内侧一线白：像玻璃边缘的反光，一下就把"洞"的立体感提起来。
            tmp.set(hole);
            tmp.inset(dp(1.4f), dp(1.4f));
            canvas.drawRoundRect(tmp, Math.max(0f, radius - dp(1.4f)),
                    Math.max(0f, radius - dp(1.4f)), innerPaint);

            for (int i = 3; i >= 1; i--) {
                float grow = dp(4f) * i;
                tmp.set(hole);
                tmp.inset(-grow, -grow);
                glowPaint.setStrokeWidth(dp(1.6f) * i);
                glowPaint.setAlpha((int) (12 + 16 * pulse) / i + 8);
                canvas.drawRoundRect(tmp, radius + grow, radius + grow, glowPaint);
            }

            ringPaint.setAlpha((int) (165 + 90 * pulse));
            canvas.drawRoundRect(hole, radius, radius, ringPaint);
        }

        /** 四角的 HUD 角标：比描边更亮一档，把"这是一个被锁定的区域"说清楚。 */
        private void drawCorners(Canvas canvas) {
            float len = Math.min(dp(17), Math.min(hole.width(), hole.height()) * 0.26f);
            if (len < dp(6)) return;
            float off = dp(2.5f);
            cornerPaint.setAlpha(215);

            float l = hole.left - off;
            float t = hole.top - off;
            float r = hole.right + off;
            float b = hole.bottom + off;

            // 左上
            canvas.drawLine(l, t, l + len, t, cornerPaint);
            canvas.drawLine(l, t, l, t + len, cornerPaint);
            // 右上
            canvas.drawLine(r, t, r - len, t, cornerPaint);
            canvas.drawLine(r, t, r, t + len, cornerPaint);
            // 左下
            canvas.drawLine(l, b, l + len, b, cornerPaint);
            canvas.drawLine(l, b, l, b - len, cornerPaint);
            // 右下
            canvas.drawLine(r, b, r - len, b, cornerPaint);
            canvas.drawLine(r, b, r, b - len, cornerPaint);
        }

        /**
         * 沿边框绕行的流光：用 PathMeasure 在圆角矩形路径上取 18 个点，
         * 越靠后越暗越小，连起来就是一条彗星尾巴。
         */
        private void drawFlow(Canvas canvas) {
            borderPath.reset();
            borderPath.addRoundRect(hole, radius, radius, Path.Direction.CW);
            measure.setPath(borderPath, false);
            float length = measure.getLength();
            if (length <= 0f) return;

            final int segments = 18;
            for (int i = 0; i < segments; i++) {
                float backward = i * length * 0.014f;
                float distance = (holo * length - backward) % length;
                if (distance < 0f) distance += length;
                if (!measure.getPosTan(distance, pos, null)) continue;

                float fade = 1f - (float) i / segments;
                fade = fade * fade;
                trailPaint.setAlpha((int) (235 * fade));
                trailPaint.setColor(i < 3 ? Color.WHITE : accent);
                canvas.drawCircle(pos[0], pos[1], dp(2.1f) * (0.35f + 0.65f * fade), trailPaint);
            }
        }

        /** 换步冲击波：两圈从洞的边缘向外扩散，越远越淡。 */
        private void drawShock(Canvas canvas) {
            for (int ring = 0; ring < 2; ring++) {
                float progress = shockT - ring * 0.16f;
                if (progress <= 0f || progress >= 1f) continue;
                float k = Motion.easeOutCubic(progress);
                float grow = dp(4) + dp(46) * k;
                tmp.set(hole);
                tmp.inset(-grow, -grow);
                shockPaint.setStrokeWidth(dp(2.2f) * (1f - k * 0.55f));
                shockPaint.setAlpha((int) (120 * (1f - progress)));
                canvas.drawRoundRect(tmp, radius + grow, radius + grow, shockPaint);
            }
        }

        /** 光尘：沿法线飞出、边飞边淡，像被灯光弹开的碎屑。 */
        private void drawDust(Canvas canvas) {
            for (Dust d : dust) {
                float k = Motion.easeOutCubic(d.t);
                float x = d.x + d.dx * k;
                float y = d.y + d.dy * k;
                float fade = 1f - d.t;
                dustPaint.setAlpha((int) (210 * fade * fade));
                dustPaint.setColor(d.t < 0.35f ? Color.WHITE : accent);
                canvas.drawCircle(x, y, d.r * (0.4f + 0.6f * fade), dustPaint);
            }
        }

        /** 洞与说明卡之间循环流动的三颗光点，像数据在传输。 */
        private void drawLink(Canvas canvas) {
            if (!hasBubble || RectF.intersects(hole, bubble)) return;
            float cx = hole.centerX();
            float fromY;
            float toY;
            if (bubble.top > hole.bottom) {
                fromY = hole.bottom;
                toY = bubble.top;
            } else {
                fromY = hole.top;
                toY = bubble.bottom;
            }
            if (Math.abs(toY - fromY) < dp(8)) return;

            linkPaint.setAlpha(46);
            canvas.drawLine(cx, fromY, cx, toY, linkPaint);

            for (int i = 0; i < 3; i++) {
                float t = ((holo * 1.6f) + i / 3f) % 1f;
                float y = fromY + (toY - fromY) * t;
                float alpha = (float) Math.sin(t * Math.PI);
                linkPaint.setAlpha((int) (200 * alpha));
                canvas.drawCircle(cx, y, dp(2.2f), linkPaint);
            }
        }

        /** 开场扫描带：一条横向亮线，后面拖着一段渐隐的光。 */
        private void drawScan(Canvas canvas, int w, int h) {
            if (calm || scanT >= 1f) return;
            float travel = h + dp(260);
            float y = -dp(130) + travel * Motion.easeOutCubic(scanT);
            if (scanShader == null) {
                scanShader = new LinearGradient(0f, 0f, 0f, dp(150),
                        new int[]{0, alpha(accent, 40), alpha(accent, 120)},
                        new float[]{0f, 0.72f, 1f}, Shader.TileMode.CLAMP);
            }
            scanPaint.setShader(scanShader);
            scanMatrix.setTranslate(0f, y - dp(150));
            scanShader.setLocalMatrix(scanMatrix);
            canvas.drawRect(0f, y - dp(150), w, y, scanPaint);
            scanPaint.setShader(null);

            scanLinePaint.setAlpha((int) (150 * (1f - scanT)));
            canvas.drawRect(0f, y - dp(1), w, y + dp(1), scanLinePaint);
        }

        private float dp(float value) {
            return value * density;
        }

        private static int alpha(int color, int value) {
            return Color.argb(value, Color.red(color), Color.green(color), Color.blue(color));
        }
    }

    // ---------------------------------------------------------------- 小工具

    private int dp(float value) { return Ui.dp(ctx, value); }

    private static int alpha(int color, int value) {
        return Color.argb(value, Color.red(color), Color.green(color), Color.blue(color));
    }

    /**
     * 带高度上限的 ScrollView。
     *
     * <p>原生 ScrollView 没有 maxHeight：放进 wrap_content 的气泡里，要么把气泡撑出屏幕，
     * 要么被压成 0。这里只改一件事 —— 量高度时把上限传成 AT_MOST，
     * 内容短时按内容高度、内容长时按上限，多出来的自己滚。
     */
    private static final class BoundedScrollView extends ScrollView {
        private int maxHeight = Integer.MAX_VALUE;

        BoundedScrollView(Context context) {
            super(context);
        }

        void setMaxHeight(int value) {
            if (maxHeight == value) return;
            maxHeight = value;
            requestLayout();
        }

        @Override
        protected void onMeasure(int widthSpec, int heightSpec) {
            if (maxHeight != Integer.MAX_VALUE && maxHeight > 0) {
                heightSpec = MeasureSpec.makeMeasureSpec(maxHeight, MeasureSpec.AT_MOST);
            }
            super.onMeasure(widthSpec, heightSpec);
        }
    }
}
