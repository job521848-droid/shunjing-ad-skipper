package app.shunjing.skipper.engine;

import java.util.Locale;

/**
 * 摇一摇 / 扭一扭广告的「误跳转回退」判定 v1.6。
 *
 * <p>为什么需要它：这类广告的跳转由传感器触发，发生在两次扫描之间。等我们发现"页面变了"，
 * 广告页早已被目标 App 覆盖，任何关闭按钮都点不到了。唯一可行的补救是<b>立刻退回去</b>，
 * 让本地引擎重新看到广告页，再按正常规则处理。
 *
 * <p>旧版只判断"窗口包名变化 + 1.6 秒内"，两个漏洞：
 * <ul>
 *   <li>延迟跳转 —— 传感器触发后 2~3 秒才切页面，旧窗口早就过期；</li>
 *   <li>同包落地页 —— 很多 SDK 跳到本 App 的 H5 Activity，包名根本没变。</li>
 * </ul>
 *
 * <p>安全边界（任何一条不满足都不回退）：
 * <ul>
 *   <li>只有"刚刚在广告页看见摇一摇文案"才进入待命，最长 8 秒；</li>
 *   <li>用户 0.9 秒内主动点过屏幕 —— 那是用户自己的操作，绝不抢；</li>
 *   <li>同包只认"落地页长相"的 Activity（web / h5 / landing / browser / detail / ad），
 *       正常页面切换不动；</li>
 *   <li>同一波广告最多回退 2 次，两次之间至少间隔 20 秒，防止和目标 App 来回拉锯。</li>
 * </ul>
 */
public final class ShakeJumpGuard {

    public enum Result {
        NONE,
        /** 跳到了别的 App（浏览器 / 应用商店 / 第三方 App）。 */
        CROSS_APP,
        /** 还在同一个 App，但换成了 H5 落地页。 */
        SAME_APP_LANDING
    }

    private static final long WINDOW_MS = 8_000L;
    private static final long USER_CLICK_GRACE_MS = 900L;
    private static final int MAX_REVERTS = 2;
    private static final long REVERT_COOLDOWN_MS = 20_000L;

    private static final String[] LANDING_ACTIVITY_HINTS = {
            "webview", "webactivity", "h5", "landing", "browser", "detail", "adactivity",
            "interstitial", "openurl", "deeplink", "scheme"
    };

    private String packageName = "";
    private String activityName = "";
    private String fingerprint = "";
    private long armedAt = 0L;
    private int reverts = 0;
    private long lastRevertAt = 0L;

    /** 在"确认出现摇一摇广告"的页面调用；每次扫描都会刷新待命时间。 */
    public void arm(ScreenModel screen, String pageFingerprint, long now) {
        if (screen == null) return;
        packageName = screen.packageName;
        activityName = screen.activityName;
        fingerprint = pageFingerprint == null ? "" : pageFingerprint;
        armedAt = now;
    }

    public boolean armed() { return armedAt > 0L; }

    public String armedPackage() { return packageName; }

    public void disarm() { armedAt = 0L; }

    /** 窗口过期或被消耗后自动关闭待命。 */
    private void expireIfNeeded(long now) {
        if (armedAt > 0L && now - armedAt > WINDOW_MS) armedAt = 0L;
    }

    /**
     * 窗口包名发生变化时的快速判定（事件驱动，延迟最低）。
     *
     * @param currentPackage 新前台包名
     * @param lastUserClickAt 最近一次用户真实点击的时刻，0 表示未记录
     */
    public Result checkCrossApp(String currentPackage, long now, long lastUserClickAt) {
        expireIfNeeded(now);
        if (armedAt <= 0L || currentPackage == null || currentPackage.isEmpty()) return Result.NONE;
        if (currentPackage.equals(packageName)) return Result.NONE;
        if (userActed(now, lastUserClickAt)) return Result.NONE;
        if (!canRevert(now)) { disarm(); return Result.NONE; }
        consume(now);
        return Result.CROSS_APP;
    }

    /**
     * 扫描时的判定：能拿到新页面指纹，因此可以区分"同包换了落地页"和"同包正常切页"。
     */
    public Result checkSamePageChange(String currentPackage, String currentActivity,
                                      String currentFingerprint, long now, long lastUserClickAt) {
        expireIfNeeded(now);
        if (armedAt <= 0L) return Result.NONE;
        String pkg = currentPackage == null ? "" : currentPackage;
        String activity = currentActivity == null ? "" : currentActivity;
        String fp = currentFingerprint == null ? "" : currentFingerprint;
        if (!pkg.equals(packageName)) {
            if (userActed(now, lastUserClickAt)) return Result.NONE;
            if (!canRevert(now)) { disarm(); return Result.NONE; }
            consume(now);
            return Result.CROSS_APP;
        }
        if (fp.equals(fingerprint)) return Result.NONE;
        if (activity.equals(activityName)) return Result.NONE;
        if (!looksLikeLanding(activity)) return Result.NONE;
        if (userActed(now, lastUserClickAt)) return Result.NONE;
        if (!canRevert(now)) { disarm(); return Result.NONE; }
        consume(now);
        return Result.SAME_APP_LANDING;
    }

    private boolean userActed(long now, long lastUserClickAt) {
        if (lastUserClickAt <= 0L) return false;
        if (now - lastUserClickAt <= USER_CLICK_GRACE_MS) {
            // 用户自己在操作，别抢他的屏幕。
            disarm();
            return true;
        }
        return false;
    }

    private boolean canRevert(long now) {
        if (reverts < MAX_REVERTS) return true;
        return now - lastRevertAt >= REVERT_COOLDOWN_MS;
    }

    private void consume(long now) {
        reverts++;
        lastRevertAt = now;
        disarm();
    }

    private static boolean looksLikeLanding(String activity) {
        String value = activity.toLowerCase(Locale.ROOT);
        for (String hint : LANDING_ACTIVITY_HINTS) {
            if (value.contains(hint)) return true;
        }
        return false;
    }
}
