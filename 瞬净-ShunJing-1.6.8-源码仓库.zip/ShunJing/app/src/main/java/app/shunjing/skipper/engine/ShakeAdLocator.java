package app.shunjing.skipper.engine;

import java.util.Locale;

/**
 * 「摇一摇 / 扭一扭」互动广告页的关闭按钮定位。
 *
 * <p>为什么单独一类：这类页面本身就是广告落地页，整屏由 SDK 自绘，关闭按钮几乎总是
 * 一枚贴在屏幕角落、没有文字、没有 id、甚至不可点击的纯图片 ImageView。文字规则打不中，
 * 叠层定位只找"居中卡片右上角"，布局锚点又要求节点可点击——三条路全断。
 *
 * <p>安全边界（全部为硬条件）：
 * <ul>
 *   <li>必须同时命中"摇一摇/扭一扭/摇动手机/转动手机" + "跳转/打开/详情/第三方/广告"，
 *       单个词不算。这类文案组合几乎只出现在互动广告页。</li>
 *   <li>页面必须存在覆盖 ≥85% 宽、≥60% 高的广告面，排除普通功能页。</li>
 *   <li>敏感页 / 受保护包直接拒绝。</li>
 *   <li>候选必须是纯图片、无文字；desc 为空或就是"关闭"义；尺寸 2.8%~13% 屏宽。</li>
 *   <li>候选必须落在屏幕四角之一，且距边缘 2%~12%（紧贴 0~2% 的通常是 AdChoices 角标）。</li>
 *   <li>候选不得与"下载/安装/打开/领取/立即"等 CTA 文案重叠。</li>
 *   <li>候选必须唯一，第二名的分数差距不足 12 分时放弃。</li>
 * </ul>
 */
public final class ShakeAdLocator {

    public static final class Hit {
        public final int nodeIndex;
        public final int score;
        public final String reason;

        Hit(int nodeIndex, int score, String reason) {
            this.nodeIndex = nodeIndex;
            this.score = score;
            this.reason = reason;
        }
    }

    private static final float AD_SURFACE_W = 0.85f, AD_SURFACE_H = 0.60f;
    private static final float ICON_MIN_W = 0.028f, ICON_MAX_W = 0.13f;
    private static final float ASPECT_MIN = 0.55f, ASPECT_MAX = 1.85f;
    /** 距屏幕边缘的合法区间：太贴边多广告角标，太靠内多是内容控件。 */
    private static final float EDGE_MIN = 0.02f, EDGE_MAX = 0.12f;
    private static final float MAX_AREA = 0.012f;
    private static final int MIN_SCORE = 74;

    private static final String[] CTA_WORDS = {
            "下载", "安装", "打开", "领取", "前往", "立即", "查看详情", "了解更多",
            "购买", "试玩", "预约", "咨询", "关注", "进入", "跳转"
    };

    private static final String[] CLOSE_WORDS = {
            "关闭", "叉", "取消", "close", "dismiss", "exit", "skip"
    };

    private ShakeAdLocator() { }

    public static Hit find(ScreenModel screen, int width, int height) {
        if (screen == null || screen.nodes.isEmpty()) return null;
        if (AdDecisionEngine.isSensitive(screen)) return null;
        if (AdDecisionEngine.isProtectedPackage(screen.packageName)) return null;
        if (!AdDecisionEngine.hasShakeAd(screen)) return null;

        int w = width > 0 ? width : inferWidth(screen);
        int h = height > 0 ? height : inferHeight(screen);
        if (w <= 0 || h <= 0) return null;
        if (!hasAdSurface(screen, w, h)) return null;

        Hit best = null;
        Hit second = null;
        java.util.Set<String> seen = new java.util.HashSet<>();
        for (NodeModel node : screen.nodes) {
            if (!qualifies(screen, node, w, h)) continue;
            // 父容器与子 ImageView 常常同一 bounds，只算一个候选。
            String key = node.left + "," + node.top + "," + node.right + "," + node.bottom;
            if (!seen.add(key)) continue;
            Hit candidate = new Hit(node.index, score(node, w, h), "摇一摇广告页 · 角落关闭图标");
            if (best == null || candidate.score > best.score) {
                second = best;
                best = candidate;
            } else if (second == null || candidate.score > second.score) {
                second = candidate;
            }
        }
        if (best == null || best.score < MIN_SCORE) return null;
        if (second != null && best.score - second.score < 12) return null;
        return best;
    }

    private static boolean hasAdSurface(ScreenModel screen, int w, int h) {
        for (NodeModel n : screen.nodes) {
            // 根节点本身永远是整屏，不能拿它当"广告面"。
            if (n.parentIndex < 0 || !n.visible || !n.hasBounds()) continue;
            if ((n.right - n.left) >= w * AD_SURFACE_W && (n.bottom - n.top) >= h * AD_SURFACE_H) {
                return true;
            }
        }
        return false;
    }

    private static boolean qualifies(ScreenModel screen, NodeModel node, int w, int h) {
        if (!node.visible || node.password || !node.hasBounds()) return false;
        if (!isImage(node.className)) return false;
        if (!node.normalizedText().isEmpty()) return false;
        String desc = node.normalizedDescription();
        if (!desc.isEmpty() && !looksLikeClose(desc)) return false;

        int bw = node.right - node.left, bh = node.bottom - node.top;
        if (bw < w * ICON_MIN_W || bw > w * ICON_MAX_W) return false;
        if (bh < w * ICON_MIN_W || bh > w * ICON_MAX_W) return false;
        float aspect = bw / (float) bh;
        if (aspect < ASPECT_MIN || aspect > ASPECT_MAX) return false;
        if ((long) bw * bh > (long) (w * h * MAX_AREA)) return false;

        if (!nearCorner(node, w, h)) return false;
        return !overlapsCta(screen, node);
    }

    /** 中心点必须落在某个角落的合法环带内。 */
    private static boolean nearCorner(NodeModel node, int w, int h) {
        float cx = (node.left + node.right) / 2f, cy = (node.top + node.bottom) / 2f;
        boolean rightSide = cx >= w * (1 - EDGE_MAX) && cx <= w * (1 - EDGE_MIN);
        boolean leftSide = cx <= w * EDGE_MAX && cx >= w * EDGE_MIN;
        boolean bottomSide = cy >= h * (1 - EDGE_MAX) && cy <= h * (1 - EDGE_MIN);
        boolean topSide = cy <= h * EDGE_MAX && cy >= h * EDGE_MIN;
        return (rightSide || leftSide) && (bottomSide || topSide);
    }

    private static int score(NodeModel node, int w, int h) {
        int value = 62;
        float cx = (node.left + node.right) / 2f, cy = (node.top + node.bottom) / 2f;
        // 右下角是互动广告最常见的位置，右上其次。
        if (cx >= w * (1 - EDGE_MAX) && cy >= h * (1 - EDGE_MAX)) value += 16;
        else if (cx >= w * (1 - EDGE_MAX)) value += 10;
        if (!node.normalizedDescription().isEmpty()) value += 8;
        if (node.clickable) value += 6;
        float side = (node.right - node.left) / (float) w;
        if (side >= 0.04f && side <= 0.09f) value += 6;
        return value;
    }

    private static boolean overlapsCta(ScreenModel screen, NodeModel icon) {
        float cx = (icon.left + icon.right) / 2f, cy = (icon.top + icon.bottom) / 2f;
        for (NodeModel n : screen.nodes) {
            if (n == icon) continue;
            String value = n.normalizedText() + n.normalizedDescription();
            if (value.isEmpty()) continue;
            if (!containsAny(value, CTA_WORDS)) continue;
            if (cx >= n.left && cx <= n.right && cy >= n.top && cy <= n.bottom) return true;
        }
        return false;
    }

    private static boolean looksLikeClose(String desc) {
        for (String word : CLOSE_WORDS) if (desc.contains(word)) return true;
        return false;
    }

    private static boolean containsAny(String value, String[] words) {
        if (value == null || value.isEmpty()) return false;
        for (String word : words) if (value.contains(word)) return true;
        return false;
    }

    private static boolean isImage(String className) {
        String c = className == null ? "" : className.toLowerCase(Locale.ROOT);
        return c.endsWith("imageview") || c.endsWith("imagebutton")
                || c.contains("appcompatimage");
    }

    private static int inferWidth(ScreenModel screen) {
        int value = 0;
        for (NodeModel n : screen.nodes) if (n.visible) value = Math.max(value, n.right);
        return value;
    }

    private static int inferHeight(ScreenModel screen) {
        int value = 0;
        for (NodeModel n : screen.nodes) if (n.visible) value = Math.max(value, n.bottom);
        return value;
    }
}
