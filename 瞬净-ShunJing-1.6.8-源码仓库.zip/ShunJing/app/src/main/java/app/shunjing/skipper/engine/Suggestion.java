package app.shunjing.skipper.engine;

/** One actionable fix produced by the offline diagnosis engine. */
public final class Suggestion {
    public enum Kind {
        ADD_PHRASE,          // add a custom close-word rule (verified)
        ADD_ID_RULE,         // add a view-id based rule (verified)
        ADD_LAYOUT_RULE,     // add a scoped geometric rule for a pure-image close button
        SCOPE_RULE,          // narrow an existing global rule down to one package
        RELAX_FOR_APP,       // app-scoped rule that no longer requires ad context
        SET_REWARD_MODE,     // switch the rewarded-ad three-state policy
        ADD_REWARD_APP,      // whitelist one package for auto-abandoning rewards
        TOGGLE_CLOSE_ICONS,
        TOGGLE_REWARDED,
        TOGGLE_LAYOUT_ANCHORS,
        TOGGLE_MASTER,
        ENABLE_APP,
        OPEN_SETTINGS,
        EXPORT_AI,
        INFO
    }

    public final Kind kind;
    public final String title;
    public final String detail;
    public final String risk;
    public final Rule rule;
    public final LayoutAnchorRule layoutRule;
    public final String prefKey;
    /** For SET_REWARD_MODE: the target EngineSettings.RewardMode name. */
    public final String settingValue;
    /** For SCOPE_RULE: id of the existing rule to narrow. */
    public final String targetRuleId;
    /** For SCOPE_RULE: package the existing rule should be limited to. */
    public final String targetPackage;
    public final boolean verified;

    private Suggestion(Kind kind, String title, String detail, String risk, Rule rule,
                       LayoutAnchorRule layoutRule, String prefKey, String settingValue,
                       String targetRuleId, String targetPackage, boolean verified) {
        this.kind = kind;
        this.title = title;
        this.detail = detail;
        this.risk = risk == null ? "" : risk;
        this.rule = rule;
        this.layoutRule = layoutRule;
        this.prefKey = prefKey == null ? "" : prefKey;
        this.settingValue = settingValue == null ? "" : settingValue;
        this.targetRuleId = targetRuleId == null ? "" : targetRuleId;
        this.targetPackage = targetPackage == null ? "" : targetPackage;
        this.verified = verified;
    }

    public static Suggestion withRule(Kind kind, String title, String detail, String risk,
                                      Rule rule, boolean verified) {
        return new Suggestion(kind, title, detail, risk, rule, null, "", "", "", "", verified);
    }

    public static Suggestion withLayoutRule(String title, String detail, String risk,
                                            LayoutAnchorRule layoutRule, boolean verified) {
        return new Suggestion(Kind.ADD_LAYOUT_RULE, title, detail, risk, null, layoutRule,
                "", "", "", "", verified);
    }

    public static Suggestion scopeRule(String title, String detail, String risk,
                                       String ruleId, String packageName) {
        return new Suggestion(Kind.SCOPE_RULE, title, detail, risk, null, null,
                "", "", ruleId, packageName, false);
    }

    public static Suggestion setRewardMode(String title, String detail, String risk, String mode) {
        return new Suggestion(Kind.SET_REWARD_MODE, title, detail, risk, null, null,
                "", mode, "", "", false);
    }

    public static Suggestion addRewardApp(String title, String detail, String risk, String packageName) {
        return new Suggestion(Kind.ADD_REWARD_APP, title, detail, risk, null, null,
                "", "", "", packageName, false);
    }

    public static Suggestion withToggle(Kind kind, String title, String detail, String risk, String prefKey) {
        return new Suggestion(kind, title, detail, risk, null, null, prefKey, "", "", "", false);
    }

    public static Suggestion action(Kind kind, String title, String detail) {
        return new Suggestion(kind, title, detail, "", null, null, "", "", "", "", false);
    }

    public static Suggestion info(String title, String detail) {
        return new Suggestion(Kind.INFO, title, detail, "", null, null, "", "", "", "", false);
    }

    public boolean isRule() { return rule != null; }
    public boolean isToggle() { return !prefKey.isEmpty(); }
}
