package app.shunjing.skipper.engine;

/**
 * v1.6.3 —— 「广告点进应用商店，自动退回原页面」。
 *
 * <p>为什么要单独一个判定：市面上大量开屏 / 插屏广告的落地页就是应用商店的商品详情，
 * 点一下「×」稍微偏一点，人就被送进商店了。进了商店以后，返回键要按两三次才能回到
 * 原来的 App，中间还可能被商店的推荐位拦一下。
 *
 * <p>为什么默认关闭：这是唯一一个「用户没让我们点，我们也主动按键」的行为。用户主动
 * 去商店装东西是完全正常的操作，一旦误判就是把人从商店里踢出去，比不做更烦。所以
 * 只有同时满足下面三条才动手，宁可漏，不可误：
 * <ol>
 *   <li>新前台确实是商店；</li>
 *   <li>跳出去之前那一页，6 秒内被确认过是广告位（有跳过 / 广告词 / 摇一摇 / 运营弹窗）；</li>
 *   <li>起跳点不是桌面或系统界面（那是用户自己按图标打开的）。</li>
 * </ol>
 *
 * <p>纯判定，不碰无障碍 API，可单测。
 */
public final class StoreJumpGuard {

    /** 跳转前多久内见过广告上下文，才算「广告把你送过去」。太短会漏，太长会误伤。 */
    public static final long AD_WINDOW_MS = 6_000L;

    /**
     * 主流应用商店。只列包名，不做名称模糊匹配 —— 名字里有「商店」的普通 App 太多了。
     */
    private static final String[] STORE_PACKAGES = {
            "com.android.vending",              // Google Play
            "com.xiaomi.market",                // 小米应用商店
            "com.xiaomi.gamecenter",            // 小米游戏中心
            "com.huawei.appmarket",             // 华为应用市场
            "com.hihonor.appmarket",            // 荣耀应用市场
            "com.oppo.market",                  // OPPO 软件商店（旧）
            "com.heytap.market",                // OPPO / 一加软件商店（新）
            "com.bbk.appstore",                 // vivo 应用商店
            "com.tencent.android.qqdownloader", // 应用宝
            "com.qihoo.appstore",               // 360 手机助手
            "com.meizu.mstore",                 // 魅族应用商店
            "com.lenovo.leos.appstore",         // 联想应用商店
            "com.coolapk.market",               // 酷安
            "com.wandoujia.phoenix2",           // 豌豆荚
            "com.sec.android.app.samsungapps",  // 三星应用商店
            "com.transsion.appstore",           // 传音
            "com.oneplus.market"                // 一加（部分机型）
    };

    private StoreJumpGuard() { }

    /** 这个包是不是应用商店。允许带子包名（如 com.xiaomi.market.module）。 */
    public static boolean isStore(String packageName) {
        if (packageName == null || packageName.isEmpty()) return false;
        for (String store : STORE_PACKAGES) {
            if (packageName.equals(store) || packageName.startsWith(store + ".")) return true;
        }
        return false;
    }

    /**
     * 该不该按一次返回。
     *
     * @param from        跳转前的前台包（原页面）
     * @param to          新的前台包
     * @param now         当前时刻（elapsedRealtime）
     * @param adContextAt 最近一次确认「这一页是广告」的时刻；从未确认过传 0
     */
    public static boolean shouldRevert(String from, String to, long now, long adContextAt) {
        if (!isStore(to)) return false;
        if (from == null || from.isEmpty() || from.equals(to)) return false;
        // 桌面 / 系统界面出发的，是用户自己按图标打开的，别动。
        if (AdDecisionEngine.isProtectedPackage(from)) return false;
        if (adContextAt <= 0L) return false;
        long age = now - adContextAt;
        return age >= 0L && age <= AD_WINDOW_MS;
    }
}
