package app.shunjing.skipper;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.os.SystemClock;

import app.shunjing.skipper.ui.IconSwitcher;

/**
 * 进程级生命周期。
 *
 * <p>存在的唯一理由：判断"应用是不是还在前台"。
 *
 * <p>桌面图标是靠 {@code activity-alias} 换的，换的时候必须禁用旧的别名。如果这个别名
 * 正好承载着当前任务，部分 ROM（ColorOS / OriginOS 尤其明显）会直接把任务结束掉，
 * 用户看到的就是"点了几下突然回到桌面"。所以换图标只能在应用到后台之后做，
 * 而判断"到后台"需要跨 Activity 计数，只能放在 Application 里。
 */
public final class ShunJingApp extends Application
        implements Application.ActivityLifecycleCallbacks {

    private static int startedActivities;
    private static long backgroundedAt;

    /** 只要有任何一个页面处于 started 状态，就认为应用仍在前台。 */
    public static boolean isForeground() {
        return startedActivities > 0;
    }

    public static long backgroundedAt() {
        return backgroundedAt;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        registerActivityLifecycleCallbacks(this);
        CrashLog.install(this);
    }

    @Override
    public void onActivityStarted(Activity activity) {
        startedActivities++;
    }

    @Override
    public void onActivityStopped(Activity activity) {
        if (startedActivities > 0) startedActivities--;
        if (startedActivities == 0) {
            backgroundedAt = SystemClock.elapsedRealtime();
            // 等 700ms，避开"旋转屏幕 / 跳转别的 App 又马上回来"这类瞬时切换。
            IconSwitcher.onAppBackgrounded(this);
        }
    }

    @Override public void onActivityCreated(Activity activity, Bundle savedInstanceState) { }
    @Override public void onActivityResumed(Activity activity) { }
    @Override public void onActivityPaused(Activity activity) { }
    @Override public void onActivitySaveInstanceState(Activity activity, Bundle outState) { }
    @Override public void onActivityDestroyed(Activity activity) { }
}
