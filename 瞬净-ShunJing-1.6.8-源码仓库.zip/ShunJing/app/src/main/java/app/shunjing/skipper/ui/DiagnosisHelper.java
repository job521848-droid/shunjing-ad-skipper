package app.shunjing.skipper.ui;

import android.content.Context;

import app.shunjing.skipper.data.Prefs;
import app.shunjing.skipper.engine.Diagnosis;
import app.shunjing.skipper.engine.DumpAnalyzer;
import app.shunjing.skipper.engine.PageDump;

/** Shared entry point for running the offline diagnosis with current settings. */
public final class DiagnosisHelper {
    private DiagnosisHelper() { }

    public static Diagnosis analyze(Context context, PageDump dump) {
        Prefs prefs = new Prefs(context.getApplicationContext());
        return new DumpAnalyzer().analyze(dump, prefs.getRules(), prefs.engineSettings(),
                prefs.masterEnabled(), prefs.isAppEnabled(dump.packageName),
                prefs.layoutAnchors());
    }
}
