package app.shunjing.skipper.engine;

import java.util.Locale;

/**
 * v1.6.5：叠加式下载广告右下角的关闭键。
 *
 * <p>为什么前面三个定位器全都打不中这一类页面：
 * <ul>
 *   <li>{@link OverlayCloseLocator}：要求关闭图标在<b>卡片右上角</b>且「有可点祖先」。
 *       下载广告的 × 在<b>右下角</b>（合规条上方），而且整棵树 c=0、一个可点祖先都没有。</li>
 *   <li>{@link CornerCloseLocator}：要求 Activity 是广告 SDK 的代理页（{@code sdkActivity}）。
 *       这里的 Activity 是 {@code android.app.Dialog}，第一道闸就返回 null。</li>
 *   <li>文字规则：× 是一枚 68×68 的纯 ImageView，无文字、无 id、无描述。</li>
 * </ul>
 *
 * <p>于是「手能点、机器点不到」。本类只补这一种版式，条件收得很紧：
 * <ol>
 *   <li>整页先通过 {@link OverlayAdEvidence}（合规条 / 视频素材 / 下载文案）—— 不是广告页直接拒；</li>
 *   <li>敏感页、受保护包、危险动作词（支付 / 密码 / 验证码 / 授权 / 卸载 / 购买 / 订阅）直接拒；</li>
 *   <li>候选必须是「无文字、无 id、尺寸 1.2%~9% 屏宽、接近正方形」的小图标；</li>
 *   <li>位置必须在屏幕<b>右侧 14% + 下方 30%</b> 这块区域；</li>
 *   <li>不能压在文字行上，也不是某行文字的一部分（合规条里那个「广告」角标就在文字旁边）；</li>
 *   <li>全页只有<b>一个</b>候选。出现第二个不同位置的候选就返回 null —— 歧义不猜。</li>
 * </ol>
 *
 * <p>点击仍走「节点 ACTION_CLICK → 失败回退该控件自身中心坐标」的既有链路，
 * 服务层的落点闸（≤600px、面积 ≤6% 屏）照旧生效。
 */
public final class DownloadAdCloseLocator {

    /** 出现这些词说明页面在要求用户做实质决定，绝不代点。 */
    private static final String[] DANGEROUS = {
            "支付", "付款", "转账", "充值", "提现", "密码", "验证码", "授权登录", "注册",
            "同意并", "允许", "卸载", "格式化", "恢复出厂", "购买", "下单", "确认订单",
            "开通会员", "订阅", "扣费", "签约", "实名认证"
    };

    private static final String[] CLOSE_WORDS = {
            "关闭", "叉", "取消", "close", "dismiss", "exit", "skip"
    };

    /** 候选图标边长占屏宽的比例区间。 */
    private static final float ICON_MIN_RATIO = 0.012f;
    private static final float ICON_MAX_RATIO = 0.09f;
    /** 图标面积上限（占整屏），排除装饰性大图。 */
    private static final float ICON_MAX_AREA = 0.008f;
    private static final float ASPECT_MIN = 0.60f;
    private static final float ASPECT_MAX = 1.70f;
    /** 右侧带 / 下方带。 */
    private static final float RIGHT_BAND = 0.86f;
    private static final float BOTTOM_BAND = 0.70f;

    public static final class Hit {
        public final int nodeIndex;
        public final String reason;

        Hit(int nodeIndex, String reason) {
            this.nodeIndex = nodeIndex;
            this.reason = reason;
        }
    }

    private DownloadAdCloseLocator() { }

    public static Hit find(ScreenModel screen, int width, int height) {
        if (screen == null || screen.nodes.isEmpty() || width <= 0 || height <= 0) return null;
        if (AdDecisionEngine.isProtectedPackage(screen.packageName)) return null;
        if (AdDecisionEngine.isSensitive(screen)) return null;
        if (!OverlayAdEvidence.matches(screen)) return null;
        if (hasDangerousAction(screen)) return null;

        long screenArea = (long) width * height;
        NodeModel best = null;
        int bestIndex = Integer.MAX_VALUE;

        for (NodeModel n : screen.nodes) {
            if (!isIconNode(n, width, height)) continue;
            if (!inBand(n, width, height)) continue;
            if ((long) n.area() > (long) (screenArea * ICON_MAX_AREA)) continue;
            if (!n.normalizedText().isEmpty()) continue;
            String desc = n.normalizedDescription();
            if (!desc.isEmpty() && !looksLikeClose(desc)) continue;
            if (overlapsText(screen, n)) continue;
            if (insideTextNode(screen, (n.left + n.right) / 2f, (n.top + n.bottom) / 2f)) continue;
            if (parentHasText(screen, n)) continue;

            if (best == null) {
                best = n;
                bestIndex = n.index;
                continue;
            }
            if (sameBox(best, n)) {
                // 父子同框（FrameLayout 套 ImageView）：留外层那个，点一次就够。
                if (n.index < bestIndex) { best = n; bestIndex = n.index; }
                continue;
            }
            // 两个不同位置的"像关闭键"：这条路径只认唯一解，宁可不点。
            return null;
        }
        if (best == null) return null;
        return new Hit(best.index, "下载广告 · 右下角悬浮关闭键（控件不可点，按坐标点击）");
    }

    private static boolean isIconNode(NodeModel n, int width, int height) {
        if (!n.visible || n.password || !n.hasBounds()) return false;
        String cls = n.className.toLowerCase(Locale.ROOT);
        boolean icon = cls.endsWith("imageview") || cls.endsWith("imagebutton")
                || cls.endsWith("android.view.view") || cls.endsWith("framelayout");
        if (!icon) return false;
        int bw = n.right - n.left, bh = n.bottom - n.top;
        if (bw <= 0 || bh <= 0) return false;
        if (bw < width * ICON_MIN_RATIO || bw > width * ICON_MAX_RATIO) return false;
        if (bh < width * ICON_MIN_RATIO || bh > width * ICON_MAX_RATIO) return false;
        float aspect = bw / (float) bh;
        return aspect >= ASPECT_MIN && aspect <= ASPECT_MAX;
    }

    private static boolean inBand(NodeModel n, int width, int height) {
        float cx = (n.left + n.right) / 2f;
        float cy = (n.top + n.bottom) / 2f;
        return cx >= width * RIGHT_BAND && cy >= height * BOTTOM_BAND;
    }

    /** 与任意一行文字的区域重叠即视为"文字的一部分"（合规条里的广告角标就长这样）。 */
    private static boolean overlapsText(ScreenModel screen, NodeModel icon) {
        for (NodeModel n : screen.nodes) {
            if (n.index == icon.index || !n.visible || !n.hasBounds()) continue;
            if (n.normalizedText().isEmpty()) continue;
            boolean horizontal = icon.left < n.right && icon.right > n.left;
            boolean vertical = icon.top < n.bottom && icon.bottom > n.top;
            if (horizontal && vertical) return true;
        }
        return false;
    }

    private static boolean insideTextNode(ScreenModel screen, float x, float y) {
        for (NodeModel n : screen.nodes) {
            if (!n.visible || !n.hasBounds()) continue;
            if (n.normalizedText().isEmpty()) continue;
            if (x >= n.left && x <= n.right && y >= n.top && y <= n.bottom) return true;
        }
        return false;
    }

    /** 上溯两级：父容器有文字说明这枚图标属于某条文案（如"点击这里关闭"），不点。 */
    private static boolean parentHasText(ScreenModel screen, NodeModel node) {
        NodeModel current = node;
        for (int depth = 0; depth < 2; depth++) {
            if (current.parentIndex < 0 || current.parentIndex >= screen.nodes.size()) return false;
            current = screen.nodes.get(current.parentIndex);
            if (!current.normalizedText().isEmpty()) return true;
        }
        return false;
    }

    private static boolean sameBox(NodeModel a, NodeModel b) {
        return a.left == b.left && a.top == b.top && a.right == b.right && a.bottom == b.bottom;
    }

    private static boolean hasDangerousAction(ScreenModel screen) {
        for (NodeModel n : screen.nodes) {
            String value = n.normalizedText() + n.normalizedDescription();
            if (value.isEmpty()) continue;
            for (String word : DANGEROUS) {
                if (value.contains(word)) return true;
            }
        }
        return false;
    }

    private static boolean looksLikeClose(String desc) {
        for (String word : CLOSE_WORDS) {
            if (desc.contains(word)) return true;
        }
        return false;
    }
}
