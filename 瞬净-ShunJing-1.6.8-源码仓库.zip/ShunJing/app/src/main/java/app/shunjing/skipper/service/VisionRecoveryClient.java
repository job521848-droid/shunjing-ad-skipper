package app.shunjing.skipper.service;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import app.shunjing.skipper.engine.NodeModel;
import app.shunjing.skipper.engine.ScreenModel;
import app.shunjing.skipper.engine.VisionRecoveryPolicy;

/** Minimal OpenAI-compatible vision request. Screenshots stay in memory and are never saved. */
public final class VisionRecoveryClient {
    public interface Callback {
        void onResult(Answer answer);
        void onError(String message);
    }

    public static final class Answer {
        public final boolean found;
        public final int x;
        public final int y;
        public final float confidence;
        public final String reason;

        Answer(boolean found, int x, int y, float confidence, String reason) {
            this.found = found;
            this.x = x;
            this.y = y;
            this.confidence = confidence;
            this.reason = reason == null ? "" : reason;
        }
    }

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    public void analyze(String endpoint, String apiKey, String model, Bitmap screenshot,
                        ScreenModel screen, Callback callback) {
        analyze(endpoint, apiKey, model, screenshot, screen, false, callback);
    }

    /**
     * @param classifyFirst 本地没有广告证据、只凭结构"疑似"时置 true：先让模型判断是不是广告，
     *                      不是就明确回 found=false。避免它在一张普通页面里硬凑一个 × 出来。
     */
    public void analyze(String endpoint, String apiKey, String model, Bitmap screenshot,
                        ScreenModel screen, boolean classifyFirst, Callback callback) {
        // 注意：调用方把这张位图的所有权交给本方法，请求结束后由这里统一回收。
        executor.execute(() -> {
            Bitmap scaled = null;
            HttpURLConnection connection = null;
            try {
                // 缩放放到工作线程：1024→900 的 copy 放在主线程会白占 40ms，而广告只停一两秒。
                scaled = scale(screenshot);
                ByteArrayOutputStream jpeg = new ByteArrayOutputStream();
                scaled.compress(Bitmap.CompressFormat.JPEG, 62, jpeg);
                String encoded = Base64.encodeToString(jpeg.toByteArray(), Base64.NO_WRAP);
                JSONObject body = new JSONObject();
                body.put("model", model);
                body.put("temperature", 0);
                body.put("max_tokens", 90);
                JSONArray messages = new JSONArray();
                JSONObject message = new JSONObject();
                message.put("role", "user");
                JSONArray content = new JSONArray();
                content.put(new JSONObject().put("type", "text").put("text", prompt(screen, classifyFirst)));
                content.put(new JSONObject().put("type", "image_url").put("image_url",
                        new JSONObject().put("url", "data:image/jpeg;base64," + encoded)
                                .put("detail", "auto")));
                message.put("content", content);
                messages.put(message);
                body.put("messages", messages);

                URL url = new URL(endpoint);
                if (!"https".equalsIgnoreCase(url.getProtocol())) {
                    throw new IllegalArgumentException("仅允许 HTTPS 接口");
                }
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                // v1.5: 接管要求"快"。宁可早失败退回本地，也不要在广告页上干等十秒。
                connection.setConnectTimeout(3_500);
                connection.setReadTimeout(7_000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                connection.setRequestProperty("Authorization", "Bearer " + apiKey);
                connection.setRequestProperty("Accept", "application/json");
                byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
                connection.setFixedLengthStreamingMode(payload.length);
                try (OutputStream output = connection.getOutputStream()) { output.write(payload); }
                int code = connection.getResponseCode();
                InputStream stream = code >= 200 && code < 300
                        ? connection.getInputStream() : connection.getErrorStream();
                String response = read(stream);
                if (code < 200 || code >= 300) throw new IllegalStateException("接口 HTTP " + code);
                Answer answer = parse(response);
                main.post(() -> callback.onResult(answer));
            } catch (Exception e) {
                String message = e instanceof IllegalArgumentException
                        || e instanceof IllegalStateException ? e.getMessage() : "视觉接口请求失败或超时";
                main.post(() -> callback.onError(message));
            } finally {
                if (connection != null) connection.disconnect();
                if (scaled != null && !scaled.isRecycled()) scaled.recycle();
                if (!screenshot.isRecycled()) screenshot.recycle();
            }
        });
    }

    public void shutdown() { executor.shutdownNow(); }

    private static Answer parse(String response) throws Exception {
        JSONObject root = new JSONObject(response);
        String content = root.getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content").trim();
        if (content.startsWith("```")) {
            int firstLine = content.indexOf('\n');
            if (firstLine >= 0) content = content.substring(firstLine + 1);
            int fence = content.lastIndexOf("```");
            if (fence >= 0) content = content.substring(0, fence);
        }
        int start = content.indexOf('{'), end = content.lastIndexOf('}');
        if (start < 0 || end <= start) return new Answer(false, 0, 0, 0f, "模型未返回坐标");
        JSONObject value = new JSONObject(content.substring(start, end + 1));
        boolean found = value.optBoolean("found", false);
        int x = value.optInt("x", -1), y = value.optInt("y", -1);
        float confidence = (float) value.optDouble("confidence", 0.0);
        if (!VisionRecoveryPolicy.hasUsableCoordinates(found, x, y, confidence)) {
            return new Answer(false, 0, 0, confidence, "模型未给出可用坐标");
        }
        return new Answer(true, x, y, confidence, value.optString("reason", ""));
    }

    private static String prompt(ScreenModel screen, boolean classifyFirst) {
        StringBuilder tree = new StringBuilder();
        int count = 0;
        for (NodeModel n : screen.nodes) {
            if (!n.visible || !n.hasBounds() || count++ >= 48) continue;
            tree.append('#').append(n.index).append(' ').append(n.className)
                    .append(" c=").append(n.clickable ? 1 : 0)
                    .append(" [").append(n.left).append(',').append(n.top).append(',')
                    .append(n.right).append(',').append(n.bottom).append("] ")
                    .append(n.viewId.isEmpty() ? "" : n.viewId).append('\n');
        }
        String head = classifyFirst
                ? "第一步：判断这张截图是不是广告 —— 开屏广告、插屏广告、激励视频、"
                  + "互动广告（摇一摇 / 扭一扭），或 App 内的运营弹窗（红包 / 签到 / 抽奖 / 限时福利）。"
                  + "如果都不是（普通功能页、聊天、商品列表、设置、扫码、支付、验证码页面），"
                  + "必须返回 {\"found\":false,\"reason\":\"not_ad\"}，绝不要勉强找一个 × 充数。"
                  + "第二步：只有确认是广告或运营弹窗时，才找出关闭它用的按钮：通常是角落的 ×、"
                  + "“跳过 3”“关闭”。"
                : "找出截图中用于【关闭广告 / 跳过广告】的按钮，通常是角落里的 ×、"
                  + "“跳过 3”“关闭”。"
                  + "只要该页是广告或运营弹窗，即使没有“广告”二字也要给出关闭控件。";
        return head
                + "不要选下载、安装、打开、领取、立即、登录、授权、支付、播放、暂停、分享。"
                + "返回 JSON：{\"found\":true|false,\"x\":0-1000,\"y\":0-1000,\"confidence\":0-1,\"reason\":\"短\"}。"
                + "x/y 为按钮中心相对整屏的归一化坐标；仅在完全确定时给 0.85 以上。"
                + "应用 " + screen.packageName + " / " + screen.activityName + "。控件树：\n" + tree;
    }

    /**
     * 900px 长边足够看清角落的 50px × 图标，体积却只有 1080p 的一半左右：
     * 上传耗时是接管延迟里最大的一块，这一步比换模型更立竿见影。
     */
    private static Bitmap scale(Bitmap source) {
        int max = Math.max(source.getWidth(), source.getHeight());
        if (max <= 900) return Bitmap.createBitmap(source);
        float ratio = 900f / max;
        return Bitmap.createScaledBitmap(source, Math.max(1, Math.round(source.getWidth() * ratio)),
                Math.max(1, Math.round(source.getHeight() * ratio)), true);
    }

    private static String read(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder result = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) result.append(line);
        }
        return result.toString();
    }
}
