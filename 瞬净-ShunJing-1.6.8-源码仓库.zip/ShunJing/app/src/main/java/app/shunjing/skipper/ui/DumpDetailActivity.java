package app.shunjing.skipper.ui;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import app.shunjing.skipper.R;
import app.shunjing.skipper.data.DumpStore;
import app.shunjing.skipper.data.Prefs;
import app.shunjing.skipper.engine.Diagnosis;
import app.shunjing.skipper.engine.DumpReport;
import app.shunjing.skipper.engine.NodeModel;
import app.shunjing.skipper.engine.PageDump;
import app.shunjing.skipper.engine.Rule;
import app.shunjing.skipper.engine.Suggestion;

/** Shows the diagnosis for one captured page and lets the user adopt verified fixes. */
public final class DumpDetailActivity extends BaseActivity {
    private Prefs prefs;
    private DumpStore store;
    private File file;
    private PageDump dump;
    private Diagnosis diagnosis;
    private LinearLayout body;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        store = new DumpStore(this);
        String path = getIntent().getStringExtra(DumpActivity.EXTRA_FILE);
        if (path != null) file = new File(path);
        dump = file == null ? null : store.load(file);

        LinearLayout root = Ui.root(this);
        root.addView(Ui.header(this, "诊断详情", "本地分析 · 规则可一键采纳并回验", true));
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(body, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        render();
    }

    private void render() {
        body.removeAllViews();
        if (dump == null) {
            body.addView(Ui.text(this, "这条快照已损坏或已被删除。", 15, getColor(R.color.danger)));
            return;
        }
        diagnosis = DiagnosisHelper.analyze(this, dump);

        LinearLayout info = Ui.card(this);
        info.addView(Ui.caption(this, "01  /  现场信息"));
        String label = dump.appLabel.isEmpty() ? dump.packageName : dump.appLabel;
        TextView title = Ui.text(this, label, 20, getColor(R.color.text_primary));
        title.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        info.addView(title);
        info.addView(Ui.text(this, dump.packageName + "\n"
                        + (dump.activityName.isEmpty() ? "未知页面" : dump.activityName) + "\n"
                        + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(new Date(dump.time))
                        + "  ·  " + dump.sourceLabel() + "  ·  " + dump.nodes.size() + " 个控件",
                12, getColor(R.color.text_secondary)));
        body.addView(info);

        LinearLayout verdict = Ui.card(this);
        verdict.addView(Ui.caption(this, "02  /  诊断结论"));
        int color = verdictColor(diagnosis.verdict);
        TextView headline = Ui.text(this, diagnosis.verdictLabel() + " · " + diagnosis.headline,
                18, color);
        headline.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        verdict.addView(headline);
        TextView explanation = Ui.text(this, diagnosis.explanation, 13,
                getColor(R.color.text_primary));
        explanation.setPadding(0, Ui.dp(this, 8), 0, 0);
        verdict.addView(explanation);
        body.addView(verdict);

        LinearLayout evidence = Ui.card(this);
        evidence.addView(Ui.caption(this, "03  /  判断依据"));
        for (String item : diagnosis.evidence) {
            evidence.addView(Ui.text(this, "· " + item, 12, getColor(R.color.text_secondary)));
        }
        if (!diagnosis.candidates.isEmpty()) {
            TextView sub = Ui.text(this, "疑似关闭控件", 14, getColor(R.color.cyan));
            sub.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 4));
            evidence.addView(sub);
            for (Diagnosis.Candidate c : diagnosis.candidates) {
                evidence.addView(Ui.text(this, "  #" + c.index + " " + c.label + "\n      "
                                + c.bounds + " · id=" + (c.id.isEmpty() ? "无" : c.id)
                                + " · 可点击=" + (c.clickable || c.hasClickableAncestor),
                        11, getColor(R.color.text_secondary)));
            }
        }
        body.addView(evidence);

        LinearLayout fixes = Ui.card(this);
        fixes.addView(Ui.caption(this, "04  /  修复建议"));
        if (diagnosis.suggestions.isEmpty()) {
            fixes.addView(Ui.text(this, "暂无建议", 13, getColor(R.color.text_secondary)));
        }
        for (Suggestion suggestion : diagnosis.suggestions) {
            fixes.addView(suggestionCard(suggestion));
        }
        body.addView(fixes);

        LinearLayout export = Ui.card(this);
        export.addView(Ui.caption(this, "05  /  交给 AI 深度分析"));
        export.addView(Ui.text(this,
                "导出一份含完整控件树、现有规则与诊断证据的结构化报告，粘贴给任意大模型即可获得更细的方案。"
                        + (prefs.maskExportEnabled() ? "当前已开启导出脱敏。" : "当前导出包含页面文字。"),
                12, getColor(R.color.text_secondary)));
        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button copy = Ui.primary(this, "复制报告");
        copy.setOnClickListener(v -> copyReport());
        buttons.addView(copy, halfParams());
        Button share = Ui.secondary(this, "分享报告");
        share.setOnClickListener(v -> shareReport());
        buttons.addView(share, halfParams());
        export.addView(buttons);
        Button tree = Ui.secondary(this, "查看原始控件树");
        tree.setOnClickListener(v -> showTree());
        export.addView(tree);
        body.addView(export);

        Button delete = Ui.secondary(this, "删除这条快照");
        delete.setTextColor(getColor(R.color.danger));
        delete.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("删除快照").setMessage("删除后不可恢复。")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", (d, w) -> { store.delete(file); finish(); }).show());
        body.addView(delete);
    }

    private LinearLayout.LayoutParams halfParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(Ui.dp(this, 3), Ui.dp(this, 8), Ui.dp(this, 3), 0);
        return p;
    }

    private LinearLayout suggestionCard(Suggestion suggestion) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_input);
        card.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12));
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(0, Ui.dp(this, 8), 0, Ui.dp(this, 4));
        card.setLayoutParams(cardParams);

        String prefix = suggestion.verified ? "✓ 已回验  " : "";
        TextView title = Ui.text(this, prefix + suggestion.title, 15,
                getColor(suggestion.verified ? R.color.cyan : R.color.text_primary));
        title.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        card.addView(title);
        card.addView(Ui.text(this, suggestion.detail, 12, getColor(R.color.text_primary)));
        if (!suggestion.risk.isEmpty()) {
            TextView risk = Ui.text(this, "⚠ " + suggestion.risk, 12, getColor(R.color.warning));
            risk.setPadding(0, Ui.dp(this, 4), 0, 0);
            card.addView(risk);
        }
        if (suggestion.isRule() || suggestion.isToggle()
                || suggestion.kind == Suggestion.Kind.ADD_LAYOUT_RULE
                || suggestion.kind == Suggestion.Kind.SCOPE_RULE
                || suggestion.kind == Suggestion.Kind.SET_REWARD_MODE
                || suggestion.kind == Suggestion.Kind.ADD_REWARD_APP
                || suggestion.kind == Suggestion.Kind.ENABLE_APP
                || suggestion.kind == Suggestion.Kind.OPEN_SETTINGS
                || suggestion.kind == Suggestion.Kind.EXPORT_AI) {
            Button apply = Ui.primary(this, actionLabel(suggestion));
            apply.setTextSize(13);
            apply.setMinHeight(Ui.dp(this, 40));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, Ui.dp(this, 10), 0, 0);
            apply.setOnClickListener(v -> applySuggestion(suggestion));
            card.addView(apply, params);
        }
        return card;
    }

    private String actionLabel(Suggestion s) {
        switch (s.kind) {
            case ADD_PHRASE:
            case ADD_ID_RULE: return "添加规则并回验";
            case ADD_LAYOUT_RULE: return "添加布局锚点并开启";
            case SCOPE_RULE: return "收窄到本应用";
            case SET_REWARD_MODE: return "切换策略";
            case ADD_REWARD_APP: return "仅授权此应用";
            case RELAX_FOR_APP: return "确认风险并启用";
            case TOGGLE_CLOSE_ICONS:
            case TOGGLE_REWARDED:
            case TOGGLE_LAYOUT_ANCHORS:
            case TOGGLE_MASTER: return "立即开启";
            case ENABLE_APP: return "重新启用该应用";
            case OPEN_SETTINGS: return "打开设置";
            case EXPORT_AI: return "复制报告";
            default: return "应用";
        }
    }

    private void applySuggestion(Suggestion suggestion) {
        if (dump == null) return;
        if (suggestion.kind == Suggestion.Kind.RELAX_FOR_APP
                || suggestion.kind == Suggestion.Kind.TOGGLE_REWARDED
                || suggestion.kind == Suggestion.Kind.ADD_LAYOUT_RULE
                || suggestion.kind == Suggestion.Kind.ADD_REWARD_APP
                || isAutoAbandonMode(suggestion)) {
            new AlertDialog.Builder(this)
                    .setTitle("请确认风险")
                    .setMessage(suggestion.risk.isEmpty() ? suggestion.detail : suggestion.risk)
                    .setNegativeButton("取消", null)
                    .setPositiveButton("我确认，启用", (d, w) -> commitSuggestion(suggestion))
                    .show();
            return;
        }
        commitSuggestion(suggestion);
    }

    private boolean isAutoAbandonMode(Suggestion s) {
        return s.kind == Suggestion.Kind.SET_REWARD_MODE
                && "AUTO_ABANDON".equals(s.settingValue);
    }

    private void commitSuggestion(Suggestion suggestion) {
        String message;
        switch (suggestion.kind) {
            case ADD_PHRASE:
            case ADD_ID_RULE:
            case RELAX_FOR_APP:
                if (suggestion.rule == null) return;
                if (hasSameRule(suggestion.rule)) {
                    Toast.makeText(this, "相同规则已存在", Toast.LENGTH_SHORT).show();
                    return;
                }
                prefs.addCustomRule(suggestion.rule);
                message = "规则已添加，正在重新诊断";
                break;
            case ADD_LAYOUT_RULE:
                if (suggestion.layoutRule == null) return;
                prefs.addLayoutAnchor(suggestion.layoutRule);
                prefs.preferences().edit().putBoolean("layout_anchors", true).apply();
                message = "布局锚点已添加并开启，正在重新诊断";
                break;
            case SCOPE_RULE:
                prefs.scopeCustomRuleTo(suggestion.targetRuleId, suggestion.targetPackage);
                message = "规则已收窄到 " + suggestion.targetPackage + "，正在重新诊断";
                break;
            case SET_REWARD_MODE:
                try {
                    prefs.setRewardMode(app.shunjing.skipper.engine.EngineSettings.RewardMode
                            .valueOf(suggestion.settingValue));
                } catch (IllegalArgumentException e) { return; }
                message = "激励视频策略已切换，正在重新诊断";
                break;
            case ADD_REWARD_APP:
                prefs.setRewardAutoAbandonApp(suggestion.targetPackage, true);
                if (prefs.rewardMode() == app.shunjing.skipper.engine.EngineSettings.RewardMode.PROTECT) {
                    prefs.setRewardMode(app.shunjing.skipper.engine.EngineSettings.RewardMode.END_CARD_ONLY);
                }
                message = "已仅授权 " + suggestion.targetPackage + " 自动放弃奖励";
                break;
            case TOGGLE_CLOSE_ICONS:
            case TOGGLE_REWARDED:
            case TOGGLE_LAYOUT_ANCHORS:
            case TOGGLE_MASTER:
                prefs.preferences().edit().putBoolean(suggestion.prefKey, true).apply();
                if (suggestion.kind == Suggestion.Kind.TOGGLE_REWARDED) {
                    prefs.setRewardMode(app.shunjing.skipper.engine.EngineSettings.RewardMode.AUTO_ABANDON);
                }
                message = "设置已开启，正在重新诊断";
                break;
            case ENABLE_APP:
                prefs.setAppEnabled(dump.packageName, true);
                message = "应用已启用，正在重新诊断";
                break;
            case OPEN_SETTINGS:
                startActivity(new Intent(this, SettingsActivity.class));
                return;
            case EXPORT_AI:
                copyReport();
                return;
            default:
                return;
        }
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        render();
    }

    private boolean hasSameRule(Rule rule) {
        for (Rule existing : prefs.getRules()) {
            if (!existing.builtIn && existing.phrase.equalsIgnoreCase(rule.phrase)
                    && existing.matchType == rule.matchType
                    && existing.packageName.equals(rule.packageName)) return true;
        }
        return false;
    }

    private String report() {
        return DumpReport.build(dump, diagnosis, prefs.getRules(), prefs.engineSettings(),
                prefs.maskExportEnabled());
    }

    private void copyReport() {
        ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (manager == null) return;
        manager.setPrimaryClip(ClipData.newPlainText("瞬净诊断报告", report()));
        Toast.makeText(this, "报告已复制，可粘贴给 AI", Toast.LENGTH_LONG).show();
    }

    private void shareReport() {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, "瞬净广告诊断报告");
        send.putExtra(Intent.EXTRA_TEXT, report());
        try {
            startActivity(Intent.createChooser(send, "交给 AI 分析"));
        } catch (RuntimeException e) {
            copyReport();
        }
    }

    private void showTree() {
        StringBuilder b = new StringBuilder();
        for (NodeModel n : dump.nodes) {
            b.append('#').append(n.index).append(" p").append(n.parentIndex)
                    .append(' ').append(n.className)
                    .append(" [").append(n.left).append(',').append(n.top).append(',')
                    .append(n.right).append(',').append(n.bottom).append(']')
                    .append(" c=").append(n.clickable ? 1 : 0)
                    .append(" v=").append(n.visible ? 1 : 0)
                    .append(" pwd=").append(n.password ? 1 : 0).append('\n');
            if (!n.viewId.isEmpty()) b.append("    id: ").append(n.viewId).append('\n');
            if (n.password) b.append("    text: [密码字段已隐藏]\n");
            else {
                if (!n.text.isEmpty()) b.append("    text: ").append(clip(n.text)).append('\n');
                if (!n.contentDescription.isEmpty())
                    b.append("    desc: ").append(clip(n.contentDescription)).append('\n');
            }
        }
        TextView view = Ui.text(this, b.toString(), 11, getColor(R.color.text_primary));
        view.setTextIsSelectable(true);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(view);
        new AlertDialog.Builder(this)
                .setTitle("控件树 · " + dump.nodes.size() + " 个节点")
                .setView(scroll)
                .setPositiveButton("关闭", null)
                .show();
    }

    private static String clip(String value) {
        String clean = value.replace('\n', ' ').trim();
        return clean.length() > 100 ? clean.substring(0, 100) + "…" : clean;
    }

    private int verdictColor(Diagnosis.Verdict verdict) {
        switch (verdict) {
            case SKIPPABLE: return getColor(R.color.cyan);
            case PROTECTED:
            case REWARDED: return getColor(R.color.blue);
            case MASTER_OFF:
            case APP_DISABLED:
            case NOT_CLICKABLE: return getColor(R.color.warning);
            default: return getColor(R.color.danger);
        }
    }
}
