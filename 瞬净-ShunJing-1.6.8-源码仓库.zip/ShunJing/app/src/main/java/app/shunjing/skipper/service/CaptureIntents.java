package app.shunjing.skipper.service;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

/** Explicit, app-local intents used to ask the accessibility service to capture a page. */
public final class CaptureIntents {
    public static final String ACTION_CAPTURE = "app.shunjing.skipper.action.CAPTURE";
    public static final String ACTION_DUMP_SAVED = "app.shunjing.skipper.action.DUMP_SAVED";
    public static final String EXTRA_MODE = "mode";
    public static final String MODE_NOW = "now";
    public static final String MODE_NEXT = "next";

    /** v1.5.9：从通知栏按钮进入 / 退出「学习」。 */
    public static final String ACTION_LEARN = "app.shunjing.skipper.action.LEARN";
    public static final String EXTRA_LEARN = "learn";
    public static final String LEARN_START = "start";
    public static final String LEARN_STOP = "stop";

    /** v1.6.2：临时暂停 / 恢复。minutes <= 0 表示恢复。 */
    public static final String ACTION_PAUSE = "app.shunjing.skipper.action.PAUSE";
    public static final String EXTRA_PAUSE_MINUTES = "pause_minutes";

    private CaptureIntents() { }

    public static Intent pause(Context context, int minutes) {
        return new Intent(ACTION_PAUSE)
                .setPackage(context.getPackageName())
                .putExtra(EXTRA_PAUSE_MINUTES, minutes);
    }

    public static PendingIntent pausePending(Context context, int minutes, int requestCode) {
        return PendingIntent.getBroadcast(context, requestCode, pause(context, minutes),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static Intent capture(Context context, String mode) {
        return new Intent(ACTION_CAPTURE)
                .setPackage(context.getPackageName())
                .putExtra(EXTRA_MODE, mode);
    }

    public static PendingIntent capturePending(Context context, String mode, int requestCode) {
        return PendingIntent.getBroadcast(context, requestCode, capture(context, mode),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** 显式指向 LearnReceiver：清单里静态注册，点按钮一定有人接，不看动态注册时机。 */
    public static Intent learn(Context context, String mode) {
        return new Intent(context, LearnReceiver.class)
                .setAction(ACTION_LEARN)
                .putExtra(EXTRA_LEARN, mode);
    }

    public static PendingIntent learnPending(Context context, String mode, int requestCode) {
        return PendingIntent.getBroadcast(context, requestCode, learn(context, mode),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static Intent saved(Context context) {
        return new Intent(ACTION_DUMP_SAVED).setPackage(context.getPackageName());
    }
}
