package app.shunjing.skipper.engine;

import java.util.HashMap;

/**
 * v1.5.4 —— 「点一下关闭，被连拽好几个 App」的连锁跳转拦截。
 *
 * <p>1.5.1 的 {@link ClickOutcomeGuard} 只开一个 2.2 秒窗口、只肯退一次、退完还锁 8 秒。
 * 遇到穿山甲 / 优量汇那类「deeplink 一条接一条」的页面就不够了：第一层退回去以后，
 * 广告页仍然在，SDK 继续把用户往第二个、第三个 App 里送，而守卫已经用完了自己那一次配额，
 * 于是用户被扔在一串陌生应用里，按一次返回只退一层，看起来就是「退不回去了」。
 *
 * <p>所以这里改成<b>跟踪整条链</b>而不是单次点击：
 * <ul>
 *   <li>一次误点之后 9 秒内，每一层跨包跳转都退；</li>
 *   <li>最多退 5 层，同一个目标 App 最多退 2 次 —— 退不动的（比如商店拦返回键）就收手，不跟它拉锯；</li>
 *   <li>两次返回之间至少隔 480ms，避免连按被系统吞掉；</li>
 *   <li>退回原页面后窗口顺延，还能接住下一次自动拉起；</li>
 *   <li>用户 0.9 秒内自己点过屏幕，立刻整条链作废 —— 绝不和用户抢屏幕。</li>
 * </ul>
 *
 * <p>纯状态机，不碰无障碍 API，可单测。
 */
public final class JumpChainGuard {

    /** 一条链最长跟踪时间。超过就当广告页已经翻篇，不再干预。 */
    private static final long WINDOW_MS = 9_000L;
    /** 两次返回的最小间隔：太密会被系统合并/丢弃。 */
    private static final long MIN_GAP_MS = 480L;
    /** 用户自己在操作的豁免窗口。 */
    private static final long USER_GRACE_MS = 900L;
    /** 每退一层之后，暂停自动点击的时长，避免在新应用里又点出下一条链。 */
    private static final long QUIET_MS = 1_400L;
    /** 整条链最多退几层。 */
    private static final int MAX_HOPS = 5;
    /** 同一个目标应用最多退几次；超过说明它退不动。 */
    private static final int PER_TARGET_MAX = 2;

    public enum Result { NONE, REVERT, GIVE_UP }

    private String origin = "";
    private long armedAt = 0L;
    private long lastHopAt = 0L;
    private int hops = 0;
    private final HashMap<String, Integer> targets = new HashMap<>();

    /** 在一次「位置是推断出来的」点击之后调用。 */
    public void arm(String pkg, long now) {
        if (pkg == null || pkg.isEmpty()) return;
        origin = pkg;
        armedAt = now;
        lastHopAt = 0L;
        hops = 0;
        targets.clear();
    }

    public boolean active(long now) {
        return armedAt > 0L && now - armedAt <= WINDOW_MS;
    }

    /** 链还在跑，且刚退过一层 —— 这段时间内不要在任何应用里自动点击。 */
    public boolean paused(long now) {
        return active(now) && hops > 0 && now - lastHopAt < QUIET_MS;
    }

    public String origin() { return origin; }

    public int hops() { return hops; }

    public long lastHopAt() { return lastHopAt; }

    public void disarm() {
        armedAt = 0L;
        hops = 0;
        lastHopAt = 0L;
        targets.clear();
    }

    /**
     * 前台换到了一个新包。
     *
     * @return {@link Result#REVERT} 表示该按一次返回；{@link Result#GIVE_UP} 表示这条链退不动了。
     */
    public Result observe(String pkg, long now, long lastUserClickAt) {
        if (armedAt <= 0L) return Result.NONE;
        if (now - armedAt > WINDOW_MS) { disarm(); return Result.NONE; }
        if (pkg == null || pkg.isEmpty()) return Result.NONE;
        // 用户自己在点：整条链作废，一个返回都不许按。
        if (lastUserClickAt > 0L && now - lastUserClickAt <= USER_GRACE_MS) {
            disarm();
            return Result.NONE;
        }
        // 回桌面多半是用户按了 Home，不是广告干的。
        if (AdDecisionEngine.isLauncherPackage(pkg)) { disarm(); return Result.NONE; }
        // 已经退回原页面：窗口顺延，等它下一次自动拉起。
        if (pkg.equals(origin)) {
            armedAt = now;
            lastHopAt = now;
            return Result.NONE;
        }
        Integer seen = targets.get(pkg);
        int count = seen == null ? 0 : seen;
        if (hops >= MAX_HOPS || count >= PER_TARGET_MAX) { disarm(); return Result.GIVE_UP; }
        targets.put(pkg, count + 1);
        hops++;
        lastHopAt = now;
        return Result.REVERT;
    }

    /**
     * 已经按过返回，但前台仍停在外部应用（说明那一层被压在栈里）。
     * 由复查循环调用，再记一层。
     */
    public boolean noteExtraHop(long now) {
        if (!active(now) || hops >= MAX_HOPS) return false;
        hops++;
        lastHopAt = now;
        return true;
    }

    /** 节流：距离上一次返回还不够久，等一会儿再看。 */
    public boolean coolingDown(long now) {
        return lastHopAt > 0L && now - lastHopAt < MIN_GAP_MS;
    }
}
