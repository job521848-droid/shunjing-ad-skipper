package app.shunjing.skipper.ui;

import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import app.shunjing.skipper.R;
import app.shunjing.skipper.data.LogEntry;
import app.shunjing.skipper.data.Prefs;
import app.shunjing.skipper.service.StatusUtils;

public final class LogsActivity extends BaseActivity {
    private Prefs prefs;
    private final List<LogEntry> entries = new ArrayList<>();
    private LogAdapter adapter;
    private TextView emptyHint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        // v1.5.7: 同诊断页，顶部固定卡片会把列表挤成 0 高且整页不能滚。
        LinearLayout headerBox = new LinearLayout(this);
        headerBox.setOrientation(LinearLayout.VERTICAL);
        headerBox.setPadding(0, Ui.dp(this, 14), 0, 0);
        headerBox.addView(Ui.header(this, "触发日志", "只记录操作结果，不保存页面文字、截图或扫码内容", true));
        LinearLayout summary = Ui.card(this);
        summary.addView(Ui.caption(this, "LOCAL AUDIT TRAIL"));
        summary.addView(Ui.text(this, "累计执行 " + prefs.totalCount() + " 次自动操作", 20,
                getColor(R.color.text_primary)));
        // v1.5.8: 一条记录都没有时，多半不是"没遇到广告"，而是服务根本没连上。
        boolean alive = StatusUtils.isAccessibilityEnabled(this) && !prefs.serviceStale();
        summary.addView(Ui.text(this, alive
                        ? "服务状态：正在接收系统事件"
                        : "服务状态：没有连上，去系统无障碍里关掉再打开一次",
                12, getColor(alive ? R.color.text_secondary : R.color.warning)));
        summary.addView(Ui.text(this, "只保留最近 " + prefs.logKeepLimit()
                        + " 条，超出自动删除；条数可在「智能诊断 → 自动清理」里调整。", 12,
                getColor(R.color.text_secondary)));
        Button clear = Ui.secondary(this, "清空日志");
        clear.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("清空触发日志").setMessage("累计次数会保留，仅删除下面的记录。")
                .setNegativeButton("取消", null)
                .setPositiveButton("清空", (d, w) -> { prefs.clearLogs(); reload(); }).show());
        summary.addView(clear);
        headerBox.addView(summary);

        emptyHint = Ui.text(this, "还没有触发记录\n开启守护后，成功操作会显示在这里", 14,
                getColor(R.color.text_secondary));
        emptyHint.setGravity(Gravity.CENTER);
        emptyHint.setPadding(0, Ui.dp(this, 36), 0, Ui.dp(this, 36));
        headerBox.addView(emptyHint);

        ListView list = new ListView(this);
        list.setBackgroundResource(R.drawable.bg_screen);
        list.setPadding(Ui.dp(this, 20), 0, Ui.dp(this, 20), Ui.dp(this, 20));
        list.setClipToPadding(false);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setVerticalScrollBarEnabled(false);
        list.addHeaderView(headerBox, null, false);
        adapter = new LogAdapter();
        list.setAdapter(adapter);
        setContentView(list);
    }

    @Override protected void onResume() { super.onResume(); reload(); }
    private void reload() {
        entries.clear();
        entries.addAll(prefs.getLogs());
        adapter.notifyDataSetChanged();
        if (emptyHint != null) emptyHint.setVisibility(entries.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private String appLabel(String pkg) {
        try { return getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg, 0)).toString(); }
        catch (PackageManager.NameNotFoundException e) { return pkg; }
    }

    private final class LogAdapter extends BaseAdapter {
        @Override public int getCount() { return entries.size(); }
        @Override public LogEntry getItem(int position) { return entries.get(position); }
        @Override public long getItemId(int position) { return entries.get(position).time; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LogEntry entry = getItem(position);
            LinearLayout card = Ui.card(LogsActivity.this);
            LinearLayout line = new LinearLayout(LogsActivity.this);
            line.setGravity(Gravity.CENTER_VERTICAL);
            TextView action = Ui.text(LogsActivity.this, entry.action, 16, getColor(R.color.cyan));
            action.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
            line.addView(action, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            String time = new SimpleDateFormat("MM-dd HH:mm:ss", Locale.CHINA).format(new Date(entry.time));
            line.addView(Ui.text(LogsActivity.this, time, 11, getColor(R.color.text_secondary)));
            card.addView(line);
            card.addView(Ui.text(LogsActivity.this, appLabel(entry.packageName), 15,
                    getColor(R.color.text_primary)));
            card.addView(Ui.text(LogsActivity.this, entry.detail + "\n" + entry.packageName, 11,
                    getColor(R.color.text_secondary)));
            LinearLayout wrapper = new LinearLayout(LogsActivity.this);
            wrapper.addView(card);
            return wrapper;
        }
    }
}
