package app.shunjing.skipper.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

/** 状态指示灯：实心点 + 一圈慢慢扩散的光环，用来替代"颜色说明一切"。 */
public final class PulseDot extends View {

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private ValueAnimator animator;
    private float phase;
    private int color = 0xFF4EF2D0;
    private boolean pulsing = true;

    public PulseDot(Context context) { super(context); }

    public PulseDot(Context context, AttributeSet attrs) { super(context, attrs); }

    public void setDotColor(int value) {
        if (color == value) return;
        color = value;
        invalidate();
    }

    public void setPulsing(boolean value) {
        if (pulsing == value) return;
        pulsing = value;
        if (value) start(); else stop();
        invalidate();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        start();
    }

    @Override
    protected void onDetachedFromWindow() {
        stop();
        super.onDetachedFromWindow();
    }

    private void start() {
        if (!pulsing || !isAttachedToWindow()) return;
        if (animator == null) {
            animator = ValueAnimator.ofFloat(0f, 1f);
            animator.setDuration(2_400L);
            animator.setRepeatCount(ValueAnimator.INFINITE);
            animator.setInterpolator(new LinearInterpolator());
            animator.addUpdateListener(a -> {
                phase = (float) a.getAnimatedValue();
                invalidate();
            });
        }
        if (!animator.isStarted()) animator.start();
    }

    private void stop() {
        if (animator != null) animator.cancel();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float base = Math.min(getWidth(), getHeight()) * 0.22f;
        base = Math.max(base, Ui.dp(getContext(), 2.6f));

        int r = Color.red(color), g = Color.green(color), b = Color.blue(color);
        if (pulsing) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Ui.dp(getContext(), 1));
            paint.setColor(Color.argb((int) (90 * (1f - phase)), r, g, b));
            canvas.drawCircle(cx, cy, base + (base * 1.9f) * phase, paint);
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(70, r, g, b));
        canvas.drawCircle(cx, cy, base * 1.75f, paint);
        paint.setColor(color);
        canvas.drawCircle(cx, cy, base, paint);
    }
}
