package app.shunjing.skipper.engine;

/**
 * v1.5.3: 广告 SDK 代理页右上角的纯图标关闭键。
 *
 * <p>现场来源两条，指向同一个模板：
 * <ul>
 *   <li>囧次元 / 优量汇 {@code com.qq.e.ads.PortraitADActivity}（36 节点）</li>
 *   <li>囧次元 / 风马 {@code com.windmill.sdk.widget.InterstitialView_4012001}（116 节点）</li>
 * </ul>
 * 两者右上角都是一组 91×91 的容器套 56×56 的 ImageView，<b>整条父链 c=0</b>、
 * 无文字、无 id，文字规则够不着，只能按坐标点。
 *
 * <p>放行条件是"只有 SDK 代理页 + 贴右上角 + 极小 + 无文字"，四条同时成立：
 * 普通 App 页面不满足第一条，卡片主体不满足第二条，装饰点不满足第三条。
 * 敏感页硬锁在 {@link AdDecisionEngine#evaluate} 最前面就已返回，轮不到这里。
 */
public final class CornerCloseLocator {

    public static final class Hit {
        public final int nodeIndex;
        public final String reason;

        Hit(int nodeIndex, String reason) {
            this.nodeIndex = nodeIndex;
            this.reason = reason;
        }
    }

    private CornerCloseLocator() { }

    public static Hit find(ScreenModel screen, int w, int h) {
        if (screen == null || w <= 0 || h <= 0) return null;
        if (!StructuralAdEvidence.sdkActivity(screen.activityName)
                && !StructuralAdEvidence.sdkPlacementId(screen.activityName)) {
            return null;
        }
        long screenArea = (long) w * h;
        Hit best = null;
        long bestArea = Long.MAX_VALUE;
        for (NodeModel n : screen.nodes) {
            if (!n.visible || n.password || !n.hasBounds()) continue;
            // 坐标必须真的落在屏幕里。分屏/双开的窗口坐标系会整体越界，
            // 那种情况交给 BoundsNormalizer 先平移，这里不能"因为越界反而通过"。
            if (n.left < 0 || n.top < 0 || n.right > w || n.bottom > h) continue;
            // 有文字的一律交给文字规则，这里只收"读了也读不出东西"的图标。
            if (!n.normalizedText().isEmpty() || !n.normalizedDescription().isEmpty()) continue;
            String cls = n.className.toLowerCase(java.util.Locale.ROOT);
            if (!cls.endsWith("imageview") && !cls.endsWith("imagebutton")
                    && !cls.endsWith("android.view.view")) continue;
            long area = n.area();
            if (area < screenArea * 0.0002 || area > screenArea * 0.005) continue;
            int centerY = (n.top + n.bottom) / 2;
            if (centerY > h * 18 / 100) continue;
            if (w - n.right > w * 7 / 100) continue;
            if (n.left < w / 2) continue;
            if (area < bestArea) {
                bestArea = area;
                best = new Hit(n.index, "SDK 代理页 · 右上角纯图标关闭键");
            }
        }
        return best;
    }
}
