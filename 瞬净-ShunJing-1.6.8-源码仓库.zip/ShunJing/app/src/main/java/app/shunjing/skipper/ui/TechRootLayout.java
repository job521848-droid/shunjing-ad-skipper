package app.shunjing.skipper.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.widget.LinearLayout;

/**
 * 页面根容器：负责画那层「深空 + 网格 + 光晕」的底。
 *
 * <p>为什么不用一堆 drawable 叠：XML 画不了网格，也画不了带衰减的大面积光晕；
 * 而用 View 画，背景就跟着页面一起滚动定位，不额外占用布局层级。
 *
 * <p>全部是静态绘制，不跑动画 —— 常驻动画的耗电账最后都会算在"这软件怎么这么费电"上。
 */
public final class TechRootLayout extends LinearLayout {

    private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arcPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint topLine = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint flarePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF arcRect = new RectF();
    private int accent;
    private float flare;
    private ValueAnimator flareAnim;

    public TechRootLayout(Context context) {
        super(context);
        init();
    }

    public TechRootLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        setWillNotDraw(false);
        setOrientation(VERTICAL);
        gridPaint.setStyle(Paint.Style.STROKE);
        gridPaint.setStrokeWidth(Ui.dp(getContext(), 0.7f));
        glowPaint.setStyle(Paint.Style.FILL);
        arcPaint.setStyle(Paint.Style.STROKE);
        arcPaint.setStrokeWidth(Ui.dp(getContext(), 1));
        topLine.setStrokeWidth(Ui.dp(getContext(), 1));
    }

    /**
     * 换挡时整页背景跟着换色，并让右上角那团光短暂亮一下 —— 只亮 480ms，
     * 画在子 View 之下，所以只会在卡片缝隙里透出来，不会盖住字。
     */
    public void setAccent(int color) {
        if (color == accent) return;
        accent = color;
        rebuildShaders();
        flare();
        invalidate();
    }

    private void flare() {
        if (!isAttachedToWindow() || Motion.reduced(getContext())) return;
        if (flareAnim != null) flareAnim.cancel();
        flareAnim = ValueAnimator.ofFloat(1f, 0f);
        flareAnim.setDuration(Motion.duration(getContext(), 480L));
        flareAnim.setInterpolator(new android.view.animation.DecelerateInterpolator(1.6f));
        flareAnim.addUpdateListener(animation -> {
            flare = (float) animation.getAnimatedValue();
            invalidate();
        });
        flareAnim.start();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        rebuildShaders();
    }

    private void rebuildShaders() {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;
        int accent = accent();

        // 右上角一团冷光，模拟屏幕外的光源斜照进来
        glowPaint.setShader(new RadialGradient(
                w * 0.86f, -h * 0.04f, Math.max(w, h) * 0.72f,
                new int[]{withAlpha(accent, 30), withAlpha(accent, 8), Color.TRANSPARENT},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));

        // 网格：越往下越淡，避免整页都是格线显得脏
        gridPaint.setShader(new LinearGradient(0f, 0f, 0f, h,
                new int[]{withAlpha(accent, 16), withAlpha(accent, 5), Color.TRANSPARENT},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));

        // 右下角那道大圆弧，只有画面上留白时才会露出来
        float radius = Math.max(w, h) * 0.62f;
        arcRect.set(w - radius * 1.1f, h - radius * 0.75f, w + radius * 0.9f, h + radius * 1.25f);
        arcPaint.setShader(new LinearGradient(w, h * 0.4f, w * 0.4f, h,
                withAlpha(accent, 55), Color.TRANSPARENT, Shader.TileMode.CLAMP));

        topLine.setShader(new LinearGradient(w * 0.08f, 0f, w * 0.92f, 0f,
                new int[]{Color.TRANSPARENT, withAlpha(accent, 70), Color.TRANSPARENT},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));

        // 换挡闪光：比常驻光晕更集中、更亮，只在 480ms 内可见
        flarePaint.setShader(new RadialGradient(w * 0.86f, -h * 0.04f, Math.max(w, h) * 0.62f,
                withAlpha(accent, 96), Color.TRANSPARENT, Shader.TileMode.CLAMP));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        canvas.drawRect(0, 0, w, h, glowPaint);

        int step = Ui.dp(getContext(), 56);
        for (int x = step; x < w; x += step) {
            canvas.drawLine(x, 0, x, h, gridPaint);
        }
        for (int y = step; y < h; y += step) {
            canvas.drawLine(0, y, w, y, gridPaint);
        }

        canvas.drawArc(arcRect, 180f, 90f, false, arcPaint);
        canvas.drawLine(w * 0.1f, 0.5f, w * 0.9f, 0.5f, topLine);

        if (flare > 0.001f) {
            flarePaint.setAlpha((int) (255 * Motion.clamp01(flare)));
            canvas.drawRect(0f, 0f, w, h, flarePaint);
            flarePaint.setAlpha(255);
        }
    }

    private int accent() {
        return accent != 0 ? accent : Ui.accentOf(getContext());
    }

    private static int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }
}
