package app.shunjing.skipper.ui;

/**
 * 启动动效的时间轴（1.6.1）。
 *
 * <p>上一版整段只有 1.04 秒：光条刚合拢、名字还没看清就切到首页，快是真的快，
 * 但"没看见什么" —— 开场动效的价值在于让用户确认「我在等的是这个 App」，
 * 而不是抢在广告前面结束。这一版把总时长放到 2.34 秒，并且把节奏拆成
 * <b>合拢 → 点亮 → 冲击 → 落名 → 状态切换 → 拉开</b> 六段，
 * 每一段都有明确的视觉落点，慢下来但每一帧都在变化，不是干等。
 *
 * <p>时间点全部放在这里，而不是散落在 render() 里：改节奏只动这一张表，
 * 单元测试也能直接断言"冲击必须在标题落位之前""拉开之前首页必须已经入场"。
 */
public final class BootTimeline {

    /** 两侧光条开始合拢。 */
    public static final long BARS_IN = 110L;
    /** 光条合拢到位并开始消隐。 */
    public static final long BARS_LOCK = 760L;

    /** 核心环开始显形。 */
    public static final long ORB_IN = 360L;
    /** 核心环完全到位（与冲击同一拍收住）。 */
    public static final long ORB_FULL = 900L;

    /** 冲击：冲击波 + 白闪 + 第一拍震动，全部在这一毫秒。 */
    public static final long IMPACT = 820L;

    /** 标题落定。 */
    public static final long WORD_FULL = 1_240L;
    /** 副标题开始 / 落定。 */
    public static final long SUB_IN = 1_020L;
    public static final long SUB_FULL = 1_400L;

    /** 底部状态文案从"规则装载"切到"防护就绪"。 */
    public static final long STATUS_SWAP = 1_520L;
    /** 首页在幕布后面开始入场（此时还在遮罩之下，看不见）。 */
    public static final long PREPARE = 1_600L;

    /** 幕布开始拉开：底色先退，首页推近，光条向两侧划出。 */
    public static final long EXIT = 1_920L;
    /** 整段结束，移除遮罩。 */
    public static final long TOTAL = 2_340L;

    private BootTimeline() { }

    /** 拉开进度 0..1。 */
    public static float exit(long t) {
        return Motion.clamp01((t - EXIT) / (float) (TOTAL - EXIT));
    }

    /** 从 start 起、长 length 的窗口进度 0..1；越界自动夹住。 */
    public static float span(long t, long start, long length) {
        if (length <= 0L) return t >= start ? 1f : 0f;
        return Motion.clamp01((t - start) / (float) length);
    }
}
