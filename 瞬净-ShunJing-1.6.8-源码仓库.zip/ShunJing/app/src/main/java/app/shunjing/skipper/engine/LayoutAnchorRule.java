package app.shunjing.skipper.engine;

import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * A strictly-scoped geometric rule for pure-image close buttons (no text, no description,
 * no resource id) such as the one on 闪动校园 / DSP interstitial cards.
 *
 * <p>Safety design — every condition below is mandatory and NOT user-tunable:
 * <ul>
 *   <li>Scoped to ONE package AND ONE Activity fragment (never global).</li>
 *   <li>Still requires an independent ad context supplied by the caller.</li>
 *   <li>Sensitive-page hard lock is re-checked here as well as in the engine.</li>
 *   <li>Only a small, clickable, label-less ImageView in the TOP-RIGHT of a centered,
 *       NON-fullscreen card qualifies. Large CTA buttons carrying text are excluded.</li>
 * </ul>
 *
 * <p>This is a heuristic, not semantic recognition. It is off by default and must be enabled
 * explicitly by the user.
 */
public final class LayoutAnchorRule {
    /** Card width as a fraction of screen width. */
    private static final float CARD_W_MIN = 0.60f, CARD_W_MAX = 0.90f;
    /** Card height as a fraction of screen height. */
    private static final float CARD_H_MIN = 0.45f, CARD_H_MAX = 0.80f;
    /** Minimum inset on every side of the card. */
    private static final float CARD_INSET_X = 0.08f, CARD_INSET_Y = 0.08f;
    /** Close icon side length as a fraction of screen width. */
    private static final float ICON_MIN = 0.05f, ICON_MAX = 0.12f;
    /** Max distance from the icon to the card's top/right edges. */
    private static final float ICON_EDGE_X = 0.05f, ICON_EDGE_Y = 0.05f;
    private static final float ICON_ASPECT_MIN = 0.60f, ICON_ASPECT_MAX = 1.70f;

    public final String id;
    public final String packageName;
    public final String activityFragment;
    public final boolean enabled;
    /** Human-readable description of the geometry captured when the rule was created. */
    public final String description;

    public LayoutAnchorRule(String id, String packageName, String activityFragment,
                            boolean enabled, String description) {
        this.id = id;
        this.packageName = packageName == null ? "" : packageName;
        this.activityFragment = activityFragment == null ? "" : activityFragment;
        this.enabled = enabled;
        this.description = description == null ? "" : description;
    }

    public static LayoutAnchorRule create(String packageName, String activityFragment,
                                          String description) {
        return new LayoutAnchorRule(UUID.randomUUID().toString(), packageName,
                activityFragment, true, description);
    }

    public LayoutAnchorRule withEnabled(boolean value) {
        return new LayoutAnchorRule(id, packageName, activityFragment, value, description);
    }

    /** Returns the node index of the close control, or -1 when no safe target exists. */
    public int findTarget(ScreenModel screen, boolean adContext, int screenWidth, int screenHeight) {
        if (!enabled || !adContext) return -1;
        if (packageName.isEmpty() || activityFragment.isEmpty()) return -1;
        if (!packageName.equals(screen.packageName)) return -1;
        String activity = screen.activityName.toLowerCase(Locale.ROOT);
        if (!activity.contains(activityFragment.toLowerCase(Locale.ROOT))) return -1;
        if (AdDecisionEngine.isSensitive(screen) || AdDecisionEngine.isProtectedPackage(screen.packageName)) {
            return -1;
        }
        int w = screenWidth > 0 ? screenWidth : inferWidth(screen.nodes);
        int h = screenHeight > 0 ? screenHeight : inferHeight(screen.nodes);
        if (w <= 0 || h <= 0) return -1;

        for (NodeModel card : screen.nodes) {
            if (!isCenteredCard(card, w, h)) continue;
            int target = findCornerIcon(screen.nodes, card, w, h);
            if (target >= 0) return target;
        }
        return -1;
    }

    private boolean isCenteredCard(NodeModel card, int w, int h) {
        if (!card.visible || card.password || !card.hasBounds()) return false;
        if (!isContainerClass(card.className)) return false;
        float cw = card.right - card.left;
        float ch = card.bottom - card.top;
        if (cw < w * CARD_W_MIN || cw > w * CARD_W_MAX) return false;
        if (ch < h * CARD_H_MIN || ch > h * CARD_H_MAX) return false;
        if (card.left < w * CARD_INSET_X || (w - card.right) < w * CARD_INSET_X) return false;
        if (card.top < h * CARD_INSET_Y || (h - card.bottom) < h * CARD_INSET_Y) return false;
        return true;
    }

    private int findCornerIcon(List<NodeModel> nodes, NodeModel card, int w, int h) {
        float minSide = w * ICON_MIN, maxSide = w * ICON_MAX;
        for (NodeModel n : nodes) {
            if (n.parentIndex != card.index) continue;      // direct child of the card only
            if (!n.visible || n.password || !n.hasBounds()) continue;
            if (AdDecisionEngine.findClickableAncestor(nodes, n) < 0) continue;
            if (!isImageClass(n.className)) continue;
            // A pure image control: no text, no description, no resource id.
            if (!n.normalizedText().isEmpty() || !n.normalizedDescription().isEmpty()) continue;
            if (!n.viewId.isEmpty()) continue;
            float bw = n.right - n.left, bh = n.bottom - n.top;
            if (bw < minSide || bw > maxSide || bh < minSide || bh > maxSide) continue;
            float aspect = bw / bh;
            if (aspect < ICON_ASPECT_MIN || aspect > ICON_ASPECT_MAX) continue;
            if (card.right - n.right > w * ICON_EDGE_X || n.right > card.right) continue;
            if (n.top - card.top > h * ICON_EDGE_Y || n.top < card.top) continue;
            return n.index;
        }
        return -1;
    }

    private static boolean isContainerClass(String name) {
        String c = safe(name).toLowerCase(Locale.ROOT);
        return c.endsWith("linearlayout") || c.endsWith("framelayout")
                || c.endsWith("relativelayout") || c.endsWith("constraintlayout")
                || c.endsWith("viewgroup") || c.contains("cardview");
    }

    private static boolean isImageClass(String name) {
        String c = safe(name).toLowerCase(Locale.ROOT);
        return c.endsWith("imageview") || c.endsWith("imagebutton")
                || c.endsWith("appcompatimagebutton") || c.endsWith("appcompatimageview");
    }

    private static int inferWidth(List<NodeModel> nodes) {
        int w = 0;
        for (NodeModel n : nodes) if (n.visible) w = Math.max(w, n.right);
        return w;
    }

    private static int inferHeight(List<NodeModel> nodes) {
        int h = 0;
        for (NodeModel n : nodes) if (n.visible) h = Math.max(h, n.bottom);
        return h;
    }

    private static String safe(String value) { return value == null ? "" : value; }
}
