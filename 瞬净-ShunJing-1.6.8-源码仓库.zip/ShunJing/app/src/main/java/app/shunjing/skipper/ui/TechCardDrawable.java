package app.shunjing.skipper.ui;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/**
 * 卡片底：一层半透明深色玻璃 + 一圈只有上半部分看得见的描边 + 两个 HUD 切角。
 *
 * <p>比纯色圆角矩形多出来的三样东西，正是"科技感"的来源：
 * 边缘不是均匀的（光从左上来），所以描边用渐变而不是实色；
 * 顶上留一道 1px 高光，看起来像玻璃有厚度；
 * 左上角/右下角各一小段折线，像仪表盘上的定位角标。
 *
 * <p>v1.5.13 起多了一个 {@link #setSweep(float)}：换挡时一道斜向光带从左下扫到右上，
 * 像扫描仪扫过表面。着色器只在尺寸变化时建一次 —— 滚动时每帧新建对象会拉扯 GC。
 */
public final class TechCardDrawable extends Drawable {

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint highlight = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint corner = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint innerGlow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sheen = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path cornerPath = new Path();
    private final Path clipPath = new Path();
    private final float radius;
    private final int padH;
    private final int padV;
    private final float mark;
    private int accent;
    private float sweep = -1f;

    public TechCardDrawable(float radiusPx, float markPx, int padHorizontal, int padVertical,
                            int accentColor) {
        this.radius = radiusPx;
        this.mark = markPx;
        this.padH = padHorizontal;
        this.padV = padVertical;
        this.accent = accentColor;
        highlight.setStyle(Paint.Style.STROKE);
        highlight.setStrokeWidth(1f);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(1f);
        corner.setStyle(Paint.Style.STROKE);
        corner.setStrokeWidth(Math.max(1.5f, markPx * 0.16f));
        corner.setStrokeCap(Paint.Cap.SQUARE);
        innerGlow.setStyle(Paint.Style.STROKE);
        innerGlow.setStrokeWidth(1.2f);
        sheen.setStyle(Paint.Style.FILL);
    }

    /** 换挡时卡片描边、内发光跟着换色，整块界面才是"一起换挡"。 */
    public void setAccent(int color) {
        if (color == accent) return;
        accent = color;
        buildShaders();
        invalidateSelf();
    }

    /**
     * 扫光进度：0 刚进入左下角，1 已扫出右上角；-1 表示不放。
     * 由外部的 ValueAnimator 驱动，这里只负责画。
     */
    public void setSweep(float value) {
        sweep = value;
        invalidateSelf();
    }

    @Override
    protected void onBoundsChange(Rect bounds) {
        super.onBoundsChange(bounds);
        if (bounds.isEmpty()) return;
        rect.set(bounds.left + 0.5f, bounds.top + 0.5f, bounds.right - 0.5f, bounds.bottom - 0.5f);
        clipPath.reset();
        clipPath.addRoundRect(rect, radius, radius, Path.Direction.CW);
        buildShaders();
    }

    private void buildShaders() {
        if (rect.isEmpty()) return;
        fill.setShader(new LinearGradient(rect.left, rect.top, rect.left, rect.bottom,
                new int[]{0xF2162338, 0xF00B1524, 0xF8090F1B}, new float[]{0f, 0.55f, 1f},
                Shader.TileMode.CLAMP));
        innerGlow.setShader(new LinearGradient(rect.left, rect.top, rect.right, rect.bottom,
                withAlpha(accent, 34), Color.TRANSPARENT, Shader.TileMode.CLAMP));
        stroke.setShader(new LinearGradient(rect.left, rect.top, rect.right, rect.bottom,
                new int[]{withAlpha(accent, 120), withAlpha(accent, 40), withAlpha(accent, 12)},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        highlight.setShader(new LinearGradient(rect.left + mark * 1.6f, 0f,
                rect.right - mark * 1.6f, 0f,
                Color.TRANSPARENT, 0x24FFFFFF, Shader.TileMode.CLAMP));
    }

    @Override
    public void draw(Canvas canvas) {
        if (rect.isEmpty()) return;

        canvas.drawRoundRect(rect, radius, radius, fill);
        // 贴着填充内侧的一圈微光，让卡片"浮"起来
        canvas.drawRoundRect(rect, radius, radius, innerGlow);
        // 描边：左上亮、右下暗
        canvas.drawRoundRect(rect, radius, radius, stroke);

        // 顶部高光：只有中间那一段，两端淡出
        float top = rect.top + radius * 0.55f;
        canvas.drawLine(rect.left + mark * 1.6f, top, rect.right - mark * 1.6f, top, highlight);

        corner.setColor(withAlpha(accent, 150));
        cornerPath.reset();
        // 左上
        cornerPath.moveTo(rect.left + mark, rect.top + radius * 0.9f);
        cornerPath.lineTo(rect.left + mark, rect.top + mark);
        cornerPath.lineTo(rect.left + radius * 0.9f, rect.top + mark);
        // 右下
        cornerPath.moveTo(rect.right - mark, rect.bottom - radius * 0.9f);
        cornerPath.lineTo(rect.right - mark, rect.bottom - mark);
        cornerPath.lineTo(rect.right - radius * 0.9f, rect.bottom - mark);
        canvas.drawPath(cornerPath, corner);

        drawSweep(canvas);
    }

    /** 斜向扫光：一条比卡片还宽的柔光带，从左上外侧滑到右下外侧。 */
    private void drawSweep(Canvas canvas) {
        if (sweep < 0f || sweep > 1f) return;
        float diagonal = (float) Math.hypot(rect.width(), rect.height());
        float travel = rect.centerX() - diagonal * 0.5f + diagonal * sweep;
        float band = Math.max(rect.height() * 0.55f, 48f);

        canvas.save();
        canvas.clipPath(clipPath);
        canvas.rotate(-18f, rect.centerX(), rect.centerY());
        sheen.setShader(new LinearGradient(travel - band, 0f, travel + band, 0f,
                new int[]{0x00FFFFFF, 0x12FFFFFF, 0x1FFFFFFF, 0x12FFFFFF, 0x00FFFFFF},
                new float[]{0f, 0.32f, 0.5f, 0.68f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRect(rect.left - band, rect.top - band, rect.right + band, rect.bottom + band, sheen);
        sheen.setShader(null);
        canvas.restore();
    }

    @Override
    public boolean getPadding(Rect padding) {
        padding.set(padH, padV, padH, padV);
        return true;
    }

    @Override
    public void setAlpha(int alpha) { }

    @Override
    public void setColorFilter(android.graphics.ColorFilter colorFilter) { }

    @Override
    public int getOpacity() {
        return android.graphics.PixelFormat.TRANSLUCENT;
    }

    private static int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }
}
