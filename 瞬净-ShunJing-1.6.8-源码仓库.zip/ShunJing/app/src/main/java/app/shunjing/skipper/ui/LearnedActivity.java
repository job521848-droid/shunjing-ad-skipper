package app.shunjing.skipper.ui;

import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import app.shunjing.skipper.R;
import app.shunjing.skipper.data.Prefs;
import app.shunjing.skipper.engine.LearnedClose;

/** 学到的关闭位置：看得见、能删掉，用户才敢用。 */
public final class LearnedActivity extends BaseActivity {

    private Prefs prefs;
    private final List<LearnedClose> items = new ArrayList<>();
    private Adapter adapter;
    private TextView emptyHint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(0, Ui.dp(this, 14), 0, 0);
        header.addView(Ui.header(this, "学习记录", "你亲手教过的关闭位置，只在本应用本页面生效", true));

        LinearLayout intro = Ui.card(this);
        intro.addView(Ui.caption(this, "LEARNED ON THIS DEVICE"));
        intro.addView(Ui.text(this,
                "三步：① 等广告真的出现在屏幕上 → ② 下拉通知栏点「学习」→ ③ 自己手动把广告关掉。\n"
                        + "关掉后不用再点任何按钮，它会自己收尾。学到位置只绑定当前应用的这个页面，"
                        + "换了页面不会乱点；如果哪次点完反而跳转，这条记录会被自动删掉。",
                13, getColor(R.color.text_secondary)));
        Button clear = Ui.secondary(this, "全部清空");
        clear.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("清空学习记录")
                .setMessage("删除后这些页面会回到「只靠内置规则识别」的状态。")
                .setNegativeButton("取消", null)
                .setPositiveButton("清空", (d, w) -> {
                    prefs.clearLearnedCloses();
                    reload();
                }).show());
        LinearLayout.LayoutParams clearParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clearParams.topMargin = Ui.dp(this, 12);
        intro.addView(clear, clearParams);
        header.addView(intro);

        emptyHint = Ui.text(this, "还没有学过任何关闭位置\n\n下拉通知栏点「学习」试试",
                14, getColor(R.color.text_secondary));
        emptyHint.setGravity(Gravity.CENTER);
        emptyHint.setPadding(0, Ui.dp(this, 36), 0, Ui.dp(this, 36));
        header.addView(emptyHint);

        ListView list = new ListView(this);
        list.setBackgroundResource(R.drawable.bg_screen);
        list.setPadding(Ui.dp(this, 20), 0, Ui.dp(this, 20), Ui.dp(this, 20));
        list.setClipToPadding(false);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setVerticalScrollBarEnabled(false);
        list.addHeaderView(header, null, false);
        adapter = new Adapter();
        list.setAdapter(adapter);
        setContentView(list);
    }

    @Override
    protected void onResume() {
        super.onResume();
        reload();
    }

    private void reload() {
        items.clear();
        items.addAll(prefs.learnedCloses());
        if (adapter != null) adapter.notifyDataSetChanged();
        if (emptyHint != null) emptyHint.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private String appLabel(String pkg) {
        try {
            return getPackageManager().getApplicationLabel(
                    getPackageManager().getApplicationInfo(pkg, 0)).toString();
        } catch (PackageManager.NameNotFoundException e) {
            return pkg;
        }
    }

    private static String positionLabel(LearnedClose close) {
        float cx = (close.leftRatio + close.rightRatio) / 2f;
        float cy = (close.topRatio + close.bottomRatio) / 2f;
        String horizontal = cx > 0.66f ? "靠右" : cx < 0.34f ? "靠左" : "居中";
        String vertical = cy < 0.25f ? "顶部" : cy > 0.75f ? "底部" : "中段";
        return vertical + horizontal + " " + Math.round(cx * 100) + "% , " + Math.round(cy * 100) + "%";
    }

    private static String shortActivity(String activity) {
        if (activity == null || activity.isEmpty()) return "未记录页面";
        int dot = activity.lastIndexOf('.');
        return dot >= 0 && dot < activity.length() - 1 ? activity.substring(dot + 1) : activity;
    }

    private final class Adapter extends BaseAdapter {
        @Override public int getCount() { return items.size(); }
        @Override public LearnedClose getItem(int position) { return items.get(position); }
        @Override public long getItemId(int position) { return getItem(position).createdAt; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LearnedClose close = getItem(position);
            LinearLayout card = Ui.card(LearnedActivity.this);

            LinearLayout line = new LinearLayout(LearnedActivity.this);
            line.setGravity(Gravity.CENTER_VERTICAL);
            TextView name = Ui.text(LearnedActivity.this, appLabel(close.packageName), 16,
                    getColor(R.color.text_primary));
            name.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
            line.addView(name, new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            String time = new SimpleDateFormat("MM-dd HH:mm", Locale.CHINA)
                    .format(new Date(close.createdAt));
            line.addView(Ui.text(LearnedActivity.this, time, 11, getColor(R.color.text_secondary)));
            card.addView(line);

            card.addView(Ui.text(LearnedActivity.this, shortActivity(close.activityName),
                    12, getColor(R.color.text_secondary)));

            LinearLayout foot = new LinearLayout(LearnedActivity.this);
            foot.setGravity(Gravity.CENTER_VERTICAL);
            foot.setPadding(0, Ui.dp(LearnedActivity.this, 6), 0, 0);
            TextView where = Ui.text(LearnedActivity.this, positionLabel(close), 12,
                    getColor(R.color.cyan));
            foot.addView(where, new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            Button delete = Ui.secondary(LearnedActivity.this, "删除");
            delete.setMinHeight(Ui.dp(LearnedActivity.this, 34));
            delete.setTextSize(12);
            delete.setOnClickListener(v -> {
                prefs.deleteLearnedClose(close.packageName, close.activityName);
                reload();
            });
            foot.addView(delete);
            card.addView(foot);
            return card;
        }
    }
}
