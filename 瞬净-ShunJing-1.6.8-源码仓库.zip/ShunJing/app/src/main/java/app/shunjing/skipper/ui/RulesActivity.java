package app.shunjing.skipper.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import app.shunjing.skipper.R;
import app.shunjing.skipper.data.Prefs;
import app.shunjing.skipper.engine.Rule;

public final class RulesActivity extends BaseActivity {
    private Prefs prefs;
    private RuleAdapter adapter;
    private final List<Rule> rules = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        LinearLayout root = Ui.root(this);
        root.addView(Ui.header(this, "规则中枢", "内置规则 + 自定义关闭词，按应用精准生效", true));

        LinearLayout intro = Ui.card(this);
        intro.addView(Ui.text(this, "添加特殊关闭词", 17, getColor(R.color.text_primary)));
        intro.addView(Ui.text(this, "遇到未覆盖的关闭文案时，输入控件上显示的文字或无障碍描述。默认要求页面同时存在广告线索，最大程度避免误点。",
                13, getColor(R.color.text_secondary)));
        Button add = Ui.primary(this, "+  添加自定义规则");
        add.setOnClickListener(v -> showAddDialog());
        LinearLayout.LayoutParams addParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        addParams.setMargins(0, Ui.dp(this, 12), 0, 0);
        intro.addView(add, addParams);
        root.addView(intro);

        TextView count = Ui.caption(this, "规则列表");
        count.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 8));
        root.addView(count);
        ListView list = new ListView(this);
        list.setDivider(null);
        list.setDividerHeight(0);
        adapter = new RuleAdapter();
        list.setAdapter(adapter);
        TextView empty = Ui.text(this, "暂无规则", 14, getColor(R.color.text_secondary));
        empty.setGravity(Gravity.CENTER);
        root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        reload();
    }

    private void reload() {
        rules.clear();
        rules.addAll(prefs.getRules());
        adapter.notifyDataSetChanged();
    }

    private void showAddDialog() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(Ui.dp(this, 22), Ui.dp(this, 8), Ui.dp(this, 22), 0);
        EditText phrase = Ui.input(this, "关闭词，例如：点我关闭");
        form.addView(phrase);
        EditText packageInput = Ui.input(this, "限定应用包名（留空为所有应用）");
        LinearLayout.LayoutParams fieldParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        fieldParams.setMargins(0, Ui.dp(this, 12), 0, 0);
        form.addView(packageInput, fieldParams);
        RadioGroup matchGroup = new RadioGroup(this);
        matchGroup.setOrientation(LinearLayout.HORIZONTAL);
        matchGroup.setPadding(0, Ui.dp(this, 14), 0, 0);
        RadioButton exact = new RadioButton(this);
        exact.setText("精确匹配");
        exact.setId(View.generateViewId());
        exact.setChecked(true);
        RadioButton contains = new RadioButton(this);
        contains.setText("包含匹配");
        contains.setId(View.generateViewId());
        RadioButton byId = new RadioButton(this);
        byId.setText("控件ID");
        byId.setId(View.generateViewId());
        matchGroup.addView(exact);
        matchGroup.addView(contains);
        matchGroup.addView(byId);
        form.addView(matchGroup);
        TextView idHint = Ui.text(this,
                "控件ID：填入按钮的资源 ID 片段（如 ad_close），用于没有文字的纯图片关闭按钮。",
                11, getColor(R.color.text_secondary));
        form.addView(idHint);
        CheckBox context = new CheckBox(this);
        context.setText("仅在检测到广告上下文时触发（推荐）");
        context.setTextColor(getColor(R.color.text_secondary));
        context.setChecked(true);
        form.addView(context);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("新增关闭词")
                .setView(form)
                .setNegativeButton("取消", null)
                .setPositiveButton("添加", null)
                .create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(click -> {
            String value = phrase.getText().toString().trim();
            String pkg = packageInput.getText().toString().trim();
            if (value.isEmpty()) {
                phrase.setError("请输入关闭词");
                return;
            }
            if (value.length() > 40) {
                phrase.setError("关闭词请控制在 40 字以内");
                return;
            }
            if (!pkg.isEmpty() && !pkg.contains(".")) {
                packageInput.setError("请输入完整包名，或留空");
                return;
            }
            for (Rule rule : rules) {
                if (rule.phrase.equalsIgnoreCase(value) && rule.packageName.equals(pkg)) {
                    phrase.setError("相同关闭词已存在");
                    return;
                }
            }
            Rule.MatchType type = byId.isChecked() ? Rule.MatchType.ID
                    : contains.isChecked() ? Rule.MatchType.CONTAINS : Rule.MatchType.EXACT;
            prefs.addCustomRule(Rule.custom(value, type, context.isChecked(), pkg));
            reload();
            dialog.dismiss();
            Toast.makeText(this, "规则已添加并即时生效", Toast.LENGTH_SHORT).show();
        }));
        dialog.show();
    }

    private final class RuleAdapter extends BaseAdapter {
        @Override public int getCount() { return rules.size(); }
        @Override public Rule getItem(int position) { return rules.get(position); }
        @Override public long getItemId(int position) { return rules.get(position).id.hashCode(); }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LinearLayout row = new LinearLayout(RulesActivity.this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setBackgroundResource(R.drawable.bg_panel);
            row.setPadding(Ui.dp(RulesActivity.this, 16), Ui.dp(RulesActivity.this, 12),
                    Ui.dp(RulesActivity.this, 12), Ui.dp(RulesActivity.this, 12));
            LinearLayout labels = new LinearLayout(RulesActivity.this);
            labels.setOrientation(LinearLayout.VERTICAL);
            Rule rule = getItem(position);
            TextView phrase = Ui.text(RulesActivity.this, rule.phrase, 17, getColor(R.color.text_primary));
            phrase.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
            labels.addView(phrase);
            String category = rule.builtIn ? "内置" : "自定义";
            String match = rule.matchType == Rule.MatchType.EXACT ? "精确"
                    : rule.matchType == Rule.MatchType.ID ? "控件ID" : "包含";
            String scope = rule.packageName.isEmpty() ? "全部应用" : rule.packageName;
            String guard = rule.requiresAdContext ? "需广告上下文" : "可直接触发";
            labels.addView(Ui.text(RulesActivity.this, category + " · " + match + " · " + guard + "\n" + scope,
                    11, getColor(R.color.text_secondary)));
            row.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            if (!rule.builtIn) {
                TextView delete = Ui.text(RulesActivity.this, "删除", 13, getColor(R.color.danger));
                delete.setPadding(Ui.dp(RulesActivity.this, 10), 0, Ui.dp(RulesActivity.this, 8), 0);
                delete.setOnClickListener(v -> new AlertDialog.Builder(RulesActivity.this)
                        .setTitle("删除规则")
                        .setMessage("确定删除“" + rule.phrase + "”吗？")
                        .setNegativeButton("取消", null)
                        .setPositiveButton("删除", (d, w) -> {
                            prefs.deleteCustomRule(rule.id);
                            reload();
                        }).show());
                row.addView(delete);
            }
            Switch enabled = new Switch(RulesActivity.this);
            enabled.setChecked(rule.enabled);
            enabled.setOnCheckedChangeListener((button, checked) -> {
                if (rule.builtIn) prefs.setBuiltInRuleEnabled(rule.id, checked);
                else prefs.setCustomRuleEnabled(rule.id, checked);
            });
            row.addView(enabled);
            LinearLayout wrapper = new LinearLayout(RulesActivity.this);
            wrapper.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
            wrapper.setPadding(0, 0, 0, Ui.dp(RulesActivity.this, 8));
            return wrapper;
        }
    }
}
