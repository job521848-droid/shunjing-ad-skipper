package app.shunjing.skipper.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import app.shunjing.skipper.R;

public final class Ui {
    /** 当前模式的强调色。由 BaseActivity 在 onCreate 时写入，让所有页面的小标题、箭头统一换色。 */
    private static int accentColor = 0;

    private Ui() { }

    public static void setAccent(int color) { accentColor = color; }

    /** 供自绘背景（TechRootLayout）取当前模式色。 */
    public static int accentOf(Context context) { return accent(context); }

    private static int accent(Context context) {
        return accentColor == 0 ? context.getColor(R.color.cyan) : accentColor;
    }

    public static int dp(Context context, float value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    public static LinearLayout root(Context context) {
        TechRootLayout root = new TechRootLayout(context);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundResource(R.drawable.bg_screen);
        root.setPadding(dp(context, 20), dp(context, 14), dp(context, 20), dp(context, 20));
        return root;
    }

    public static TextView text(Context context, String value, float size, int color) {
        TextView view = new TextView(context);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setLineSpacing(dp(context, 3), 1f);
        return view;
    }

    public static TextView title(Context context, String value) {
        TextView view = text(context, value, 25, context.getColor(R.color.text_primary));
        view.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return view;
    }

    public static TextView caption(Context context, String value) {
        TextView view = text(context, value, 12, accent(context));
        view.setLetterSpacing(0.14f);
        view.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return view;
    }

    public static LinearLayout card(Context context) {
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(new TechCardDrawable(
                dp(context, 18), dp(context, 14), dp(context, 18), dp(context, 16), accent(context)));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, dp(context, 8), 0, dp(context, 8));
        card.setLayoutParams(params);
        return card;
    }

    public static Button primary(Context context, String value) {
        Button button = new Button(context);
        button.setText(value);
        button.setTextSize(15);
        button.setTextColor(context.getColor(R.color.ink));
        button.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        button.setAllCaps(false);
        button.setMinHeight(dp(context, 48));
        button.setBackgroundResource(R.drawable.bg_button);
        button.setGravity(Gravity.CENTER);
        button.setLetterSpacing(0.04f);
        button.setStateListAnimator(android.animation.AnimatorInflater.loadStateListAnimator(
                context, R.animator.press_scale));
        return button;
    }

    public static Button secondary(Context context, String value) {
        Button button = primary(context, value);
        button.setTextColor(context.getColor(R.color.text_primary));
        button.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.NORMAL);
        button.setBackgroundResource(R.drawable.bg_button_secondary);
        return button;
    }

    public static EditText input(Context context, String hint) {
        EditText input = new EditText(context);
        input.setHint(hint);
        input.setTextColor(context.getColor(R.color.text_primary));
        input.setHintTextColor(context.getColor(R.color.text_secondary));
        input.setBackgroundResource(R.drawable.bg_input);
        input.setPadding(dp(context, 14), dp(context, 12), dp(context, 14), dp(context, 12));
        input.setSingleLine(true);
        return input;
    }

    public static LinearLayout header(Activity activity, String title, String subtitle, boolean back) {
        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, dp(activity, 8), 0, dp(activity, 16));
        if (back) {
            TextView backButton = text(activity, "‹  返回", 16, accent(activity));
            backButton.setGravity(Gravity.CENTER_VERTICAL);
            backButton.setPadding(0, dp(activity, 8), 0, dp(activity, 16));
            backButton.setOnClickListener(v -> activity.finish());
            header.addView(backButton);
        }
        header.addView(title(activity, title));
        TextView sub = text(activity, subtitle, 13, activity.getColor(R.color.text_secondary));
        sub.setPadding(0, dp(activity, 5), 0, 0);
        header.addView(sub);
        return header;
    }

    public static View divider(Context context) {
        View view = new View(context);
        int accent = accent(context);
        GradientDrawable line = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.TRANSPARENT, withAlpha(accent, 46), Color.TRANSPARENT});
        view.setBackground(line);
        view.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 1)));
        return view;
    }

    private static int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    /** 等宽数字：统计数字用它，电量/次数跳变时不会左右抖。 */
    public static TextView stat(Context context, String value, float size, int color) {
        TextView view = text(context, value, size, color);
        view.setTypeface(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD);
        view.setLetterSpacing(0.02f);
        return view;
    }

    public static GradientDrawable badge(Context context, int color) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(Color.TRANSPARENT);
        drawable.setCornerRadius(dp(context, 30));
        drawable.setStroke(dp(context, 1), color);
        return drawable;
    }

    /** 模式卡片左侧的档位光条：一档一个颜色，切换时整条换色。 */
    public static GradientDrawable accentBar(Context context, int color) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setColor(color);
        drawable.setCornerRadius(dp(context, 3));
        return drawable;
    }

    /** 主按钮跟随模式换色，按下时压暗一档，保留按压反馈。 */
    public static android.graphics.drawable.Drawable primaryGradient(Context context,
                                                                     int start, int end) {
        android.graphics.drawable.StateListDrawable states =
                new android.graphics.drawable.StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed},
                gradient(context, darken(start), darken(end)));
        states.addState(new int[]{}, gradient(context, start, end));
        return states;
    }

    private static GradientDrawable gradient(Context context, int start, int end) {
        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT, new int[]{start, end});
        drawable.setCornerRadius(dp(context, 14));
        drawable.setStroke(dp(context, 1), 0x3DFFFFFF);
        return drawable;
    }

    private static int darken(int color) {
        int r = (int) (Color.red(color) * 0.84f);
        int g = (int) (Color.green(color) * 0.84f);
        int b = (int) (Color.blue(color) * 0.84f);
        return Color.rgb(r, g, b);
    }

    /** 一行入口：标题 + 一句说明 + 右侧箭头。比 2×2 大方块按钮安静得多。 */
    public static LinearLayout listRow(Context context, String title, String subtitle,
                                       View.OnClickListener onClick) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundResource(R.drawable.bg_row);
        row.setPadding(dp(context, 4), dp(context, 13), dp(context, 4), dp(context, 13));
        row.setClickable(true);
        if (onClick != null) row.setOnClickListener(onClick);

        // 左侧一道细光条，给每一行一个"接口"的样子；比图标省事，也不会跟文字打架。
        View mark = new View(context);
        mark.setBackground(accentBar(context, withAlpha(accent(context), 150)));
        LinearLayout.LayoutParams markParams = new LinearLayout.LayoutParams(dp(context, 2), dp(context, 18));
        markParams.setMargins(dp(context, 6), 0, dp(context, 12), 0);
        row.addView(mark, markParams);

        LinearLayout column = new LinearLayout(context);
        column.setOrientation(LinearLayout.VERTICAL);
        TextView head = text(context, title, 15, context.getColor(R.color.text_primary));
        head.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        head.setLetterSpacing(0.02f);
        column.addView(head);
        TextView sub = text(context, subtitle, 12, context.getColor(R.color.text_secondary));
        sub.setPadding(0, dp(context, 3), 0, 0);
        column.addView(sub);
        row.addView(column, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView arrow = text(context, "›", 22, accent(context));
        arrow.setPadding(dp(context, 8), 0, dp(context, 4), 0);
        row.addView(arrow);
        return row;
    }

    /**
     * 可折叠分区：默认收起，只露出标题与一句摘要。用来收纳低频开关，
     * 让首屏只保留"现在该做什么"。
     *
     * @return 内容容器，调用方往里加控件即可
     */
    public static LinearLayout collapsible(Context context, LinearLayout parent, String title,
                                           String summary, boolean expanded) {
        LinearLayout card = card(context);
        final LinearLayout body = new LinearLayout(context);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setVisibility(expanded ? View.VISIBLE : View.GONE);

        LinearLayout head = new LinearLayout(context);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(0, dp(context, 2), 0, dp(context, 2));
        head.setClickable(true);

        LinearLayout column = new LinearLayout(context);
        column.setOrientation(LinearLayout.VERTICAL);
        TextView headTitle = text(context, title, 15, context.getColor(R.color.text_primary));
        headTitle.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        column.addView(headTitle);
        if (summary != null && !summary.isEmpty()) {
            TextView sub = text(context, summary, 12, context.getColor(R.color.text_secondary));
            sub.setPadding(0, dp(context, 3), 0, 0);
            column.addView(sub);
        }
        head.addView(column, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        final TextView chevron = text(context, expanded ? "▾" : "▸", 16, accent(context));
        chevron.setPadding(dp(context, 10), 0, dp(context, 2), 0);
        head.addView(chevron);

        head.setOnClickListener(v -> {
            boolean show = body.getVisibility() != View.VISIBLE;
            body.setVisibility(show ? View.VISIBLE : View.GONE);
            chevron.setText(show ? "▾" : "▸");
        });

        card.addView(head);
        card.addView(body);
        parent.addView(card);
        return body;
    }

    /** 小标签：用于"推荐""已启用"这类状态提示。 */
    public static TextView pill(Context context, String label, int color) {
        TextView view = text(context, label, 11, color);
        view.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        view.setBackground(badge(context, color));
        view.setPadding(dp(context, 9), dp(context, 4), dp(context, 9), dp(context, 4));
        return view;
    }
}
