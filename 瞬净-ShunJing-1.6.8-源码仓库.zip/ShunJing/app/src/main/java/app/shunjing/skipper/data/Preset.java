package app.shunjing.skipper.data;

import android.content.SharedPreferences;

import app.shunjing.skipper.engine.EngineSettings;

/**
 * 场景模式。用户不需要理解二十个开关，只需要选「我愿意让软件多激进」。
 *
 * <p>三种模式的差别只在于"行动门槛"，安全硬锁在任何模式下都不变：
 * <ul>
 *   <li>安静 —— 只处理明说"广告 / 跳过"的页面；运营弹窗、纯图片叉号一律不碰。</li>
 *   <li>均衡 —— 广告 + 运营弹窗都关；激励视频等播完再关，奖励不丢。</li>
 *   <li>极速 —— 见到关闭控件就点，激励视频直接放弃奖励，换取开屏无感。</li>
 * </ul>
 *
 * <p>任何一个开关被手动改动后，模式会自动落回"自定义"，不会假装还是预置。
 */
public final class Preset {

    public enum Mode {
        SAFE("安静", "只关闭明说“广告 / 跳过”的页面，运营弹窗与纯图片叉号不处理。"),
        BALANCED("均衡", "广告和运营弹窗都关；激励视频播完再关，奖励不丢。"),
        FAST("极速", "见到关闭控件就点，激励视频直接放弃奖励，换取最快开屏。"),
        CUSTOM("自定义", "你手动调整过开关，当前配置不归属于任何预置。");

        public final String label;
        public final String summary;

        Mode(String label, String summary) {
            this.label = label;
            this.summary = summary;
        }
    }

    public static final String KEY_MODE = "preset_mode";

    private Preset() { }

    public static Mode modeOf(Prefs prefs) {
        String stored = prefs.preferences().getString(KEY_MODE, "");
        for (Mode mode : Mode.values()) {
            if (mode.name().equals(stored)) return mode;
        }
        Mode detected = detect(prefs);
        prefs.preferences().edit().putString(KEY_MODE, detected.name()).apply();
        return detected;
    }

    public static void apply(Prefs prefs, Mode mode) {
        if (mode == Mode.CUSTOM) return;
        SharedPreferences.Editor editor = prefs.preferences().edit();
        boolean safe = mode == Mode.SAFE;
        boolean fast = mode == Mode.FAST;
        editor.putBoolean("close_icons", true);
        editor.putBoolean("fast_splash", !safe);
        editor.putBoolean("shake_back", !safe);
        editor.putBoolean("shake_preempt", !safe);
        editor.putBoolean("overlay_close", !safe);
        editor.putBoolean("web_ad_template", !safe);
        editor.putBoolean("structural_evidence", !safe);
        editor.putBoolean("ad_suspect", !safe);
        editor.putBoolean("confirm_followup", true);
        editor.putBoolean("adaptive_recovery", true);
        editor.putBoolean("auto_capture", true);
        editor.putInt("scan_interval", safe ? 90 : fast ? 40 : 60);
        editor.putString("reward_mode", (safe ? EngineSettings.RewardMode.PROTECT
                : fast ? EngineSettings.RewardMode.AUTO_ABANDON
                : EngineSettings.RewardMode.END_CARD_ONLY).name());
        editor.putString(KEY_MODE, mode.name());
        editor.apply();
    }

    /** 与预置逐项比对；任何一项不同就算自定义。 */
    public static Mode detect(Prefs prefs) {
        for (Mode mode : new Mode[]{Mode.SAFE, Mode.BALANCED, Mode.FAST}) {
            if (matches(prefs, mode)) return mode;
        }
        return Mode.CUSTOM;
    }

    private static boolean matches(Prefs prefs, Mode mode) {
        boolean safe = mode == Mode.SAFE;
        boolean fast = mode == Mode.FAST;
        SharedPreferences p = prefs.preferences();
        if (!p.getBoolean("close_icons", true)) return false;
        if (p.getBoolean("fast_splash", true) != !safe) return false;
        if (p.getBoolean("shake_back", true) != !safe) return false;
        if (p.getBoolean("shake_preempt", true) != !safe) return false;
        if (p.getBoolean("overlay_close", true) != !safe) return false;
        if (p.getBoolean("web_ad_template", true) != !safe) return false;
        if (p.getBoolean("structural_evidence", true) != !safe) return false;
        if (p.getBoolean("ad_suspect", !safe) != !safe) return false;
        if (!p.getBoolean("confirm_followup", true)) return false;
        if (!p.getBoolean("adaptive_recovery", true)) return false;
        if (!p.getBoolean("auto_capture", true)) return false;
        if (prefs.scanIntervalMs() != (safe ? 90 : fast ? 40 : 60)) return false;
        EngineSettings.RewardMode expected = safe ? EngineSettings.RewardMode.PROTECT
                : fast ? EngineSettings.RewardMode.AUTO_ABANDON
                : EngineSettings.RewardMode.END_CARD_ONLY;
        return prefs.rewardMode() == expected;
    }

    /** 供 UI 使用：三种可见模式的顺序。 */
    public static Mode[] selectable() {
        return new Mode[]{Mode.SAFE, Mode.BALANCED, Mode.FAST};
    }

    /** 自定义模式没有对应的段，返回 -1 让 UI 保持全不高亮。 */
    public static int indexOf(Mode mode) {
        Mode[] modes = selectable();
        for (int i = 0; i < modes.length; i++) if (modes[i] == mode) return i;
        return -1;
    }

    public static Mode fromIndex(int index) {
        Mode[] modes = selectable();
        return modes[Math.max(0, Math.min(index, modes.length - 1))];
    }
}
