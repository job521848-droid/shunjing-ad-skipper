package app.shunjing.skipper.engine;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Structural, text-independent ad evidence.
 *
 * <p>Why this exists: many ad SDK pages (rewarded video, DSP splash/interstitial proxies)
 * contain no readable "广告" text at all — the confirm dialog, the ad badge and the close
 * control are pure geometry. Text-based {@code hasAdContext} then fails and every
 * {@code ctx=1} rule stays silent, even though the page is unmistakably an ad.
 *
 * <p>Hard rule: a bare package name is NEVER evidence. At least one SDK-grade signal
 * (Activity name or SDK id family) must be present AND be corroborated by a second
 * independent structural signal. A single generic signal (a corner image, a centered card)
 * can never establish ad context on its own.
 *
 * <p>This only ever makes {@code adContext} true. The sensitive-page hard lock is evaluated
 * before any of this in {@link AdDecisionEngine#evaluate} and cannot be bypassed.
 */
public final class StructuralAdEvidence {
    private static final String[] AD_ACTIVITY_MARKERS = {
            "ksrewardvideoactivity", "rewardvideoactivity", "rewardadactivity", "rewardactivity",
            "dsp.open", "baseproxyactivity", "adproxyactivity",
            "splashactivity", "adactivity", "interstitialactivity", "portraitactivity",
            "landingpageactivity", "adlandingpage", "expressadactivity",
            "interstitialview", "windmill"
    };
    private static final String[] SDK_ID_FAMILIES = {
            "ksad", "kwad", "com.kwad", "tt_", "bytedance", "pangle", "csj", "gdt_", "gdt",
            "sigmob", "mintegral", "anythink", "topon", "beizi", "admob", "facebook.ads"
    };
    private static final String[] END_CARD_MARKERS = {
            "end_card", "endcard", "middle_end", "play_end", "reward_end", "ad_end"
    };

    private StructuralAdEvidence() { }

    public static boolean matches(ScreenModel screen) {
        return !signals(screen).isEmpty();
    }

    /** Returns the list of corroborating signals; empty means "no structural evidence". */
    public static List<String> signals(ScreenModel screen) {
        List<String> result = new ArrayList<>();
        if (screen == null || screen.nodes.isEmpty()) return result;

        boolean sdkActivity = sdkActivity(screen.activityName);
        boolean sdkIds = sdkIds(screen);
        int w = inferWidth(screen.nodes), h = inferHeight(screen.nodes);
        boolean badge = adBadge(screen.nodes, w, h);
        boolean card = centeredCard(screen.nodes, w, h);

        // 风马（WindMill）这类 SDK 把广告位 ID 直接拼进代理 Activity 名：
        // com.windmill.sdk.widget.InterstitialView_4012001。App 自己不会这样命名，
        // 这个"SDK 包 + 广告类型 + 数字位 ID"的组合本身就是两个独立信号。
        if (sdkPlacementId(screen.activityName)) {
            result.add("SDK 广告位 Activity (" + shortActivity(screen.activityName) + ")");
            if (card) result.add("居中非全屏广告卡片");
            return result;
        }

        // SDK-grade signal PLUS corroboration. Never a lone generic signal.
        if (sdkActivity && (sdkIds || badge || card)) {
            if (sdkActivity) result.add("广告 SDK 代理页 (" + shortActivity(screen.activityName) + ")");
            if (sdkIds) result.add("广告 SDK 控件 ID 家族");
            if (badge) result.add("右下角广告角标");
            if (card) result.add("居中非全屏广告卡片");
        } else if (sdkIds && (badge || card)) {
            result.add("广告 SDK 控件 ID 家族");
            if (badge) result.add("右下角广告角标");
            if (card) result.add("居中非全屏广告卡片");
        }
        return result;
    }

    public static boolean sdkActivity(String activityName) {
        String a = safe(activityName).toLowerCase(Locale.ROOT);
        for (String marker : AD_ACTIVITY_MARKERS) if (a.contains(marker)) return true;
        return false;
    }

    /**
     * {@code com.windmill.sdk.widget.InterstitialView_4012001} 这种"SDK 包 + 广告类型 + 位 ID"。
     * 要求同时出现 {@code .sdk.}、广告类型词和 3 位以上的数字位 ID，三者缺一不可。
     */
    public static boolean sdkPlacementId(String activityName) {
        String a = safe(activityName).toLowerCase(Locale.ROOT);
        if (!a.contains(".sdk.")) return false;
        if (!a.matches(".*(interstitial|splash|reward|native|banner)[a-z]*_\\d{3,}$")) return false;
        return true;
    }

    public static boolean sdkIds(ScreenModel screen) {
        for (NodeModel n : screen.nodes) {
            String id = n.viewId.toLowerCase(Locale.ROOT);
            for (String family : SDK_ID_FAMILIES) if (id.contains(family)) return true;
        }
        return false;
    }

    /** True when the rewarded video's end card has appeared (video finished). */
    public static boolean hasVisibleEndCard(ScreenModel screen) {
        for (NodeModel n : screen.nodes) {
            if (!n.visible) continue;
            String id = n.viewId.toLowerCase(Locale.ROOT);
            for (String marker : END_CARD_MARKERS) if (id.contains(marker)) return true;
        }
        return false;
    }

    /** Bottom-right "small icon + short label" ad badge, always outside the ad card. */
    private static boolean adBadge(List<NodeModel> nodes, int w, int h) {
        if (w <= 0 || h <= 0) return false;
        for (NodeModel container : nodes) {
            if (!container.visible || !container.hasBounds()) continue;
            if (container.left < w * 0.78f || container.top < h * 0.88f) continue;
            if (container.right - container.left > w * 0.20f) continue;
            if (container.bottom - container.top > h * 0.045f) continue;
            boolean icon = false, label = false;
            for (NodeModel child : nodes) {
                if (child.parentIndex != container.index || !child.visible) continue;
                String c = child.className.toLowerCase(Locale.ROOT);
                if (c.endsWith("imageview") || c.endsWith("imagebutton")) icon = true;
                if (c.endsWith("textview")) {
                    String t = child.normalizedText();
                    if (!t.isEmpty() && t.length() <= 4) label = true;
                }
            }
            if (icon && label) return true;
        }
        return false;
    }

    private static boolean centeredCard(List<NodeModel> nodes, int w, int h) {
        if (w <= 0 || h <= 0) return false;
        for (NodeModel n : nodes) {
            if (!n.visible || n.password || !n.hasBounds()) continue;
            String c = n.className.toLowerCase(Locale.ROOT);
            if (!(c.endsWith("linearlayout") || c.endsWith("framelayout")
                    || c.endsWith("relativelayout") || c.endsWith("constraintlayout"))) continue;
            float cw = n.right - n.left, ch = n.bottom - n.top;
            if (cw < w * 0.60f || cw > w * 0.90f || ch < h * 0.45f || ch > h * 0.80f) continue;
            if (n.left < w * 0.08f || (w - n.right) < w * 0.08f) continue;
            if (n.top < h * 0.08f || (h - n.bottom) < h * 0.08f) continue;
            return true;
        }
        return false;
    }

    private static int inferWidth(List<NodeModel> nodes) {
        int w = 0;
        for (NodeModel n : nodes) if (n.visible) w = Math.max(w, n.right);
        return w;
    }

    private static int inferHeight(List<NodeModel> nodes) {
        int h = 0;
        for (NodeModel n : nodes) if (n.visible) h = Math.max(h, n.bottom);
        return h;
    }

    private static String shortActivity(String name) {
        String v = safe(name);
        int dot = v.lastIndexOf('.');
        return dot >= 0 && v.length() - dot < 40 ? v.substring(dot + 1) : v;
    }

    private static String safe(String value) { return value == null ? "" : value; }
}
