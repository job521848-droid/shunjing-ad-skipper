package app.shunjing.skipper;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Process;

/**
 * 把未捕获异常记在本地，供「高级设置 → 诊断」查看。
 *
 * <p>不联网、不上传，只保留最近一次的摘要（异常类型 + 前 6 帧）。目的是把"偶发退回桌面"
 * 这种说不清的现象变成一条能复述的信息，而不是靠猜。
 */
public final class CrashLog {

    private static final String FILE = "local_state";
    private static final String KEY_AT = "last_crash_at";
    private static final String KEY_TEXT = "last_crash_text";

    private CrashLog() { }

    public static void install(Context context) {
        if (context == null) return;
        final Context app = context.getApplicationContext();
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try {
                record(app, thread, error);
            } catch (Throwable ignored) {
                // 记录本身失败也绝不能掩盖原始崩溃
            }
            if (previous != null) previous.uncaughtException(thread, error);
            else {
                Process.killProcess(Process.myPid());
                System.exit(10);
            }
        });
    }

    private static void record(Context context, Thread thread, Throwable error) {
        if (error == null) return;
        StringBuilder text = new StringBuilder();
        text.append(error.getClass().getName());
        if (error.getMessage() != null) text.append(": ").append(error.getMessage());
        StackTraceElement[] trace = error.getStackTrace();
        for (int i = 0; i < Math.min(6, trace.length); i++) {
            text.append('\n').append("    at ").append(trace[i]);
        }
        Throwable cause = error.getCause();
        if (cause != null) {
            text.append("\n由 ").append(cause.getClass().getName());
            if (cause.getMessage() != null) text.append(": ").append(cause.getMessage());
        }
        if (thread != null) text.append("\n线程 ").append(thread.getName());
        SharedPreferences prefs = context.getSharedPreferences(FILE, Context.MODE_PRIVATE);
        prefs.edit()
                .putLong(KEY_AT, System.currentTimeMillis())
                .putString(KEY_TEXT, text.toString())
                .apply();
    }

    public static long lastCrashAt(Context context) {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getLong(KEY_AT, 0L);
    }

    public static String lastCrashText(Context context) {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
                .getString(KEY_TEXT, "");
    }

    public static void clear(Context context) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
                .remove(KEY_AT).remove(KEY_TEXT).apply();
    }
}
