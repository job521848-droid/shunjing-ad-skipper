package app.shunjing.skipper.ui;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;


/**
 * 守护核心：旋转刻度环 + 呼吸护盾 + 换挡爆发。
 *
 * <p>v1.5.13 把"换挡"做成三段式，而不是一拍就炸：
 * <ol>
 *   <li><b>蓄力</b>（0~160ms）：整环向内收 5%，外圈收紧、亮度上升，像绷紧的弹簧；</li>
 *   <li><b>释放</b>：两圈冲击波先后甩出（第二圈晚 120ms、更大更淡），12 条射线带旋转，
 *       同时额外多转 52° —— 转速改变才让人真的感觉到"换了一档"；</li>
 *   <li><b>落定</b>：护盾闪一下白，回落到新的档位色。</li>
 * </ol>
 *
 * <p>动画只在 View 可见时运行，detach 立即停，不在后台耗电。
 */
public final class GuardOrbView extends View {
    private static final int IDLE_COLOR = 0xFF6B7F94;
    /** 蓄力占整段动画的比例。 */
    private static final float CHARGE_UNTIL = 0.18f;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path shield = new Path();
    private final Path bolt = new Path();
    private final Path sweep = new Path();
    private final RectF oval = new RectF();
    private final RectF sweepRect = new RectF();
    private boolean active;
    private float phase;
    private ValueAnimator loop;
    private ValueAnimator colorAnim;
    private ValueAnimator shiftAnim;
    private int accent = Accent.BALANCED;
    private float shift = 1f;

    public GuardOrbView(Context context) { super(context); }
    public GuardOrbView(Context context, AttributeSet attrs) { super(context, attrs); }

    public void setActive(boolean value) {
        if (active == value) return;
        active = value;
        invalidate();
    }

    /** 换挡配色。animate=false 用于首次布局，避免一进页面就从青色渐变过去。 */
    public void setAccent(int color, boolean animate) {
        if (color == accent) return;
        if (colorAnim != null) colorAnim.cancel();
        if (!animate || !isLaidOut()) {
            accent = color;
            invalidate();
            return;
        }
        colorAnim = ValueAnimator.ofObject(new ArgbEvaluator(), accent, color);
        colorAnim.setDuration(Motion.duration(getContext(), Motion.COLOR));
        colorAnim.setInterpolator(new DecelerateInterpolator(1.4f));
        colorAnim.addUpdateListener(animation -> {
            accent = (int) animation.getAnimatedValue();
            invalidate();
        });
        colorAnim.start();
    }

    /** 换挡：蓄力 → 双圈冲击波 → 落定。切模式、以及成功跳过时也能用。 */
    public void burst() {
        if (!isAttachedToWindow()) return;
        if (Motion.reduced(getContext())) return;
        if (shiftAnim != null) shiftAnim.cancel();
        shift = 0f;
        shiftAnim = ValueAnimator.ofFloat(0f, 1f);
        shiftAnim.setDuration(Motion.duration(getContext(), Motion.BURST));
        // 线性推进：快慢由 onDraw 里的分段曲线决定，插值器会把节奏抹平。
        shiftAnim.setInterpolator(new LinearInterpolator());
        shiftAnim.addUpdateListener(animation -> {
            shift = (float) animation.getAnimatedValue();
            invalidate();
        });
        shiftAnim.start();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        startLoop();
    }

    @Override
    protected void onDetachedFromWindow() {
        stopLoop();
        if (shiftAnim != null) shiftAnim.cancel();
        if (colorAnim != null) colorAnim.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        if (visibility == VISIBLE) startLoop(); else stopLoop();
    }

    private void startLoop() {
        if (!isAttachedToWindow() || getWindowVisibility() != VISIBLE) return;
        if (loop == null) {
            loop = ValueAnimator.ofFloat(0f, 1f);
            loop.setDuration(5600L);
            loop.setRepeatCount(ValueAnimator.INFINITE);
            loop.setInterpolator(new LinearInterpolator());
            loop.addUpdateListener(animation -> {
                phase = (float) animation.getAnimatedValue();
                invalidate();
            });
        }
        if (!loop.isStarted()) loop.start();
    }

    private void stopLoop() {
        if (loop != null) loop.cancel();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;

        // 换挡进度拆成"蓄力"和"释放"两段
        boolean shifting = shift < 1f;
        float charge = shifting ? Motion.clamp01(shift / CHARGE_UNTIL) : 1f;
        float release = shifting ? Motion.clamp01((shift - CHARGE_UNTIL) / (1f - CHARGE_UNTIL)) : 0f;
        float e1 = shifting ? Motion.easeOutCubic(release) : 0f;
        // 蓄力时向内收，释放后回到原尺寸并轻微回弹
        float squeeze = shifting ? (float) Math.sin(charge * Math.PI) * 0.055f * (1f - e1) : 0f;

        double angle = phase * Math.PI * 2.0;
        float pulse = (float) (0.5 + 0.5 * Math.sin(angle));
        float breathe = 1f + 0.03f * (float) Math.sin(angle);
        float radius = Math.min(getWidth(), getHeight()) * 0.34f * breathe * (1f - squeeze);
        int base = active ? accent : IDLE_COLOR;
        int r = Color.red(base), g = Color.green(base), b = Color.blue(base);
        // 换挡时额外多转 52°，转速变化是"换挡感"的来源
        float rotation = phase * 360f + (shifting ? 52f * e1 : 0f);

        if (shifting) drawShock(canvas, cx, cy, radius, r, g, b, release, e1);

        // 呼吸光晕
        paint.setStyle(Paint.Style.FILL);
        paint.setPathEffect(null);
        paint.setColor(Color.argb((int) (10 + 16 * pulse), r, g, b));
        canvas.drawCircle(cx, cy, radius * 1.16f, paint);

        // 外侧刻度环，缓慢反向旋转
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Ui.dp(getContext(), 1));
        paint.setColor(Color.argb(70, r, g, b));
        paint.setPathEffect(new DashPathEffect(new float[]{8, 12}, phase * 220f));
        canvas.drawCircle(cx, cy, radius * 1.3f, paint);
        paint.setPathEffect(null);

        // 主弧。换挡时短暂加粗，让"这一下"更有重量。
        float wide = 1f + (shifting ? 1.6f * (float) Math.sin(release * Math.PI) : 0f);
        paint.setStrokeWidth(Ui.dp(getContext(), 2) * wide);
        paint.setColor(base);
        oval.set(cx - radius, cy - radius, cx + radius, cy + radius);
        canvas.drawArc(oval, -80 + rotation, 230, false, paint);
        paint.setStrokeWidth(Ui.dp(getContext(), 5));
        paint.setColor(Color.argb(35, r, g, b));
        canvas.drawArc(oval, 155 - rotation * 0.55f, 72, false, paint);

        // 内圈两道细环，一正一反地转，像仪表盘里的游标
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Ui.dp(getContext(), 1));
        paint.setColor(Color.argb(46, r, g, b));
        paint.setPathEffect(new DashPathEffect(new float[]{3, 9}, -phase * 160f));
        canvas.drawCircle(cx, cy, radius * 0.84f, paint);
        paint.setColor(Color.argb(28, r, g, b));
        paint.setPathEffect(new DashPathEffect(new float[]{14, 20}, phase * 120f));
        canvas.drawCircle(cx, cy, radius * 0.66f, paint);
        paint.setPathEffect(null);

        // 环上的能量点：一大一小，绕轨道错开半圈
        float dotAngle = (float) (angle - Math.PI / 2);
        float dotX = cx + (float) Math.cos(dotAngle) * radius * 1.3f;
        float dotY = cy + (float) Math.sin(dotAngle) * radius * 1.3f;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(60, r, g, b));
        float dotSize = Ui.dp(getContext(), 5) * (shifting ? 1f + 1.4f * (float) Math.sin(release * Math.PI) : 1f);
        canvas.drawCircle(dotX, dotY, dotSize, paint);
        paint.setColor(base);
        canvas.drawCircle(dotX, dotY, Ui.dp(getContext(), 2), paint);

        float dot2 = dotAngle + (float) Math.PI;
        float dot2X = cx + (float) Math.cos(dot2) * radius * 0.84f;
        float dot2Y = cy + (float) Math.sin(dot2) * radius * 0.84f;
        paint.setColor(Color.argb(90, r, g, b));
        canvas.drawCircle(dot2X, dot2Y, Ui.dp(getContext(), 2.4f), paint);

        // 四周的定位刻度：很短的四道线，只在画面上留白处才看得见
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Ui.dp(getContext(), 1));
        paint.setColor(Color.argb(80, r, g, b));
        float tick = radius * 1.42f;
        float mark = Ui.dp(getContext(), 4);
        for (int i = 0; i < 4; i++) {
            double a = Math.PI / 4 + Math.PI / 2 * i;
            float x = cx + (float) Math.cos(a) * tick;
            float y = cy + (float) Math.sin(a) * tick;
            canvas.drawLine(x - mark, y, x + mark, y, paint);
            canvas.drawLine(x, y - mark, x, y + mark, paint);
        }

        // 左右刻度
        paint.setColor(Color.argb(100, r, g, b));
        canvas.drawLine(cx - radius * 1.55f, cy, cx - radius * 1.1f, cy, paint);
        canvas.drawLine(cx + radius * 1.1f, cy, cx + radius * 1.55f, cy, paint);
        canvas.drawCircle(cx - radius * 1.55f, cy, 3, paint);
        canvas.drawCircle(cx + radius * 1.55f, cy, 3, paint);

        // 护盾
        shield.reset();
        shield.moveTo(cx, cy - radius * 0.56f);
        shield.lineTo(cx + radius * 0.48f, cy - radius * 0.35f);
        shield.lineTo(cx + radius * 0.42f, cy + radius * 0.12f);
        shield.quadTo(cx + radius * 0.34f, cy + radius * 0.45f, cx, cy + radius * 0.62f);
        shield.quadTo(cx - radius * 0.34f, cy + radius * 0.45f, cx - radius * 0.42f, cy + radius * 0.12f);
        shield.lineTo(cx - radius * 0.48f, cy - radius * 0.35f);
        shield.close();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb((int) (18 + 14 * pulse), r, g, b));
        canvas.drawPath(shield, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Ui.dp(getContext(), 2));
        paint.setColor(base);
        canvas.drawPath(shield, paint);

        bolt.reset();
        bolt.moveTo(cx + radius * 0.08f, cy - radius * 0.38f);
        bolt.lineTo(cx - radius * 0.24f, cy + radius * 0.02f);
        bolt.lineTo(cx - radius * 0.02f, cy + radius * 0.02f);
        bolt.lineTo(cx - radius * 0.08f, cy + radius * 0.4f);
        bolt.lineTo(cx + radius * 0.26f, cy - radius * 0.1f);
        bolt.lineTo(cx + radius * 0.03f, cy - radius * 0.1f);
        bolt.close();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(base);
        canvas.drawPath(bolt, paint);

        // 落定：护盾整体闪一下白，把视线收回来（不是一直亮着）
        if (shifting && release > 0.15f) {
            float flash = (float) Math.sin((release - 0.15f) / 0.85f * Math.PI);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.argb((int) (22 * flash), 255, 255, 255));
            canvas.drawPath(shield, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Ui.dp(getContext(), 1.2f));
            paint.setColor(Color.argb((int) (120 * flash), 255, 255, 255));
            canvas.drawPath(shield, paint);
            // 闪电也跟着亮一下，避免整块护盾均匀发白显得平
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.argb((int) (180 * flash), 255, 255, 255));
            canvas.drawPath(bolt, paint);
        }
    }

    /**
     * 换挡冲击波：两圈 + 12 条射线 + 一道雷达扫光。
     * 第二圈刻意晚 120ms、扩得更远更淡 —— 单圈看起来像水波，两圈才有"能量"的错觉。
     */
    private void drawShock(Canvas canvas, float cx, float cy, float radius,
                           int r, int g, int b, float release, float e1) {
        if (release <= 0f) return;
        paint.setPathEffect(null);
        paint.setStyle(Paint.Style.STROKE);

        // 第一圈：亮、快、细
        float ring1 = radius * (1.02f + 1.65f * e1);
        paint.setStrokeWidth(Ui.dp(getContext(), 2.4f) * (1f - 0.65f * e1));
        paint.setColor(Color.argb((int) (150 * (1f - e1)), r, g, b));
        canvas.drawCircle(cx, cy, ring1, paint);

        // 第二圈：晚 120ms 起跑，扩得更远
        float late = Motion.clamp01((release - 0.16f) / 0.84f);
        if (late > 0f) {
            float e2 = Motion.easeOutCubic(late);
            float ring2 = radius * (0.94f + 2.55f * e2);
            paint.setStrokeWidth(Ui.dp(getContext(), 1.2f) * (1f - 0.5f * e2));
            paint.setColor(Color.argb((int) (78 * (1f - e2)), r, g, b));
            canvas.drawCircle(cx, cy, ring2, paint);
        }

        // 12 条射线：长度按 3 档循环，甩出去时带一点旋转
        paint.setStrokeWidth(Ui.dp(getContext(), 1.4f));
        paint.setColor(Color.argb((int) (100 * (1f - e1)), r, g, b));
        for (int i = 0; i < 12; i++) {
            double a = Math.PI * 2 * i / 12 + 0.5 * e1;
            float inner = ring1 * 0.98f;
            float length = 0.06f + 0.09f * (i % 3);
            float outer = ring1 + radius * length * e1;
            canvas.drawLine(cx + (float) Math.cos(a) * inner, cy + (float) Math.sin(a) * inner,
                    cx + (float) Math.cos(a) * outer, cy + (float) Math.sin(a) * outer, paint);
        }

        // 雷达扫光：一道 80° 的扇形，从 12 点方向扫过一圈，快速淡出
        float sweepAngle = (float) (release * 300f);
        if (sweepAngle < 300f) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.argb((int) (34 * (1f - release)), r, g, b));
            sweep.reset();
            sweep.moveTo(cx, cy);
            sweepRect.set(cx - radius * 1.45f, cy - radius * 1.45f,
                    cx + radius * 1.45f, cy + radius * 1.45f);
            sweep.arcTo(sweepRect, -90f + sweepAngle, 78f, false);
            sweep.close();
            canvas.drawPath(sweep, paint);
        }
    }
}
