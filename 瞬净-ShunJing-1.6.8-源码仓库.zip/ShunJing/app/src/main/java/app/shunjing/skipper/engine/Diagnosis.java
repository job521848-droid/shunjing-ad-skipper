package app.shunjing.skipper.engine;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Result of analysing one captured page. */
public final class Diagnosis {
    public enum Verdict {
        SKIPPABLE,          // engine would have clicked
        PROTECTED,          // sensitive or system page, deliberately locked
        LAUNCHER,           // system launcher / recents — never an ad page
        REWARDED,           // rewarded video protection
        NO_AD_EVIDENCE,     // close control exists but no ad context
        NO_MATCHING_RULE,   // ad context exists, close control has no matching rule
        NOT_CLICKABLE,      // candidate found but not clickable / no clickable ancestor
        NO_TEXT_IMAGE_ONLY, // pure image / webview controls, nothing readable
        MASTER_OFF,
        APP_DISABLED,
        UNKNOWN
    }

    public final Verdict verdict;
    public final String headline;
    public final String explanation;
    public final List<String> evidence;
    public final List<Candidate> candidates;
    public final List<Suggestion> suggestions;
    public final boolean adContext;
    public final boolean sensitive;

    public Diagnosis(Verdict verdict, String headline, String explanation, List<String> evidence,
                     List<Candidate> candidates, List<Suggestion> suggestions,
                     boolean adContext, boolean sensitive) {
        this.verdict = verdict;
        this.headline = headline;
        this.explanation = explanation;
        this.evidence = unmodifiable(evidence);
        this.candidates = unmodifiable(candidates);
        this.suggestions = unmodifiable(suggestions);
        this.adContext = adContext;
        this.sensitive = sensitive;
    }

    public String verdictLabel() {
        switch (verdict) {
            case SKIPPABLE: return "规则已覆盖";
            case PROTECTED: return "敏感页锁定";
            case LAUNCHER: return "系统桌面";
            case REWARDED: return "激励视频保护";
            case NO_AD_EVIDENCE: return "缺少广告证据";
            case NO_MATCHING_RULE: return "缺关闭词";
            case NOT_CLICKABLE: return "控件不可点";
            case NO_TEXT_IMAGE_ONLY: return "纯图片控件";
            case MASTER_OFF: return "总开关关闭";
            case APP_DISABLED: return "应用被停用";
            default: return "未定位到目标";
        }
    }

    private static <T> List<T> unmodifiable(List<T> source) {
        return source == null ? Collections.emptyList()
                : Collections.unmodifiableList(new ArrayList<>(source));
    }

    /** A control that looks like an ad close/skip target. */
    public static final class Candidate {
        public final int index;
        public final String label;
        public final String id;
        public final String bounds;
        public final boolean clickable;
        public final boolean hasClickableAncestor;
        public final boolean idLooksLikeAd;

        public Candidate(int index, String label, String id, String bounds, boolean clickable,
                         boolean hasClickableAncestor, boolean idLooksLikeAd) {
            this.index = index;
            this.label = label;
            this.id = id;
            this.bounds = bounds;
            this.clickable = clickable;
            this.hasClickableAncestor = hasClickableAncestor;
            this.idLooksLikeAd = idLooksLikeAd;
        }
    }
}
