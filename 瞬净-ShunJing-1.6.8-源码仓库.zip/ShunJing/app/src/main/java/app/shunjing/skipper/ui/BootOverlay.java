package app.shunjing.skipper.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import app.shunjing.skipper.data.Prefs;

/**
 * 冷启动的开场动效（1.6.1）。
 *
 * <p>这一版解决两个真问题：<b>太快</b>和<b>接得硬</b>。
 *
 * <p><b>太短</b>：旧版整段 1.04 秒，光条刚合拢、名字还没看清就没了。现在 2.34 秒，
 * 拆成五段各自有落点 —— 合拢（0.1~0.76s）、点亮（0.36~0.90s）、冲击（0.82s 一拍）、
 * 落名（0.82~1.24s）、状态切换（1.52s）、拉开（1.92~2.34s）。慢下来靠的是"每段都在变"，
 * 不是把同一段拉长，所以不会显得卡。看得不耐烦可以随时轻触跳过。
 *
 * <p><b>接得硬</b>：旧版是「遮罩瞬间消失 → 首页卡片才开始一条条掉下来」，
 * 中间那一下等于黑屏。现在遮罩分三层退场：底色先淡（露出已经就位的首页）→
 * 光条向两侧划开 → 标题上移淡出；同时首页从一开始就压暗缩到 0.972，
 * 跟着退场进度推近到 1.0。两边共用一条时间轴，所以是"幕布拉开、页面迎面过来"，
 * 而不是"盖住 → 拿开"。
 *
 * <p>三条硬约束不变：
 * <ul>
 *   <li>系统开了「移除动画」就整段不播（由调用方判断）；</li>
 *   <li>任意时刻被打断都能安全取消，不残留动画和震动；</li>
 *   <li>振动只落在冲击（820ms）与标题落位（+300ms）两处，其余时间安静。</li>
 * </ul>
 */
public final class BootOverlay extends FrameLayout implements View.OnClickListener {

    /** 让调用方跟着退场进度调整下面的首页。 */
    public interface Reveal {
        /** @param progress 0 = 幕布还盖着，1 = 完全拉开。 */
        void onReveal(float progress);
    }

    private final View bg;
    private final TechRootLayout tech;
    private final View flash;
    private final View leftBar;
    private final View rightBar;
    private final LinearLayout column;
    private final LinearLayout bottom;
    private final TextView statusLine;
    private final TextView statusReady;
    private final TextView skipHint;
    private final View progress;
    private final GuardOrbView orb;
    private final TextView wordmark;
    private final TextView subtitle;
    private final Prefs prefs;
    private final float barSpread;

    private ValueAnimator clock;
    private ValueAnimator rush;
    private Runnable done;
    private Runnable prepare;
    private Reveal reveal;
    private long lastT;
    private boolean impacted;
    private boolean prepared;
    private boolean finished;
    private boolean silent;

    public BootOverlay(Context context, int accent, Prefs prefs) {
        super(context);
        this.prefs = prefs;
        setClickable(true);
        setOnClickListener(this);

        // 1) 纯色幕布：退出时第一个淡掉，用来露出下面已经摆好的首页。
        //    颜色跟 windowBackground 完全一致，缩放首页时才不会闪出别的底色。
        bg = new View(context);
        bg.setBackgroundColor(0xFF050911);
        addView(bg, full());

        // 2) 网格与光晕：和首页同一套底纹，让"拉开"前后是同一种空间。
        tech = new TechRootLayout(context);
        tech.setAccent(accent);
        tech.setAlpha(0f);
        addView(tech, full());

        // 3) 两侧光条。
        int half = Math.max(1, context.getResources().getDisplayMetrics().widthPixels / 2);
        barSpread = half * 1.02f;
        leftBar = lightBar(context, accent, true, half);
        rightBar = lightBar(context, accent, false, half);
        addView(leftBar, new FrameLayout.LayoutParams(half, dp(context, 2),
                Gravity.START | Gravity.CENTER_VERTICAL));
        addView(rightBar, new FrameLayout.LayoutParams(half, dp(context, 2),
                Gravity.END | Gravity.CENTER_VERTICAL));

        // 4) 标题列：核心环 + 名字 + 一行英文。
        column = new LinearLayout(context);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setGravity(Gravity.CENTER_HORIZONTAL);

        orb = new GuardOrbView(context);
        orb.setActive(true);
        orb.setAccent(accent, false);
        orb.setAlpha(0f);
        column.addView(orb, new LinearLayout.LayoutParams(dp(context, 204), dp(context, 204)));

        wordmark = new TextView(context);
        wordmark.setText("瞬净");
        wordmark.setTextSize(31);
        wordmark.setTextColor(0xFFE8F4FF);
        wordmark.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        wordmark.setLetterSpacing(0.46f);
        wordmark.setGravity(Gravity.CENTER);
        wordmark.setIncludeFontPadding(false);
        wordmark.setAlpha(0f);
        column.addView(wordmark, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        subtitle = new TextView(context);
        subtitle.setText("SHUNJING · LOCAL AD DEFENSE");
        subtitle.setTextSize(9.5f);
        subtitle.setTextColor(withAlpha(accent, 190));
        subtitle.setLetterSpacing(0.26f);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(context, 10), 0, 0);
        subtitle.setAlpha(0f);
        column.addView(subtitle, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        addView(column, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER));

        // 5) 底部：状态文案 + 细进度线。两条文案叠在同一格里交叉淡入，切换时不跳布局。
        bottom = new LinearLayout(context);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setGravity(Gravity.CENTER_HORIZONTAL);

        FrameLayout statusWrap = new FrameLayout(context);
        statusLine = statusText("本地引擎 · 规则装载", withAlpha(accent, 130), 9f);
        statusReady = statusText("防护链路已就绪", withAlpha(accent, 205), 9.5f);
        statusReady.setAlpha(0f);
        statusWrap.addView(statusLine, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER));
        statusWrap.addView(statusReady, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER));
        bottom.addView(statusWrap, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(context, 16)));

        progress = new View(context);
        GradientDrawable line = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{withAlpha(accent, 0), withAlpha(accent, 225), withAlpha(accent, 0)});
        progress.setBackground(line);
        progress.setScaleX(0f);
        LinearLayout.LayoutParams progressParams =
                new LinearLayout.LayoutParams(dp(context, 152), dp(context, 2));
        progressParams.topMargin = dp(context, 8);
        bottom.addView(progress, progressParams);

        FrameLayout.LayoutParams bottomParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        bottomParams.bottomMargin = dp(context, 72);
        bottom.setAlpha(0f);
        addView(bottom, bottomParams);

        // 6) 白闪：冲击那一拍铺满全屏，压在所有内容之上。
        flash = new View(context);
        flash.setBackgroundColor(0xFFFFFFFF);
        flash.setAlpha(0f);
        addView(flash, full());

        // 7) 轻触跳过。做得极克制：右下角、低透明度、1 秒后才出现。
        skipHint = new TextView(context);
        skipHint.setText("轻触跳过");
        skipHint.setTextSize(9f);
        skipHint.setTextColor(0xFF7E8FA3);
        skipHint.setLetterSpacing(0.12f);
        skipHint.setAlpha(0f);
        FrameLayout.LayoutParams skipParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.END);
        skipParams.bottomMargin = dp(context, 26);
        skipParams.rightMargin = dp(context, 24);
        addView(skipHint, skipParams);
    }

    /**
     * 播放。
     *
     * @param prepare 首页该开始入场的时刻（此时画面仍被遮罩盖住，用户看不到卡片在动）
     * @param reveal  退场进度回调，用来同步推近下面的首页
     * @param done    整段结束，把这一层摘掉
     */
    public void play(Runnable prepare, Reveal reveal, Runnable done) {
        this.prepare = prepare;
        this.reveal = reveal;
        this.done = done;

        clock = ValueAnimator.ofFloat(0f, BootTimeline.TOTAL);
        clock.setDuration(Motion.duration(getContext(), BootTimeline.TOTAL));
        clock.setInterpolator(new LinearInterpolator());
        clock.addUpdateListener(animation -> render((long) (float) animation.getAnimatedValue()));
        clock.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator animation) {
                finish();
            }
        });
        clock.start();
        render(0L);
        // 标题列整体居中，核心环的中心比屏幕中线高一点；光条必须跟环对齐，
        // 否则合拢出来的是屏幕正中的一条横线，而不是"汇聚到环上"。
        post(this::alignBars);
    }

    private void alignBars() {
        if (getHeight() <= 0) return;
        float center = column.getTop() + orb.getTop() + orb.getHeight() / 2f;
        float offset = center - getHeight() / 2f;
        leftBar.setTranslationY(offset);
        rightBar.setTranslationY(offset);
    }

    private void render(long t) {
        lastT = t;
        float e = BootTimeline.exit(t);

        // ---------------------------------------------------------- 幕布退场
        // 底色最先走（0~55%），首页在它下面就位；网格跟在后面，避免"灰罩"停留太久。
        bg.setAlpha(1f - Motion.easeInQuad(Motion.clamp01(e / 0.55f)));
        tech.setAlpha(0.95f * BootTimeline.span(t, 0L, 460L)
                * (1f - Motion.clamp01((e - 0.10f) / 0.52f)));

        // ---------------------------------------------------------- 光条
        float spread;
        float barAlpha;
        if (e <= 0f) {
            // 起手：从屏幕两侧向环心合拢，尾段几乎停住，像被磁铁吸过去。
            float in = Motion.easeOutQuint(BootTimeline.span(t, BootTimeline.BARS_IN, 650L));
            spread = (1f - in) * barSpread;
            float appear = BootTimeline.span(t, BootTimeline.BARS_IN, 170L);
            // 合拢后必须彻底淡掉：留一点就会变成横贯全屏的线，像渲染残留。
            float fade = Motion.clamp01((t - 720f) / 140f);
            barAlpha = 0.95f * appear * (1f - fade);
        } else {
            // 收尾：同一对光条反向划开，把"汇聚"变成"拉开"。
            // 光条只在"揭幕"那一下出现：跟着底色一起划开、一起消失。
            // 留到首页已经清楚的时候，它就变成一条横在卡片上的线，像渲染残留。
            float open = Motion.easeInQuad(Motion.clamp01(e / 0.50f));
            spread = barSpread * 1.22f * open;
            barAlpha = 0.70f * (float) Math.sin(Math.PI * Motion.clamp01(e / 0.50f));
        }
        leftBar.setTranslationX(-spread);
        rightBar.setTranslationX(spread);
        leftBar.setAlpha(barAlpha);
        rightBar.setAlpha(barAlpha);

        // ---------------------------------------------------------- 核心环
        float orbT = BootTimeline.span(t, BootTimeline.ORB_IN,
                BootTimeline.ORB_FULL - BootTimeline.ORB_IN);
        orb.setAlpha(Motion.clamp01(orbT * 1.45f));
        float orbScale = 0.90f + 0.10f * Motion.spring(orbT);
        orb.setScaleX(orbScale);
        orb.setScaleY(orbScale);

        // ---------------------------------------------------------- 冲击
        if (t >= BootTimeline.IMPACT && !impacted) {
            impacted = true;
            orb.burst();
            if (!silent) Feedback.boot(getContext(), prefs);
        }
        float flashT = Motion.clamp01((t - BootTimeline.IMPACT) / 180f);
        flash.setAlpha(flashT <= 0f || flashT >= 1f
                ? 0f : 0.075f * (float) Math.sin(Math.PI * flashT));

        // ---------------------------------------------------------- 名字
        // 先落位再收字距：字距直接换会让宽度跳，用弹簧压回来才像"缩紧"。
        float wordT = BootTimeline.span(t, BootTimeline.IMPACT,
                BootTimeline.WORD_FULL - BootTimeline.IMPACT);
        wordmark.setAlpha(Motion.easeOutCubic(wordT));
        wordmark.setTranslationY((1f - Motion.spring(wordT)) * dp(getContext(), 20));
        wordmark.setLetterSpacing(0.46f - 0.33f * Motion.easeOutCubic(wordT));

        float subT = BootTimeline.span(t, BootTimeline.SUB_IN,
                BootTimeline.SUB_FULL - BootTimeline.SUB_IN);
        subtitle.setAlpha(0.78f * Motion.easeOutCubic(subT));
        subtitle.setTranslationY((1f - Motion.spring(subT)) * dp(getContext(), 9));

        // ---------------------------------------------------------- 状态与进度
        // 进度线只给一个"在动"的交代，不承诺真实加载百分比。
        progress.setScaleX(Motion.easeOutQuint(
                BootTimeline.span(t, 220L, BootTimeline.EXIT - 220L)));
        long swap = BootTimeline.STATUS_SWAP;
        statusLine.setAlpha(0.85f * BootTimeline.span(t, 380L, 280L)
                * (1f - BootTimeline.span(t, swap, 240L)));
        statusReady.setAlpha(Motion.easeOutCubic(BootTimeline.span(t, swap + 60L, 300L)));

        float bottomFade = 1f - Motion.clamp01((e - 0.02f) / 0.42f);
        bottom.setAlpha(bottomFade);
        bottom.setTranslationY(-dp(getContext(), 20) * Motion.easeInQuad(e));

        // ---------------------------------------------------------- 标题列退场
        float colFade = 1f - Motion.clamp01((e - 0.04f) / 0.38f);
        column.setAlpha(colFade);
        column.setTranslationY(-dp(getContext(), 36) * Motion.easeInQuad(e));
        float colScale = 1f + 0.045f * e;
        column.setScaleX(colScale);
        column.setScaleY(colScale);

        // ---------------------------------------------------------- 跳过提示
        skipHint.setAlpha(0.34f * BootTimeline.span(t, 900L, 420L) * (1f - e));

        // ---------------------------------------------------------- 首页预入场 + 推近
        if (t >= BootTimeline.PREPARE) launchPrepare();
        if (reveal != null) reveal.onReveal(e);
    }

    private void launchPrepare() {
        if (prepared) return;
        prepared = true;
        if (prepare != null) prepare.run();
    }

    /** 轻触跳过：把剩下的时间压成 0.3 倍的"快进"，而不是直接黑掉。 */
    @Override
    public void onClick(View view) {
        skip();
    }

    public void skip() {
        if (finished || rush != null) return;
        // 从桌面点图标进来时手指可能还压在屏幕上，前 0.6 秒不响应，避免刚播就没了。
        if (lastT < 600L) return;
        silent = true;
        Feedback.cancel(getContext());
        if (clock != null) {
            clock.removeAllUpdateListeners();
            clock.removeAllListeners();
            clock.cancel();
            clock = null;
        }
        long remain = Math.max(120L, BootTimeline.TOTAL - lastT);
        long duration = Math.max(200L, Math.min(560L, Math.round(remain * 0.30f)));
        rush = ValueAnimator.ofFloat(lastT, BootTimeline.TOTAL);
        rush.setDuration(Motion.duration(getContext(), duration));
        rush.setInterpolator(new AccelerateDecelerateInterpolator());
        rush.addUpdateListener(a -> render((long) (float) a.getAnimatedValue()));
        rush.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator animation) {
                finish();
            }
        });
        rush.start();
    }

    private void finish() {
        if (finished) return;
        finished = true;
        if (rush != null) {
            rush.removeAllUpdateListeners();
            rush.removeAllListeners();
            rush = null;
        }
        if (clock != null) {
            clock.removeAllUpdateListeners();
            clock.removeAllListeners();
            clock = null;
        }
        setAlpha(0f);
        // 万一动画意外提前结束（系统时长缩放、正好在 PREPARE 之前被掐），
        // 也要把首页的入场补上，否则用户看到的是一片空页面。
        launchPrepare();
        if (reveal != null) reveal.onReveal(1f);
        if (done != null) done.run();
    }

    /**
     * 中途被打断（返回键、切后台、Activity 销毁）时调用，别让动画留在后台跑。
     *
     * <p>必须照常回调：首页是等这个回调才恢复亮度的，
     * 不然动画被打断之后，用户回来看到的是一片暗掉的页面。
     */
    public void cancel() {
        if (rush != null) {
            rush.removeAllUpdateListeners();
            rush.removeAllListeners();
            rush.cancel();
            rush = null;
        }
        if (clock != null) {
            clock.removeAllUpdateListeners();
            clock.removeAllListeners();
            clock.cancel();
            clock = null;
        }
        if (!finished) {
            finished = true;
            launchPrepare();
            if (reveal != null) reveal.onReveal(1f);
            if (done != null) done.run();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        cancel();
        super.onDetachedFromWindow();
    }

    private TextView statusText(String text, int color, float size) {
        TextView view = new TextView(getContext());
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setLetterSpacing(0.18f);
        view.setGravity(Gravity.CENTER);
        view.setAlpha(0f);
        return view;
    }

    private FrameLayout.LayoutParams full() {
        return new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private static View lightBar(Context context, int accent, boolean fromLeft, int width) {
        View view = new View(context);
        // 靠近屏幕中线的一端最亮，外侧完全透明 —— 合拢时才像"能量汇聚"而不是两条棍子平移。
        int[] colors = fromLeft
                ? new int[]{withAlpha(accent, 0), withAlpha(accent, 150), withAlpha(accent, 235)}
                : new int[]{withAlpha(accent, 235), withAlpha(accent, 150), withAlpha(accent, 0)};

        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT, colors);
        drawable.setCornerRadius(Math.max(1f, width * 0.002f));
        view.setBackground(drawable);
        view.setAlpha(0f);
        return view;
    }

    private static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | (alpha << 24);
    }

    private static int dp(Context context, int value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }
}
