package app.shunjing.skipper.engine;

import java.util.Locale;

/**
 * v1.4 — 叠层弹窗（红包 / 签到 / 限时福利 / H5 活动弹窗）的关闭按钮定位。
 *
 * <p>为什么需要它：这类弹窗通常由 App 自己的运营活动页绘制，关闭按钮是一张纯图片
 * ImageView —— 没有文字、没有 contentDescription、没有资源 id，而且往往"悬浮"在卡片
 * 右上角的外侧。{@link LayoutAnchorRule} 要求按钮必须是卡片的直接子节点且落在卡片内，
 * 因此对这类样式 100% 打不中；规则引擎也无法匹配无文本节点。结果是"叉号很明显，但
 * 软件完全没动作"。
 *
 * <p>安全边界（任何一条不满足都不返回候选）：
 * <ul>
 *   <li>敏感页面 / 受保护包 直接拒绝（与引擎硬锁独立复核）。</li>
 *   <li>必须由调用方提供独立的广告上下文（本类不自行认定广告）。</li>
 *   <li>页面内不得出现支付 / 密码 / 验证码 / 授权 / 卸载 / 购买等确认类动作词。</li>
 *   <li>必须是"居中卡片 + 卡片右上角邻域内的小尺寸无文本图标"，且图标位于卡片上半区，
 *       从而排除底部的 CTA 大按钮、播放器控制条、以及右上角的"更多"菜单。</li>
 *   <li>候选不唯一且分数接近时返回 null（歧义不猜）。</li>
 * </ul>
 */
public final class OverlayCloseLocator {

    /** 出现这些词说明当前页面在要求用户做实质决定，绝不代点。 */
    private static final String[] DANGEROUS = {
            "支付", "付款", "转账", "充值", "提现", "密码", "验证码", "授权", "登录", "注册",
            "同意", "允许", "拒绝", "卸载", "删除", "格式化", "恢复出厂", "购买", "下单",
            "确认订单", "开通", "订阅", "扣费", "签约", "实名"
    };

    private static final float CARD_W_MIN = 0.50f, CARD_W_MAX = 0.96f;
    private static final float CARD_H_MIN = 0.26f, CARD_H_MAX = 0.90f;
    private static final float CARD_INSET_X = 0.02f;
    private static final float CARD_CENTER_X_TOL = 0.10f;
    private static final float CARD_CENTER_Y_TOL = 0.20f;

    private static final float ICON_MIN_W = 0.035f, ICON_MAX_W = 0.14f;
    private static final float ICON_ASPECT_MIN = 0.55f, ICON_ASPECT_MAX = 1.80f;
    private static final float ICON_MAX_AREA = 0.018f;
    /** 图标中心相对卡片右上角的偏移（负值表示在卡片外侧/上方）。 */
    private static final float DX_MIN = -0.09f, DX_MAX = 0.11f;
    private static final float DY_MIN = -0.10f, DY_MAX = 0.06f;
    /** 图标必须落在卡片顶部这段高度内，避免命中底部 CTA。 */
    private static final float ICON_MAX_CARD_TOP_RATIO = 0.30f;

    private static final int MIN_SCORE = 80;

    /** 只有这些描述才允许出现在关闭图标上；其它描述（更多/静音/分享）一律排除。 */
    private static final String[] CLOSE_WORDS = {
            "关闭", "叉", "取消", "close", "dismiss", "exit", "skip"
    };

    public static final class Hit {
        public final int nodeIndex;
        public final int score;
        public final String reason;

        Hit(int nodeIndex, int score, String reason) {
            this.nodeIndex = nodeIndex;
            this.score = score;
            this.reason = reason;
        }
    }

    private OverlayCloseLocator() { }

    public static Hit find(ScreenModel screen, int width, int height) {
        if (screen == null || screen.nodes.isEmpty()) return null;
        if (AdDecisionEngine.isSensitive(screen)) return null;
        if (AdDecisionEngine.isProtectedPackage(screen.packageName)) return null;
        if (hasDangerousAction(screen)) return null;

        int w = width > 0 ? width : inferWidth(screen);
        int h = height > 0 ? height : inferHeight(screen);
        if (w <= 0 || h <= 0) return null;

        Hit best = null;
        Hit second = null;
        for (NodeModel card : screen.nodes) {
            if (!isCenteredCard(card, w, h)) continue;
            for (NodeModel icon : screen.nodes) {
                if (!isCornerIcon(icon, card, w, h)) continue;
                if (AdDecisionEngine.findClickableAncestor(screen.nodes, icon) < 0) continue;
                Hit candidate = new Hit(icon.index, score(icon, card, w, h),
                        "叠层弹窗 · 右上角悬浮关闭");
                if (best == null || candidate.score > best.score
                        || (candidate.score == best.score
                        && icon.area() < screen.nodes.get(best.nodeIndex).area())) {
                    second = best;
                    best = candidate;
                } else if (second == null || candidate.score > second.score) {
                    second = candidate;
                }
            }
        }
        if (best == null || best.score < MIN_SCORE) return null;
        // 两个同样像关闭按钮的控件（例如静音 + 关闭）时宁可不点。
        if (second != null && best.score - second.score < 10) return null;
        return best;
    }

    private static boolean isCenteredCard(NodeModel card, int w, int h) {
        if (!card.visible || card.password || !card.hasBounds()) return false;
        if (card.parentIndex < 0) return false;                 // 根节点永远不是卡片
        int cw = card.right - card.left, ch = card.bottom - card.top;
        if (cw < w * CARD_W_MIN || cw > w * CARD_W_MAX) return false;
        if (ch < h * CARD_H_MIN || ch > h * CARD_H_MAX) return false;
        if (card.left < w * CARD_INSET_X || (w - card.right) < w * CARD_INSET_X) return false;
        float cx = (card.left + card.right) / 2f, cy = (card.top + card.bottom) / 2f;
        if (Math.abs(cx - w / 2f) > w * CARD_CENTER_X_TOL) return false;
        if (Math.abs(cy - h / 2f) > h * CARD_CENTER_Y_TOL) return false;
        return isContainer(card.className) || card.normalizedText().isEmpty();
    }

    private static boolean isCornerIcon(NodeModel icon, NodeModel card, int w, int h) {
        if (!icon.visible || icon.password || !icon.hasBounds()) return false;
        // 有文案的一律视为 CTA（"摇动手机或点击查看详情"就是典型）。
        if (!icon.normalizedText().isEmpty()) return false;
        // 允许 contentDescription，但必须本身就表示"关闭"，否则可能是"更多""静音"。
        String desc = icon.normalizedDescription();
        if (!desc.isEmpty() && !looksLikeClose(desc)) return false;
        if (!isImage(icon.className)) return false;

        int bw = icon.right - icon.left, bh = icon.bottom - icon.top;
        if (bw < w * ICON_MIN_W || bw > w * ICON_MAX_W) return false;
        if (bh < w * ICON_MIN_W || bh > w * ICON_MAX_W) return false;
        float aspect = bw / (float) bh;
        if (aspect < ICON_ASPECT_MIN || aspect > ICON_ASPECT_MAX) return false;
        if ((long) bw * bh > (long) (w * h * ICON_MAX_AREA)) return false;

        float cx = (icon.left + icon.right) / 2f, cy = (icon.top + icon.bottom) / 2f;
        float dx = (cx - card.right) / w;
        float dy = (cy - card.top) / h;
        if (dx < DX_MIN || dx > DX_MAX) return false;
        if (dy < DY_MIN || dy > DY_MAX) return false;
        // 必须在卡片上半区（排除底部胶囊按钮、播放控件）。
        if (cy > card.top + (card.bottom - card.top) * ICON_MAX_CARD_TOP_RATIO) return false;
        return true;
    }

    private static int score(NodeModel icon, NodeModel card, int w, int h) {
        int value = 58;
        float cx = (icon.left + icon.right) / 2f, cy = (icon.top + icon.bottom) / 2f;
        float dx = Math.abs(cx - card.right) / w;
        float dy = Math.abs(cy - card.top) / h;
        if (dx <= 0.06f && dy <= 0.06f) value += 22;   // 紧贴卡片右上角
        if (dx <= 0.03f || dy <= 0.03f) value += 6;    // 与某一边几乎对齐
        if (icon.clickable) value += 8;
        if (icon.viewId.toLowerCase(Locale.ROOT).contains("close")) value += 10;
        return value;
    }

    private static boolean hasDangerousAction(ScreenModel screen) {
        for (NodeModel n : screen.nodes) {
            String value = n.normalizedText() + n.normalizedDescription();
            if (value.isEmpty()) continue;
            for (String word : DANGEROUS) if (value.contains(word)) return true;
        }
        return false;
    }

    private static boolean looksLikeClose(String desc) {
        for (String word : CLOSE_WORDS) if (desc.contains(word)) return true;
        return false;
    }

    private static boolean isContainer(String className) {
        String c = safe(className).toLowerCase(Locale.ROOT);
        return c.endsWith("layout") || c.contains("viewgroup") || c.contains("cardview")
                || c.contains("dialog") || c.contains("popup") || c.contains("webview");
    }

    private static boolean isImage(String className) {
        String c = safe(className).toLowerCase(Locale.ROOT);
        return c.endsWith("imageview") || c.endsWith("imagebutton")
                || c.contains("appcompatimage");
    }

    private static int inferWidth(ScreenModel screen) {
        int value = 0;
        for (NodeModel n : screen.nodes) if (n.visible) value = Math.max(value, n.right);
        return value;
    }

    private static int inferHeight(ScreenModel screen) {
        int value = 0;
        for (NodeModel n : screen.nodes) if (n.visible) value = Math.max(value, n.bottom);
        return value;
    }

    private static String safe(String value) { return value == null ? "" : value; }
}
