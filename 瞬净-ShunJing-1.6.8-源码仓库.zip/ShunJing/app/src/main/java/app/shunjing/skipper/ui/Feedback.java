package app.shunjing.skipper.ui;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;

import app.shunjing.skipper.data.Prefs;
import app.shunjing.skipper.data.Preset;

/**
 * 切换模式时的"换挡"反馈：一段极短的合成音 + 一次分级震动。
 *
 * <p>不打包音频文件：波形按模式实时计算，APK 不会变大，也不需要读取外部资源权限。
 *
 * <p>v1.5.13 起声音改成<b>扫频</b>（chirp）而不是固定音高：固定音高听起来像"电子音效"，
 * 频率滑动才像机械结构在动。最前面再叠 8ms 极轻的噪声瞬态，模拟触点接触的"嗒"。
 *
 * <p>震动的原则是"短、有节奏、不突袭"：单次都不超过 14ms，三档分别是一下、两下、三下，
 * 强度递增 —— 手感上有档位，但不会在口袋里吓人一跳。
 */
public final class Feedback {
    private static final int SAMPLE_RATE = 22_050;
    private static final float GAIN = 0.30f;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    /** 当前正在播的那一段。连点三档时如果不掐掉上一段，三个音会叠成噪音。 */
    private static AudioTrack current;

    private Feedback() { }

    public static void modeSwitch(Context context, Preset.Mode mode, Prefs prefs) {
        if (context == null || mode == null || mode == Preset.Mode.CUSTOM) return;
        if (prefs != null && prefs.feedbackSoundEnabled()) play(tone(mode));
        if (prefs != null && prefs.feedbackHapticEnabled()) buzz(context, mode);
    }

    /** 成功跳过广告时的轻声确认，默认关闭。 */
    public static void skip(Context context, Prefs prefs) {
        if (context == null || prefs == null || !prefs.feedbackSkipEnabled()) return;
        if (prefs.feedbackSoundEnabled()) {
            play(render(new int[][]{{1174, 1318, 42}, {1568, 1568, 52}}, 0f));
        }
        if (prefs.feedbackHapticEnabled()) vibrate(context, new long[]{0, 8}, new int[]{0, 90});
    }

    /**
     * 启动动画的两拍：冲击一下（13ms），300ms 后标题落位再轻点一下（9ms）。
     * 只有这两处响，其余时间是安静的 —— 全程嗡一下会显得廉价。
     */
    public static void boot(Context context, Prefs prefs) {
        if (context == null || prefs == null || !prefs.feedbackHapticEnabled()) return;
        vibrate(context, new long[]{0, 13, 300, 9}, new int[]{0, 150, 0, 85});
    }

    /**
     * 掐掉还没播完的震动。
     *
     * <p>开场的第二拍是写在波形里的（300ms 后），用户中途轻触跳过时，
     * 如果不管它，画面已经切到首页了还会莫名震一下。
     */
    public static void cancel(Context context) {
        if (context == null) return;
        try {
            Vibrator vibrator;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                VibratorManager manager =
                        (VibratorManager) context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
                vibrator = manager == null ? null : manager.getDefaultVibrator();
            } else {
                vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
            }
            if (vibrator != null) vibrator.cancel();
        } catch (RuntimeException ignored) {
        }
    }

    /**
     * 导览翻页的一声"嗒"：越往后音高越高，听得出进度在推进。
     *
     * <p>只有 34ms，音高从 620Hz 起每步 +68Hz。八步下来是一条很轻的上行音阶，
     * 不喧宾夺主，但手指和耳朵能同时确认"翻过去了"。
     */
    public static void tourStep(Context context, Prefs prefs, int index, int total) {
        if (context == null || prefs == null) return;
        int base = 620 + Math.max(0, Math.min(index, 8)) * 68;
        if (prefs.feedbackSoundEnabled()) {
            play(render(new int[][]{{base, base + 110, 34}}, 0.02f));
        }
        if (prefs.feedbackHapticEnabled()) {
            vibrate(context, new long[]{0, 7}, new int[]{0, 70});
        }
    }

    /**
     * 导览开场：一记低频冲击接一段上行扫频，像聚光灯"啪"地打亮。
     * 比翻页重，但只响这一次。
     */
    public static void tourOpen(Context context, Prefs prefs) {
        if (context == null || prefs == null) return;
        if (prefs.feedbackSoundEnabled()) {
            play(render(new int[][]{{220, 180, 70}, {520, 1180, 130}}, 0.06f));
        }
        if (prefs.feedbackHapticEnabled()) {
            vibrate(context, new long[]{0, 14, 90, 9}, new int[]{0, 140, 0, 70});
        }
    }

    /** 试听：按当前模式放一遍。 */
    public static void preview(Context context, Preset.Mode mode, Prefs prefs) {
        modeSwitch(context, mode, prefs);
    }

    // ---------------------------------------------------------------- 波形

    /**
     * 三档的扫频。区间都落在 480~1780Hz，手机小喇叭在这个范围最干净，
     * 不会出现"吱吱"的破音。
     */
    private static int[][] tone(Preset.Mode mode) {
        if (mode == Preset.Mode.SAFE) {
            // 下行：收束、退半步。音量最低，像把开关轻轻拨回左边。
            return new int[][]{{760, 486, 92}};
        }
        if (mode == Preset.Mode.FAST) {
            // 三连上冲：一次比一次短、一次比一次高，收尾干脆。
            return new int[][]{{540, 1120, 62}, {1240, 1420, 44}, {1600, 1760, 40}};
        }
        // 上行五度：稳、确认。两个音，第二个稍长，听起来"落定"。
        return new int[][]{{700, 990, 78}, {1180, 1240, 60}};
    }

    /**
     * 合成：每个音符是 {起始频率, 结束频率, 毫秒}，频率在音符内线性滑动。
     * 叠二次、三次谐波让音色有点"金属感"，纯正弦会显得廉价。
     */
    private static short[] render(int[][] notes, float noise) {
        int total = 0;
        for (int[] note : notes) total += Math.max(1, note[2] * SAMPLE_RATE / 1000);
        short[] buffer = new short[total];
        int cursor = 0;
        double phase = 0;
        long seed = 0x9E3779B97F4A7C15L;
        int noiseSamples = (int) (SAMPLE_RATE * 0.008);
        for (int[] note : notes) {
            int count = Math.max(1, note[2] * SAMPLE_RATE / 1000);
            for (int i = 0; i < count; i++) {
                double t = (double) i / count;
                double freq = note[0] + (note[1] - note[0]) * t;
                phase += 2.0 * Math.PI * freq / SAMPLE_RATE;
                double attack = Math.min(1.0, i / (SAMPLE_RATE * 0.004));
                double decay = Math.pow(1.0 - t, 1.9);
                double wave = Math.sin(phase) + 0.20 * Math.sin(phase * 2) + 0.07 * Math.sin(phase * 3);
                double value = wave * attack * decay * GAIN;
                int absolute = cursor + i;
                if (noise > 0f && absolute < noiseSamples) {
                    seed = seed * 6364136223846793005L + 1442695040888963407L;
                    double rnd = ((seed >>> 40) / (double) (1L << 23)) - 1.0;
                    value += rnd * noise * (1.0 - absolute / (double) noiseSamples);
                }
                double scaled = value * Short.MAX_VALUE;
                buffer[absolute] = (short) Math.max(Short.MIN_VALUE, Math.min(Short.MAX_VALUE, scaled));
            }
            cursor += count;
        }
        return buffer;
    }

    private static void play(int[][] notes) {
        play(render(notes, 0.05f));
    }

    private static void play(short[] buffer) {
        if (buffer.length == 0) return;
        try {
            int bytes = buffer.length * 2;
            AudioTrack track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SAMPLE_RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(bytes)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build();
            track.write(buffer, 0, buffer.length);
            AudioTrack previous = current;
            current = track;
            if (previous != null) {
                try {
                    previous.stop();
                    previous.release();
                } catch (RuntimeException ignored) {
                }
            }
            track.play();
            MAIN.postDelayed(() -> {
                if (current == track) current = null;
                track.release();
            }, (long) buffer.length * 1000 / SAMPLE_RATE + 260L);
        } catch (RuntimeException ignored) {
            // 静音模式、音频设备被占用、厂商裁剪 AudioTrack —— 都不该影响主流程。
        }
    }

    // ---------------------------------------------------------------- 震动

    private static void buzz(Context context, Preset.Mode mode) {
        if (mode == Preset.Mode.SAFE) {
            // 一下：轻、短，像按下拨杆的尽头
            vibrate(context, new long[]{0, 12}, new int[]{0, 85});
        } else if (mode == Preset.Mode.FAST) {
            // 三下，间隔 24ms：密度上来，"冲"的感觉来自节奏而不是时长
            vibrate(context, new long[]{0, 6, 24, 8, 24, 13}, new int[]{0, 95, 0, 145, 0, 215});
        } else {
            // 两下：第一下确认按下，第二下确认落位
            vibrate(context, new long[]{0, 8, 40, 12}, new int[]{0, 105, 0, 155});
        }
    }

    private static void vibrate(Context context, long[] timings, int[] amplitudes) {
        try {
            Vibrator vibrator;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                VibratorManager manager =
                        (VibratorManager) context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
                vibrator = manager == null ? null : manager.getDefaultVibrator();
            } else {
                vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
            }
            if (vibrator == null || !vibrator.hasVibrator()) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1));
            } else {
                vibrator.vibrate(timings, -1);
            }
        } catch (RuntimeException ignored) {
        }
    }

    /** 保留给未来接入系统媒体音量判断；当前 AudioTrack 已按 SONIFICATION 通道播放。 */
    static int stream() { return AudioManager.STREAM_MUSIC; }
}
