package app.shunjing.skipper.engine;

import java.util.Locale;

/**
 * Validates untrusted vision-model output before any coordinate can reach dispatchGesture.
 *
 * <p>v1.5 起阈值随「接管灵敏度」变化：旧版固定 0.80 置信度 + 12% 面积 + 必须命中可点击祖先，
 * 结果是无障碍树全 c=0 的 SDK 自绘广告（例如摇一摇落地页）永远过不了校验——云端明明认出来了，
 * 本地却把它丢掉。现在允许「小而干净、但没有可点击祖先」的节点通过，同时保留全部危险词排除
 * 与敏感页硬拦截。
 */
public final class VisionRecoveryPolicy {
    private static final String[] DANGEROUS = {
            "下载", "安装", "打开", "领取", "立即", "详情", "购买", "登录", "注册", "同意",
            "允许", "授权", "支付", "付款", "提交", "播放", "暂停", "静音", "更多", "分享",
            "download", "install", "open", "buy", "pay", "login", "allow", "agree", "share"
    };
    private static final String[] CLOSE = {"关闭广告", "跳过广告", "关闭", "跳过",
            "close ad", "skip ad", "dismiss", "exit"};

    /** 单个目标最多占屏幕的比例：广告关闭图标远小于此，整屏容器必然超过。 */
    private static final int MAX_TARGET_PERCENT = 20;

    private VisionRecoveryPolicy() { }

    /** 基础结构校验（旧版语义，0.80 门槛）。 */
    public static boolean validAnswer(boolean found, int x, int y, float confidence) {
        return hasUsableCoordinates(found, x, y, confidence) && confidence >= 0.80f;
    }

    /**
     * v1.5：坐标是否值得继续往下校验。置信度门槛不在这里定，而是按接管灵敏度在
     * {@link #allowCoordinateOnly} 里判——激进档本来就要求"先给个位置，再本地校验"。
     */
    public static boolean hasUsableCoordinates(boolean found, int x, int y, float confidence) {
        return found && x >= 0 && x <= 1000 && y >= 0 && y <= 1000 && confidence >= 0.35f;
    }

    public static int toPixels(int normalized, int size) {
        return Math.round(normalized / 1000f * size);
    }

    /**
     * 返回包含该点的最安全的可点击祖先，找不到则 -1。
     * 保留给"节点确实可点击"的常规路径。
     */
    public static int findSafeNode(ScreenModel screen, int x, int y, int width, int height) {
        if (screen == null || AdDecisionEngine.isSensitive(screen)) return -1;
        int best = -1, bestArea = Integer.MAX_VALUE;
        for (NodeModel n : screen.nodes) {
            if (!n.visible || n.password || !n.hasBounds()) continue;
            if (x < n.left || x > n.right || y < n.top || y > n.bottom) continue;
            int clickableIndex = AdDecisionEngine.findClickableAncestor(screen.nodes, n);
            if (clickableIndex < 0) continue;
            NodeModel target = screen.nodes.get(clickableIndex);
            if (!safeNodeAndChildren(screen, n) || !safeNodeAndChildren(screen, target)) continue;
            int area = target.area();
            if (area <= 0 || (long) area * 100L > (long) width * height * MAX_TARGET_PERCENT) continue;
            if (area < bestArea) { best = clickableIndex; bestArea = area; }
        }
        return best;
    }

    /**
     * v1.5：返回包含该点的最小安全节点，**不要求可点击**。
     *
     * <p>大量广告 SDK 的关闭图标在无障碍层里整棵子树 `clickable=false`，坐标却完全正确。
     * 这里只校验"这个点确实落在一个小尺寸、无危险文案的控件里"，点击由服务层用坐标手势完成。
     *
     * @return 节点下标；没有任何候选返回 -1
     */
    public static int findSafeTarget(ScreenModel screen, int x, int y, int width, int height) {
        if (screen == null || width <= 0 || height <= 0) return -1;
        if (AdDecisionEngine.isSensitive(screen)) return -1;
        int best = -1, bestArea = Integer.MAX_VALUE;
        for (NodeModel n : screen.nodes) {
            if (!n.visible || n.password || !n.hasBounds()) continue;
            if (x < n.left || x > n.right || y < n.top || y > n.bottom) continue;
            if (!safeNodeAndChildren(screen, n)) continue;
            int area = n.area();
            if (area <= 0 || (long) area * 100L > (long) width * height * MAX_TARGET_PERCENT) continue;
            if (area < bestArea) { best = n.index; bestArea = area; }
        }
        return best;
    }

    /**
     * 直接按模型给的坐标点击，需要同时满足：页面确实是广告位、置信度达到当前灵敏度阈值、
     * 且不是敏感页。只有拿不到任何安全节点时才走这条路。
     */
    public static boolean allowCoordinateOnly(ScreenModel screen, int x, int y, float confidence,
                                              VisionTriggerPolicy.Sensitivity sensitivity) {
        if (screen == null || AdDecisionEngine.isSensitive(screen)) return false;
        if (!VisionTriggerPolicy.allowsCoordinateOnly(sensitivity, confidence)) return false;
        if (pointsAtDangerousControl(screen, x, y)) return false;
        return AdDecisionEngine.hasPromoContext(screen)
                || AdDecisionEngine.hasShakeAd(screen)
                || StructuralAdEvidence.matches(screen)
                || AdDecisionEngine.hasAdContext(screen, EngineSettings.defaults());
    }

    /**
     * v1.6：本地只有「疑似」时，云端坐标兜底要更贵一点才放行。
     *
     * <p>这是"让 AI 敢在看起来像广告的页面上动手"的那道闸：置信度下限抬到
     * {@code max(minConfidence, 0.80)}，并且要求页面此刻仍然是疑似广告页
     * （不是扫码 / 支付 / 密码 / 桌面 / 系统应用），坐标也不得压在下载、支付、
     * 领取、授权这类按钮上。任一条件不满足就放弃，只留日志。
     */
    public static boolean allowCoordinateOnly(ScreenModel screen, int x, int y, float confidence,
                                              VisionTriggerPolicy.Sensitivity sensitivity,
                                              float minConfidence, boolean suspectOnly) {
        if (screen == null || AdDecisionEngine.isSensitive(screen)) return false;
        if (AdDecisionEngine.isProtectedPackage(screen.packageName)) return false;
        if (suspectOnly && !AdSuspectDetector.isSuspect(screen)) return false;
        float threshold = minConfidence;
        if (suspectOnly) threshold = Math.max(threshold, 0.80f);
        if (sensitivity != null) threshold = Math.max(threshold, sensitivity.minConfidence);
        if (confidence < threshold) return false;
        if (pointsAtDangerousControl(screen, x, y)) return false;
        if (!suspectOnly) {
            return AdDecisionEngine.hasPromoContext(screen)
                    || AdDecisionEngine.hasShakeAd(screen)
                    || StructuralAdEvidence.matches(screen)
                    || AdDecisionEngine.hasAdContext(screen, EngineSettings.defaults());
        }
        return true;
    }

    /**
     * 兼容 v1.3 / v1.4 的调用签名：按最保守档校验，行为等价于旧版（高置信度 + 广告上下文）。
     */
    @Deprecated
    public static boolean allowCoordinateOnly(ScreenModel screen, float confidence,
                                              EngineSettings settings) {
        if (settings == null) return false;
        return allowCoordinateOnly(screen, -1, -1, confidence,
                VisionTriggerPolicy.Sensitivity.CONSERVATIVE);
    }

    /**
     * 模型给的坐标是否压在下载 / 安装 / 领取 / 支付这类按钮上。
     * 只取覆盖该点的最小控件，再沿父链向上检查，避免把根容器的文案算进来。
     */
    private static boolean pointsAtDangerousControl(ScreenModel screen, int x, int y) {
        if (x < 0 || y < 0) return false;
        int smallest = -1;
        long smallestArea = Long.MAX_VALUE;
        for (NodeModel n : screen.nodes) {
            if (!n.visible || !n.hasBounds()) continue;
            if (x < n.left || x > n.right || y < n.top || y > n.bottom) continue;
            long area = (long) (n.right - n.left) * (n.bottom - n.top);
            if (area < smallestArea) { smallest = n.index; smallestArea = area; }
        }
        int guard = 0;
        while (smallest >= 0 && smallest < screen.nodes.size() && guard++ < 12) {
            NodeModel node = screen.nodes.get(smallest);
            String value = (node.text + " " + node.contentDescription + " " + node.viewId)
                    .toLowerCase(Locale.ROOT);
            if (containsAny(value, DANGEROUS) && !containsAny(value, CLOSE)) return true;
            smallest = node.parentIndex;
        }
        return false;
    }

    private static boolean safeNodeAndChildren(ScreenModel screen, NodeModel node) {
        String value = (node.text + " " + node.contentDescription + " " + node.viewId)
                .toLowerCase(Locale.ROOT);
        if (containsAny(value, DANGEROUS) && !containsAny(value, CLOSE)) return false;
        for (NodeModel child : screen.nodes) {
            if (child.parentIndex != node.index) continue;
            String childValue = (child.text + " " + child.contentDescription + " " + child.viewId)
                    .toLowerCase(Locale.ROOT);
            if (containsAny(childValue, DANGEROUS) && !containsAny(childValue, CLOSE)) return false;
        }
        return true;
    }

    private static boolean containsAny(String value, String[] words) {
        for (String word : words) if (value.contains(word)) return true;
        return false;
    }
}
