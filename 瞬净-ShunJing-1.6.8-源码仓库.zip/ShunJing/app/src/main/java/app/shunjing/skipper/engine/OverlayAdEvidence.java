package app.shunjing.skipper.engine;

import java.util.Locale;

/**
 * v1.6.5：「叠加式下载广告」的结构证据。
 *
 * <p>现场来源：胖乖生活（com.qiekj.user）在「我的设备」页弹出的梦幻西游下载广告。
 * Activity 名是 {@code android.app.Dialog}，整棵树 32 个节点、全部 c=0，没有任何
 * 广告 SDK 的代理页或控件 ID 家族 —— {@link StructuralAdEvidence} 一条都不成立，
 * 于是 {@code adContext=false}：所有 ctx=1 规则静默，三个几何定位器全部要求
 * 「可点祖先」或「SDK 代理页」，也全部落空，云端 AI 又因为「本地看不出是广告」
 * 而睡不醒。用户看到的就是：广告明明就在眼前，软件一动不动。
 *
 * <p>这类广告有一套别的页面不会同时具备的特征：
 * <ul>
 *   <li><b>合规条</b>：应用名称 / 应用版本 / 开发者 / 适用年龄 / 权限详情 / 隐私协议 /
 *       备案信息，这一行是《互联网广告管理办法》强制要求下载类广告披露的。同一条文本里
 *       同时出现「应用名称」和「开发者」（或版本号 / 权限详情 / 隐私协议 / 备案信息），
 *       只会出现在广告上 —— App 自己的「关于」页是分行的独立字段。</li>
 *   <li><b>视频素材</b>：TextureView / SurfaceView / VideoView 占屏 ≥3%。</li>
 *   <li><b>下载诱导文案</b>：下载游戏 / 立即下载 / 查看详情 / 上滑 …</li>
 *   <li><b>叠加窗口</b>：Activity 是 Dialog / Popup / Overlay，而不是 App 自己的页面。</li>
 * </ul>
 *
 * <p>权重分配刻意做成「合规条单项不够、两项才成立」：合规条 4 分、视频 2 分、
 * 文案 2 分、叠加窗口 1 分，阈值 5。也就是说，<b>单独一条「查看详情」或单独一个
 * 对话框永远不会被判成广告</b>，必须再叠上视频素材或那行合规条。
 *
 * <p>本类只回答「这一页是不是下载广告」，不授权点击。点击入口在
 * {@link DownloadAdCloseLocator}，它还会再查一遍敏感页硬锁与危险动作词。
 */
public final class OverlayAdEvidence {

    /** 下载类广告合规条的开头：应用名称。 */
    private static final String DISCLOSURE_HEAD = "应用名称";
    /** 与「应用名称」同句出现的佐证字段。 */
    private static final String[] DISCLOSURE_TAIL = {
            "开发者", "开发公司", "应用版本", "版本号", "权限详情", "隐私协议", "备案信息", "适用年龄"
    };

    private static final String[] CTA_WORDS = {
            "下载游戏", "立即下载", "马上下载", "点击下载", "去下载", "下载应用", "立即安装",
            "查看详情", "点击查看详情", "上滑", "滑动查看", "了解更多", "打开应用", "打开第三方"
    };

    private static final String[] VIDEO_CLASSES = {
            "textureview", "surfaceview", "videoview"
    };

    private static final String[] OVERLAY_MARKERS = {
            "dialog", "popup", "overlay", "float", "dialogactivity"
    };

    /** 4（合规条）+2（视频）+2（文案）+1（叠加窗）= 9；阈值 5 要求至少两项独立信号。 */
    public static final int THRESHOLD = 5;

    private OverlayAdEvidence() { }

    public static boolean matches(ScreenModel screen) {
        return score(screen) >= THRESHOLD;
    }

    /** 0 = 不是下载广告；分数越高越确定。支付 / 扫码 / 受保护包直接 0。 */
    public static int score(ScreenModel screen) {
        if (screen == null || screen.nodes.isEmpty()) return 0;
        if (AdDecisionEngine.isProtectedPackage(screen.packageName)) return 0;
        if (AdDecisionEngine.isPaymentOrScan(screen)) return 0;

        int width = 0, height = 0;
        for (NodeModel n : screen.nodes) {
            if (!n.visible || !n.hasBounds()) continue;
            width = Math.max(width, n.right);
            height = Math.max(height, n.bottom);
        }
        if (width <= 0 || height <= 0) return 0;

        int score = 0;
        if (hasDisclosure(screen)) score += 4;
        if (hasVideoCreative(screen, width, height)) score += 2;
        if (hasDownloadCta(screen)) score += 2;
        if (isOverlayWindow(screen.activityName)) score += 1;
        return score;
    }

    /** 监管强制披露行：同一条文本里既有「应用名称」，又有开发者 / 版本 / 权限 / 备案。 */
    public static boolean hasDisclosure(ScreenModel screen) {
        for (NodeModel n : screen.nodes) {
            String value = n.text + " " + n.contentDescription;
            if (value.isEmpty() || !value.contains(DISCLOSURE_HEAD)) continue;
            for (String tail : DISCLOSURE_TAIL) {
                if (value.contains(tail)) return true;
            }
        }
        return false;
    }

    public static boolean hasVideoCreative(ScreenModel screen, int width, int height) {
        long screenArea = (long) width * height;
        for (NodeModel n : screen.nodes) {
            if (!n.visible || !n.hasBounds()) continue;
            String cls = n.className.toLowerCase(Locale.ROOT);
            boolean video = false;
            for (String marker : VIDEO_CLASSES) {
                if (cls.endsWith(marker)) { video = true; break; }
            }
            if (!video) continue;
            long area = (long) (n.right - n.left) * (n.bottom - n.top);
            if (area >= screenArea * 0.03f) return true;
        }
        return false;
    }

    public static boolean hasDownloadCta(ScreenModel screen) {
        for (NodeModel n : screen.nodes) {
            String value = n.text + " " + n.contentDescription;
            if (value.isEmpty()) continue;
            for (String word : CTA_WORDS) {
                if (value.contains(word)) return true;
            }
        }
        return false;
    }

    public static boolean isOverlayWindow(String activityName) {
        String value = activityName == null ? "" : activityName.toLowerCase(Locale.ROOT);
        if (value.isEmpty()) return false;
        for (String marker : OVERLAY_MARKERS) {
            if (value.contains(marker)) return true;
        }
        return false;
    }
}
