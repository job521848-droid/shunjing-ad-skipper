package app.shunjing.skipper.engine;

import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/** Finds skip controls that appear or change while a splash countdown is still running. */
public final class DynamicSkipDetector {
    private static final Pattern COUNTDOWN = Pattern.compile(".*\\d+\\s*(s|秒|s$)?.*", Pattern.CASE_INSENSITIVE);
    private static final String[] CTA_WORDS = {
            "下载", "安装", "打开", "领取", "立即", "详情", "购买", "登录", "注册", "同意", "允许"
    };

    private DynamicSkipDetector() { }

    /** A compact label such as "跳过", "3秒后可跳过" or "Skip 2". */
    public static boolean isCompactSkipLabel(NodeModel node) {
        return compact(node.normalizedText()) || compact(node.normalizedDescription());
    }

    private static boolean compact(String value) {
        if (value.isEmpty() || value.length() > 28) return false;
        boolean skip = value.contains("跳过") || value.contains("skip");
        if (!skip || containsAny(value, CTA_WORDS)) return false;
        // "跳过" alone and "跳过3" are both valid; longer prose requires a countdown.
        if (value.matches("(跳过|skip)\\d*(s|秒)?")) return true;
        return COUNTDOWN.matcher(value).matches();
    }

    /**
     * Handles SDKs that split "跳" / "过" / "3" into sibling nodes. Returns the actual
     * clickable node/ancestor, never the numeric countdown itself.
     */
    public static int findSplitSkipTarget(ScreenModel screen, boolean adContext) {
        if (screen == null || (!adContext && !screen.launchedRecently)) return -1;
        List<NodeModel> nodes = screen.nodes;
        for (NodeModel first : nodes) {
            if (!isVisibleLabel(first)) continue;
            String a = first.normalizedText().isEmpty() ? first.normalizedDescription() : first.normalizedText();
            if (!(a.equals("跳") || a.equals("跳过了"))) continue;
            for (NodeModel second : nodes) {
                if (second.index == first.index || !isVisibleLabel(second)) continue;
                String b = second.normalizedText().isEmpty() ? second.normalizedDescription() : second.normalizedText();
                if (!b.startsWith("过")) continue;
                if (first.parentIndex != second.parentIndex && !near(first, second)) continue;
                int target = AdDecisionEngine.findClickableAncestor(nodes, first);
                if (target < 0) target = AdDecisionEngine.findClickableAncestor(nodes, second);
                if (target < 0 && first.parentIndex >= 0 && first.parentIndex < nodes.size()) {
                    NodeModel parent = nodes.get(first.parentIndex);
                    target = AdDecisionEngine.findClickableAncestor(nodes, parent);
                }
                if (target >= 0) return target;
            }
        }
        return -1;
    }

    /** True when a visible countdown exists, used only to schedule a bounded fast re-check. */
    public static boolean hasCountdown(ScreenModel screen) {
        for (NodeModel n : screen.nodes) {
            if (!n.visible) continue;
            String value = (n.normalizedText() + n.normalizedDescription()).toLowerCase(Locale.ROOT);
            if (value.matches(".*\\d+\\s*(s|秒).*") || value.matches("\\d{1,2}")) return true;
        }
        return false;
    }

    private static boolean isVisibleLabel(NodeModel n) {
        return n.visible && !n.password && n.hasBounds()
                && (!n.normalizedText().isEmpty() || !n.normalizedDescription().isEmpty());
    }

    private static boolean near(NodeModel a, NodeModel b) {
        int height = Math.max(1, Math.min(a.bottom - a.top, b.bottom - b.top));
        return Math.abs(a.top - b.top) <= height && Math.abs(a.right - b.left) <= height * 3;
    }

    private static boolean containsAny(String value, String[] words) {
        for (String word : words) if (value.contains(word)) return true;
        return false;
    }
}
