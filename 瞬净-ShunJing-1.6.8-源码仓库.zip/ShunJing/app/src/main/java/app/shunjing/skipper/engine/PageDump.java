package app.shunjing.skipper.engine;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Android-free immutable snapshot of one window's accessibility tree. */
public final class PageDump {
    public static final String SOURCE_MANUAL = "manual";
    public static final String SOURCE_AUTO = "auto";
    public static final String SOURCE_NEXT = "next";

    public final String id;
    public final long time;
    public final String packageName;
    public final String activityName;
    public final String appLabel;
    public final String source;
    public final int screenWidth;
    public final int screenHeight;
    public final boolean launchedRecently;
    public final List<NodeModel> nodes;

    public PageDump(String id, long time, String packageName, String activityName, String appLabel,
                    String source, int screenWidth, int screenHeight, boolean launchedRecently,
                    List<NodeModel> nodes) {
        this.id = safe(id);
        this.time = time;
        this.packageName = safe(packageName);
        this.activityName = safe(activityName);
        this.appLabel = safe(appLabel);
        this.source = safe(source);
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.launchedRecently = launchedRecently;
        this.nodes = nodes == null ? Collections.emptyList()
                : Collections.unmodifiableList(new ArrayList<>(nodes));
    }

    public ScreenModel toScreen() {
        return new ScreenModel(packageName, activityName, launchedRecently, nodes);
    }

    public int labeledNodeCount() {
        int count = 0;
        for (NodeModel node : nodes) {
            if (!node.text.trim().isEmpty() || !node.contentDescription.trim().isEmpty()) count++;
        }
        return count;
    }

    public String sourceLabel() {
        if (SOURCE_AUTO.equals(source)) return "自动留样";
        if (SOURCE_NEXT.equals(source)) return "抓下一屏";
        return "手动抓取";
    }

    private static String safe(String value) { return value == null ? "" : value; }
}
