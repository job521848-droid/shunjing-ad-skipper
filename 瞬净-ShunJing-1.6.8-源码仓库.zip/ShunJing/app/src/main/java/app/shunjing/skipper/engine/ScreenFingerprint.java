package app.shunjing.skipper.engine;

/** Structural page identity that ignores changing countdown digits. Android-free and testable. */
public final class ScreenFingerprint {
    private ScreenFingerprint() { }

    public static String of(ScreenModel screen) {
        StringBuilder b = new StringBuilder();
        b.append(screen.packageName).append('|').append(screen.activityName).append('|')
                .append(screen.nodes.size());
        for (NodeModel n : screen.nodes) {
            b.append('\n').append(n.index).append(':').append(n.parentIndex).append(':')
                    .append(n.className).append(':').append(n.viewId).append(':')
                    .append(n.clickable ? 1 : 0).append(n.visible ? 1 : 0).append(':')
                    .append(n.left).append(',').append(n.top).append(',')
                    .append(n.right).append(',').append(n.bottom).append(':')
                    .append(stableText(n.normalizedText())).append(':')
                    .append(stableText(n.normalizedDescription()));
        }
        return b.toString();
    }

    public static boolean unchanged(ScreenModel before, ScreenModel after) {
        return before != null && after != null && of(before).equals(of(after));
    }

    private static String stableText(String value) {
        // A 3 -> 2 -> 1 countdown is not evidence that the ad was closed.
        return value.replaceAll("\\d+(?:\\.\\d+)?", "#");
    }
}
