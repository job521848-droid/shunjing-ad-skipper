package app.shunjing.skipper.ui;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import app.shunjing.skipper.R;
import app.shunjing.skipper.data.Prefs;
import app.shunjing.skipper.data.VisionProvider;
import app.shunjing.skipper.engine.ScreenModel;
import app.shunjing.skipper.engine.VisionTriggerPolicy;
import app.shunjing.skipper.service.VisionRecoveryClient;

/** Optional cloud-vision configuration. No credentials are hard-coded or shipped. */
public final class CloudVisionActivity extends BaseActivity {
    private Prefs prefs;
    private SegmentBar bar;
    private EditText endpoint;
    private EditText apiKey;
    private EditText model;
    private LinearLayout endpointRow;
    private LinearLayout modelRow;
    private TextView tip;
    private TextView result;
    private TextView consoleUrl;
    private Button consoleCopy;
    private String consoleValue = "";
    private VisionRecoveryClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        LinearLayout root = Ui.root(this);
        root.addView(Ui.header(this, "云端视觉复核", "本地没处理掉的广告，AI 在 1 秒内接管 · 默认关闭", true));
        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout status = Ui.card(this);
        status.addView(Ui.caption(this, "01 / 触发边界"));
        Switch enabled = new Switch(this);
        enabled.setText("启用云端视觉 AI");
        enabled.setTextSize(17);
        enabled.setTextColor(getColor(R.color.text_primary));
        enabled.setChecked(prefs.cloudVisionEnabled());
        enabled.setOnCheckedChangeListener((button, checked) -> {
            if (checked && !prefs.cloudVisionConsent()) {
                button.setChecked(false);
                showConsent();
            } else {
                prefs.preferences().edit().putBoolean("cloud_vision", checked).apply();
            }
        });
        status.addView(enabled);
        status.addView(Ui.text(this,
                "本地能处理的一律本地处理，不联网。只有「页面上没有可点的关闭控件」或"
                        + "「点了之后页面没变化」时，才把这一屏交给云端。",
                13, getColor(R.color.text_secondary)));

        // 从「高级设置」搬过来的：它只影响云端是否主动出手，和别的开关无关。
        Switch patrol = new Switch(this);
        patrol.setText("AI 主动巡查");
        patrol.setTextColor(getColor(R.color.text_primary));
        patrol.setTextSize(14);
        patrol.setChecked(prefs.adSuspectEnabled());
        patrol.setOnCheckedChangeListener((button, checked) ->
                prefs.preferences().edit().putBoolean("ad_suspect", checked).apply());
        LinearLayout.LayoutParams patrolParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        patrolParams.topMargin = Ui.dp(this, 6);
        status.addView(patrol, patrolParams);
        status.addView(Ui.text(this,
                "打开后，本地看不出是广告、但整屏明显像广告的页面也会让云端看一眼；"
                        + "关掉则只在「本地确实找不到可点目标」时才请求。",
                12, getColor(R.color.text_secondary)));
        content.addView(status);

        // ------------------------------------------------------------ 接管时机
        LinearLayout timing = Ui.card(this);
        timing.addView(Ui.caption(this, "02 / 接管时机"));
        timing.addView(Ui.text(this,
                "广告只停留一两秒，等待越久越没用。档位越高，AI 越早接手，请求也越频繁。",
                13, getColor(R.color.text_secondary)));

        VisionTriggerPolicy.Sensitivity sensitivity = prefs.visionSensitivity();
        // 全局只有三档；「重点」是逐个应用点星后自动生效的档位，不出现在这里。
        int selectedIndex = sensitivity == VisionTriggerPolicy.Sensitivity.PRIORITY
                ? VisionTriggerPolicy.Sensitivity.AGGRESSIVE.ordinal() : sensitivity.ordinal();
        SegmentBar speedBar = new SegmentBar(this,
                new String[]{"保守", "积极", "激进"}, selectedIndex);
        LinearLayout.LayoutParams speedParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 46));
        speedParams.topMargin = Ui.dp(this, 14);
        timing.addView(speedBar, speedParams);

        TextView speedDetail = Ui.text(this, "", 12, getColor(R.color.cyan));
        speedDetail.setPadding(0, Ui.dp(this, 10), 0, 0);
        timing.addView(speedDetail);
        speedBar.setOnSelectListener(index -> {
            VisionTriggerPolicy.Sensitivity value =
                    VisionTriggerPolicy.Sensitivity.values()[Math.max(0,
                            Math.min(index, VisionTriggerPolicy.Sensitivity.values().length - 1))];
            prefs.setVisionSensitivity(value);
            speedDetail.setText(describe(value));
        });
        speedDetail.setText(describe(sensitivity));
        content.addView(timing);

        LinearLayout config = Ui.card(this);
        config.addView(Ui.caption(this, "03 / 选一个服务商"));
        config.addView(Ui.text(this,
                "三行配置里只有 API Key 需要你自己去拿。地址和模型名选完就自动填好，"
                        + "到服务商控制台复制一串 Key 粘贴进来即可。",
                13, getColor(R.color.text_secondary)));

        int preset = VisionProvider.indexOfEndpoint(prefs.cloudEndpoint());
        bar = new SegmentBar(this, VisionProvider.labels(), preset);
        LinearLayout.LayoutParams barParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 46));
        barParams.topMargin = Ui.dp(this, 14);
        config.addView(bar, barParams);
        bar.setOnSelectListener(this::applyProvider);

        tip = Ui.text(this, "", 12, getColor(R.color.cyan));
        tip.setPadding(0, Ui.dp(this, 10), 0, 0);
        config.addView(tip);

        endpointRow = new LinearLayout(this);
        endpointRow.setOrientation(LinearLayout.VERTICAL);
        endpoint = Ui.input(this, "https://.../v1/chat/completions");
        endpoint.setText(prefs.cloudEndpoint());
        endpoint.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        endpointRow.addView(label("接口地址（仅 HTTPS）"));
        endpointRow.addView(endpoint);
        config.addView(endpointRow);

        modelRow = new LinearLayout(this);
        modelRow.setOrientation(LinearLayout.VERTICAL);
        model = Ui.input(this, "支持图片输入的模型名");
        model.setText(prefs.cloudModel());
        modelRow.addView(label("多模态模型名"));
        modelRow.addView(model);
        config.addView(modelRow);

        apiKey = Ui.input(this, "粘贴你申请到的 Key，形如 sk-... / xxxxxxxx.xxxxxxxx");
        apiKey.setText(prefs.cloudApiKey());
        apiKey.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        config.addView(label("API Key（唯一必须自己填的一项）"));
        config.addView(apiKey);

        result = Ui.text(this, "", 12, getColor(R.color.text_secondary));
        result.setPadding(0, Ui.dp(this, 12), 0, 0);
        config.addView(result);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button save = Ui.primary(this, "保存配置");
        save.setOnClickListener(v -> saveConfig());
        actions.addView(save, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button test = Ui.secondary(this, "测试连接");
        test.setOnClickListener(v -> testConnection());
        LinearLayout.LayoutParams testParams = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        testParams.setMargins(Ui.dp(this, 10), 0, 0, 0);
        actions.addView(test, testParams);
        LinearLayout.LayoutParams actionParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        actionParams.topMargin = Ui.dp(this, 16);
        config.addView(actions, actionParams);
        content.addView(config);

        LinearLayout keyGuide = Ui.card(this);
        keyGuide.addView(Ui.caption(this, "04 / 怎么拿到 Key"));
        keyGuide.addView(Ui.text(this,
                "只有 API Key 要你自己申请，接口地址和模型名选完服务商就自动填好了。\n"
                        + "三步：打开下面的控制台 → 注册并登录 → 在「API Key / API-KEY」里新建一个，"
                        + "复制那串字符，回来粘进上面的输入框。",
                13, getColor(R.color.text_secondary)));

        consoleUrl = Ui.text(this, "", 13, getColor(R.color.cyan));
        consoleUrl.setTypeface(Typeface.MONOSPACE);
        // 长按即可选中整段，方便在没装浏览器的情况下先把地址抄走。
        consoleUrl.setTextIsSelectable(true);
        consoleUrl.setLineSpacing(Ui.dp(this, 3), 1f);
        consoleUrl.setPadding(Ui.dp(this, 12), Ui.dp(this, 11), Ui.dp(this, 12), Ui.dp(this, 11));
        consoleUrl.setBackgroundResource(R.drawable.bg_row);
        LinearLayout.LayoutParams urlParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        urlParams.topMargin = Ui.dp(this, 12);
        keyGuide.addView(consoleUrl, urlParams);

        consoleCopy = Ui.secondary(this, "复制这个地址");
        consoleCopy.setOnClickListener(v -> copyConsole());
        LinearLayout.LayoutParams copyParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        copyParams.topMargin = Ui.dp(this, 10);
        keyGuide.addView(consoleCopy, copyParams);

        keyGuide.addView(Ui.text(this,
                "· 先去控制台把要用的模型开通，没开通会返回 403 / 无权限\n"
                        + "· Key 一般只完整显示一次，关掉页面就看不到了，丢了就再建一个\n"
                        + "· 有免费额度的先用免费的，够用就别急着充钱\n"
                        + "· 填完点「测试连接」，看到「连接正常」再打开上面的开关",
                12, getColor(R.color.text_secondary)));
        content.addView(keyGuide);

        LinearLayout privacy = Ui.card(this);
        privacy.addView(Ui.caption(this, "05 / 隐私与能力边界"));
        privacy.addView(Ui.text(this,
                "开启即表示你理解：触发复核时，当前广告页截图和控件结构会发送给你配置的服务商，"
                        + "其数据保留政策由该服务商决定。截图仅内存处理，不保存到瞬净；API Key 使用应用私有存储，设备未加密时仍请妥善保管。\n\n"
                        + "只有支付、扫码、密码与验证码页面禁止截图和上传；其余页面（包括广告页）都会正常参与识别。"
                        + "模型坐标还需通过置信度、广告上下文、控件尺寸及危险按钮排除校验，不会直接盲点。\n\n"
                        + "Android 11 及以上才能使用无障碍截图；旧系统自动退回本地复核。云端受网络和服务商延迟影响，不承诺实时。\n\n"
                        + "不想折腾也可以不填：本地规则 + 叠层定位 + 自适应补点已经能处理绝大多数广告，"
                        + "云端只是在本地确实找不到可点目标时多一次机会。",
                13, getColor(R.color.text_secondary)));
        content.addView(privacy);
        setContentView(root);

        applyProvider(preset, false);
    }

    /** 把档位的真实参数说清楚，避免"选了个档但不知道差在哪"。 */
    private String describe(VisionTriggerPolicy.Sensitivity sensitivity) {
        switch (sensitivity) {
            case CONSERVATIVE:
                return "广告页停留 3 秒仍无本地动作才请求；同一页面 25 秒最多一次。最省钱，慢。";
            case AGGRESSIVE:
                return "0.3 秒即接管；同一页面 3 秒可重试。适合「跳过只闪一瞬」的倒计时广告，请求会多。";
            default:
                return "0.65 秒接管；同一页面 6 秒最多一次。日常推荐：既不会让广告溜走，也不至于频繁上传。";
        }
    }

    private TextView label(String value) {
        TextView view = Ui.text(this, value, 13, getColor(R.color.cyan));
        view.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 5));
        return view;
    }

    private void applyProvider(int index) { applyProvider(index, true); }

    private void applyProvider(int index, boolean writeFields) {
        VisionProvider provider = VisionProvider.at(index);
        updateConsole(provider);
        if (provider == null) {
            tip.setText("自定义：填你手上任何 OpenAI 兼容的多模态地址（必须 https）。");
            endpointRow.setVisibility(View.VISIBLE);
            modelRow.setVisibility(View.VISIBLE);
            return;
        }
        if (writeFields) {
            endpoint.setText(provider.endpoint);
            model.setText(provider.model);
        }
        tip.setText(provider.tip);
        endpointRow.setVisibility(View.GONE);
        modelRow.setVisibility(View.VISIBLE);
    }

    /** 地址随服务商切换，独立成一行，长按可选中，也可一键复制。 */
    private void updateConsole(VisionProvider provider) {
        if (consoleUrl == null) return;
        if (provider == null) {
            consoleValue = "";
            consoleUrl.setText("你选了「自定义」：地址填你手上服务商的 OpenAI 兼容接口。\n"
                    + "绝大多数服务商的控制台里都有「API Keys / 密钥管理」一页，Key 就在那儿创建。");
            consoleCopy.setVisibility(View.GONE);
            return;
        }
        consoleValue = provider.console;
        consoleUrl.setText(provider.console);
        consoleCopy.setVisibility(View.VISIBLE);
    }

    private void copyConsole() {
        if (consoleValue.isEmpty()) return;
        ClipboardManager manager = getSystemService(ClipboardManager.class);
        if (manager == null) return;
        manager.setPrimaryClip(ClipData.newPlainText("API 控制台", consoleValue));
        // Android 13 起系统自己会弹一个复制提示，这里不再重复。
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            Toast.makeText(this, "地址已复制", Toast.LENGTH_SHORT).show();
        }
    }

    private void showConsent() {
        new AlertDialog.Builder(this)
                .setTitle("允许失败时上传广告截图？")
                .setMessage("只在广告点击多次且页面没有变化时，把当前截图与控件结构发送给你填写的接口。"
                        + "支付 / 扫码页不上传；截图不保存到本机。请确认你信任该服务商。")
                .setNegativeButton("暂不允许", null)
                .setPositiveButton("理解并允许", (d, w) -> {
                    prefs.preferences().edit().putBoolean("cloud_vision_consent", true)
                            .putBoolean("cloud_vision", true).apply();
                    recreate();
                }).show();
    }

    private boolean collect() {
        String url = endpoint.getText().toString().trim();
        String key = apiKey.getText().toString().trim();
        String modelName = model.getText().toString().trim();
        if (!url.startsWith("https://")) {
            Toast.makeText(this, "接口地址必须使用 HTTPS", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (key.isEmpty() || modelName.isEmpty()) {
            Toast.makeText(this, "还差 API Key 或模型名", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void saveConfig() {
        if (!collect()) return;
        prefs.preferences().edit()
                .putString("cloud_endpoint", endpoint.getText().toString().trim())
                .putString("cloud_api_key", apiKey.getText().toString().trim())
                .putString("cloud_model", model.getText().toString().trim()).apply();
        Toast.makeText(this, "云端视觉配置已保存", Toast.LENGTH_SHORT).show();
    }

    /** 用一张本地生成的小图真打一次接口，验证 Key、模型名、网络是否可用。 */
    private void testConnection() {
        if (!collect()) return;
        String url = endpoint.getText().toString().trim();
        String key = apiKey.getText().toString().trim();
        String modelName = model.getText().toString().trim();
        prefs.preferences().edit().putString("cloud_endpoint", url)
                .putString("cloud_api_key", key)
                .putString("cloud_model", modelName).apply();
        result.setTextColor(getColor(R.color.text_secondary));
        result.setText("正在请求，最多等 10 秒…");
        if (client == null) client = new VisionRecoveryClient();
        ScreenModel screen = new ScreenModel("app.shunjing.skipper", "SelfTest", false, null);
        client.analyze(url, key, modelName, sample(), screen, new VisionRecoveryClient.Callback() {
            @Override
            public void onResult(VisionRecoveryClient.Answer answer) {
                result.setTextColor(getColor(R.color.cyan));
                result.setText("连接正常。模型返回：" + (answer.found ? "找到按钮" : "未给坐标")
                        + "，置信度 " + String.format("%.2f", answer.confidence)
                        + (answer.reason.isEmpty() ? "" : "（" + answer.reason + "）")
                        + "\n能拿到回复就说明 Key 和模型名都对，可以放心开开关。");
            }

            @Override
            public void onError(String message) {
                result.setTextColor(getColor(R.color.danger));
                result.setText("失败：" + message + "\n"
                        + "· 401/403 多为 Key 复制错误或没有该模型权限\n"
                        + "· 404 多为模型名不对，去控制台复制准确名字\n"
                        + "· 超时/网络错误多为接口地址不可达");
            }
        });
    }

    private Bitmap sample() {
        Bitmap bitmap = Bitmap.createBitmap(360, 240, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(Color.WHITE);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.BLACK);
        paint.setStrokeWidth(9);
        canvas.drawLine(300, 26, 334, 60, paint);
        canvas.drawLine(334, 26, 300, 60, paint);
        return bitmap;
    }

    @Override
    protected void onDestroy() {
        if (client != null) client.shutdown();
        super.onDestroy();
    }
}
