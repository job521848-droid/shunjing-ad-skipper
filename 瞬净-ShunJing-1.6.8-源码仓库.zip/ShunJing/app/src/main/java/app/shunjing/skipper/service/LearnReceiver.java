package app.shunjing.skipper.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;

import app.shunjing.skipper.R;

/**
 * 通知栏「学习 / 结束学习」按钮的落地点。
 *
 * <p>v1.5.9 第一版直接用隐式广播，结果两个问题叠在一起：
 * 一是服务端的 IntentFilter 只加了抓取动作，学习广播没人接；
 * 二是隐式广播在部分 ROM 上会被动态注册限制吞掉。
 * 现在改成清单里静态注册的显式组件，系统点按钮一定会进到这里，
 * 再由这里用「限定包名」的显式广播交给无障碍服务处理。
 */
public class LearnReceiver extends BroadcastReceiver {

    private static final int HINT_NOTIFICATION_ID = 42;
    private static final String HINT_CHANNEL_ID = "learn_hint";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null) return;
        String mode = intent.getStringExtra(CaptureIntents.EXTRA_LEARN);
        if (mode == null) mode = CaptureIntents.LEARN_START;

        // 无障碍服务没开时按钮点了也白点（没人接广播）。与其让用户对着屏幕发呆，
        // 不如明确告诉他"服务已经停了"。这里查系统里的启用列表，比看心跳准：
        // 设备刚休眠唤醒时心跳可能还没刷新，会误判成掉线。
        if (!isAccessibilityEnabled(context)) {
            warnOffline(context);
            return;
        }

        // 首选同进程直呼：服务就在跑，没必要绕一圈广播（广播在部分 ROM 上会被吞）。
        AdSkipService service = AdSkipService.peek();
        if (service != null) {
            service.requestLearn(mode);
            return;
        }

        // 服务实例暂时拿不到（刚被系统回收、正在重连）时，走广播兜底。
        Intent relay = new Intent(CaptureIntents.ACTION_LEARN)
                .setPackage(context.getPackageName())
                .putExtra(CaptureIntents.EXTRA_LEARN, mode);
        try {
            context.sendBroadcast(relay);
        } catch (RuntimeException ignored) { }
    }

    /**
     * 无障碍服务是否在系统里处于启用状态。
     *
     * <p>系统启用列表里可能是 "包名/完整类名"，也可能是 "包名/.短类名"，
     * 两种写法都算命中，避免因为格式差异误判成没开。
     */
    public static boolean isAccessibilityEnabled(Context context) {
        try {
            ComponentName mine = new ComponentName(context, AdSkipService.class);
            String fullForm = mine.flattenToString();
            String shortForm = mine.flattenToShortString();
            String enabled = Settings.Secure.getString(context.getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (enabled == null || enabled.isEmpty()) return false;
            for (String item : enabled.split(":")) {
                if (item == null) continue;
                String value = item.trim();
                if (value.equalsIgnoreCase(fullForm) || value.equalsIgnoreCase(shortForm)) return true;
            }
        } catch (RuntimeException ignored) { }
        return false;
    }

    private void warnOffline(Context context) {
        try {
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager == null) return;
            if (Build.VERSION.SDK_INT >= 33
                    && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) return;
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel channel = new NotificationChannel(HINT_CHANNEL_ID,
                        "学习按钮提示", NotificationManager.IMPORTANCE_DEFAULT);
                channel.setShowBadge(false);
                manager.createNotificationChannel(channel);
            }
            Intent open = new Intent(context, app.shunjing.skipper.ui.MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pending = PendingIntent.getActivity(context, 21, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(context, HINT_CHANNEL_ID)
                    : new Notification.Builder(context);
            Notification notification = builder
                    .setSmallIcon(R.drawable.ic_stat_shield)
                    .setContentTitle("学习按钮暂时用不了")
                    .setContentText("瞬净的无障碍服务已停止，点这里重新打开")
                    .setContentIntent(pending)
                    .setAutoCancel(true)
                    .build();
            manager.notify(HINT_NOTIFICATION_ID, notification);
        } catch (RuntimeException ignored) { }
    }
}
