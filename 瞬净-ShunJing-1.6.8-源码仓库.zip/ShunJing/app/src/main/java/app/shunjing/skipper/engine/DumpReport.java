package app.shunjing.skipper.engine;

import java.util.List;
import java.util.Locale;

/** Builds an LLM-ready structured report from a captured page. Pure Java. */
public final class DumpReport {
    private DumpReport() { }

    public static String build(PageDump dump, Diagnosis diagnosis, List<Rule> rules,
                               EngineSettings settings, boolean maskText) {
        StringBuilder b = new StringBuilder();
        b.append("# 任务：分析一条 Android 开屏/插屏广告为什么没有被自动跳过\n\n");
        b.append("你是 Android 无障碍（AccessibilityService）广告跳过专家。下面是一份"
                + "从真机抓取的控件树快照，以及本地诊断引擎的初步结论。请给出**可直接落地**的修复方案。\n\n");
        b.append("## 输出要求\n");
        b.append("1. 判断真正的关闭控件是哪一个（引用节点编号），说明依据。\n");
        b.append("2. 给出应新增的自定义关闭词 / 控件 ID 规则：匹配方式（精确 / 包含 / ID）、"
                + "是否需要「广告上下文」、是否应限定应用包名。\n");
        b.append("3. 给出该方案在最坏情况下的误触风险，尤其是会不会误关扫码、二维码、支付、"
                + "验证码页面的正常关闭按钮。\n");
        b.append("4. 如果控件完全无法被无障碍可靠识别，直接说明能力边界，不要给出会误触的方案。\n");
        b.append("5. **硬约束：不要建议关闭敏感页面保护或让规则全局免证据触发。**\n\n");

        b.append("## 一、现场信息\n");
        b.append("- 应用包名：").append(dump.packageName).append('\n');
        b.append("- 应用名称：").append(dump.appLabel.isEmpty() ? "未知" : dump.appLabel).append('\n');
        b.append("- 页面 Activity：").append(dump.activityName.isEmpty() ? "未知" : dump.activityName).append('\n');
        b.append("- 抓取方式：").append(dump.sourceLabel()).append('\n');
        b.append("- 屏幕尺寸：").append(dump.screenWidth).append(" × ").append(dump.screenHeight).append('\n');
        b.append("- 是否处于启动后开屏窗口期：").append(dump.launchedRecently ? "是" : "否").append('\n');
        b.append("- 控件总数：").append(dump.nodes.size())
                .append("，带文字/描述：").append(dump.labeledNodeCount()).append('\n');
        if (maskText) b.append("- 文本已脱敏（仅保留结构、控件 ID 与坐标）\n");
        b.append('\n');

        b.append("## 二、当前引擎设置\n");
        b.append("- 通用叉号识别（广告上下文成立才点 × / 关闭）：")
                .append(on(settings.closeIconsEnabled)).append('\n');
        b.append("- 极速开屏（识别「跳过 + 倒计时」）：").append(on(settings.fastSplashEnabled)).append('\n');
        b.append("- 激励视频策略：").append(rewardModeLabel(settings.rewardMode)).append('\n');
        b.append("- 结构性广告证据（Activity + SDK ID 家族双条件）：")
                .append(on(settings.structuralAdEvidence)).append('\n');
        b.append("- 二次确认跟进（点击后 1.1 秒内重扫新弹层）：")
                .append(on(settings.confirmationFollowUp)).append('\n');
        b.append("- 布局锚点识别（默认关闭、限定单应用单页面）：")
                .append(on(settings.layoutAnchorsEnabled)).append('\n');
        b.append("- 已检测到广告上下文：").append(on(diagnosis.adContext)).append('\n');
        b.append("- 命中敏感页面保护：").append(on(diagnosis.sensitive)).append('\n');
        b.append('\n');

        if (diagnosis != null) {
            b.append("## 三、本地诊断结论\n");
            b.append("- 判定：").append(diagnosis.verdictLabel()).append("（").append(diagnosis.verdict).append("）\n");
            b.append("- 结论：").append(diagnosis.headline).append('\n');
            b.append("- 说明：").append(diagnosis.explanation).append("\n\n");
            b.append("证据链：\n");
            for (String item : diagnosis.evidence) b.append("  - ").append(maskSentence(item, maskText)).append('\n');
            b.append('\n');
            if (!diagnosis.candidates.isEmpty()) {
                b.append("疑似关闭控件：\n");
                for (Diagnosis.Candidate c : diagnosis.candidates) {
                    b.append("  - #").append(c.index).append(' ').append(maskSentence(c.label, maskText))
                            .append(" | id=").append(c.id.isEmpty() ? "无" : c.id)
                            .append(" | ").append(c.bounds)
                            .append(" | clickable=").append(c.clickable)
                            .append(" | 可点击祖先=").append(c.hasClickableAncestor)
                            .append(" | ID 含广告特征=").append(c.idLooksLikeAd).append('\n');
                }
                b.append('\n');
            }
            if (!diagnosis.suggestions.isEmpty()) {
                b.append("本地已生成的建议（供参考，可指出其中不足）：\n");
                for (Suggestion s : diagnosis.suggestions) {
                    b.append("  - [").append(s.kind).append("] ").append(maskSentence(s.title, maskText));
                    if (s.verified) b.append("（已回验）");
                    b.append("：").append(maskSentence(s.detail, maskText)).append('\n');
                    if (!s.risk.isEmpty()) b.append("    风险：").append(maskSentence(s.risk, maskText)).append('\n');
                }
                b.append('\n');
            }
        }

        b.append("## 四、完整控件树\n");
        b.append("格式：#编号 父编号 | 类名 | 可点击 | 可见 | 密码 | 坐标 | id | text | content-desc\n\n");
        b.append("```\n");
        for (NodeModel n : dump.nodes) {
            b.append('#').append(n.index).append(" p").append(n.parentIndex)
                    .append(" | ").append(n.className.isEmpty() ? "?" : n.className)
                    .append(" | c=").append(n.clickable ? 1 : 0)
                    .append(" v=").append(n.visible ? 1 : 0)
                    .append(" pwd=").append(n.password ? 1 : 0)
                    .append(" | [").append(n.left).append(',').append(n.top)
                    .append(',').append(n.right).append(',').append(n.bottom).append(']')
                    .append(" | id=").append(n.viewId.isEmpty() ? "-" : n.viewId)
                    .append(" | t=").append(field(n.text, n, maskText))
                    .append(" | d=").append(field(n.contentDescription, n, maskText))
                    .append('\n');
        }
        b.append("```\n\n");

        b.append("## 五、当前生效的规则\n");
        b.append("格式：类型 | 词/ID片段 | 匹配方式 | 需广告上下文 | 启用 | 限定包名\n\n");
        b.append("```\n");
        for (Rule r : rules) {
            b.append(r.category).append(" | ").append(r.phrase)
                    .append(" | ").append(r.matchType)
                    .append(" | ctx=").append(r.requiresAdContext ? 1 : 0)
                    .append(" | on=").append(r.enabled ? 1 : 0)
                    .append(" | pkg=").append(r.packageName.isEmpty() ? "全局" : r.packageName)
                    .append('\n');
        }
        b.append("```\n\n");

        b.append("## 六、识别规则说明\n");
        b.append("- 文本/描述会做归一化（小写、去空格，× ✕ ✖ Ｘ 统一为 x）后再匹配。\n");
        b.append("- SKIP 类规则含明确广告语义，可直接触发；CLOSE 类（× / 关闭）必须同时存在广告上下文。\n");
        b.append("- CUSTOM 规则可设为「需广告上下文」并限定包名；ID 规则按 viewId 片段包含匹配。\n");
        b.append("- 结构性广告证据：仅当「广告 SDK 代理 Activity」+「SDK 控件 ID 家族 / 广告角标 / 居中卡片」"
                + "双信号同时成立才算广告上下文；**单凭包名绝不算证据**。\n");
        b.append("- 布局锚点规则：默认关闭、必须限定单个包名 + 单个 Activity、仍要求广告上下文，"
                + "只匹配居中卡片右上角可点击且无文字/描述/ID 的小图片控件，优先节点级 ACTION_CLICK，"
                + "失败才回退到该控件自身坐标的手势点击。\n");
        b.append("- 二次确认跟进：一次成功的广告点击后 1.1 秒内，若同一应用同一 Activity 出现新弹层，"
                + "会继承一次有时限的广告上下文以命中「残忍离开」类规则；敏感页硬锁仍优先。\n");
        b.append("- 激励视频三态：保护奖励（默认）/ 播完再关（结束卡出现后）/ 自动放弃（明确牺牲奖励，"
                + "可按应用白名单授权）。\n");
        b.append("- 扫码/二维码、支付/银行卡、密码/验证码、指纹/人脸、授权登录、用户协议、"
                + "权限与系统设置页面被硬锁定，任何规则都不会触发；**硬锁优先级高于一切证据与规则**。\n");
        b.append("- 控件需可见、非密码框、有有效坐标，且自身或祖先可点击；否则会尝试小范围坐标点击兜底。\n\n");

        b.append("## 七、隐私提示\n");
        b.append("本快照仅保存在用户手机私有目录。若其中包含聊天、账号或二维码等敏感文字，"
                + "请勿上传到不受信任的服务；可先在应用内开启「导出时脱敏」再分享。\n");
        return b.toString();
    }

    private static String field(String value, NodeModel node, boolean mask) {
        if (value == null || value.trim().isEmpty()) return "-";
        if (node.password) return "[密码字段已隐藏]";
        if (mask) return "[文字已隐藏·长度" + value.length() + "]";
        String clean = value.replace('\n', ' ').replace('\r', ' ').trim();
        return clean.length() > 80 ? clean.substring(0, 80) + "…" : clean;
    }

    /** Masks quoted page text embedded in diagnostic sentences. */
    private static String maskSentence(String value, boolean mask) {
        if (!mask || value == null) return value == null ? "" : value;
        return value.replaceAll("「[^」]*」", "「文字已隐藏」");
    }

    private static String on(boolean value) { return value ? "是" : "否"; }

    private static String rewardModeLabel(EngineSettings.RewardMode mode) {
        if (mode == null) return "保护奖励（默认）";
        switch (mode) {
            case AUTO_ABANDON: return "自动放弃奖励";
            case END_CARD_ONLY: return "播完再关";
            default: return "保护奖励（默认）";
        }
    }

    /** Short one-line summary used in the UI list. */
    public static String summary(PageDump dump, Diagnosis diagnosis) {
        return String.format(Locale.CHINA, "%s · %s · %d 控件 · %s",
                dump.appLabel.isEmpty() ? dump.packageName : dump.appLabel,
                diagnosis == null ? "待分析" : diagnosis.verdictLabel(),
                dump.nodes.size(), dump.sourceLabel());
    }
}
