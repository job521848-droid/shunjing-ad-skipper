package app.shunjing.skipper.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import app.shunjing.skipper.R;

/**
 * 分段选择器：一块会滑动的发光指示器 + 上层文字。
 *
 * <p>v1.5.13 换掉了「ViewPropertyAnimator + Decelerate」那一套，改成自己驱动一个
 * <b>连续位置</b>（0..n-1 的浮点数）：
 * <ul>
 *   <li>弹簧曲线落位，2.9% 过冲后立刻停住 —— 有弹性但不晃；</li>
 *   <li>滑动时身后拖出速度残影，还有一条从起点划到终点的能量线；</li>
 *   <li>文字不再是"跳"成高亮，而是按指示器距离连续点亮，滑块到哪亮到哪；</li>
 *   <li>落位瞬间横向压一下再弹回，像真的卡进档位。</li>
 * </ul>
 */
public final class SegmentBar extends FrameLayout {
    public interface OnSelect {
        void onSelect(int index);
    }

    private static final long DEBOUNCE_MS = 120L;
    private static final int TRAIL_SEGMENTS = 4;

    private final GlowIndicator indicator;
    private final TextView[] items;
    private final boolean[] bold;
    private int selected = -1;
    private OnSelect listener;
    private int segmentWidth;
    private long lastTapAt;
    private float slideFrom;
    private ValueAnimator slideAnim;
    private ValueAnimator accentAnim;

    public SegmentBar(Context context, String[] labels, int selected) {
        super(context);
        int pad = Ui.dp(context, 4);
        setPadding(pad, pad, pad, pad);
        setBackgroundResource(R.drawable.bg_segment_track);
        setClipChildren(false);

        indicator = new GlowIndicator(context);
        addView(indicator, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        items = new TextView[labels.length];
        bold = new boolean[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int index = i;
            TextView item = new TextView(context);
            item.setText(labels[i]);
            item.setTextSize(14);
            item.setGravity(Gravity.CENTER);
            item.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            item.setClickable(true);
            item.setFocusable(true);
            item.setOnClickListener(v -> tap(index));
            item.setOnTouchListener((v, event) -> {
                // 按下就先给一点点视觉回应，不等抬起。
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    v.animate().scaleX(0.965f).scaleY(0.965f).setDuration(80L).start();
                } else if (event.getAction() == MotionEvent.ACTION_UP
                        || event.getAction() == MotionEvent.ACTION_CANCEL) {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(180L)
                            .setInterpolator(new android.view.animation.OvershootInterpolator(1.2f))
                            .start();
                }
                return false;
            });
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.MATCH_PARENT, 1f);
            row.addView(item, params);
            items[i] = item;
        }
        addView(row, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        this.selected = (selected >= 0 && selected < labels.length) ? selected : -1;
        this.slideFrom = Math.max(this.selected, 0);
        indicator.setPosition(this.slideFrom, this.slideFrom);
        paint();
    }

    /** 跟随模式换色：指示器渐变、外发光、文字高亮都取这一组色。 */
    public void setAccent(int start, int end) {
        int curStart = indicator.startColor();
        int curEnd = indicator.endColor();
        if (start == curStart && end == curEnd) return;
        if (accentAnim != null) accentAnim.cancel();
        if (!isLaidOut() || Motion.reduced(getContext())) {
            indicator.setColors(start, end);
            paint();
            return;
        }
        // 和圆环同步做 460ms 渐变：指示器不能比圆环先跳色，否则两处颜色会对不上。
        accentAnim = ValueAnimator.ofFloat(0f, 1f);
        accentAnim.setDuration(Motion.duration(getContext(), Motion.COLOR));
        accentAnim.setInterpolator(new android.view.animation.DecelerateInterpolator(1.4f));
        accentAnim.addUpdateListener(animation -> {
            float t = (float) animation.getAnimatedValue();
            indicator.setColors(blend(curStart, start, t), blend(curEnd, end, t));
            paint();
        });
        accentAnim.start();
    }

    private void tap(int index) {
        if (!isEnabled()) return;
        long now = System.currentTimeMillis();
        if (now - lastTapAt < DEBOUNCE_MS) return;
        lastTapAt = now;
        // 点的是当前档位：没有换挡反馈，但"按到了"也要有回应，补一次系统轻触。
        if (index == selected) performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
        // 先更新视觉，再通知业务层：业务层做耗时操作时也不会显得"没点上"。
        setSelected(index);
        if (listener != null) listener.onSelect(index);
    }

    public void setOnSelectListener(OnSelect value) { listener = value; }

    public int getSelected() { return selected; }

    public void setSelected(int index) {
        if (index < 0 || index >= items.length) return;
        boolean changed = index != selected;
        selected = index;
        animateTo(index, changed);
    }

    /** -1 表示"没有匹配的预置"（自定义），此时指示器隐藏、文字全不高亮。 */
    public void syncSelected(int index) {
        int value = (index >= 0 && index < items.length) ? index : -1;
        if (value == selected) return;
        selected = value;
        if (value >= 0) animateTo(value, false); else { paint(); indicator.setVisibility(INVISIBLE); }
    }

    private void animateTo(int index, boolean animate) {
        indicator.setVisibility(VISIBLE);
        if (segmentWidth <= 0 || !isLaidOut() || !animate || Motion.reduced(getContext())) {
            slideFrom = index;
            indicator.setPosition(index, index);
            indicator.settle();
            paint();
            return;
        }
        if (slideAnim != null) slideAnim.cancel();
        final float from = indicator.position();
        final float to = index;
        slideFrom = from;
        final long duration = Motion.duration(getContext(), Motion.SLIDE);
        slideAnim = ValueAnimator.ofFloat(0f, 1f);
        slideAnim.setDuration(duration);
        slideAnim.setInterpolator(null);   // 曲线由 Motion.spring 自己算，不用插值器
        slideAnim.addUpdateListener(animation -> {
            float t = (float) animation.getAnimatedValue();
            indicator.setPosition(from + (to - from) * Motion.spring(t), from);
            paint();
        });
        slideAnim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator animation) {
                indicator.land();
            }
        });
        slideAnim.start();
    }

    private void paint() {
        int activeColor = getContext().getColor(R.color.text_primary);
        int idleColor = getContext().getColor(R.color.text_secondary);
        float position = indicator.position();
        boolean known = selected >= 0;
        for (int i = 0; i < items.length; i++) {
            // 连续点亮：指示器越靠近，文字越亮越白；滑块经过时旁边的字会跟着亮起来再暗回去。
            float near = known ? Motion.clamp01(1f - Math.abs(i - position)) : 0f;
            items[i].setTextColor(blend(idleColor, activeColor, near));
            items[i].setAlpha(0.74f + 0.26f * near);
            boolean wantBold = near > 0.5f;
            if (bold[i] != wantBold) {
                bold[i] = wantBold;
                // 只在跨过中点时换字重，避免每帧 requestLayout。
                items[i].setTypeface(Typeface.DEFAULT, wantBold ? Typeface.BOLD : Typeface.NORMAL);
            }
        }
        indicator.setVisibility(known ? VISIBLE : INVISIBLE);
    }

    private static int blend(int from, int to, float k) {
        float t = Motion.clamp01(k);
        return Color.argb(
                Math.round(Color.alpha(from) + (Color.alpha(to) - Color.alpha(from)) * t),
                Math.round(Color.red(from) + (Color.red(to) - Color.red(from)) * t),
                Math.round(Color.green(from) + (Color.green(to) - Color.green(from)) * t),
                Math.round(Color.blue(from) + (Color.blue(to) - Color.blue(from)) * t));
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (items.length == 0) return;
        segmentWidth = Math.max(0, (w - getPaddingLeft() - getPaddingRight()) / items.length);
        indicator.setGeometry(getPaddingLeft(), segmentWidth);
        if (selected >= 0) {
            slideFrom = selected;
            indicator.setPosition(selected, selected);
        }
        paint();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (slideAnim != null) slideAnim.cancel();
        if (accentAnim != null) accentAnim.cancel();
        indicator.stopAll();
        super.onDetachedFromWindow();
    }

    @Override
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        setAlpha(enabled ? 1f : 0.5f);
        for (TextView item : items) item.setEnabled(enabled);
    }

    public View itemAt(int index) { return items[index]; }

    /**
     * 自绘的发光指示器：渐变底 + 软件层外发光 + 运动拖尾。
     *
     * <p>用 View 背景做不出扩散光晕，只有 {@code Paint.setShadowLayer} 可以；它需要
     * 软件层，因此这里显式关闭硬件加速。区域只有一条轨道，代价可以忽略。
     *
     * <p>宽度铺满整个轨道、位置靠内部浮点数决定，这样拖尾和能量线才能跨段绘制。
     */
    private static final class GlowIndicator extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint trailPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final RectF temp = new RectF();
        private int startColor = Accent.BALANCED;
        private int endColor = Accent.BALANCED_END;
        private int padLeft;
        private int segWidth;
        private float position;
        private float from;
        private float trail;
        private float trailDir = 1f;
        private float squash;
        private float boost;
        private ValueAnimator flashAnim;
        private ValueAnimator landAnim;

        GlowIndicator(Context context) {
            super(context);
            setLayerType(LAYER_TYPE_SOFTWARE, null);
            trailPaint.setStyle(Paint.Style.STROKE);
            trailPaint.setStrokeCap(Paint.Cap.ROUND);
        }

        float position() { return position; }

        int startColor() { return startColor; }

        int endColor() { return endColor; }

        void setGeometry(int padLeft, int segWidth) {
            this.padLeft = padLeft;
            this.segWidth = segWidth;
            invalidate();
        }

        void setColors(int start, int end) {
            if (start == startColor && end == endColor) return;
            startColor = start;
            endColor = end;
            invalidate();
        }

        /** 每一帧推进位置；delta 越大拖尾越长，静止时按帧衰减。 */
        void setPosition(float value, float origin) {
            float delta = value - position;
            position = value;
            from = origin;
            float speed = Math.abs(delta) * 60f;           // 按 60fps 折算成"段/秒"
            float target = Motion.clamp01(speed / 4.2f);
            if (Math.abs(delta) > 0.0005f) trailDir = Math.signum(delta);
            // 上升快、下降慢：甩出去的残影不会一帧就断。
            trail = Math.max(trail * 0.86f, target);
            invalidate();
        }

        /** 落位：横向压一下再弹回，并闪一次外发光。 */
        void land() {
            if (!isAttachedToWindow()) return;
            if (landAnim != null) landAnim.cancel();
            final float startTrail = trail;
            landAnim = ValueAnimator.ofFloat(1f, 0f);
            landAnim.setDuration(Motion.duration(getContext(), 190L));
            landAnim.setInterpolator(new android.view.animation.DecelerateInterpolator(2f));
            landAnim.addUpdateListener(animation -> {
                float t = (float) animation.getAnimatedValue();
                squash = t;
                // 停下来就没有速度了，残影必须在这 190ms 里收干净，否则会一直挂在轨道上。
                trail = startTrail * t * t;
                invalidate();
            });
            landAnim.start();
            flash();
        }

        /** 直接跳位（没有滑动过程）时清掉一切临时状态。 */
        void settle() {
            if (landAnim != null) landAnim.cancel();
            squash = 0f;
            trail = 0f;
            invalidate();
        }

        /** 滑动落位时闪一下外发光。 */
        void flash() {
            if (flashAnim != null) flashAnim.cancel();
            flashAnim = ValueAnimator.ofFloat(1f, 0f);
            flashAnim.setDuration(Motion.duration(getContext(), 420L));
            flashAnim.setInterpolator(new android.view.animation.DecelerateInterpolator(1.8f));
            flashAnim.addUpdateListener(animation -> {
                boost = (float) animation.getAnimatedValue();
                invalidate();
            });
            flashAnim.start();
        }

        void stopAll() {
            if (flashAnim != null) flashAnim.cancel();
            if (landAnim != null) landAnim.cancel();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (segWidth <= 0) return;
            float inset = Ui.dp(getContext(), 1);
            float radius = Ui.dp(getContext(), 11);
            float x = padLeft + position * segWidth;
            float w = segWidth;
            // 横向压：落位瞬间两端各收 3%，再弹回去
            float pinch = w * 0.035f * squash;
            rect.set(x + inset + pinch, inset, x + w - inset - pinch, getHeight() - inset);
            if (rect.width() <= radius) return;

            // ---- 速度残影：越靠后越窄、越淡，像高速快门拖出来的
            if (trail > 0.02f) {
                for (int i = TRAIL_SEGMENTS; i >= 1; i--) {
                    float far = i * Ui.dp(getContext(), 5) * trail;
                    float shrink = far * 0.55f;
                    temp.set(rect.left - trailDir * far + shrink, rect.top + far * 0.35f,
                            rect.right - trailDir * far - shrink, rect.bottom - far * 0.35f);
                    if (temp.width() <= 2f) continue;
                    int alpha = (int) (26 * trail * (1f - (i - 1) / (float) TRAIL_SEGMENTS));
                    Paint p = trailPaint;
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(Accent.alpha(startColor, Math.max(0, alpha)));
                    canvas.drawRoundRect(temp, radius * 0.8f, radius * 0.8f, p);
                }
                // ---- 能量线：从起点划到当前位置，跨段才有"划过档位"的感觉
                if (Math.abs(from - position) > 0.04f) {
                    float lineY = rect.centerY();
                    trailPaint.setStyle(Paint.Style.STROKE);
                    trailPaint.setStrokeWidth(Ui.dp(getContext(), 1.2f));
                    trailPaint.setShader(new LinearGradient(
                            padLeft + from * segWidth, lineY, x + w / 2f, lineY,
                            Accent.alpha(startColor, 10), Accent.alpha(startColor, (int) (110 * trail)),
                            Shader.TileMode.CLAMP));
                    canvas.drawLine(padLeft + from * segWidth + segWidth / 2f, lineY,
                            x + w / 2f, lineY, trailPaint);
                    trailPaint.setShader(null);
                }
            }

            // 外发光：档位色只在这里和最外圈描边上重一点，避免把填充做得太亮压住文字。
            float spread = Ui.dp(getContext(), 6) + Ui.dp(getContext(), 5) * boost;
            glow.setStyle(Paint.Style.FILL);
            glow.setColor(Accent.alpha(startColor, 60));
            glow.setShadowLayer(spread, 0f, 0f, Accent.alpha(startColor,
                    (int) (110 + 80 * boost)));
            canvas.drawRoundRect(rect, radius, radius, glow);
            glow.clearShadowLayer();

            // 半透明渐变：深色主题上它读起来是「被一层光染过的深色玻璃」，白色文字始终清晰。
            fill.setShader(new LinearGradient(rect.left, rect.top, rect.right, rect.bottom,
                    Accent.alpha(startColor, 70), Accent.alpha(endColor, 42),
                    Shader.TileMode.CLAMP));
            canvas.drawRoundRect(rect, radius, radius, fill);
            fill.setShader(null);

            // 1.4dp 强调色描边：档位身份靠它，不靠亮度。
            Paint stroke = glow;
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(Ui.dp(getContext(), 1.4f));
            stroke.setColor(Accent.alpha(startColor, 215));
            canvas.drawRoundRect(rect, radius, radius, stroke);

            // 顶部一道细高光，让指示器看起来是有厚度的
            Paint sheen = glow;
            sheen.setStyle(Paint.Style.FILL);
            sheen.setColor(Color.argb(30, 255, 255, 255));
            RectF top = new RectF(rect.left + radius * 0.5f, rect.top + inset,
                    rect.right - radius * 0.5f, rect.top + getHeight() * 0.42f);
            canvas.drawRoundRect(top, getHeight() * 0.3f, getHeight() * 0.3f, sheen);

            // 三条竖向刻度：像档位槽里的定位齿，只在落位后短暂可见
            if (boost > 0.01f) {
                sheen.setColor(Accent.alpha(startColor, (int) (90 * boost)));
                float top0 = rect.top + getHeight() * 0.28f;
                float bottom0 = rect.bottom - getHeight() * 0.28f;
                for (int i = 1; i <= 3; i++) {
                    float lx = rect.left + rect.width() * i / 4f;
                    canvas.drawLine(lx, top0, lx, bottom0, sheen);
                }
            }
        }
    }
}
