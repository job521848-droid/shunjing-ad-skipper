package app.shunjing.skipper.engine;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Immutable engine configuration.
 *
 * <p>Safety invariants (never relax these):
 * <ul>
 *   <li>Sensitive-page hard lock is evaluated inside the engine BEFORE any rule or evidence.</li>
 *   <li>Structural ad evidence requires BOTH a known ad-SDK Activity and a matching SDK id
 *       family. A bare package name is never treated as ad evidence.</li>
 *   <li>Layout-anchor rules are opt-in, scoped to one package AND one Activity, and still
 *       require an independent ad context.</li>
 * </ul>
 */
public final class EngineSettings {
    public enum RewardMode {
        /** Never auto-close a rewarded ad. */
        PROTECT,
        /** Only close after the end card appears (reward is kept). */
        END_CARD_ONLY,
        /** Close as soon as a skip/close control appears — the user gives up the reward. */
        AUTO_ABANDON
    }

    public final boolean closeIconsEnabled;
    public final boolean fastSplashEnabled;
    /** Legacy boolean kept for compatibility; true maps to AUTO_ABANDON. */
    public final boolean rewardedAdsEnabled;
    public final RewardMode rewardMode;
    /** Packages explicitly allowed to auto-abandon rewards. Empty means "global policy only". */
    public final Set<String> rewardAutoAbandonApps;
    /** Trust Activity + SDK-id structural evidence instead of only page text. */
    public final boolean structuralAdEvidence;
    /** Re-evaluate a fresh dialog shortly after a successful click (second confirmation). */
    public final boolean confirmationFollowUp;
    /** Opt-in geometric rules for pure-image close buttons on ad cards. */
    public final boolean layoutAnchorsEnabled;
    /**
     * v1.4: locate the floating close icon of an overlay popup (red-packet / check-in /
     * H5 activity card) even when the icon sits OUTSIDE the card. Still requires ad context
     * plus a centred card and a label-less corner icon, and re-checks the hard lock.
     */
    public final boolean overlayCloseEnabled;
    /**
     * v1.5.1: locate the close key of a WebView template ad (穿山甲 / 优量汇 / 广点通) by the
     * "反馈 ⟷ 关闭" pair the template always draws on one row. These pages are entirely c=0,
     * so this is the only path that can hit them; it still requires ad context, a real
     * WebView plus an 广告 badge / template id, and no dangerous action words.
     */
    public final boolean webAdTemplateEnabled;

    /** Backwards-compatible constructor used by tests and older callers. */
    public EngineSettings(boolean closeIconsEnabled, boolean fastSplashEnabled,
                          boolean rewardedAdsEnabled) {
        this(closeIconsEnabled, fastSplashEnabled,
                rewardedAdsEnabled ? RewardMode.AUTO_ABANDON : RewardMode.PROTECT,
                Collections.<String>emptySet(), true, true, false);
    }

    public EngineSettings(boolean closeIconsEnabled, boolean fastSplashEnabled,
                          RewardMode rewardMode, Set<String> rewardAutoAbandonApps,
                          boolean structuralAdEvidence, boolean confirmationFollowUp,
                          boolean layoutAnchorsEnabled) {
        this(closeIconsEnabled, fastSplashEnabled, rewardMode, rewardAutoAbandonApps,
                structuralAdEvidence, confirmationFollowUp, layoutAnchorsEnabled, true);
    }

    public EngineSettings(boolean closeIconsEnabled, boolean fastSplashEnabled,
                          RewardMode rewardMode, Set<String> rewardAutoAbandonApps,
                          boolean structuralAdEvidence, boolean confirmationFollowUp,
                          boolean layoutAnchorsEnabled, boolean overlayCloseEnabled) {
        this(closeIconsEnabled, fastSplashEnabled, rewardMode, rewardAutoAbandonApps,
                structuralAdEvidence, confirmationFollowUp, layoutAnchorsEnabled,
                overlayCloseEnabled, true);
    }

    public EngineSettings(boolean closeIconsEnabled, boolean fastSplashEnabled,
                          RewardMode rewardMode, Set<String> rewardAutoAbandonApps,
                          boolean structuralAdEvidence, boolean confirmationFollowUp,
                          boolean layoutAnchorsEnabled, boolean overlayCloseEnabled,
                          boolean webAdTemplateEnabled) {
        this.closeIconsEnabled = closeIconsEnabled;
        this.fastSplashEnabled = fastSplashEnabled;
        this.rewardMode = rewardMode == null ? RewardMode.PROTECT : rewardMode;
        this.rewardedAdsEnabled = this.rewardMode != RewardMode.PROTECT;
        this.rewardAutoAbandonApps = rewardAutoAbandonApps == null
                ? Collections.<String>emptySet()
                : Collections.unmodifiableSet(new HashSet<>(rewardAutoAbandonApps));
        this.structuralAdEvidence = structuralAdEvidence;
        this.confirmationFollowUp = confirmationFollowUp;
        this.layoutAnchorsEnabled = layoutAnchorsEnabled;
        this.overlayCloseEnabled = overlayCloseEnabled;
        this.webAdTemplateEnabled = webAdTemplateEnabled;
    }

    public static EngineSettings defaults() {
        return new EngineSettings(true, true, false);
    }

    /** True when this package may auto-close a rewarded ad, giving up the reward. */
    public boolean allowsRewardedClose(String packageName) {
        return allowsRewardedClose(packageName, false);
    }

    /**
     * @param endCardVisible true when the rewarded video's end card has appeared (video
     *                       finished and the reward is already granted).
     */
    public boolean allowsRewardedClose(String packageName, boolean endCardVisible) {
        if (rewardMode == RewardMode.AUTO_ABANDON) return true;
        if (rewardMode == RewardMode.PROTECT) return false;
        // END_CARD_ONLY: always allow once the video is over (reward kept), or when the user
        // explicitly whitelisted this app to auto-abandon.
        return endCardVisible || (packageName != null && rewardAutoAbandonApps.contains(packageName));
    }

    public boolean rewardPerAppWhitelistActive() {
        return rewardMode == RewardMode.END_CARD_ONLY;
    }

    public EngineSettings withRewardMode(RewardMode mode) {
        return new EngineSettings(closeIconsEnabled, fastSplashEnabled, mode,
                rewardAutoAbandonApps, structuralAdEvidence, confirmationFollowUp,
                layoutAnchorsEnabled, overlayCloseEnabled, webAdTemplateEnabled);
    }

    public EngineSettings withLayoutAnchors(boolean enabled) {
        return new EngineSettings(closeIconsEnabled, fastSplashEnabled, rewardMode,
                rewardAutoAbandonApps, structuralAdEvidence, confirmationFollowUp, enabled,
                overlayCloseEnabled, webAdTemplateEnabled);
    }

    public EngineSettings withOverlayClose(boolean enabled) {
        return new EngineSettings(closeIconsEnabled, fastSplashEnabled, rewardMode,
                rewardAutoAbandonApps, structuralAdEvidence, confirmationFollowUp,
                layoutAnchorsEnabled, enabled, webAdTemplateEnabled);
    }

    public EngineSettings withWebAdTemplate(boolean enabled) {
        return new EngineSettings(closeIconsEnabled, fastSplashEnabled, rewardMode,
                rewardAutoAbandonApps, structuralAdEvidence, confirmationFollowUp,
                layoutAnchorsEnabled, overlayCloseEnabled, enabled);
    }
}
