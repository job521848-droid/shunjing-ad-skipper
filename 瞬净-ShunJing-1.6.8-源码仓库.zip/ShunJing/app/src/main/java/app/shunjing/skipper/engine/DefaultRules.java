package app.shunjing.skipper.engine;

import java.util.ArrayList;
import java.util.List;

public final class DefaultRules {
    private DefaultRules() { }

    public static List<Rule> create() {
        List<Rule> rules = new ArrayList<>();
        add(rules, "skip_ad_cn", "跳过广告", Rule.MatchType.CONTAINS, Rule.Category.SKIP, false);
        add(rules, "skip_this_ad_cn", "跳过此广告", Rule.MatchType.CONTAINS, Rule.Category.SKIP, false);
        add(rules, "skip_current_ad_cn", "跳过本广告", Rule.MatchType.CONTAINS, Rule.Category.SKIP, false);
        add(rules, "skip_ad_en", "skipad", Rule.MatchType.CONTAINS, Rule.Category.SKIP, false);
        add(rules, "skip_this_ad_en", "skipthisad", Rule.MatchType.CONTAINS, Rule.Category.SKIP, false);
        add(rules, "close_ad_cn", "关闭广告", Rule.MatchType.CONTAINS, Rule.Category.SKIP, false);
        add(rules, "close_this_ad_cn", "关闭此广告", Rule.MatchType.CONTAINS, Rule.Category.SKIP, false);
        add(rules, "close_that_ad_cn", "关闭该广告", Rule.MatchType.CONTAINS, Rule.Category.SKIP, false);
        add(rules, "close_ad_en", "closead", Rule.MatchType.CONTAINS, Rule.Category.SKIP, false);
        add(rules, "close_this_ad_en", "closethisad", Rule.MatchType.CONTAINS, Rule.Category.SKIP, false);
        add(rules, "skip_plain", "跳过", Rule.MatchType.CONTAINS, Rule.Category.SKIP, true);
        add(rules, "skip_en", "skip", Rule.MatchType.EXACT, Rule.Category.SKIP, true);
        add(rules, "close_plain", "关闭", Rule.MatchType.EXACT, Rule.Category.CLOSE, true);
        add(rules, "close_en", "close", Rule.MatchType.EXACT, Rule.Category.CLOSE, true);
        add(rules, "close_x", "x", Rule.MatchType.EXACT, Rule.Category.CLOSE, true);
        add(rules, "close_cross", "✕", Rule.MatchType.EXACT, Rule.Category.CLOSE, true);
        add(rules, "close_popup", "关闭弹窗", Rule.MatchType.EXACT, Rule.Category.CLOSE, true);
        add(rules, "close_float", "关闭悬浮窗", Rule.MatchType.EXACT, Rule.Category.CLOSE, true);
        return rules;
    }

    private static void add(List<Rule> rules, String id, String phrase, Rule.MatchType type,
                            Rule.Category category, boolean requiresContext) {
        rules.add(new Rule(id, phrase, type, category, requiresContext, true, true, ""));
    }
}
