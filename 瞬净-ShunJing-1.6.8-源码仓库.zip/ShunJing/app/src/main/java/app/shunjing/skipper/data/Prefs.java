package app.shunjing.skipper.data;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import app.shunjing.skipper.engine.DefaultRules;
import app.shunjing.skipper.engine.LearnedClose;
import app.shunjing.skipper.engine.DumpAnalyzer;
import app.shunjing.skipper.engine.EngineSettings;
import app.shunjing.skipper.engine.LayoutAnchorRule;
import app.shunjing.skipper.engine.Rule;
import app.shunjing.skipper.engine.VisionTriggerPolicy;

public final class Prefs {
    private static final String FILE = "local_state";
    private final SharedPreferences prefs;

    public Prefs(Context context) {
        prefs = context.getSharedPreferences(FILE, Context.MODE_PRIVATE);
        seedNewToggles();
    }

    /**
     * 新开关第一次出现时，默认值必须跟用户当前所在的档位一致。
     * 否则老用户一升级：安静档会凭空多出一个更激进的点击行为，
     * 同时 {@code Preset.detect()} 因为对不上任何预置，把徽章掉成「自定义」。
     */
    private void seedNewToggles() {
        if (prefs.contains("shake_preempt")) return;
        boolean safe = "SAFE".equals(prefs.getString("preset_mode", ""));
        prefs.edit().putBoolean("shake_preempt", !safe).apply();
    }

    public SharedPreferences preferences() { return prefs; }

    public boolean masterEnabled() { return prefs.getBoolean("master", true); }
    public void setMasterEnabled(boolean value) { prefs.edit().putBoolean("master", value).apply(); }
    public boolean closeIconsEnabled() { return prefs.getBoolean("close_icons", true); }
    public boolean fastSplashEnabled() { return prefs.getBoolean("fast_splash", true); }
    public boolean shakeBackEnabled() { return prefs.getBoolean("shake_back", true); }
    /** 摇一摇页第一次没点中时，短时间内再补两下（只补同一处）。 */
    public boolean shakePreemptEnabled() { return prefs.getBoolean("shake_preempt", true); }
    /**
     * v1.6.3：广告跳进应用商店时自动退回。**默认关闭** —— 这是唯一一个「用户没主动要求，
     * 我们也去按返回键」的行为，可能误伤正常逛商店，所以必须先由用户显式打开。
     */
    public boolean storeBackEnabled() { return prefs.getBoolean("store_back", false); }
    public boolean notificationsEnabled() { return prefs.getBoolean("notifications", true); }
    public boolean toastEnabled() { return prefs.getBoolean("toast", false); }
    public int scanIntervalMs() { return Math.max(40, Math.min(300, prefs.getInt("scan_interval", 60))); }
    public int totalCount() { return prefs.getInt("total_count", 0); }

    // ---------------------------------------------------------------- v1.6.2 临时暂停

    /**
     * 暂停到什么时候（毫秒时间戳，0 = 没暂停）。
     *
     * <p>存时间点而不是"剩余秒数"：手机休眠或进程被杀之后，剩余秒数会停在原处，
     * 而时间戳自己会走完 —— 用户设了 15 分钟，锁屏十分钟回来，应该只剩 5 分钟。
     */
    public long pauseUntil() { return prefs.getLong("pause_until", 0L); }

    public void setPauseUntil(long value) {
        if (value <= 0L) prefs.edit().remove("pause_until").apply();
        else prefs.edit().putLong("pause_until", value).apply();
    }

    /** 暂停 minutes 分钟（0 = 恢复）。 */
    public void pauseFor(int minutes) {
        setPauseUntil(Pause.until(System.currentTimeMillis(), minutes));
    }

    public void resume() { setPauseUntil(0L); }

    /** 暂停中？每次现算，不缓存 —— 缓存就必然有人忘了在到点时清掉。 */
    public boolean paused() {
        return Pause.active(System.currentTimeMillis(), pauseUntil());
    }

    /** 剩余毫秒（未暂停为 0）。 */
    public long pauseRemaining() {
        return Pause.remaining(System.currentTimeMillis(), pauseUntil());
    }

    /** Auto-save a dump when an ad-looking page is detected but not skipped. */
    public boolean autoCaptureEnabled() { return prefs.getBoolean("auto_capture", true); }
    /** Mask all text in exported AI reports. */
    public boolean maskExportEnabled() { return prefs.getBoolean("mask_export", false); }

    // ---------------------------------------------------------------- v1.3 recovery & vision

    /** Immediate local second-pass after repeated no-change clicks. */
    public boolean adaptiveRecoveryEnabled() { return prefs.getBoolean("adaptive_recovery", true); }
    /** Cloud vision is opt-in and additionally requires an explicit privacy consent. */
    public boolean cloudVisionEnabled() { return prefs.getBoolean("cloud_vision", false); }
    public boolean cloudVisionConsent() { return prefs.getBoolean("cloud_vision_consent", false); }
    public String cloudEndpoint() {
        return prefs.getString("cloud_endpoint", "").trim();
    }
    public String cloudApiKey() { return prefs.getString("cloud_api_key", "").trim(); }
    public String cloudModel() { return prefs.getString("cloud_model", "").trim(); }
    public boolean cloudVisionReady() {
        return cloudVisionEnabled() && cloudVisionConsent()
                && cloudEndpoint().startsWith("https://") && !cloudApiKey().isEmpty()
                && !cloudModel().isEmpty();
    }

    /** v1.5: 云端接管灵敏度。默认「积极」——广告页 0.65 秒没有本地动作就接管。 */
    public VisionTriggerPolicy.Sensitivity visionSensitivity() {
        return VisionTriggerPolicy.parse(prefs.getString("vision_sensitivity", null));
    }

    /**
     * v1.6: 本地没有广告证据（没"广告"二字、不是 SDK 页面），但页面结构极像广告时，
     * 允许花一次请求让云端看一眼。只影响"要不要问"，不影响"能不能点"。
     *
     * <p>「安静」档默认关——那一档的承诺就是"只处理明说广告的页面"，不该偷偷去问云端。
     * 用户显式拨过开关则以开关为准。
     */
    public boolean adSuspectEnabled() {
        boolean fallback = !Preset.Mode.SAFE.name()
                .equals(prefs.getString(Preset.KEY_MODE, ""));
        return prefs.getBoolean("ad_suspect", fallback);
    }

    public void setVisionSensitivity(VisionTriggerPolicy.Sensitivity value) {
        prefs.edit().putString("vision_sensitivity",
                (value == null ? VisionTriggerPolicy.Sensitivity.EAGER : value).name()).apply();
    }

    // ---------------------------------------------------------------- v1.5 体感反馈

    public boolean feedbackSoundEnabled() { return prefs.getBoolean("feedback_sound", true); }
    public boolean feedbackHapticEnabled() { return prefs.getBoolean("feedback_haptic", true); }
    /** 冷启动的开场动效。关掉就直接进首页。 */
    public boolean bootAnimationEnabled() { return prefs.getBoolean("boot_animation", true); }
    /** 每次成功跳过都响一声，默认关闭：开屏频繁时太吵。 */
    public boolean feedbackSkipEnabled() { return prefs.getBoolean("feedback_skip", false); }

    // ---------------------------------------------------------------- v1.6.6 新手引导

    /**
     * 是否已经看过新手引导。
     *
     * <p>只用一个布尔值而不是"版本号"：引导讲的是首页布局与流程，功能加得再多，
     * 首页那几行入口没变就不该再弹一次。真要重讲，把 key 换掉即可。
     *
     * <p>key 换过两次：1.6.7 从"六页说明书"变成"在首页上逐个指控件"（v2），
     * 1.6.8 又把灯光整套重做（v3）。这两次都是形态变了、值得让老用户重看一遍。
     * 之后只加功能、不动引导形态的话，不要再换 key —— 每次升级都弹一次会烦。
     */
    public boolean guideSeen() { return prefs.getBoolean("guide_seen_v3", false); }

    public void markGuideSeen() { prefs.edit().putBoolean("guide_seen_v3", true).apply(); }

    /**
     * 从设置页「重看新手引导」发出的请求。
     *
     * <p>不直接在这里弹：设置页没有首页那层容器，弹出来会跟页面返回动画打架。
     * 落一个标记，等回到首页再消费，顺便保证引导盖在完整布局之上。
     */
    public void requestGuide() { prefs.edit().putBoolean("guide_request", true).apply(); }

    public boolean consumeGuideRequest() {
        if (!prefs.getBoolean("guide_request", false)) return false;
        prefs.edit().remove("guide_request").apply();
        return true;
    }

    // ---------------------------------------------------------------- v1.2 policy

    /**
     * Three-state rewarded-ad policy. Migrates the legacy boolean switch so an existing
     * install that had "rewarded_ads=true" becomes AUTO_ABANDON rather than silently
     * falling back to protection.
     */
    public EngineSettings.RewardMode rewardMode() {
        String stored = prefs.getString("reward_mode", "");
        if (!stored.isEmpty()) {
            try { return EngineSettings.RewardMode.valueOf(stored); }
            catch (IllegalArgumentException ignored) { }
        }
        if (prefs.getBoolean("rewarded_ads", false)) return EngineSettings.RewardMode.AUTO_ABANDON;
        // v1.4: 新安装对齐「均衡」——播完再关，奖励不丢。
        return EngineSettings.RewardMode.END_CARD_ONLY;
    }

    public void setRewardMode(EngineSettings.RewardMode mode) {
        prefs.edit().putString("reward_mode", mode.name()).apply();
    }

    public Set<String> rewardAutoAbandonApps() {
        return new HashSet<>(prefs.getStringSet("reward_auto_apps", Collections.<String>emptySet()));
    }

    public void setRewardAutoAbandonApp(String packageName, boolean enabled) {
        Set<String> values = rewardAutoAbandonApps();
        if (enabled) values.add(packageName); else values.remove(packageName);
        prefs.edit().putStringSet("reward_auto_apps", values).apply();
    }

    public boolean structuralAdEvidenceEnabled() { return prefs.getBoolean("structural_evidence", true); }
    public boolean confirmationFollowUpEnabled() { return prefs.getBoolean("confirm_followup", true); }
    public boolean layoutAnchorsEnabled() { return prefs.getBoolean("layout_anchors", false); }
    /** v1.4: 叠层弹窗右上角悬浮关闭按钮自动定位（默认开启，硬锁不受影响）。 */
    public boolean overlayCloseEnabled() { return prefs.getBoolean("overlay_close", true); }
    public void setOverlayCloseEnabled(boolean value) { prefs.edit().putBoolean("overlay_close", value).apply(); }
    /**
     * v1.5.1: WebView 模板广告（穿山甲 / 优量汇 / 广点通）的「反馈 ⟷ 关闭」对偶定位。
     * 这类页面整棵树 c=0，除了几何对偶没有任何可读信号；默认开启，硬锁不受影响。
     */
    public boolean webAdTemplateEnabled() { return prefs.getBoolean("web_ad_template", true); }

    public EngineSettings engineSettings() {
        return new EngineSettings(closeIconsEnabled(), fastSplashEnabled(), rewardMode(),
                rewardAutoAbandonApps(), structuralAdEvidenceEnabled(),
                confirmationFollowUpEnabled(), layoutAnchorsEnabled(), overlayCloseEnabled(),
                webAdTemplateEnabled());
    }

    // ---------------------------------------------------------------- layout anchors

    public synchronized List<LayoutAnchorRule> layoutAnchors() {
        List<LayoutAnchorRule> result = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(prefs.getString("layout_anchor_rules", "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.getJSONObject(i);
                result.add(new LayoutAnchorRule(item.getString("id"),
                        item.optString("package", ""), item.optString("activity", ""),
                        item.optBoolean("enabled", true), item.optString("desc", "")));
            }
        } catch (JSONException ignored) { }
        return result;
    }

    public synchronized void addLayoutAnchor(LayoutAnchorRule rule) {
        List<LayoutAnchorRule> all = layoutAnchors();
        for (LayoutAnchorRule existing : all) {
            if (existing.packageName.equals(rule.packageName)
                    && existing.activityFragment.equals(rule.activityFragment)) return;
        }
        all.add(rule);
        saveLayoutAnchors(all);
    }

    public synchronized void deleteLayoutAnchor(String id) {
        List<LayoutAnchorRule> all = layoutAnchors();
        List<LayoutAnchorRule> kept = new ArrayList<>();
        for (LayoutAnchorRule rule : all) if (!rule.id.equals(id)) kept.add(rule);
        saveLayoutAnchors(kept);
    }

    private void saveLayoutAnchors(List<LayoutAnchorRule> rules) {
        JSONArray array = new JSONArray();
        for (LayoutAnchorRule rule : rules) {
            JSONObject item = new JSONObject();
            try {
                item.put("id", rule.id);
                item.put("package", rule.packageName);
                item.put("activity", rule.activityFragment);
                item.put("enabled", rule.enabled);
                item.put("desc", rule.description);
                array.put(item);
            } catch (JSONException ignored) { }
        }
        prefs.edit().putString("layout_anchor_rules", array.toString()).apply();
    }

    /** Narrow an existing global custom rule to one package (used by SCOPE_RULE suggestions). */
    public synchronized void scopeCustomRuleTo(String ruleId, String packageName) {
        List<Rule> custom = new ArrayList<>();
        for (Rule item : getRules()) {
            if (!item.builtIn) {
                custom.add(item.id.equals(ruleId)
                        ? new Rule(item.id, item.phrase, item.matchType, item.category,
                                item.requiresAdContext, false, item.enabled, packageName)
                        : item);
            }
        }
        saveCustomRules(custom);
    }

    // ---------------------------------------------------------------- apps & rules

    public boolean isAppEnabled(String packageName) {
        return !prefs.getStringSet("disabled_apps", Collections.<String>emptySet()).contains(packageName);
    }

    public void setAppEnabled(String packageName, boolean enabled) {
        Set<String> values = new HashSet<>(prefs.getStringSet("disabled_apps", Collections.<String>emptySet()));
        if (enabled) values.remove(packageName); else values.add(packageName);
        prefs.edit().putStringSet("disabled_apps", values).apply();
    }

    /** 批量启停：一次 commit，避免逐个应用触发十几次监听回调。 */
    public void setAppsEnabled(Collection<String> packageNames, boolean enabled) {
        if (packageNames == null || packageNames.isEmpty()) return;
        Set<String> values = new HashSet<>(prefs.getStringSet("disabled_apps", Collections.<String>emptySet()));
        if (enabled) values.removeAll(packageNames); else values.addAll(packageNames);
        prefs.edit().putStringSet("disabled_apps", values).apply();
    }

    /**
     * v1.5.2：重点关注应用。
     *
     * <p>大部分 App 根本没有广告，逐个开关太累；反过来，真正天天弹开屏的那几个又值得
     * "更早、更宽容"地处理。重点标记就是后者：云端 0 等待接管、置信度门槛更低、
     * 几何规则（模板 / 叠层）在该应用上强制开启，与全局预置无关。
     */
    public boolean isPriorityApp(String packageName) {
        if (packageName == null || packageName.isEmpty()) return false;
        return prefs.getStringSet("priority_apps", Collections.<String>emptySet()).contains(packageName);
    }

    public void setPriorityApp(String packageName, boolean priority) {
        if (packageName == null || packageName.isEmpty()) return;
        Set<String> values = new HashSet<>(prefs.getStringSet("priority_apps", Collections.<String>emptySet()));
        if (priority) values.add(packageName); else values.remove(packageName);
        prefs.edit().putStringSet("priority_apps", values).apply();
    }

    public Set<String> priorityApps() {
        return new HashSet<>(prefs.getStringSet("priority_apps", Collections.<String>emptySet()));
    }

    /** 某个包实际使用的接管灵敏度：重点应用直接拉到「重点」档。 */
    public VisionTriggerPolicy.Sensitivity sensitivityFor(String packageName) {
        if (isPriorityApp(packageName)) return VisionTriggerPolicy.Sensitivity.PRIORITY;
        return visionSensitivity();
    }

    // ------------------------------------------------------- learned closes (v1.5.9)

    /**
     * 用户亲手教出来的关闭位置。数量天然很少（每个应用每个页面一条），所以整体读写的开销可以忽略。
     */
    public synchronized List<LearnedClose> learnedCloses() {
        List<LearnedClose> result = new ArrayList<>();
        String json = prefs.getString("learned_closes", "[]");
        try {
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.getJSONObject(i);
                result.add(new LearnedClose(
                        item.optString("pkg", ""), item.optString("act", ""),
                        item.optString("label", ""), item.optString("vid", ""),
                        item.optString("cls", ""),
                        (float) item.optDouble("l", 0), (float) item.optDouble("t", 0),
                        (float) item.optDouble("r", 0), (float) item.optDouble("b", 0),
                        item.optLong("at", 0L), item.optInt("hits", 0)));
            }
        } catch (JSONException ignored) { }
        return result;
    }

    /** 同一应用同一页面只保留一条，重新学会覆盖旧的。 */
    public synchronized void saveLearnedClose(LearnedClose close) {
        if (close == null) return;
        List<LearnedClose> all = learnedCloses();
        for (int i = all.size() - 1; i >= 0; i--) {
            LearnedClose item = all.get(i);
            if (item.packageName.equals(close.packageName)
                    && item.activityName.equals(close.activityName)) all.remove(i);
        }
        all.add(0, close);
        writeLearnedCloses(all);
    }

    public synchronized void deleteLearnedClose(String packageName, String activityName) {
        List<LearnedClose> all = learnedCloses();
        for (int i = all.size() - 1; i >= 0; i--) {
            LearnedClose item = all.get(i);
            if (item.packageName.equals(packageName)
                    && item.activityName.equals(activityName)) all.remove(i);
        }
        writeLearnedCloses(all);
    }

    public synchronized void clearLearnedCloses() {
        prefs.edit().remove("learned_closes").apply();
    }

    private void writeLearnedCloses(List<LearnedClose> all) {
        JSONArray array = new JSONArray();
        for (LearnedClose item : all) {
            JSONObject row = new JSONObject();
            try {
                row.put("pkg", item.packageName);
                row.put("act", item.activityName);
                row.put("label", item.label);
                row.put("vid", item.viewId);
                row.put("cls", item.className);
                row.put("l", item.leftRatio);
                row.put("t", item.topRatio);
                row.put("r", item.rightRatio);
                row.put("b", item.bottomRatio);
                row.put("at", item.createdAt);
                row.put("hits", item.hits);
                array.put(row);
            } catch (JSONException ignored) { }
        }
        prefs.edit().putString("learned_closes", array.toString()).apply();
    }

    public synchronized List<Rule> getRules() {
        Set<String> disabled = prefs.getStringSet("disabled_builtin_rules", Collections.<String>emptySet());
        List<Rule> result = new ArrayList<>();
        for (Rule rule : DefaultRules.create()) result.add(rule.withEnabled(!disabled.contains(rule.id)));
        String json = prefs.getString("custom_rules", "[]");
        try {
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.getJSONObject(i);
                result.add(new Rule(item.getString("id"), item.getString("phrase"),
                        Rule.MatchType.valueOf(item.optString("match", Rule.MatchType.EXACT.name())),
                        Rule.Category.CUSTOM, item.optBoolean("context", true), false,
                        item.optBoolean("enabled", true), item.optString("package", "")));
            }
        } catch (JSONException ignored) { }
        // 旧版本曾把脱敏占位符「[文字已隐藏·长度N]」当成关闭词写入，这类规则永远匹配不到，
        // 留着只会让用户在规则列表里困惑。读取时直接丢掉，不落盘（下次保存时自然消失）。
        for (int i = result.size() - 1; i >= 0; i--) {
            Rule rule = result.get(i);
            if (!rule.builtIn && DumpAnalyzer.isMaskedText(rule.phrase)) result.remove(i);
        }
        return result;
    }

    public synchronized void addCustomRule(Rule rule) {
        List<Rule> custom = new ArrayList<>();
        for (Rule item : getRules()) if (!item.builtIn) custom.add(item);
        custom.add(rule);
        saveCustomRules(custom);
    }

    public synchronized void deleteCustomRule(String id) {
        List<Rule> custom = new ArrayList<>();
        for (Rule item : getRules()) if (!item.builtIn && !item.id.equals(id)) custom.add(item);
        saveCustomRules(custom);
    }

    public synchronized void setCustomRuleEnabled(String id, boolean enabled) {
        List<Rule> custom = new ArrayList<>();
        for (Rule item : getRules()) {
            if (!item.builtIn) custom.add(item.id.equals(id) ? item.withEnabled(enabled) : item);
        }
        saveCustomRules(custom);
    }

    public void setBuiltInRuleEnabled(String id, boolean enabled) {
        Set<String> values = new HashSet<>(prefs.getStringSet("disabled_builtin_rules", Collections.<String>emptySet()));
        if (enabled) values.remove(id); else values.add(id);
        prefs.edit().putStringSet("disabled_builtin_rules", values).apply();
    }

    private void saveCustomRules(List<Rule> rules) {
        JSONArray array = new JSONArray();
        for (Rule rule : rules) {
            JSONObject item = new JSONObject();
            try {
                item.put("id", rule.id);
                item.put("phrase", rule.phrase);
                item.put("match", rule.matchType.name());
                item.put("context", rule.requiresAdContext);
                item.put("enabled", rule.enabled);
                item.put("package", rule.packageName);
                array.put(item);
            } catch (JSONException ignored) { }
        }
        prefs.edit().putString("custom_rules", array.toString()).apply();
    }

    // ---------------------------------------------------------------- heartbeat

    /**
     * v1.5.8: 服务心跳。
     *
     * <p>"设置里显示已开启"只说明系统记着这个服务，不代表它真的连上了。荣耀 / 华为这类
     * 系统会把第三方无障碍服务悄悄停掉，界面依旧显示开启，实际什么都收不到。让服务自己
     * 定期写一个时间戳，是唯一能分辨"真的在跑"和"只是显示在跑"的办法。
     */
    public void beat(long now) {
        prefs.edit().putLong("last_beat", now).apply();
    }

    public long lastBeat() {
        return prefs.getLong("last_beat", 0L);
    }

    /** 明确停机时清零，首页立刻能看到「已掉线」，不用等超时。 */
    public void clearBeat() {
        prefs.edit().remove("last_beat").apply();
    }

    /** 超过这么久没有心跳，就当服务已经不在工作。 */
    public static final long BEAT_STALE_MS = 300_000L;

    public boolean serviceStale() {
        return isStale(lastBeat(), System.currentTimeMillis());
    }

    /** 纯判断，方便单测：没有心跳、或心跳太旧，都算服务不在工作。 */
    public static boolean isStale(long lastBeat, long now) {
        return lastBeat <= 0L || now - lastBeat > BEAT_STALE_MS;
    }

    // ---------------------------------------------------------------- logs

    /** v1.5.6: 诊断数据保留上限。留太多时，诊断页要逐条读文件 + 跑引擎，打开就卡。 */
    public static final int LOG_KEEP_MIN = 5;
    public static final int LOG_KEEP_MAX = 120;
    public static final int DUMP_KEEP_MIN = 3;
    public static final int DUMP_KEEP_MAX = 40;
    private static final int LOG_KEEP_DEFAULT = 10;
    private static final int DUMP_KEEP_DEFAULT = 10;

    public int logKeepLimit() {
        return clampKeep(prefs.getInt("log_keep", LOG_KEEP_DEFAULT), LOG_KEEP_MIN, LOG_KEEP_MAX);
    }

    public int dumpKeepLimit() {
        return clampKeep(prefs.getInt("dump_keep", DUMP_KEEP_DEFAULT), DUMP_KEEP_MIN, DUMP_KEEP_MAX);
    }

    public void setLogKeepLimit(int limit) {
        prefs.edit().putInt("log_keep", clampKeep(limit, LOG_KEEP_MIN, LOG_KEEP_MAX)).apply();
        trimLogs();
    }

    public void setDumpKeepLimit(int limit) {
        prefs.edit().putInt("dump_keep", clampKeep(limit, DUMP_KEEP_MIN, DUMP_KEEP_MAX)).apply();
    }

    private static int clampKeep(int value, int min, int max) {
        return RetentionPolicy.clamp(value, min, max);
    }

    public synchronized void addLog(String packageName, String action, String detail) {
        List<LogEntry> entries = getLogs();
        entries.add(0, new LogEntry(System.currentTimeMillis(), packageName, action, detail));
        entries = RetentionPolicy.newestFirst(entries, logKeepLimit());
        saveLogs(entries);
        prefs.edit().putInt("total_count", totalCount() + 1).apply();
    }

    /** 把已有日志裁剪到当前上限。改小保留数时立即生效，不用等新日志。 */
    public synchronized void trimLogs() {
        List<LogEntry> entries = getLogs();
        if (entries.size() <= logKeepLimit()) return;
        saveLogs(RetentionPolicy.newestFirst(entries, logKeepLimit()));
    }

    private void saveLogs(List<LogEntry> entries) {
        JSONArray array = new JSONArray();
        for (LogEntry entry : entries) {
            JSONObject item = new JSONObject();
            try {
                item.put("time", entry.time);
                item.put("package", entry.packageName);
                item.put("action", entry.action);
                item.put("detail", entry.detail);
                array.put(item);
            } catch (JSONException ignored) { }
        }
        prefs.edit().putString("logs", array.toString()).apply();
    }

    public synchronized List<LogEntry> getLogs() {
        List<LogEntry> result = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(prefs.getString("logs", "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.getJSONObject(i);
                result.add(new LogEntry(item.optLong("time"), item.optString("package"),
                        item.optString("action"), item.optString("detail")));
            }
        } catch (JSONException ignored) { }
        return result;
    }

    public int todayCount() {
        long start = System.currentTimeMillis() - 24L * 60L * 60L * 1000L;
        int count = 0;
        for (LogEntry entry : getLogs()) if (entry.time >= start) count++;
        return count;
    }

    public void clearLogs() { prefs.edit().remove("logs").apply(); }
}
