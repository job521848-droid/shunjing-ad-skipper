package app.shunjing.skipper.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import app.shunjing.skipper.R;
import app.shunjing.skipper.data.Prefs;
import app.shunjing.skipper.engine.AdDecisionEngine;

public final class AppsActivity extends BaseActivity {
    private final List<AppItem> allApps = new ArrayList<>();
    private final List<AppItem> visibleApps = new ArrayList<>();
    private Prefs prefs;
    private AppAdapter adapter;
    private TextView countLine;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        LinearLayout root = Ui.root(this);
        root.addView(Ui.header(this, "应用管理", "默认全部开启；绝大多数 App 没有广告，可以一键关掉", true));
        EditText search = Ui.input(this, "搜索应用名称或包名");
        root.addView(search, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(0, Ui.dp(this, 10), 0, 0);
        addAction(actions, "全部关闭", v -> confirmDisableAll());
        addAction(actions, "全部开启", v -> applyBulk(true));
        addAction(actions, "仅留重点", v -> confirmPriorityOnly());
        root.addView(actions);

        countLine = Ui.text(this, "", 12, getColor(R.color.text_secondary));
        countLine.setPadding(0, Ui.dp(this, 10), 0, 0);
        root.addView(countLine);

        TextView note = Ui.text(this,
                "点右侧 ☆ 可把应用标为「重点关注」：开屏一出现就让云端接管，等待为 0，"
                        + "置信度门槛更低，模板 / 叠层几何定位也强制开启。批量按钮只作用于当前搜索结果。",
                11, getColor(R.color.text_secondary));
        note.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 8));
        root.addView(note);

        ListView list = new ListView(this);
        list.setDivider(null);
        adapter = new AppAdapter();
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { filter(s.toString()); }
            @Override public void afterTextChanged(Editable s) { }
        });
        loadApps();
    }

    private void addAction(LinearLayout parent, String label, View.OnClickListener listener) {
        Button button = Ui.secondary(this, label);
        button.setTextSize(13);
        button.setMinHeight(Ui.dp(this, 40));
        button.setMinimumWidth(0);
        button.setMinWidth(0);
        button.setPadding(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0);
        button.setOnClickListener(listener);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        params.setMargins(Ui.dp(this, 2), 0, Ui.dp(this, 2), 0);
        parent.addView(button, params);
    }

    private void loadApps() {
        new Thread(() -> {
            PackageManager manager = getPackageManager();
            Intent intent = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> resolved = manager.queryIntentActivities(intent, 0);
            Map<String, AppItem> unique = new LinkedHashMap<>();
            for (ResolveInfo info : resolved) {
                if (info.activityInfo == null) continue;
                String pkg = info.activityInfo.packageName;
                if (unique.containsKey(pkg)) continue;
                unique.put(pkg, new AppItem(info.loadLabel(manager).toString(), pkg, info.loadIcon(manager)));
            }
            List<AppItem> sorted = new ArrayList<>(unique.values());
            Collections.sort(sorted, (a, b) -> a.label.compareToIgnoreCase(b.label));
            runOnUiThread(() -> {
                allApps.clear();
                allApps.addAll(sorted);
                filter("");
            });
        }).start();
    }

    private void filter(String query) {
        visibleApps.clear();
        String normalized = query.toLowerCase();
        for (AppItem app : allApps) {
            if (normalized.isEmpty() || app.label.toLowerCase().contains(normalized)
                    || app.packageName.toLowerCase().contains(normalized)) visibleApps.add(app);
        }
        adapter.notifyDataSetChanged();
        refreshCount();
    }

    private void refreshCount() {
        int enabled = 0, priority = 0;
        for (AppItem app : allApps) {
            if (!AdDecisionEngine.isProtectedPackage(app.packageName) && prefs.isAppEnabled(app.packageName)) {
                enabled++;
            }
            if (prefs.isPriorityApp(app.packageName)) priority++;
        }
        countLine.setText("已开启 " + enabled + " / " + allApps.size() + " 个应用  ·  重点关注 "
                + priority + " 个  ·  当前列表 " + visibleApps.size() + " 个");
    }

    private List<String> editableVisiblePackages() {
        List<String> values = new ArrayList<>();
        for (AppItem app : visibleApps) {
            if (!AdDecisionEngine.isProtectedPackage(app.packageName)) values.add(app.packageName);
        }
        return values;
    }

    private void applyBulk(boolean enabled) {
        List<String> targets = editableVisiblePackages();
        if (targets.isEmpty()) {
            Toast.makeText(this, "当前列表没有可修改的应用", Toast.LENGTH_SHORT).show();
            return;
        }
        prefs.setAppsEnabled(targets, enabled);
        adapter.notifyDataSetChanged();
        refreshCount();
        Toast.makeText(this, (enabled ? "已开启 " : "已关闭 ") + targets.size() + " 个应用",
                Toast.LENGTH_SHORT).show();
    }

    private void confirmDisableAll() {
        List<String> targets = editableVisiblePackages();
        if (targets.isEmpty()) {
            Toast.makeText(this, "当前列表没有可修改的应用", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("关闭 " + targets.size() + " 个应用？")
                .setMessage("这些应用里的广告将不再被自动跳过。之后可以随时单独打开，或点「全部开启」恢复。")
                .setNegativeButton("取消", null)
                .setPositiveButton("全部关闭", (dialog, which) -> applyBulk(false))
                .show();
    }

    private void confirmPriorityOnly() {
        List<String> targets = editableVisiblePackages();
        if (targets.isEmpty()) {
            Toast.makeText(this, "当前列表没有可修改的应用", Toast.LENGTH_SHORT).show();
            return;
        }
        int counted = 0;
        for (String pkg : targets) if (prefs.isPriorityApp(pkg)) counted++;
        final int kept = counted;
        if (kept == 0) {
            Toast.makeText(this, "还没有标记重点应用，先点几个 ☆ 再来", Toast.LENGTH_LONG).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("只保留 " + kept + " 个重点应用？")
                .setMessage("当前列表里其余 " + (targets.size() - kept)
                        + " 个应用会被关闭自动跳过，重点应用保持开启。")
                .setNegativeButton("取消", null)
                .setPositiveButton("仅留重点", (dialog, which) -> {
                    for (String pkg : targets) {
                        prefs.setAppEnabled(pkg, prefs.isPriorityApp(pkg));
                    }
                    adapter.notifyDataSetChanged();
                    refreshCount();
                    Toast.makeText(this, "已保留 " + kept + " 个重点应用", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private static final class AppItem {
        final String label;
        final String packageName;
        final Drawable icon;
        AppItem(String label, String packageName, Drawable icon) {
            this.label = label;
            this.packageName = packageName;
            this.icon = icon;
        }
    }

    private final class AppAdapter extends BaseAdapter {
        @Override public int getCount() { return visibleApps.size(); }
        @Override public AppItem getItem(int position) { return visibleApps.get(position); }
        @Override public long getItemId(int position) { return visibleApps.get(position).packageName.hashCode(); }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            AppItem app = getItem(position);
            final Context context = AppsActivity.this;
            LinearLayout row = new LinearLayout(context);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setBackgroundResource(R.drawable.bg_panel);
            row.setPadding(Ui.dp(context, 14), Ui.dp(context, 12),
                    Ui.dp(context, 10), Ui.dp(context, 12));
            ImageView icon = new ImageView(context);
            icon.setImageDrawable(app.icon);
            row.addView(icon, new LinearLayout.LayoutParams(Ui.dp(context, 44), Ui.dp(context, 44)));
            LinearLayout labels = new LinearLayout(context);
            labels.setOrientation(LinearLayout.VERTICAL);
            labels.setPadding(Ui.dp(context, 12), 0, Ui.dp(context, 8), 0);
            boolean protect = AdDecisionEngine.isProtectedPackage(app.packageName);
            boolean priority = prefs.isPriorityApp(app.packageName);
            labels.addView(Ui.text(context, app.label, 16, getColor(R.color.text_primary)));
            String detail = app.packageName + (protect ? "\n系统保护 · 永不操作"
                    : priority ? "\n重点关注 · 优先接管" : "");
            labels.addView(Ui.text(context, detail, 10,
                    getColor(protect ? R.color.warning : priority ? R.color.cyan : R.color.text_secondary)));
            row.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            TextView star = Ui.text(context, priority ? "★" : "☆", 22,
                    getColor(priority ? R.color.warning : R.color.text_secondary));
            star.setGravity(Gravity.CENTER);
            star.setPadding(Ui.dp(context, 8), 0, Ui.dp(context, 8), 0);
            star.setContentDescription(priority ? "取消重点关注" : "设为重点关注");
            if (protect) {
                star.setVisibility(View.INVISIBLE);
            } else {
                star.setOnClickListener(v -> {
                    boolean next = !prefs.isPriorityApp(app.packageName);
                    prefs.setPriorityApp(app.packageName, next);
                    // 重点应用必须处于开启状态，否则标星没有任何意义。
                    if (next && !prefs.isAppEnabled(app.packageName)) {
                        prefs.setAppEnabled(app.packageName, true);
                    }
                    notifyDataSetChanged();
                    refreshCount();
                    Toast.makeText(context, next ? "已设为重点关注：" + app.label : "已取消重点关注",
                            Toast.LENGTH_SHORT).show();
                });
            }
            row.addView(star);

            Switch enabled = new Switch(context);
            enabled.setEnabled(!protect);
            enabled.setChecked(protect || prefs.isAppEnabled(app.packageName));
            enabled.setContentDescription(protect ? "系统保护" : "自动跳过开关");
            enabled.setOnCheckedChangeListener((button, checked) -> {
                if (protect) return;
                prefs.setAppEnabled(app.packageName, checked);
                if (!checked && prefs.isPriorityApp(app.packageName)) {
                    // 关掉的应用不该继续留在重点名单里，否则「仅留重点」会出现关了又开的怪现象。
                    prefs.setPriorityApp(app.packageName, false);
                }
                notifyDataSetChanged();
                refreshCount();
            });
            row.addView(enabled);
            LinearLayout wrapper = new LinearLayout(context);
            wrapper.addView(row);
            wrapper.setPadding(0, 0, 0, Ui.dp(context, 8));
            return wrapper;
        }
    }
}
