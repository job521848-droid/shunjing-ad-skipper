package app.shunjing.skipper.data;

public final class LogEntry {
    public final long time;
    public final String packageName;
    public final String action;
    public final String detail;

    public LogEntry(long time, String packageName, String action, String detail) {
        this.time = time;
        this.packageName = packageName;
        this.action = action;
        this.detail = detail;
    }
}
