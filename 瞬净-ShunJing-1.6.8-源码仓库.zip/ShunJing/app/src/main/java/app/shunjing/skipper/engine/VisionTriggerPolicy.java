package app.shunjing.skipper.engine;

/**
 * 云端视觉的接管时机。
 *
 * <p>旧逻辑要求「连续 10 次扫描都没有候选 + 同一页面 25 秒只请求一次」，实际使用中
 * 广告早就过去了，云端还没轮到，等于白配。这里把"什么时候该让 AI 上"抽成纯函数，
 * 三档灵敏度只是参数不同，安全校验（敏感页、广告上下文、坐标复核）一律不变。
 *
 * <ul>
 *   <li>保守 —— 本地确实无能为力（1 秒以上没有任何可点目标）才请求，且同一页面 25 秒一次。</li>
 *   <li>积极（默认）—— 广告页出现约 0.65 秒仍没有本地动作就接管，同一页面 6 秒一次。</li>
 *   <li>激进 —— 0.3 秒就接管，同一页面 3 秒一次；适合"跳过按钮只闪一瞬"的倒计时广告。</li>
 * </ul>
 */
public final class VisionTriggerPolicy {

    public enum Sensitivity {
        CONSERVATIVE("保守", 3_000L, 25_000L, 10, 2, 0.80f, 4_000L),
        EAGER("积极", 650L, 6_000L, 2, 1, 0.60f, 1_200L),
        AGGRESSIVE("激进", 300L, 3_000L, 1, 1, 0.48f, 500L),
        /**
         * v1.5.2：只作用于「重点关注」应用。广告页一出现就接管（0 等待），同一页面
         * 1.2 秒即可重试，置信度门槛再降一档。它不是一档全局设置，而是用户逐个 App
         * 点过星的显式授权，所以可以比全局最激进档还快。
         */
        PRIORITY("重点", 0L, 1_200L, 0, 1, 0.42f, 0L);

        public final String label;
        /** 页面出现后多久仍无本地动作就接管。 */
        public final long idleTakeoverMs;
        /** 同一页面两次云端请求的最小间隔。 */
        public final long pageCooldownMs;
        /** 保守档额外要求的"连续无候选"扫描次数。 */
        public final int minIdleScans;
        /** 点击已失败时，最短等待多久再接管。 */
        public final int minFailedClickChecks;
        /** 接受模型答案的最低置信度。 */
        public final float minConfidence;
        /**
         * v1.6：本地只有"疑似"（没有广告词、没有 SDK 结构证据）时的接管等待。
         * 比强证据慢一点——它是"花一次请求问一句"，不值得为它牺牲响应速度，
         * 但也不该像旧版那样永远不问。
         */
        public final long suspectTakeoverMs;

        Sensitivity(String label, long idleTakeoverMs, long pageCooldownMs,
                    int minIdleScans, int minFailedClickChecks, float minConfidence,
                    long suspectTakeoverMs) {
            this.label = label;
            this.idleTakeoverMs = idleTakeoverMs;
            this.pageCooldownMs = pageCooldownMs;
            this.minIdleScans = minIdleScans;
            this.minFailedClickChecks = minFailedClickChecks;
            this.minConfidence = minConfidence;
            this.suspectTakeoverMs = suspectTakeoverMs;
        }
    }

    private VisionTriggerPolicy() { }

    public static Sensitivity parse(String name) {
        if (name != null) {
            for (Sensitivity value : Sensitivity.values()) {
                if (value.name().equals(name)) return value;
            }
        }
        return Sensitivity.EAGER;
    }

    /**
     * 页面上找不到任何可点目标时的接管判定。
     *
     * @param visualAdContext 页面确实是广告位（广告词 / 摇一摇 / 广告面 / 运营弹窗），不是普通功能页
     * @param sensitive       命中扫码、支付、密码等硬锁
     * @param pageAgeMs       当前页面首次出现到现在
     * @param idleScans       同一页面连续没有候选的扫描次数
     * @param sinceLastMs     同一页面距上次云端请求，从未请求过传 {@link Long#MAX_VALUE}
     */
    public static boolean shouldTakeOver(Sensitivity sensitivity, boolean cloudReady,
                                         boolean visualAdContext, boolean sensitive,
                                         long pageAgeMs, int idleScans, long sinceLastMs) {
        return shouldTakeOver(sensitivity, cloudReady, visualAdContext, false, sensitive,
                pageAgeMs, idleScans, sinceLastMs);
    }

    /**
     * v1.6：区分「强证据」与「仅疑似」。
     *
     * @param strongEvidence 页面有广告词 / 摇一摇 / 广告面 / SDK 结构，本地已确认是广告位
     * @param suspect        只有结构上的"像"（全屏媒体、无输入框、无列表骨架），没有广告证据
     */
    public static boolean shouldTakeOver(Sensitivity sensitivity, boolean cloudReady,
                                         boolean strongEvidence, boolean suspect, boolean sensitive,
                                         long pageAgeMs, int idleScans, long sinceLastMs) {
        if (sensitivity == null || !cloudReady || sensitive) return false;
        if (!strongEvidence && !suspect) return false;
        long dwell = strongEvidence ? sensitivity.idleTakeoverMs : sensitivity.suspectTakeoverMs;
        if (pageAgeMs < dwell) return false;
        if (idleScans < (strongEvidence ? sensitivity.minIdleScans : 1)) return false;
        return sinceLastMs >= sensitivity.pageCooldownMs;
    }

    /**
     * 本地点过一次但页面没变（或补点也没变）时的接管判定。
     * 这条路径不再要求"页面静止很久"，只要求同一页面没有刚请求过。
     */
    public static boolean shouldTakeOverAfterFailedClick(Sensitivity sensitivity, boolean cloudReady,
                                                         boolean visualAdContext, boolean sensitive,
                                                         long sinceLastMs) {
        if (sensitivity == null || !cloudReady || !visualAdContext || sensitive) return false;
        return sinceLastMs >= sensitivity.pageCooldownMs;
    }

    /** 云端返回坐标后，是否值得再让本地几何策略做一次兜底点击。 */
    public static boolean allowsCoordinateOnly(Sensitivity sensitivity, float confidence) {
        if (sensitivity == null) return false;
        return confidence >= sensitivity.minConfidence;
    }
}
