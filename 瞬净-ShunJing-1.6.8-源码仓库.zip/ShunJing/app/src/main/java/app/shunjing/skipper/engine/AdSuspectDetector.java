package app.shunjing.skipper.engine;

import java.util.Locale;

/**
 * 「疑似广告页」评分 v1.6。
 *
 * <p>解决的问题：云端视觉只在「本地已经确认是广告」时才会被叫醒，于是出现一种尴尬——
 * 页面明明是全屏图片 / H5 落地页 / 摇一摇广告，但既没有「广告」二字，也不命中 SDK 的
 * 结构特征，本地判定"无证据"，云端永远轮不上。用户看到的现象就是：AI 明明能认出来，
 * 却压根没被调用。
 *
 * <p>本类只回答一个问题：<b>这一页值不值得花一次截图 + 一次 API 调用，让云端看一眼。</b>
 * 它<b>不授权任何点击</b>。真正落地点击前仍要过 {@link VisionRecoveryPolicy}：
 * 敏感页硬锁、受保护包、危险按钮（下载 / 支付 / 领取 / 授权）一律拒绝，
 * 且"仅疑似"时置信度门槛更高。
 *
 * <p>评分原则：加分项必须是"广告页常见、功能页少见"的结构；减分项覆盖 App 的常规骨架
 * （底部导航、Tab、长列表、多入口文案）。任何输入框 / 密码框直接判 0。
 */
public final class AdSuspectDetector {
    /** 达到该分数才值得问云端。偏低会烧钱，偏高又回到"永远不触发"。 */
    public static final int THRESHOLD = 58;

    /** 广告位 Activity 的常见命名。命中只是"可能"，不是证据。 */
    private static final String[] ACTIVITY_HINTS = {
            "splash", "interstitial", "advert", "adactivity", "adloader", "adsdk", "openads",
            "reward", "insert", "webview", "webactivity", "h5", "landing", "promo", "promotion"
    };
    /** App 常规骨架文案：出现两个以上说明这更像功能页而不是广告页。 */
    private static final String[] SHELL_WORDS = {
            "首页", "我的", "发现", "消息", "购物车", "分类", "推荐", "关注", "设置", "全部",
            "最近任务", "全部应用", "文件夹", "搜索", "排序", "编辑"
    };
    private static final String[] LIST_CLASSES = {
            "recyclerview", "listview", "gridview", "scrollview", "viewpager",
            "tablayout", "bottomnavigation", "nestedscrollview"
    };
    private static final String[] MEDIA_CLASSES = {
            "imageview", "webview", "surfaceview", "videoview", "textureview"
    };
    private static final String[] INPUT_CLASSES = {
            "edittext", "autocompletetextview", "textinputedittext", "searchview"
    };
    private static final String[] CLOSE_WORDS = {"关闭", "叉", "cancel", "close", "dismiss", "skip", "跳过"};

    private AdSuspectDetector() { }

    public static boolean isSuspect(ScreenModel screen) {
        return score(screen) >= THRESHOLD;
    }

    /** 0 = 完全不像广告；100 = 极像。任何硬锁命中直接 0。 */
    public static int score(ScreenModel screen) {
        if (screen == null || screen.nodes.isEmpty()) return 0;
        if (AdDecisionEngine.isProtectedPackage(screen.packageName)) return 0;
        // v1.6.3：只排除支付 / 扫码页。旧写法用 isSensitive，会因为广告页脚的一行
        // 「隐私政策」直接判 0 分，云端连看一眼的机会都没有。
        if (AdDecisionEngine.isPaymentOrScan(screen)) return 0;
        if (screen.nodes.size() < 4) return 0;

        int width = 0, height = 0;
        for (NodeModel n : screen.nodes) {
            if (!n.visible || !n.hasBounds()) continue;
            width = Math.max(width, n.right);
            height = Math.max(height, n.bottom);
        }
        if (width <= 0 || height <= 0) return 0;
        long screenArea = (long) width * height;

        for (NodeModel n : screen.nodes) {
            if (!n.visible) continue;
            if (n.password) return 0;
            String cls = n.className.toLowerCase(Locale.ROOT);
            for (String input : INPUT_CLASSES) {
                if (cls.endsWith(input)) return 0;
            }
        }

        int score = 0;
        if (screen.launchedRecently) score += 20;

        String activity = screen.activityName.toLowerCase(Locale.ROOT);
        boolean activityHit = false;
        for (String hint : ACTIVITY_HINTS) {
            if (activity.contains(hint)) { score += 25; activityHit = true; break; }
        }
        // v1.6.5：叠加式下载广告的 Activity 往往是 android.app.Dialog / PopupWindow，
        // 不含任何 SDK 命名，一条 hint 都对不上。它本身就是"浮层"结构，给一点分。
        if (!activityHit && OverlayAdEvidence.isOverlayWindow(screen.activityName)) score += 12;

        // v1.6.5：下载诱导文案（下载游戏 / 立即下载 / 点击查看详情 / 上滑）是这类广告
        // 最稳定的文字特征，比"广告"二字常见得多。
        if (OverlayAdEvidence.hasDownloadCta(screen)) score += 15;

        score += mediaBonus(screen, screenArea);

        int listContainers = 0;
        for (NodeModel n : screen.nodes) {
            String cls = n.className.toLowerCase(Locale.ROOT);
            for (String list : LIST_CLASSES) {
                if (cls.endsWith(list)) { listContainers++; break; }
            }
        }
        if (listContainers == 0) score += 10;
        else score -= 25 * Math.min(2, listContainers);

        int labeled = 0;
        for (NodeModel n : screen.nodes) {
            if (!n.visible) continue;
            if (!n.normalizedText().isEmpty() || !n.normalizedDescription().isEmpty()) labeled++;
        }
        if (labeled <= 6) score += 8;
        else if (labeled >= 16) score -= 12;

        if (hasTinyCornerTarget(screen, width, height)) score += 18;

        int shellHits = 0;
        for (NodeModel n : screen.nodes) {
            String value = n.normalizedText() + n.normalizedDescription();
            if (value.isEmpty() || value.length() > 6) continue;
            for (String shell : SHELL_WORDS) {
                if (value.contains(shell)) { shellHits++; break; }
            }
        }
        if (shellHits >= 2) score -= 30;

        return Math.max(0, Math.min(100, score));
    }

    /** 大面积图片 / WebView 是广告落地页最稳定的结构信号。 */
    private static int mediaBonus(ScreenModel screen, long screenArea) {
        int bonus = 0;
        for (NodeModel n : screen.nodes) {
            if (!n.visible || !n.hasBounds() || n.parentIndex < 0) continue;
            String cls = n.className.toLowerCase(Locale.ROOT);
            boolean media = false;
            for (String marker : MEDIA_CLASSES) {
                if (cls.endsWith(marker)) { media = true; break; }
            }
            if (!media) continue;
            long area = (long) (n.right - n.left) * (n.bottom - n.top);
            float ratio = area / (float) screenArea;
            if (ratio >= 0.80f) return 30;
            if (ratio >= 0.45f) bonus = Math.max(bonus, 20);
            // v1.6.5：广告卡片里的视频窗往往只占屏幕 15%~20%（上面标题、下面按钮），
            // 旧阈值 45% 完全够不着。视频控件出现在非视频类 App 的浮层里，本身就罕见。
            if (ratio >= 0.03f && (cls.endsWith("textureview") || cls.endsWith("surfaceview")
                    || cls.endsWith("videoview"))) {
                bonus = Math.max(bonus, 8);
            }
        }
        return bonus;
    }

    /**
     * 角落里那枚"无文字、无描述、很小"的图片控件：广告关闭按钮的典型长相。
     * 有文字的角落按钮（扫一扫、消息）一律不算。
     */
    private static boolean hasTinyCornerTarget(ScreenModel screen, int width, int height) {
        long screenArea = (long) width * height;
        for (NodeModel n : screen.nodes) {
            if (!n.visible || !n.hasBounds() || n.password) continue;
            String cls = n.className.toLowerCase(Locale.ROOT);
            boolean image = cls.endsWith("imageview") || cls.endsWith("imagebutton")
                    || cls.endsWith("framelayout") || cls.endsWith("view");
            if (!image) continue;
            if (!n.normalizedText().isEmpty()) continue;
            String desc = n.normalizedDescription();
            if (!desc.isEmpty() && !looksLikeClose(desc)) continue;
            long area = (long) (n.right - n.left) * (n.bottom - n.top);
            if (area <= 0 || area > screenArea * 0.03f) continue;
            if (inCornerBand(n, width, height)) return true;
        }
        return false;
    }

    private static boolean inCornerBand(NodeModel n, int width, int height) {
        float cx = (n.left + n.right) / 2f, cy = (n.top + n.bottom) / 2f;
        boolean side = cx <= width * 0.20f || cx >= width * 0.80f;
        boolean depth = cy <= height * 0.20f || cy >= height * 0.80f;
        return side && depth;
    }

    private static boolean looksLikeClose(String desc) {
        String value = desc.toLowerCase(Locale.ROOT);
        for (String word : CLOSE_WORDS) if (value.contains(word)) return true;
        return false;
    }
}
