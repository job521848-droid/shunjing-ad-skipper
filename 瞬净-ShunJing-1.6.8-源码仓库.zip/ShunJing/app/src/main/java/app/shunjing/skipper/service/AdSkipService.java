package app.shunjing.skipper.service;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.drawable.Icon;
import android.hardware.HardwareBuffer;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import app.shunjing.skipper.R;
import app.shunjing.skipper.data.DumpStore;
import app.shunjing.skipper.data.Pause;
import app.shunjing.skipper.data.Prefs;
import app.shunjing.skipper.engine.AdDecisionEngine;
import app.shunjing.skipper.engine.AdSuspectDetector;
import app.shunjing.skipper.engine.BoundsNormalizer;
import app.shunjing.skipper.engine.ClickOutcomeGuard;
import app.shunjing.skipper.engine.AdaptiveCloseLocator;
import app.shunjing.skipper.engine.Decision;
import app.shunjing.skipper.engine.DumpAnalyzer;
import app.shunjing.skipper.engine.DynamicSkipDetector;
import app.shunjing.skipper.engine.EngineSettings;
import app.shunjing.skipper.engine.JumpChainGuard;
import app.shunjing.skipper.engine.LearnedClose;
import app.shunjing.skipper.engine.LearningAnalyzer;
import app.shunjing.skipper.engine.LayoutAnchorRule;
import app.shunjing.skipper.engine.NodeModel;
import app.shunjing.skipper.engine.PageDump;
import app.shunjing.skipper.engine.Rule;
import app.shunjing.skipper.engine.ScreenFingerprint;
import app.shunjing.skipper.engine.ScreenModel;
import app.shunjing.skipper.engine.ShakeAdLocator;
import app.shunjing.skipper.engine.ShakePreemptGuard;
import app.shunjing.skipper.engine.StoreJumpGuard;
import app.shunjing.skipper.engine.ShakeJumpGuard;
import app.shunjing.skipper.engine.StructuralAdEvidence;
import app.shunjing.skipper.engine.VisionAttemptLedger;
import app.shunjing.skipper.engine.VisionRecoveryPolicy;
import app.shunjing.skipper.engine.VisionTriggerPolicy;
import app.shunjing.skipper.ui.DumpActivity;
import app.shunjing.skipper.ui.MainActivity;

public final class AdSkipService extends AccessibilityService implements SharedPreferences.OnSharedPreferenceChangeListener {
    private static final int NOTIFICATION_ID = 41;
    /** v1.5.10 换成 LOW 重要度；渠道 id 必须换，否则旧的 MIN 设置不会被改写。 */
    private static final String CHANNEL_ID = "guard_v2";
    private static final String LEGACY_CHANNEL_ID = "guard";
    private static final int MAX_NODES = 700;
    private static final long LAUNCH_WINDOW_MS = 12_000L;
    private static final long SAME_TARGET_COOLDOWN_MS = 1_800L;
    /** v1.4: 叠层弹窗常在上一关刚关掉的瞬间弹出，全局冷却必须足够短。 */
    private static final long MIN_CLICK_GAP_MS = 180L;
    private static final long AUTO_CAPTURE_COOLDOWN_MS = 45_000L;
    /** After a click, re-scan a freshly-appeared dialog ("残忍离开" style) within this window. */
    private static final long FOLLOW_UP_WINDOW_MS = 1_100L;
    private static final long FOLLOW_UP_DELAY_MS = 420L;
    private static final long VERIFY_CLICK_DELAY_MS = 360L;
    private static final long RECOVERY_COOLDOWN_MS = 25_000L;
    /** v1.5.5: 两次窗口状态变化相隔这么久，就当中间离开过（热启动）。 */
    private static final long BACKGROUND_GAP_MS = 6_000L;

    /** v1.5.5: 最近一次窗口状态变化的时刻，用来识别「同包热启动」。 */
    private long lastStateChangeAt = 0L;


    private final Handler handler = new Handler(Looper.getMainLooper());
    private final AdDecisionEngine engine = new AdDecisionEngine();
    private final Map<String, Long> clickHistory = new HashMap<>();
    private final Runnable scanRunnable = () -> {
        scanScheduled = false;
        scanActiveWindow();
    };
    private final Runnable captureNowRunnable = () -> captureWindow(PageDump.SOURCE_MANUAL);
    private final Runnable verifyClickRunnable = this::verifyClickedPage;
    private VisionRecoveryClient visionClient;

    private Prefs prefs;
    private DumpStore dumpStore;
    private List<Rule> rules = new ArrayList<>();
    private List<LayoutAnchorRule> layoutAnchors = new ArrayList<>();
    private EngineSettings engineSettings = EngineSettings.defaults();
    private String currentPackage = "";
    private String currentActivity = "";
    private long launchStartedAt = 0L;
    private long lastClickAt = 0L;
    private boolean previousShakeAd = false;
    private long previousShakeAt = 0L;
    private String previousShakePackage = "";
    /** v1.5.14 抢跳：摇一摇页第一次点空之后，短时间内对同一处再补两下。 */
    private final ShakePreemptGuard shakePreempt = new ShakePreemptGuard();
    private boolean scanning = false;
    private boolean captureNextArmed = false;
    private long lastAutoCaptureAt = 0L;
    private String lastAutoCaptureSignature = "";
    private boolean receiverRegistered = false;
    private long followUpUntil = 0L;
    private String followUpPackage = "";
    private String followUpActivity = "";
    private boolean previousEndCardVisible = false;

    private boolean scanScheduled = false;
    private long scanDueAt = 0L;
    private boolean countdownTracking = false;
    private int countdownChecksLeft = 0;

    private boolean attemptPending = false;
    private int attemptFailureCount = 0;
    private String attemptPackage = "";
    private String attemptActivity = "";
    private String attemptPageFingerprint = "";
    private String attemptTargetKey = "";
    private int attemptLeft, attemptTop, attemptRight, attemptBottom;
    /** 这一次点击是不是云端给的坐标：生效后单独记一条日志，便于回看 AI 到底有没有用。 */
    private boolean attemptVision = false;
    /** 几何推断出来的目标（模板 / 摇一摇 / 叠层 / 云端坐标）：同一点补点没有意义，验证要更快、更直接。 */
    private boolean attemptGeometric = false;
    private boolean cloudInFlight = false;
    private long recoveryToken = 0L;
    private long lastRecoveryAt = 0L;
    private String lastRecoveryFingerprint = "";

    /** Fingerprint of the page at the moment of the last accepted click. */
    private String lastClickFingerprint = "";
    /** v1.5.9: 上一次点击用的是哪条规则、在哪个包/页面 —— 点歪了要把学习记录删掉。 */
    private String lastClickRuleId = "";
    private String lastClickPackage = "";
    private String lastClickActivity = "";
    /** Idle tracking used to decide when a stuck ad page deserves a cloud look. */
    private String idleFingerprint = "";
    private int idleScanCount = 0;
    /** v1.5: 当前页面第一次被看到的时间，用来判断"广告页停留了多久还没被处理"。 */
    private long idleSinceAt = 0L;
    private long lastProactiveVisionAt = 0L;
    private String lastProactiveVisionFingerprint = "";
    /** v1.5: 一次云端请求的起始时刻，用于在日志里给出真实接管耗时。 */
    private long visionStartedAt = 0L;
    /** v1.6: 摇一摇广告一旦跳转，广告页就被覆盖了，只能立刻退回再处理。 */
    private final ShakeJumpGuard shakeGuard = new ShakeJumpGuard();
    /** v1.5.1: 对"几何推断出来的关闭键"点击后开 2.2 秒观察窗，一旦被拽到别的 App 立刻退回。 */
    private final ClickOutcomeGuard clickGuard = new ClickOutcomeGuard();
    /** v1.5.4: 一次误点可能引来一串跳转（deeplink 连发），按整条链退，而不是只退一层。 */
    private final JumpChainGuard jumpChain = new JumpChainGuard();
    private boolean chainHunting = false;
    /** 上过当的页面：点「关闭」反而被拽走，短期内别再点同一处。 */
    private final VisionAttemptLedger jumpTraps = new VisionAttemptLedger();
    /** v1.6: 用户最近一次真实点击的时刻。用户自己在操作时，绝不替他按返回。 */
    private long lastUserClickAt = 0L;
    /** v1.6.3: 最近一次确认「这一页是广告」的时刻，用于判断商店跳转是不是广告带过去的。 */
    private long lastAdContextAt = 0L;
    private boolean storeHunting = false;
    private int storeHops = 0;
    private String storeOrigin = "";
    private String lastToastText = "";
    private long lastToastAt = 0L;
    /**
     * v1.5.5: 云端「这页问过两次了」的记录。旧版是永久 Map，同一张开屏广告第二次出现时
     * 就被永久拉黑 —— 表现就是「放后台再点开，广告又来了，它却不动了」。
     */
    private final VisionAttemptLedger visionLedger = new VisionAttemptLedger();

    /**
     * v1.5.8: 心跳。
     *
     * <p>荣耀 / 华为这类系统会悄悄停掉第三方无障碍服务，而系统设置里依旧显示"已开启"，
     * 首页也就一直显示"守护运行中"，用户完全无从判断。服务每 30 秒写一个时间戳，
     * 首页读这个时间戳，才能区分"真在跑"和"只是看起来在跑"。
     */
    private static final long BEAT_INTERVAL_MS = 30_000L;

    // ---------------------------------------------------------------- 学习模式 (v1.5.9)
    /** 学习期间多久采一帧，用来判断广告是不是已经关掉了。 */
    private static final long LEARN_SAMPLE_GAP_MS = 400L;
    /** 相似度低于这个值就算「页面明显变了」，广告大概率已经关掉。 */
    private static final double LEARN_CHANGED_THRESHOLD = 0.72d;
    /** 太早判断会把「刚打开还在渲染」当成关闭完成，至少等这么久。 */
    private static final long LEARN_MIN_DURATION_MS = 1_500L;
    /** 一直没动作就自动退出，别让服务永远停在"不点任何东西"的状态。 */
    private static final long LEARN_TIMEOUT_MS = 180_000L;

    private List<LearnedClose> learnedCloses = new ArrayList<>();
    private boolean learning = false;
    private long learnStartedAt = 0L;
    private String learnPackage = "";
    private String learnActivity = "";
    private List<NodeModel> learnBefore = null;
    private List<NodeModel> learnLatest = null;
    private long lastLearnSampleAt = 0L;
    /**
     * 学习期间保留的一段画面历史。只记首帧的话，用户先看到的是主页（广告还没弹出来），
     * 关掉广告又回到主页，前后一模一样 —— 就成了"页面没有变化"。真正的关闭动作是
     * 历史里的某一次跳变，结束时从后往前找就行。
     */
    private final List<LearningAnalyzer.Frame> learnFrames = new ArrayList<>();
    private long lastLearnScrollAt = 0L;
    private static final int LEARN_FRAME_LIMIT = 14;
    private final List<NodeModel> learnClicks = new ArrayList<>();
    private boolean learnFinishScheduled = false;
    private static final long BEAT_EVENT_GAP_MS = 15_000L;
    private long lastBeatAt = 0L;
    private final Runnable beatRunnable = new Runnable() {
        @Override public void run() {
            writeBeat();
            handler.postDelayed(this, BEAT_INTERVAL_MS);
        }
    };

    private void writeBeat() {
        if (prefs == null) return;
        long now = System.currentTimeMillis();
        if (now - lastBeatAt < 1_000L) return;
        lastBeatAt = now;
        prefs.beat(now);
    }

    /** 有事件经过说明服务确实在收消息，用事件刷新比定时器更可信。 */
    private void beatOnEvent() {
        if (System.currentTimeMillis() - lastBeatAt < BEAT_EVENT_GAP_MS) return;
        writeBeat();
    }

    private final BroadcastReceiver captureReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null) return;
            if (CaptureIntents.ACTION_LEARN.equals(intent.getAction())) {
                String mode = intent.getStringExtra(CaptureIntents.EXTRA_LEARN);
                if (CaptureIntents.LEARN_START.equals(mode)) {
                    startLearning("通知栏");
                } else {
                    finishLearning("手动结束");
                }
                return;
            }
            if (CaptureIntents.ACTION_PAUSE.equals(intent.getAction())) {
                applyPause(intent.getIntExtra(CaptureIntents.EXTRA_PAUSE_MINUTES, 0));
                return;
            }
            if (!CaptureIntents.ACTION_CAPTURE.equals(intent.getAction())) return;
            String mode = intent.getStringExtra(CaptureIntents.EXTRA_MODE);
            if (CaptureIntents.MODE_NEXT.equals(mode)) {
                captureNextArmed = true;
                notifyUser("已就绪：切回广告页面即自动抓取");
            } else {
                handler.removeCallbacks(captureNowRunnable);
                handler.postDelayed(captureNowRunnable, 700L);
            }
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        prefs = new Prefs(this);
        dumpStore = new DumpStore(this);
        dumpStore.setKeepLimit(prefs.dumpKeepLimit());
        reloadSettings();
        prefs.preferences().registerOnSharedPreferenceChangeListener(this);
        registerCaptureReceiver();
        live = new java.lang.ref.WeakReference<>(this);
        showStatusNotification();
        schedulePauseTick();
        writeBeat();
        handler.removeCallbacks(beatRunnable);
        handler.postDelayed(beatRunnable, BEAT_INTERVAL_MS);
    }

    // The 3-arg registerReceiver overload only exists on API 33+; the legacy branch below is
    // intentionally limited to this app's own explicit broadcasts (setPackage + NOT_EXPORTED above).
    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    private void registerCaptureReceiver() {
        if (receiverRegistered) return;
        IntentFilter filter = new IntentFilter(CaptureIntents.ACTION_CAPTURE);
        // v1.5.10: 通知栏「学习」按钮当年就是漏了这一行，广播发出去没人收，
        // 用户点了完全没反应。抓取和学习走同一个接收器，动作必须都注册。
        filter.addAction(CaptureIntents.ACTION_LEARN);
        filter.addAction(CaptureIntents.ACTION_PAUSE);
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(captureReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(captureReceiver, filter);
            }
            receiverRegistered = true;
        } catch (RuntimeException ignored) { }
    }

    /**
     * 当前活着的服务实例。通知栏的学习按钮直接调这里，不必赌广播能不能送到 ——
     * 广播只是兜底路径，真正可靠的是同进程直呼。
     */
    private static java.lang.ref.WeakReference<AdSkipService> live = new java.lang.ref.WeakReference<AdSkipService>(null);

    static AdSkipService peek() {
        return live.get();
    }

    /** 从通知栏按钮进来的入口，切回主线程再改状态。 */
    void requestLearn(String mode) {
        final String value = mode == null ? CaptureIntents.LEARN_START : mode;
        handler.post(new Runnable() {
            @Override public void run() {
                if (CaptureIntents.LEARN_START.equals(value)) startLearning("通知栏");
                else finishLearning("手动结束");
            }
        });
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        beatOnEvent();
        if (event == null || prefs == null) return;
        String eventPackage = event.getPackageName() == null ? "" : event.getPackageName().toString();
        if (eventPackage.isEmpty()) return;
        // v1.5.9: 下拉通知栏会让前台包变成系统界面。以前这种情况会被"跨包 = 广告跳转"
        // 的守卫当成误跳转，直接按返回把通知栏收起来 —— 现在统一无视系统界面。
        if (isSystemUi(eventPackage)) return;
        if (learning) {
            if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                if (event.getClassName() != null) currentActivity = event.getClassName().toString();
                currentPackage = eventPackage;
            }
            handleLearningEvent(event, eventPackage, SystemClock.elapsedRealtime());
            return;
        }
        if (prefs.paused()) {
            // 暂停期间不做任何判定，但前台包还是要记：否则恢复后的第一个事件
            // 会拿暂停前的包名去比，把一次正常切 App 当成"跨包误跳转"。
            if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                currentPackage = eventPackage;
                if (event.getClassName() != null) currentActivity = event.getClassName().toString();
            }
            return;
        }
        if (!prefs.masterEnabled()) return;
        long now = SystemClock.elapsedRealtime();
        int type = event.getEventType();

        // v1.6: 用户点了屏幕，说明是他在主动操作（摇一摇广告也确实会"被点"），
        // 这种时候任何自动返回都是在跟用户抢屏幕，直接记下来当豁免依据。
        if (type == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            lastUserClickAt = now;
        }

        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            // v1.5.5: 有些 ROM 在"放后台再点回来"时不报包切换（包名一直是它自己），
            // 只补一个窗口状态事件。用两次状态变化的间隔判断是不是真的离开过。
            boolean resumedFromBackground = now - lastStateChangeAt > BACKGROUND_GAP_MS;
            if (!eventPackage.equals(currentPackage)) {
                if (handleCrossAppJump(eventPackage, now)) return;
                currentPackage = eventPackage;
                launchStartedAt = now;
                previousShakeAd = false;
                // A follow-up evidence window must never leak into a different app.
                followUpUntil = 0L;
                followUpPackage = "";
                followUpActivity = "";
                previousEndCardVisible = false;
                countdownTracking = false;
                countdownChecksLeft = 0;
                beginNewSession(eventPackage, now);
                clearClickAttempt();
            } else if (resumedFromBackground) {
                // 同包热启动：广告会重新加载，上一轮的失败记录必须作废。
                launchStartedAt = now;
                previousShakeAd = false;
                followUpUntil = 0L;
                followUpPackage = "";
                followUpActivity = "";
                previousEndCardVisible = false;
                countdownTracking = false;
                countdownChecksLeft = 0;
                beginNewSession(eventPackage, now);
                clearClickAttempt();
            }
            lastStateChangeAt = now;
            if (event.getClassName() != null) currentActivity = event.getClassName().toString();
            scheduleScan(0L);
            scheduleLaunchProbes();
            if (captureNextArmed && isCapturablePackage(eventPackage)) {
                captureNextArmed = false;
                handler.postDelayed(() -> captureWindow(PageDump.SOURCE_NEXT), 420L);
            }
        } else if (type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                || type == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            // Inside the follow-up window a freshly appeared confirmation dialog gets priority.
            long delay = now < followUpUntil
                    ? Math.min(FOLLOW_UP_DELAY_MS, prefs.scanIntervalMs())
                    : prefs.scanIntervalMs();
            scheduleScan(delay);
        }
    }

    private boolean isCapturablePackage(String packageName) {
        return packageName != null && !packageName.isEmpty()
                && !packageName.equals(getPackageName())
                && !AdDecisionEngine.isProtectedPackage(packageName);
    }

    /**
     * v1.5.4: 前台换包时的统一出口 —— 先看有没有在跑的跳转链，再看是不是新的一次误跳。
     *
     * <p>顺序很重要：链在前。因为一条链上的第二、三层，{@link ClickOutcomeGuard} 早就
     * 用完了自己那一次配额，只有链还在数层数。
     */
    private boolean handleCrossAppJump(String newPackage, long now) {
        if (prefs == null || newPackage == null || newPackage.isEmpty()) return false;
        // 按了 Home 键也会切到桌面，那不是广告跳转，别把用户从桌面拽回去。
        if (AdDecisionEngine.isLauncherPackage(newPackage)) {
            jumpChain.disarm();
            return false;
        }

        if (jumpChain.active(now)) {
            JumpChainGuard.Result result = jumpChain.observe(newPackage, now, lastUserClickAt);
            if (result == JumpChainGuard.Result.GIVE_UP) {
                showToast("连环跳转退不动了，已停手");
                prefs.addLog(newPackage, "已放弃", "连环跳转超过可退回层数，停止自动返回");
                return false;
            }
            if (result != JumpChainGuard.Result.REVERT) return false;
            return revertOneMoreLayer(newPackage, now, "连环跳转第 " + jumpChain.hops() + " 层");
        }

        // 摇一摇广告把用户甩到别的 App：广告页已被覆盖，只能退。
        if (prefs.shakeBackEnabled()
                && shakeGuard.checkCrossApp(newPackage, now, lastUserClickAt)
                == ShakeJumpGuard.Result.CROSS_APP) {
            String origin = shakeGuard.armedPackage();
            jumpChain.arm(origin.isEmpty() ? currentPackage : origin, now);
            return revertOneMoreLayer(newPackage, now, "摇一摇广告误跳转");
        }

        // 几何推断的关闭键点歪了：先退这一层，再把后续连跳交给链。
        if (clickGuard.armed() && clickGuard.shouldRevert(newPackage, now, lastUserClickAt)) {
            String origin = clickGuard.armedPackage();
            jumpChain.arm(origin.isEmpty() ? currentPackage : origin, now);
            return revertOneMoreLayer(newPackage, now, "关闭键位置不准");
        }

        // v1.6.3: 广告落地页本身就是应用商店。放最后 —— 自己点歪的那次仍由上面的
        // clickGuard 处理（它还要记住这个位置别再点），这里只接"人点广告进商店"。
        if (prefs.storeBackEnabled()
                && StoreJumpGuard.shouldRevert(currentPackage, newPackage, now, lastAdContextAt)) {
            return revertStoreJump(newPackage);
        }
        return false;
    }

    /**
     * v1.6.3: 广告把用户送进了应用商店 —— 按返回回到刚才那一页。
     *
     * <p>不走 {@link #revertOneMoreLayer}：那条路径会记「这个位置是陷阱」并删学习记录，
     * 而这里并没有发生误点，只是广告的落地页恰好是商店。乱记会把本来正确的规则删掉。
     */
    private boolean revertStoreJump(String storePackage) {
        String origin = currentPackage;
        if (!performGlobalAction(GLOBAL_ACTION_BACK)) return false;
        haltScanning();
        storeOrigin = origin == null ? "" : origin;
        storeHops = 1;
        prefs.addLog(origin == null || origin.isEmpty() ? storePackage : origin,
                "已返回", "广告跳进了应用商店，已退回原页面");
        showToast("已从应用商店退回");
        scheduleStoreHunt(620L);
        scheduleScan(200L);
        return true;
    }

    private void scheduleStoreHunt(long delay) {
        if (storeHunting) return;
        storeHunting = true;
        handler.postDelayed(storeHunt, delay);
    }

    /** 商店把「主页 → 商品详情」两层压进栈时，一次返回不够，最多再补一次。 */
    private final Runnable storeHunt = new Runnable() {
        @Override public void run() {
            storeHunting = false;
            if (storeOrigin == null || storeOrigin.isEmpty()) return;
            String pkg = currentPackage;
            if (pkg == null || pkg.isEmpty()) return;
            if (pkg.equals(storeOrigin) || AdDecisionEngine.isLauncherPackage(pkg)) {
                storeOrigin = "";
                storeHops = 0;
                return;
            }
            if (StoreJumpGuard.isStore(pkg) && storeHops < 2
                    && performGlobalAction(GLOBAL_ACTION_BACK)) {
                storeHops++;
                prefs.addLog(storeOrigin, "已返回", "商店里还压着一层详情页，再退一次");
                scheduleStoreHunt(620L);
                return;
            }
            storeOrigin = "";
            storeHops = 0;
        }
    };

    /**
     * v1.5.9: 学到的位置把人拽走了 —— 这条记录是错的，立刻删掉。
     *
     * <p>学习本身靠的是"用户点了这里，广告就没了"的推断，偶尔会被"点这里跳落地页"
     * 的诱导热区骗到。不删的话每次遇到这个页面都会再跳一次，比不学还糟。
     */
    private void forgetLearnedCloseIfGuilty() {
        if (prefs == null || !"learned_close".equals(lastClickRuleId)) return;
        if (lastClickPackage == null || lastClickPackage.isEmpty()) return;
        prefs.deleteLearnedClose(lastClickPackage, lastClickActivity);
        learnedCloses = prefs.learnedCloses();
        prefs.addLog(lastClickPackage, "已删除", "刚学会的关闭位置会导致跳转，已丢弃");
        showToast("刚学的那个位置不对，已删掉");
        lastClickRuleId = "";
    }

    /** 按一次返回、记日志、再排一次复查（防止那一层压在栈里没退干净）。 */
    private boolean revertOneMoreLayer(String newPackage, long now, String reason) {
        String origin = jumpChain.origin();
        // 只记第一层：那一页的那个位置把我们送出去了，30 秒内不再用几何方式点同一处。
        if (jumpChain.hops() <= 1) {
            rememberJumpTrap(now);
            forgetLearnedCloseIfGuilty();
        }
        if (!performGlobalAction(GLOBAL_ACTION_BACK)) return false;
        haltScanning();
        prefs.addLog(origin.isEmpty() ? newPackage : origin, "已返回", reason + "，已退回广告页");
        showToast("已拦截一次广告跳转");
        scheduleChainHunt(560L);
        // v1.5.14: 180ms 而不是 280ms —— 返回键按下后广告页通常已经重新可见，
        // 早 100ms 看一眼，就多一点在用户手再抖一次之前把广告关掉的机会。
        scheduleScan(180L);
        return true;
    }

    /**
     * 退了一层之后，前台如果还停在外部应用，说明广告把好几层 Activity 压在一起了。
     * 每 560ms 复查一次，直到回到原页面、回桌面，或退到上限。
     */
    private final Runnable chainHunt = new Runnable() {
        @Override
        public void run() {
            chainHunting = false;
            long now = SystemClock.elapsedRealtime();
            if (prefs == null || !jumpChain.active(now)) {
                jumpChain.disarm();
                return;
            }
            String origin = jumpChain.origin();
            if (currentPackage == null || currentPackage.isEmpty()) return;
            if (currentPackage.equals(origin) || AdDecisionEngine.isLauncherPackage(currentPackage)) {
                jumpChain.disarm();
                return;
            }
            if (jumpChain.coolingDown(now)) {
                scheduleChainHunt(320L);
                return;
            }
            if (!jumpChain.noteExtraHop(now)) {
                showToast("连环跳转退不动了，已停手");
                prefs.addLog(origin.isEmpty() ? currentPackage : origin, "已放弃",
                        "退到第 " + jumpChain.hops() + " 层仍未回到原页面");
                jumpChain.disarm();
                return;
            }
            if (!performGlobalAction(GLOBAL_ACTION_BACK)) {
                jumpChain.disarm();
                return;
            }
            prefs.addLog(origin.isEmpty() ? currentPackage : origin, "已返回",
                    "仍有广告页压在栈里，继续退回（第 " + jumpChain.hops() + " 层）");
            scheduleChainHunt(560L);
        }
    };

    private void scheduleChainHunt(long delay) {
        if (chainHunting) return;
        chainHunting = true;
        handler.postDelayed(chainHunt, delay);
    }

    /**
     * v1.5.5: 进入一个应用（含「放后台再点回来」）就是一次新会话。
     * 上一轮在这里问过云端、失败过、被拽走过的记录，都不该拦住这一轮重新加载的开屏广告。
     */
    private void beginNewSession(String pkg, long now) {
        if (pkg == null || pkg.isEmpty()) return;
        visionLedger.clearPackage(pkg);
        jumpTraps.clearPackage(pkg);
        idleFingerprint = "";
        idleScanCount = 0;
        idleSinceAt = now;
        lastProactiveVisionFingerprint = "";
        lastProactiveVisionAt = 0L;
        // 上一轮在同一页的"恢复冷却"也不该延续到新一轮开屏。
        lastRecoveryAt = 0L;
        lastRecoveryFingerprint = "";
        lastClickAt = 0L;
        lastClickFingerprint = "";
        // 换应用 / 热启动后，上一页的"补点额度"不能带过来。
        clearPreempt();
    }

    private void haltScanning() {
        handler.removeCallbacks(scanRunnable);
        scanScheduled = false;
        scanDueAt = 0L;
    }

    /** 记下「这一页点关闭会被拽走」，短期内不再对它做几何点击。 */
    private void rememberJumpTrap(long now) {
        if (lastClickFingerprint == null || lastClickFingerprint.isEmpty()) return;
        jumpTraps.miss(VisionAttemptLedger.key(currentPackage, lastClickFingerprint), now);
    }

    private boolean isJumpTrap(String pkg, String fingerprint, long now) {
        return jumpTraps.count(VisionAttemptLedger.key(pkg, fingerprint), now) > 0;
    }

    /** 同包内的 H5 落地页跳转（包名不变，Activity 换成 web / h5 / landing 之类）。 */
    private boolean handleSamePageJump(String pkg, String fingerprint, long now) {
        ShakeJumpGuard.Result result = shakeGuard.checkSamePageChange(pkg, currentActivity,
                fingerprint, now, lastUserClickAt);
        if (result == ShakeJumpGuard.Result.NONE) return false;
        if (!performGlobalAction(GLOBAL_ACTION_BACK)) return false;
        String origin = shakeGuard.armedPackage();
        // v1.5.4: 同包 H5 落地页往往是连跳的第一跳，退完同样要盯着后面几层。
        jumpChain.arm(origin.isEmpty() ? pkg : origin, now);
        scheduleChainHunt(560L);
        prefs.addLog(origin.isEmpty() ? pkg : origin, "已返回",
                result == ShakeJumpGuard.Result.CROSS_APP
                        ? "摇一摇跳到其他应用，已退回" : "摇一摇跳到 H5 落地页，已退回");
        showToast("已拦截一次广告误跳转");
        scheduleScan(180L);
        return true;
    }

    /**
     * v1.5.5: 热启动（放后台再点开）的开屏广告常常在窗口切换后 0.4~2.5 秒才渲染完成，
     * 而部分 ROM 此时不再补发内容变化事件，只靠事件驱动就会整轮漏掉。
     * 三个轻量探针只做"到点扫一次"，不改变任何判定逻辑。
     */
    private void scheduleLaunchProbes() {
        handler.postDelayed(launchProbe, 420L);
        handler.postDelayed(launchProbe, 1_150L);
        handler.postDelayed(launchProbe, 2_400L);
    }

    private final Runnable launchProbe = new Runnable() {
        @Override
        public void run() {
            scheduleScan(0L);
        }
    };

    private void scheduleScan(long delay) {
        long due = SystemClock.elapsedRealtime() + Math.max(0L, delay);
        // Do not endlessly postpone a scan when countdown text emits an event every few ms.
        // Keep the earliest scheduled run instead of remove-and-repost on every event.
        if (scanScheduled && scanDueAt <= due) return;
        handler.removeCallbacks(scanRunnable);
        scanScheduled = true;
        scanDueAt = due;
        handler.postDelayed(scanRunnable, Math.max(0L, delay));
    }

    private void scanActiveWindow() {
        if (scanning || !guarding()) return;
        // 学习期间必须让出屏幕：用户正在手动点关闭键，抢着点只会点乱。
        if (learning) return;
        // v1.5.4: 正在往回收拾连环跳转时，任何自动点击都会在新应用里再点出一条新链。
        // 这段时间只按返回，不点任何东西。
        if (jumpChain.paused(SystemClock.elapsedRealtime())) return;
        if (currentPackage.isEmpty() || !prefs.isAppEnabled(currentPackage)
                || AdDecisionEngine.isProtectedPackage(currentPackage)) return;
        Snapshot snapshot = null;
        try {
            snapshot = captureSnapshot(true);
            if (snapshot == null) return;
            scanning = true;
            String pkg = snapshot.packageName;
            if (!pkg.equals(currentPackage) || !prefs.isAppEnabled(pkg)
                    || AdDecisionEngine.isProtectedPackage(pkg)) return;
            long now = SystemClock.elapsedRealtime();
            ScreenModel screen = new ScreenModel(pkg, currentActivity,
                    now - launchStartedAt <= LAUNCH_WINDOW_MS, snapshot.models);
            boolean shakeAd = AdDecisionEngine.hasShakeAd(screen);
            previousShakeAd = shakeAd;
            previousShakeAt = now;
            previousShakePackage = pkg;
            String pageFingerprint = ScreenFingerprint.of(screen);
            // 摇一摇页面在场 = 随时可能跳转，进入 8 秒待命；页面已经变了 = 跳转发生了，先退回去。
            if (shakeAd) {
                shakeGuard.arm(screen, pageFingerprint, now);
                // 抢跳：上一次点的是这一页的角落图标，但画面没变 —— 说明点空了。
                // 常规路径要等 1.8 秒的同目标冷却，摇一摇根本等不了那么久，这里补点。
                if (prefs.shakePreemptEnabled() && shakePreempt.armed()) {
                    long wait = shakePreempt.dueIn(pkg, currentActivity, true, now);
                    if (wait == 0L && preemptStrike(snapshot, screen, pkg, now)) return;
                    if (wait > 0L) schedulePreempt(wait + 30L);
                }
            } else if (prefs.shakeBackEnabled() && handleSamePageJump(pkg, pageFingerprint, now)) {
                return;
            }

            // Rewarded-video end card turning visible is a reliable "video finished, reward
            // granted" moment — immediately re-evaluate so END_CARD_ONLY can close it.
            boolean endCardVisible = StructuralAdEvidence.hasVisibleEndCard(screen);
            if (endCardVisible && !previousEndCardVisible) scheduleScan(0L);
            previousEndCardVisible = endCardVisible;

            // Short-lived, causality-based ad evidence for a second confirmation dialog that
            // appears right after a successful ad click. Bounded by time, same package and
            // the same (ad-SDK) Activity. The hard lock is still evaluated first in the engine.
            boolean inheritedAdContext = prefs != null && prefs.confirmationFollowUpEnabled()
                    && now < followUpUntil
                    && pkg.equals(followUpPackage)
                    && currentActivity.equals(followUpActivity);

            DisplayMetrics metrics = getResources().getDisplayMetrics();
            Decision decision = engine.evaluate(screen, rules, settingsFor(pkg), layoutAnchors,
                    metrics.widthPixels, metrics.heightPixels, inheritedAdContext);
            if (decision.type != Decision.Type.CLICK) {
                // 用户亲手教过的位置排在内置规则之后、几何推断之前：
                // 它比模板猜测准，但仍要求广告上下文成立，不是免证据通道。
                Decision learned = learnedDecision(screen, metrics.widthPixels, metrics.heightPixels,
                        adContextFor(screen, inheritedAdContext));
                if (learned.type == Decision.Type.CLICK) decision = learned;
            }
            if (decision.type != Decision.Type.CLICK) {
                trackIdlePage(screen, now, adContextFor(screen, inheritedAdContext), pageFingerprint);
                maybeAutoCapture(screen, pkg, now);
                scheduleCountdownRecheck(screen, adContextFor(screen, inheritedAdContext));
                return;
            }
            idleScanCount = 0;
            idleFingerprint = pageFingerprint;
            countdownTracking = false;
            countdownChecksLeft = 0;
            // v1.5.4: 这一页上次几何点击把用户拽走了 —— 30 秒内不再点同一处。
            // 否则就是"退回来又点、点了又跳"，整屏都在来回弹。
            if ((isGeometricTarget(decision.ruleId) || "learned_close".equals(decision.ruleId))
                    && isJumpTrap(pkg, pageFingerprint, now)) {
                prefs.addLog(pkg, "已跳过", "这一处上次把你拽走了，30 秒内不再点同一位置");
                return;
            }
            if (decision.nodeIndex < 0 || decision.nodeIndex >= snapshot.models.size()) return;
            NodeModel targetModel = snapshot.models.get(decision.nodeIndex);
            String signature = pkg + "|" + currentActivity + "|" + decision.ruleId + "|"
                    + targetModel.left + "," + targetModel.top;
            if (now - lastClickAt < MIN_CLICK_GAP_MS) return;
            Long last = clickHistory.get(signature);
            // A brand-new page (previous ad closed, next popup already up) is NOT the same
            // target: the cooldown must not swallow the follow-up click.
            if (last != null && now - last < SAME_TARGET_COOLDOWN_MS
                    && pageFingerprint.equals(lastClickFingerprint)) return;
            if (executeClick(snapshot, targetModel, false)) {
                lastClickAt = now;
                lastClickFingerprint = pageFingerprint;
                lastClickRuleId = decision.ruleId;
                lastClickPackage = pkg;
                lastClickActivity = currentActivity;
                clickHistory.put(signature, now);
                if (clickHistory.size() > 80) clickHistory.clear();
                if (prefs.feedbackSkipEnabled()) {
                    app.shunjing.skipper.ui.Feedback.skip(this, prefs);
                }
                prefs.addLog(pkg, "已触发", decision.reason);
                showToast("已点击广告关闭控件");
                beginClickAttempt(screen, targetModel, decision.ruleId);
                if (isGeometricTarget(decision.ruleId)) clickGuard.arm(pkg, now);
                // 摇一摇页：记下刚点的这一处。280ms 后画面还没变，就说明点空了，补第二下。
                if (shakeAd && prefs.shakePreemptEnabled() && !shakePreempt.armed()) {
                    shakePreempt.arm(pkg, currentActivity,
                            (targetModel.left + targetModel.right) / 2f,
                            (targetModel.top + targetModel.bottom) / 2f, now);
                    schedulePreempt(ShakePreemptGuard.RETRY_DELAY_MS + 30L);
                }
                // Expect a possible "残忍离开 / 放弃奖励" confirmation dialog.
                if (prefs.confirmationFollowUpEnabled()) {
                    followUpUntil = now + FOLLOW_UP_WINDOW_MS;
                    followUpPackage = pkg;
                    followUpActivity = currentActivity;
                    scheduleScan(FOLLOW_UP_DELAY_MS);
                }
            } else {
                // A matching rule fired but the OS refused the click — keep the evidence.
                maybeAutoCapture(screen, pkg, now, true);
            }
        } catch (RuntimeException ignored) {
            // A window can mutate while it is being traversed; the next event will retry safely.
        } finally {
            scanning = false;
            if (snapshot != null) snapshot.recycle();
        }
    }

    // ---------------------------------------------------------------- 抢跳 (v1.5.14)

    /**
     * 抢跳复击：摇一摇页第一次点空之后，对同一处再补一下。
     *
     * <p>为什么单开一条路而不是放宽去重：服务层"同页同目标 1.8 秒"的冷却，是为了防止
     * 「退回来又点、点了又跳」的来回弹，那条不能动；但摇一摇的跳转发生在 1~3 秒内，
     * 等冷却走完广告早就把用户送走了。这里只给「同一处、隔 280ms、最多两次」的例外。
     *
     * <p>安全边界：目标必须由 {@link ShakeAdLocator} 重新定位（角落、小尺寸、无文字、
     * 唯一候选），且落点与上次相差不超过 6% 屏 —— 页面重排过就放弃，不追着新位置点。
     */
    private boolean preemptStrike(Snapshot snapshot, ScreenModel screen, String pkg, long now) {
        if (now - lastClickAt < MIN_CLICK_GAP_MS) {
            schedulePreempt(MIN_CLICK_GAP_MS);
            return false;
        }
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        int width = metrics.widthPixels, height = metrics.heightPixels;
        ShakeAdLocator.Hit hit = ShakeAdLocator.find(screen, width, height);
        if (hit == null || hit.nodeIndex < 0 || hit.nodeIndex >= snapshot.models.size()) {
            shakePreempt.disarm();
            return false;
        }
        NodeModel target = snapshot.models.get(hit.nodeIndex);
        float cx = (target.left + target.right) / 2f, cy = (target.top + target.bottom) / 2f;
        if (!shakePreempt.sameSpot(cx, cy, width, height)) {
            shakePreempt.disarm();
            return false;
        }
        if (!executeClick(snapshot, target, false)) return false;
        lastClickAt = now;
        shakePreempt.noteStrike(now);
        prefs.addLog(pkg, "抢跳", "第一次没点中，第 " + shakePreempt.attempts() + " 次补点");
        schedulePreempt(ShakePreemptGuard.RETRY_DELAY_MS + 30L);
        return true;
    }

    /**
     * 摇一摇页往往点完就静止、不再产生任何事件，所以复击只能靠定时器叫醒，
     * 不能指望下一帧自己送上门。
     */
    private final Runnable preemptTick = new Runnable() {
        @Override public void run() {
            if (!guarding()) return;
            if (!prefs.shakePreemptEnabled() || !shakePreempt.armed()) return;
            scheduleScan(0L);
        }
    };

    private void schedulePreempt(long delay) {
        handler.removeCallbacks(preemptTick);
        handler.postDelayed(preemptTick, Math.max(60L, delay));
    }

    private void clearPreempt() {
        shakePreempt.disarm();
        handler.removeCallbacks(preemptTick);
    }

    /** 这三个 id 命中都来自几何推断，而不是可读文字，点错了需要兜底。 */
    // ---------------------------------------------------------------- 学习模式 (v1.5.9)

    /** 系统界面（通知栏、音量条、电源菜单）永远不是广告页，也不该算作"跳到了别的应用"。 */
    private static final String[] SYSTEM_UI_PACKAGES = {
            "com.android.systemui", "com.oplus.systemui", "com.miui.systemui"
    };

    private static boolean isSystemUi(String pkg) {
        if (pkg == null || pkg.isEmpty()) return false;
        for (String item : SYSTEM_UI_PACKAGES) if (item.equals(pkg)) return true;
        return false;
    }

    /** 当前桌面包名。学习时如果停在桌面上，不能把桌面当广告页锁定。 */
    private boolean isHomePackage(String pkg) {
        if (pkg == null || pkg.isEmpty()) return false;
        try {
            Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            android.content.pm.ResolveInfo info = getPackageManager()
                    .resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY);
            return info != null && info.activityInfo != null && pkg.equals(info.activityInfo.packageName);
        } catch (RuntimeException e) {
            return false;
        }
    }

    private final Runnable learnProbe = new Runnable() {
        @Override public void run() {
            if (!learning) return;
            sampleLearning(true);
            if (!learning) return;
            // 用户可能点了按钮后还要找一会儿才切到目标 App，这一轮没锁到页面就继续等，
            // 别只试一次然后一直靠事件推送 —— 有的广告页压根不产生事件。
            // 锁定之后也保留低频采样：倒计时自动结束的广告没有点击事件，只能靠看帧。
            if (learning
                    && SystemClock.elapsedRealtime() - learnStartedAt < LEARN_TIMEOUT_MS) {
                handler.postDelayed(this, learnPackage.isEmpty() ? 1_200L : 2_000L);
            }
        }
    };

    private final Runnable learnTimeout = new Runnable() {
        @Override public void run() {
            if (!learning) return;
            showToast("学习超时，已取消");
            learning = false;
            resetLearning();
            handler.removeCallbacks(closeShade);
            showStatusNotification();
            scheduleScan(0L);
        }
    };

    private final Runnable learnFinishRunnable = new Runnable() {
        @Override public void run() {
            finishLearning("检测到广告已关闭");
        }
    };

    /**
     * 开始学习。用户此刻通常还在通知栏里，所以不立刻抓图 —— 等下一个非系统界面的窗口事件，
     * 那才是真正的广告页。
     */
    private void startLearning(String from) {
        if (prefs == null) return;
        if (learning) {
            showToast("学习已经在进行，把广告关掉就会自动结束");
            return;
        }
        if (prefs.paused()) {
            notifyUser("守护处于暂停中，先恢复再学习");
            return;
        }
        learning = true;
        // 学习期间必须让出屏幕：补点会跟用户手动关广告抢同一处。
        clearPreempt();
        learnStartedAt = SystemClock.elapsedRealtime();
        learnPackage = "";
        learnActivity = "";
        learnBefore = null;
        learnLatest = null;
        lastLearnSampleAt = 0L;
        learnFinishScheduled = false;
        learnClicks.clear();
        learnFrames.clear();
        lastLearnScrollAt = 0L;

        showStatusNotification();
        showToast("学习已开始：切回广告页，手动把广告关掉");
        prefs.addLog(currentPackage, "学习", "开始记录关闭位置");
        handler.removeCallbacks(learnTimeout);
        handler.postDelayed(learnTimeout, LEARN_TIMEOUT_MS);
        handler.removeCallbacks(learnProbe);
        handler.postDelayed(learnProbe, 700L);
        // 用户是在通知栏里点的这个按钮，通知栏不会自己收起来。
        // 不收起来他就看不到广告页，会以为"点了没反应"。
        if (isShadeOpen()) handler.postDelayed(closeShade, 320L);
    }

    private final Runnable closeShade = new Runnable() {
        @Override public void run() {
            // 再确认一次：用户可能已经自己收起了通知栏，这时按返回会直接把广告页退掉。
            if (learning && isShadeOpen()) performGlobalAction(GLOBAL_ACTION_BACK);
        }
    };

    /** 通知栏 / 电源菜单这类系统窗口在场时，才敢按一次返回把面板收起来。 */
    private boolean isShadeOpen() {
        try {
            List<AccessibilityWindowInfo> windows = getWindows();
            if (windows != null) {
                for (AccessibilityWindowInfo window : windows) {
                    if (window != null && window.getType() == AccessibilityWindowInfo.TYPE_SYSTEM) return true;
                }
            }
        } catch (RuntimeException ignored) { }
        // 少数 ROM 的遮罩不算 TYPE_SYSTEM，但根节点包名仍是 systemui。
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null && root.getPackageName() != null) {
                return isSystemUi(root.getPackageName().toString());
            }
        } catch (RuntimeException ignored) { }
        return false;
    }

    private void handleLearningEvent(AccessibilityEvent event, String pkg, long now) {
        if (isSystemUi(pkg)) return;
        if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            // 滑动会让整页节点全变，跟"关掉广告"在数据上很像。先记下来，
            // 紧跟在滑动后面的那一帧不参与"是不是关闭了"的判断。
            lastLearnScrollAt = now;
        }
        if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_CLICKED
                && learnClicks.size() < 8) {
            AccessibilityNodeInfo source = null;
            try {
                source = event.getSource();
            } catch (RuntimeException ignored) { }
            if (source != null) {
                Rect bounds = new Rect();
                source.getBoundsInScreen(bounds);
                if (!bounds.isEmpty()) {
                    learnClicks.add(new NodeModel(0, -1, text(source.getText()),
                            text(source.getContentDescription()), text(source.getViewIdResourceName()),
                            text(source.getClassName()), source.isClickable(), true, false,
                            bounds.left, bounds.top, bounds.right, bounds.bottom));
                }
            }
        }
        sampleLearning(false);
    }

    /** 采一帧。400ms 节流，避免学习期间把主线程拖住。 */
    private void sampleLearning(boolean force) {
        if (!learning) return;
        long now = SystemClock.elapsedRealtime();
        if (!force && now - lastLearnSampleAt < LEARN_SAMPLE_GAP_MS) return;
        lastLearnSampleAt = now;

        Snapshot snapshot = captureFrame();
        if (snapshot == null) return;

        if (learnPackage.isEmpty()) {
            // 点了通知栏按钮之后，人往往还停在通知栏或桌面上。这时候锁基准帧，
            // 锁到的就是桌面，之后广告页的每一帧都因包名不同被丢掉，学习必然失败。
            if (isSystemUi(snapshot.packageName)
                    || snapshot.packageName.equals(getPackageName())
                    || isHomePackage(snapshot.packageName)) return;
            learnPackage = snapshot.packageName;
            learnActivity = currentActivity;
            if (learnActivity.startsWith("app.shunjing.skipper")) learnActivity = "";
            learnBefore = new ArrayList<>(snapshot.models);
            pushLearnFrame(learnBefore, now);
            prefs.addLog(learnPackage, "学习", "已锁定这一页，等你把广告关掉");
            return;
        }
        if (!snapshot.packageName.equals(learnPackage)) return;   // 被拉到落地页了，不采样
        learnLatest = new ArrayList<>(snapshot.models);
        // 以前这里会用"2.5 秒内节点变多"去刷新基准帧，结果用户手快、两秒内就把广告关了：
        // 刷新后的基准帧其实是关闭后的页面，结束后一比对当然"没有变化"。
        // 现在基准帧交给帧历史保管，这里不再覆盖任何东西。
        pushLearnFrame(learnLatest, now);
        maybeAutoFinish(now);
    }

    /** 存一帧进历史。完全没变化的帧不重复存，只保留最近若干帧。 */
    private void pushLearnFrame(List<NodeModel> nodes, long now) {
        if (nodes == null || nodes.isEmpty()) return;
        if (!learnFrames.isEmpty()) {
            LearningAnalyzer.Frame last = learnFrames.get(learnFrames.size() - 1);
            if (LearningAnalyzer.similarity(last.nodes, nodes) > 0.985d) return;
        }
        boolean afterScroll = now - lastLearnScrollAt < 900L;
        learnFrames.add(new LearningAnalyzer.Frame(new ArrayList<>(nodes), now, afterScroll));
        while (learnFrames.size() > LEARN_FRAME_LIMIT) learnFrames.remove(0);
    }

    /**
     * 自动结束。只看相邻两帧：广告关掉那一刻画面会明显换掉，而且广告特征（跳过/广告角标/
     * splash 之类）会跟着消失。光看"节点变少"不行 —— 关掉广告回到首页，首页节点往往更多。
     */
    private void maybeAutoFinish(long now) {
        if (learnFinishScheduled || learnFrames.size() < 2) return;
        if (now - learnStartedAt < LEARN_MIN_DURATION_MS) return;
        LearningAnalyzer.Frame prev = learnFrames.get(learnFrames.size() - 2);
        LearningAnalyzer.Frame last = learnFrames.get(learnFrames.size() - 1);
        if (last.afterScroll) return;   // 滑动也会让画面大变，那不是关闭
        double similarity = LearningAnalyzer.similarity(prev.nodes, last.nodes);
        if (similarity >= LEARN_CHANGED_THRESHOLD) return;
        int adBefore = LearningAnalyzer.adSignals(prev.nodes);
        int adAfter = LearningAnalyzer.adSignals(last.nodes);
        boolean adGone = adBefore > 0 && adAfter < adBefore;
        boolean shrunk = last.nodes.size() <= prev.nodes.size() * 0.85f;
        // 插屏广告最典型：底下那层页面一直都在，只是上面那层广告浮层没了。
        // 这时候整体相似度不会低到夸张，但一次会掉好几个节点（关闭键、广告图、角标…）。
        boolean blockGone = LearningAnalyzer.vanishedCount(prev.nodes, last.nodes) >= 4
                && similarity < 0.9d;
        // 广告弹出来那一刻也是"大变"，但那是变多，三个条件都不满足。
        if (!adGone && !shrunk && !blockGone) return;
        // 页面明显变了：等半秒让新页面稳定，再抓一帧收尾。
        learnFinishScheduled = true;
        handler.removeCallbacks(learnFinishRunnable);
        handler.postDelayed(learnFinishRunnable, 500L);
    }

    /**
     * 结束学习并落库。
     *
     * <p>失败也要说清楚原因：页面根本没变化、看不出点了哪儿、取不到画面，
     * 三种情况的处理完全不同，含糊的"失败"用户没法自己修。
     */
    private void finishLearning(String reason) {
        if (!learning) return;
        learning = false;
        handler.removeCallbacks(learnTimeout);
        handler.removeCallbacks(learnProbe);
        handler.removeCallbacks(learnFinishRunnable);
        handler.removeCallbacks(closeShade);
        learnFinishScheduled = false;
        showStatusNotification();

        if (learnBefore == null || learnBefore.isEmpty() || learnPackage.isEmpty()) {
            showToast("没能在广告页上取到画面，学习已取消");
            prefs.addLog("", "学习", "失败：没有取到广告页画面");
            resetLearning();
            scheduleScan(0L);
            return;
        }

        // 用户点"结束学习"时画面通常已经稳定在关闭后的样子，但事件驱动可能没来得及采。
        // 补这一帧进去，比拿最后一次采样当结尾准得多。
        Snapshot current = captureFrame();
        if (current != null && current.packageName.equals(learnPackage)) {
            pushLearnFrame(new ArrayList<>(current.models), SystemClock.elapsedRealtime());
        }

        DisplayMetrics dm = getResources().getDisplayMetrics();
        String label = appLabel(learnPackage);
        LearningAnalyzer.Result result = LearningAnalyzer.analyzeFrames(
                learnPackage, learnActivity, label, learnFrames, learnClicks,
                dm.widthPixels, dm.heightPixels);
        if (result.ok()) {
            prefs.saveLearnedClose(result.learned);
            learnedCloses = prefs.learnedCloses();
            showToast("已学会：" + label + " 的这个位置，" + reason);
            prefs.addLog(learnPackage, "学会", result.message);
        } else {
            showToast("没学会：" + result.message);
            prefs.addLog(learnPackage, "学习", "失败：" + result.message
                    + "（画面 " + learnFrames.size() + " 帧）");
        }
        resetLearning();
        scheduleScan(0L);
    }

    private void resetLearning() {
        learnBefore = null;
        learnLatest = null;
        learnClicks.clear();
        learnFrames.clear();
        lastLearnScrollAt = 0L;
        learnPackage = "";
        learnActivity = "";
    }

    /** 抓当前这一帧，附带包名校验；拿不到就返回 null。 */
    private Snapshot captureFrame() {
        Snapshot snapshot = captureSnapshot(false);
        if (snapshot == null || snapshot.models.isEmpty()) return null;
        if (snapshot.packageName.isEmpty() || isSystemUi(snapshot.packageName)) return null;
        return snapshot;
    }

    /** 学习记录：同包同页面，位置尺寸都对得上才认。 */
    private Decision learnedDecision(ScreenModel screen, int width, int height, boolean adContext) {
        if (!adContext) return Decision.NONE;
        for (LearnedClose close : learnedCloses) {
            if (!close.appliesTo(screen)) continue;
            int index = close.find(screen, width, height);
            if (index >= 0) {
                return Decision.click(index, "learned_close", "你教过的关闭位置");
            }
        }
        return Decision.NONE;
    }

    private static boolean isGeometricTarget(String ruleId) {
        return "download_ad_close".equals(ruleId)
                || "web_ad_template_close".equals(ruleId)
                || "shake_ad_close".equals(ruleId)
                || "overlay_close".equals(ruleId)
                || "corner_skip".equals(ruleId)
                || "corner_close_icon".equals(ruleId);
    }

    private boolean adContextFor(ScreenModel screen, boolean inherited) {
        return inherited || AdDecisionEngine.hasAdContext(screen, settingsFor(screen.packageName));
    }

    /**
     * 重点应用：模板广告与叠层弹窗的几何定位强制开启。
     *
     * <p>这只是"允许本地多试一条路"，不是免证据：两条定位器内部仍然要求广告上下文
     * （WebView + 模板 id / 广告角标；或居中卡片 + 角落悬浮图标），敏感页硬锁照旧
     * 排在最前面。
     */
    private EngineSettings settingsFor(String packageName) {
        if (prefs == null || !prefs.isPriorityApp(packageName)) return engineSettings;
        return engineSettings.withWebAdTemplate(true).withOverlayClose(true);
    }

    /**
     * v1.4: 页面明显是广告、却连一个候选控件都找不到（典型：H5 运营弹窗，关闭按钮根本
     * 不在无障碍树里）。本地已经没有可点的东西，只能交给云端视觉；严格限流、同一页面
     * 25 秒最多一次，且只在用户已开启云端复核时生效。
     */
    /**
     * v1.6：接管判定的两条路。
     *
     * <p>① 强证据 —— 页面有广告词 / 摇一摇 / SDK 结构，本地却没找到可点控件。老路子，最快。
     * <p>② 仅疑似 —— 本地完全看不出是广告（没有"广告"二字、不是 SDK 页面），但结构上
     * 就是一块整屏媒体 + 角落里一枚无字图标。旧版在这里直接 return，于是云端永远叫不醒；
     * 现在允许花一次请求问一句，但<b>不授权本地点击</b>，答案落地要过更高的置信度门槛。
     */
    private void trackIdlePage(ScreenModel screen, long now, boolean adContext, String fingerprint) {
        if (!fingerprint.equals(idleFingerprint)) {
            idleFingerprint = fingerprint;
            idleScanCount = 0;
            idleSinceAt = now;
        } else if (idleScanCount < 1000) {
            idleScanCount++;
        }
        if (prefs == null) return;
        boolean priority = prefs.isPriorityApp(screen.packageName);
        boolean strong = adContext && hasVisualAdContext(screen);
        // 重点应用即使本地没证据也允许问一句；全局「安静」档下只有重点应用有这个豁免。
        boolean suspect = !strong && (prefs.adSuspectEnabled() || priority)
                && AdSuspectDetector.isSuspect(screen);
        if (!strong && !suspect) return;
        if (!prefs.cloudVisionReady() || cloudInFlight) return;
        // 同一页最多问两次：第一次可能是坐标偏差，第二次仍无解才拉黑，避免一次误判就永久放弃。
        // 记录有寿命（20 秒）且按应用分桶，下一轮开屏不会被上一轮拦死。
        if (visionLedger.count(VisionAttemptLedger.key(screen.packageName, fingerprint), now) >= 2) {
            return;
        }

        VisionTriggerPolicy.Sensitivity sensitivity = prefs.sensitivityFor(screen.packageName);
        long sinceLast = fingerprint.equals(lastProactiveVisionFingerprint)
                ? now - lastProactiveVisionAt : Long.MAX_VALUE;
        // v1.6.3：交给 AI 之前只拦「支付 / 扫码」，不再拦页脚写着「用户协议」的广告页。
        if (!VisionTriggerPolicy.shouldTakeOver(sensitivity, true, strong, suspect,
                AdDecisionEngine.isPaymentOrScan(screen), now - idleSinceAt, idleScanCount, sinceLast)) {
            return;
        }
        lastProactiveVisionAt = now;
        lastProactiveVisionFingerprint = fingerprint;
        int waited = (int) Math.max(0L, now - idleSinceAt);
        prefs.addLog(screen.packageName, priority ? "AI 接管·重点" : "AI 接管", strong
                ? "本地 " + waited + "ms 无可用目标，云端定位中"
                : "本地无广告证据，疑似广告页交云端核对（" + waited + "ms）");
        // 静默请求：接管是设计好的兜底，不需要每次都弹一句 Toast 打断用户。
        requestCloudVision(screen, fingerprint, ++recoveryToken, true, strong);
    }

    /** A bounded fast follow-up for skip controls that appear before a countdown finishes. */
    private void scheduleCountdownRecheck(ScreenModel screen, boolean adContext) {
        boolean eligible = engineSettings.fastSplashEnabled && screen.launchedRecently
                && adContext && DynamicSkipDetector.hasCountdown(screen);
        if (!eligible) {
            countdownTracking = false;
            countdownChecksLeft = 0;
            return;
        }
        if (!countdownTracking) {
            countdownTracking = true;
            countdownChecksLeft = 75; // at most ~6 seconds; normal event-driven scans continue
        }
        if (countdownChecksLeft > 0) {
            countdownChecksLeft--;
            scheduleScan(80L);
        }
    }

    private void beginClickAttempt(ScreenModel screen, NodeModel target) {
        armClickAttempt(screen, target,
                (target.left + target.right) / 2, (target.top + target.bottom) / 2, false);
    }

    private void beginClickAttempt(ScreenModel screen, NodeModel target, String ruleId) {
        armClickAttempt(screen, target,
                (target.left + target.right) / 2, (target.top + target.bottom) / 2,
                isGeometricTarget(ruleId));
    }

    /**
     * @param target 云端只给了坐标、本地没有可挂靠节点时传 null，此时用 tapX/tapY 作为
     *               观察点：页面没变化就说明这一击无效，直接进入复核，而不是假装成功。
     */
    private void beginClickAttempt(ScreenModel screen, NodeModel target, int tapX, int tapY) {
        armClickAttempt(screen, target, tapX, tapY, true);
    }

    private void armClickAttempt(ScreenModel screen, NodeModel target, int tapX, int tapY,
                                 boolean geometric) {
        handler.removeCallbacks(verifyClickRunnable);
        recoveryToken++;
        attemptPending = true;
        attemptFailureCount = 0;
        attemptGeometric = geometric;
        attemptVision = false;
        attemptPackage = screen.packageName;
        attemptActivity = screen.activityName;
        attemptPageFingerprint = ScreenFingerprint.of(screen);
        if (target != null) {
            attemptTargetKey = targetKey(target);
            attemptLeft = target.left;
            attemptTop = target.top;
            attemptRight = target.right;
            attemptBottom = target.bottom;
        } else {
            int radius = Math.max(16, Math.round(20f * getResources().getDisplayMetrics().density));
            attemptTargetKey = "";
            attemptLeft = tapX - radius;
            attemptTop = tapY - radius;
            attemptRight = tapX + radius;
            attemptBottom = tapY + radius;
        }
        // 几何目标再点同一个点也不会生效，验证提前到 240ms，尽快交棒给云端。
        handler.postDelayed(verifyClickRunnable, geometric ? 240L : VERIFY_CLICK_DELAY_MS);
    }

    private void clearClickAttempt() {
        handler.removeCallbacks(verifyClickRunnable);
        recoveryToken++;
        attemptPending = false;
        attemptFailureCount = 0;
        attemptPackage = "";
        attemptActivity = "";
        attemptPageFingerprint = "";
        attemptTargetKey = "";
        cloudInFlight = false;
        attemptVision = false;
        attemptGeometric = false;
    }

    /** Verify the actual page, not merely the return value of ACTION_CLICK. */
    private void verifyClickedPage() {
        if (!attemptPending || !guarding()) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) { clearClickAttempt(); return; }
        Snapshot snapshot = null;
        try {
            snapshot = flatten(root);
            String pkg = root.getPackageName() == null ? "" : root.getPackageName().toString();
            if (!pkg.equals(attemptPackage) || !currentActivity.equals(attemptActivity)) {
                clearClickAttempt();
                return;
            }
            ScreenModel current = new ScreenModel(pkg, currentActivity,
                    SystemClock.elapsedRealtime() - launchStartedAt <= LAUNCH_WINDOW_MS, snapshot.models);
            if (AdDecisionEngine.isSensitive(current)) { clearClickAttempt(); return; }
            String fingerprint = ScreenFingerprint.of(current);
            if (!fingerprint.equals(attemptPageFingerprint)) {
                // 页面确实变了：这才是"关掉了"的证据，而不是点击返回 true。
                if (attemptVision) {
                    prefs.addLog(pkg, "已跳过", "AI 点击生效");
                }
                clearClickAttempt();
                return;
            }
            NodeModel target = findAttemptTarget(snapshot.models);
            if (target == null && !attemptTargetKey.isEmpty()) {
                // 目标控件消失了但页面指纹没变（同一套骨架重建），当作已处理。
                clearClickAttempt();
                return;
            }
            attemptFailureCount++;
            if (target == null) {
                // 纯坐标点击：同一个点再点一次没有意义，直接走复核（自适应 / 再问云端）。
                startRecovery(snapshot, current, null);
                return;
            }
            if (attemptFailureCount == 1 && !attemptGeometric) {
                // ACTION_CLICK returned true but was swallowed: exactly one coordinate retry.
                // 几何目标不适用——它本来就是按坐标点的，同一个点再来一次只是多等 400ms。
                if (executeClick(snapshot, target, true)) {
                    attemptPageFingerprint = fingerprint;
                    handler.postDelayed(verifyClickRunnable, VERIFY_CLICK_DELAY_MS + 70L);
                } else {
                    startRecovery(snapshot, current, target);
                }
            } else {
                startRecovery(snapshot, current, target);
            }
        } catch (RuntimeException ignored) {
            clearClickAttempt();
        } finally {
            if (snapshot != null) snapshot.recycle(); else root.recycle();
        }
    }

    private NodeModel findAttemptTarget(List<NodeModel> nodes) {
        for (NodeModel n : nodes) {
            if (n.left == attemptLeft && n.top == attemptTop && n.right == attemptRight
                    && n.bottom == attemptBottom && targetKey(n).equals(attemptTargetKey)) return n;
        }
        return null;
    }

    private static String targetKey(NodeModel n) {
        return n.className + "|" + n.viewId + "|"
                + n.normalizedText().replaceAll("\\d+", "#") + "|"
                + n.normalizedDescription().replaceAll("\\d+", "#");
    }

    private void startRecovery(Snapshot snapshot, ScreenModel screen, NodeModel previousTarget) {
        handler.removeCallbacks(verifyClickRunnable);
        attemptPending = false;
        long now = SystemClock.elapsedRealtime();
        String fingerprint = ScreenFingerprint.of(screen);
        // v1.5: 同一页面重复请求的间隔由灵敏度决定（保守 25s / 积极 6s / 激进 3s）。
        // v1.5.2: 重点应用降到 1.2 秒，点了没反应就再来一次。
        long cooldown = prefs == null ? RECOVERY_COOLDOWN_MS
                : prefs.sensitivityFor(screen.packageName).pageCooldownMs;
        if (now - lastRecoveryAt < cooldown && fingerprint.equals(lastRecoveryFingerprint)) {
            // 冷却没到不等于放弃：排一次到期重扫，让"点了没反应"在 1~3 秒后还有第二次机会。
            if (prefs != null && hasVisualAdContext(screen)
                    && visionLedger.count(VisionAttemptLedger.key(screen.packageName, fingerprint), now) < 2) {
                long remaining = cooldown - (now - lastRecoveryAt);
                if (remaining > 0L && remaining <= 2_800L) scheduleScan(remaining + 40L);
            }
            return;
        }

        if (prefs.adaptiveRecoveryEnabled()) {
            DisplayMetrics metrics = getResources().getDisplayMetrics();
            AdaptiveCloseLocator.Result result = AdaptiveCloseLocator.find(screen,
                    previousTarget == null ? -1 : previousTarget.index,
                    metrics.widthPixels, metrics.heightPixels);
            if (result != null && result.nodeIndex >= 0 && result.nodeIndex < snapshot.models.size()) {
                NodeModel target = snapshot.models.get(result.nodeIndex);
                if (executeClick(snapshot, target, false)) {
                    prefs.addLog(screen.packageName, "自适应补点", result.reason + " · 置信分 " + result.score);
                    showToast("已重新定位关闭按钮");
                    // Keep the same verification loop; if this candidate also fails, the next
                    // failure escalates to cloud vision instead of stopping at a cooldown.
                    beginClickAttempt(screen, target);
                    return;
                }
            }
        }
        lastRecoveryAt = now;
        lastRecoveryFingerprint = fingerprint;
        long token = ++recoveryToken;
        long since = fingerprint.equals(lastProactiveVisionFingerprint)
                ? now - lastProactiveVisionAt : Long.MAX_VALUE;
        boolean takeOver = VisionTriggerPolicy.shouldTakeOverAfterFailedClick(
                prefs.sensitivityFor(screen.packageName), prefs.cloudVisionReady(),
                hasVisualAdContext(screen), AdDecisionEngine.isPaymentOrScan(screen), since);
        if (takeOver && !cloudInFlight) {
            lastProactiveVisionAt = now;
            lastProactiveVisionFingerprint = fingerprint;
            prefs.addLog(screen.packageName, "AI 接管", "点击后页面未变化，交给云端复核");
            requestCloudVision(screen, fingerprint, token, false,
                    hasVisualAdContext(screen));
        } else {
            maybeAutoCapture(screen, screen.packageName, now, true);
        }
    }

    private void requestCloudVision(ScreenModel expected, String fingerprint, long token) {
        requestCloudVision(expected, fingerprint, token, false, true);
    }

    private void requestCloudVision(ScreenModel expected, String fingerprint, long token,
                                    boolean quiet, boolean strongEvidence) {
        if (Build.VERSION.SDK_INT < 30) return;
        if (visionClient == null) visionClient = new VisionRecoveryClient();
        cloudInFlight = true;
        visionStartedAt = SystemClock.elapsedRealtime();
        // 兜底解锁：截图回调或网络回调因任何原因没回来时，不能让"请求中"这个标记把
        // 后续所有接管都堵死（那正是"有时候有用、有时候一直没反应"的来源之一）。
        final long guardToken = token;
        handler.postDelayed(() -> {
            if (guardToken == recoveryToken) cloudInFlight = false;
        }, 9_000L);
        if (!quiet) showToast("AI 正在接管…");
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(),
                    new AccessibilityService.TakeScreenshotCallback() {
                        @Override
                        public void onSuccess(AccessibilityService.ScreenshotResult result) {
                            Bitmap hardware = null;
                            Bitmap screenshot = null;
                            HardwareBuffer buffer = result.getHardwareBuffer();
                            try {
                                hardware = Bitmap.wrapHardwareBuffer(buffer, result.getColorSpace());
                                if (hardware != null) {
                                    screenshot = hardware.copy(Bitmap.Config.ARGB_8888, false);
                                }
                            } catch (RuntimeException ignored) {
                            } finally {
                                if (hardware != null) hardware.recycle();
                                if (buffer != null) buffer.close();
                            }
                            if (token != recoveryToken || screenshot == null) {
                                if (screenshot != null) screenshot.recycle();
                                cloudInFlight = false;
                                return;
                            }
                            AccessibilityNodeInfo root = getRootInActiveWindow();
                            Snapshot current = null;
                            try {
                                if (root == null) throw new IllegalStateException("页面已变化");
                                current = flatten(root);
                                String pkg = root.getPackageName() == null ? "" : root.getPackageName().toString();
                                ScreenModel latest = new ScreenModel(pkg, currentActivity, expected.launchedRecently,
                                        current.models);
                                final boolean strongNow = hasVisualAdContext(latest);
                                final boolean suspectNow = !strongNow
                                        && AdSuspectDetector.isSuspect(latest);
                                if (!pkg.equals(expected.packageName) || !currentActivity.equals(expected.activityName)
                                        || AdDecisionEngine.isPaymentOrScan(latest)
                                        || (!strongNow && !suspectNow)
                                        || !ScreenFingerprint.of(latest).equals(fingerprint)) {
                                    throw new IllegalStateException("页面已变化或受保护");
                                }
                                visionClient.analyze(prefs.cloudEndpoint(), prefs.cloudApiKey(), prefs.cloudModel(),
                                        screenshot, latest, !strongNow,
                                        new VisionRecoveryClient.Callback() {
                                            @Override public void onResult(VisionRecoveryClient.Answer answer) {
                                                cloudInFlight = false;
                                                if (token == recoveryToken) {
                                                    applyVisionAnswer(answer, expected, fingerprint, strongNow);
                                                }
                                            }
                                            @Override public void onError(String message) {
                                                cloudInFlight = false;
                                                if (token == recoveryToken && !quiet) {
                                                    showToast("云端复核未完成：" + message);
                                                }
                                            }
                                        });
                                // 所有权交给客户端：它在工作线程里缩放、压缩，请求结束后自行回收，
                                // 这里不能再碰这张位图。
                                screenshot = null;
                            } catch (RuntimeException e) {
                                cloudInFlight = false;
                                if (screenshot != null && !screenshot.isRecycled()) screenshot.recycle();
                            } finally {
                                if (current != null) current.recycle(); else if (root != null) root.recycle();
                            }
                        }

                        @Override public void onFailure(int errorCode) {
                            cloudInFlight = false;
                            if (token != recoveryToken) return;
                            // 广告页自己设了 FLAG_SECURE 时，系统会拒绝无障碍截图。这不是
                            // 「被我们判成敏感页」，而是那一页根本不允许被看 —— 云端无从参与，
                            // 说清楚原因，并且自动接管时别再弹窗打扰。
                            prefs.addLog(expected.packageName, "云端跳过",
                                    "该页面自身禁止截屏（系统限制），AI 无法参与");
                            if (!quiet) showToast("该页面禁止截屏，云端看不了");
                        }
                    });
        } catch (RuntimeException e) {
            cloudInFlight = false;
        }
    }

    /** v1.4: 运营弹窗没有"广告"字样，但仍属于可关闭的广告位。 */
    private boolean hasVisualAdContext(ScreenModel screen) {
        boolean visual = AdDecisionEngine.hasAdContext(screen, settingsFor(screen.packageName))
                || AdDecisionEngine.hasPromoContext(screen)
                || AdDecisionEngine.hasShakeAd(screen);
        // v1.6.3: 顺手记下"这一页确实是广告位"。跳转发生时它就是唯一的证据来源 ——
        // 商店页面本身没有广告字样，只能靠起跳点判断。
        if (visual) lastAdContextAt = SystemClock.elapsedRealtime();
        return visual;
    }

    private void applyVisionAnswer(VisionRecoveryClient.Answer answer, ScreenModel expected,
                                   String fingerprint, boolean strongEvidence) {
        if (answer == null) return;
        if (!answer.found) {
            // 云端明确说"这里没有关闭按钮"：记一次，同一页第二次仍无解才彻底拉黑。
            rememberVisionMiss(expected.packageName, fingerprint);
            return;
        }
        // v1.5.4: 这一页上一次点的位置已经把人拽走过，短时间内别再让 AI 点同一处。
        if (isJumpTrap(expected.packageName, fingerprint, SystemClock.elapsedRealtime())) {
            prefs.addLog(expected.packageName, "已跳过", "这一页上次点完被拽走了，30 秒内不再交给 AI 点击");
            return;
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        Snapshot snapshot = null;
        try {
            snapshot = flatten(root);
            String pkg = root.getPackageName() == null ? "" : root.getPackageName().toString();
            ScreenModel latest = new ScreenModel(pkg, currentActivity, expected.launchedRecently, snapshot.models);
            final boolean strongNow = hasVisualAdContext(latest);
            final boolean suspectNow = !strongNow && AdSuspectDetector.isSuspect(latest);
            if (!pkg.equals(expected.packageName) || !currentActivity.equals(expected.activityName)
                    || AdDecisionEngine.isPaymentOrScan(latest)
                    || (!strongNow && !suspectNow)
                    || !ScreenFingerprint.of(latest).equals(fingerprint)) return;
            VisionTriggerPolicy.Sensitivity sensitivity = prefs.sensitivityFor(pkg);
            DisplayMetrics metrics = getResources().getDisplayMetrics();
            int x = VisionRecoveryPolicy.toPixels(answer.x, metrics.widthPixels);
            int y = VisionRecoveryPolicy.toPixels(answer.y, metrics.heightPixels);
            // 先找可点击祖先；找不到就退到"小而干净、但不可点击"的节点（SDK 自绘广告的常态）。
            int node = VisionRecoveryPolicy.findSafeNode(latest, x, y,
                    metrics.widthPixels, metrics.heightPixels);
            if (node < 0) node = VisionRecoveryPolicy.findSafeTarget(latest, x, y,
                    metrics.widthPixels, metrics.heightPixels);
            // 仅疑似时再收一道：命中节点不得大于屏幕 8%，否则那是横幅 / 卡片而不是关闭图标。
            if (node >= 0 && !strongNow) {
                NodeModel hit = latest.nodes.get(node);
                long area = (long) (hit.right - hit.left) * (hit.bottom - hit.top);
                if (area > (long) metrics.widthPixels * metrics.heightPixels * 0.08f) node = -1;
            }
            if (node < 0 && !VisionRecoveryPolicy.allowCoordinateOnly(latest, x, y, answer.confidence,
                    sensitivity, strongNow ? 0f : 0.80f, !strongNow)) {
                rememberVisionMiss(pkg, fingerprint);
                return;
            }
            NodeModel target = node >= 0 ? latest.nodes.get(node) : null;
            // 有节点就用节点中心：模型给的是"看图估出来的坐标"，节点框才是无障碍层认可的实体，
            // 两者差个十几像素，对小尺寸 × 就是点中与点空的区别。
            int tapX = target == null ? x : (target.left + target.right) / 2;
            int tapY = target == null ? y : (target.top + target.bottom) / 2;
            if (!precisionTap(tapX, tapY)) {
                rememberVisionMiss(pkg, fingerprint);
                return;
            }
            // 记下"这一页的这一次 AI 点击"：万一被拽走，回收时才知道该拉黑哪一页。
            lastClickFingerprint = fingerprint;
            long elapsed = Math.max(0L, SystemClock.elapsedRealtime() - visionStartedAt);
            prefs.addLog(pkg, "AI 定位", "置信度 " + Math.round(answer.confidence * 100) + "%"
                    + " · 接管耗时 " + elapsed + "ms"
                    + " · " + (target == null ? "坐标兜底" : "节点 #" + target.index)
                    + (strongNow ? "" : " · 仅疑似页"));
            // 不再一上来就说"已跳过"：点了不等于关掉了，先进入 1.1 秒观察窗。
            showToast("AI 已点击，正在确认");
            // 坐标是模型估的，点错可能直接跳到落地页 —— 和几何点击用同一道回退闸。
            clickGuard.arm(pkg, SystemClock.elapsedRealtime());
            beginClickAttempt(latest, target, tapX, tapY);
            attemptVision = true;
            if (prefs.confirmationFollowUpEnabled()) {
                followUpUntil = SystemClock.elapsedRealtime() + FOLLOW_UP_WINDOW_MS;
                followUpPackage = pkg;
                followUpActivity = currentActivity;
            }
            scheduleScan(FOLLOW_UP_DELAY_MS);
        } catch (RuntimeException ignored) {
        } finally {
            if (snapshot != null) snapshot.recycle(); else root.recycle();
        }
    }

    private void rememberVisionMiss(String pkg, String fingerprint) {
        if (fingerprint == null || fingerprint.isEmpty()) return;
        visionLedger.miss(VisionAttemptLedger.key(pkg, fingerprint), SystemClock.elapsedRealtime());
    }

    private boolean precisionTap(int x, int y) {
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        if (x < 0 || y < 0 || x >= metrics.widthPixels || y >= metrics.heightPixels) return false;
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0L, 45L)).build();
        return dispatchGesture(gesture, null, null);
    }

    private void maybeAutoCapture(ScreenModel screen, String pkg, long now) {
        maybeAutoCapture(screen, pkg, now, false);
    }

    /**
     * Keeps evidence only for pages that genuinely look like an ad but were not skipped.
     * Throttled per page signature so normal browsing never fills the storage.
     */
    private void maybeAutoCapture(ScreenModel screen, String pkg, long now, boolean forced) {
        if (prefs == null || dumpStore == null || !prefs.autoCaptureEnabled()) return;
        if (AdDecisionEngine.isSensitive(screen)) return;
        boolean looksLikeAd = AdDecisionEngine.hasAdContext(screen, engineSettings)
                || !DumpAnalyzer.findCandidates(new PageDump("", now, pkg, screen.activityName,
                "", "", 0, 0, screen.launchedRecently, screen.nodes)).isEmpty();
        if (!looksLikeAd && !forced) return;
        String signature = pkg + "|" + screen.activityName;
        if (!forced && now - lastAutoCaptureAt < AUTO_CAPTURE_COOLDOWN_MS
                && signature.equals(lastAutoCaptureSignature)) return;
        if (now - lastAutoCaptureAt < 4_000L) return;
        lastAutoCaptureAt = now;
        lastAutoCaptureSignature = signature;
        saveDump(screen, pkg, PageDump.SOURCE_AUTO);
    }

    /** Grabs the live window from the notification action / "capture next screen". */
    private void captureWindow(String source) {
        if (prefs == null || dumpStore == null) return;
        AccessibilityNodeInfo root;
        try {
            root = getRootInActiveWindow();
        } catch (RuntimeException e) {
            notifyUser("未能读取当前窗口");
            return;
        }
        if (root == null) {
            notifyUser("未能读取当前窗口");
            return;
        }
        Snapshot snapshot = null;
        try {
            snapshot = flatten(root);
            String pkg = root.getPackageName() == null ? currentPackage : root.getPackageName().toString();
            if (!isCapturablePackage(pkg)) {
                notifyUser("当前是系统或瞬净页面，未抓取");
                return;
            }
            ScreenModel screen = new ScreenModel(pkg, currentActivity,
                    SystemClock.elapsedRealtime() - launchStartedAt <= LAUNCH_WINDOW_MS,
                    snapshot.models);
            saveDump(screen, pkg, source);
            notifyUser("已保存页面快照 · " + snapshot.models.size() + " 个控件");
        } catch (RuntimeException ignored) {
            notifyUser("页面正在变化，请重试");
        } finally {
            if (snapshot != null) snapshot.recycle();
            else root.recycle();
        }
    }

    private void saveDump(ScreenModel screen, String pkg, String source) {
        if (dumpStore == null) return;
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        PageDump dump = new PageDump(
                UUID.randomUUID().toString(),
                System.currentTimeMillis(),
                pkg,
                screen.activityName,
                appLabel(pkg),
                source,
                metrics.widthPixels,
                metrics.heightPixels,
                screen.launchedRecently,
                screen.nodes);
        dumpStore.setKeepLimit(prefs.dumpKeepLimit());
        dumpStore.save(dump);
        sendBroadcast(CaptureIntents.saved(this));
    }

    private String appLabel(String packageName) {
        try {
            ApplicationInfo info = getPackageManager().getApplicationInfo(packageName, 0);
            return getPackageManager().getApplicationLabel(info).toString();
        } catch (PackageManager.NameNotFoundException e) {
            return packageName;
        }
    }

    private void notifyUser(String message) {
        Toast toast = Toast.makeText(this, message, Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 180);
        toast.show();
    }

    // ---------------------------------------------------------------- v1.6.2 临时暂停

    /**
     * 真正在干活吗：总开关开着、而且不在临时暂停里。
     *
     * <p>所有"要不要动手"的判断都必须走这里，不要各自写 {@code masterEnabled()} ——
     * 漏一处就会出现"暂停了但还在补点一下"这种最让人不信任的行为。
     */
    private boolean guarding() {
        return prefs != null && prefs.masterEnabled() && !prefs.paused();
    }

    /**
     * 暂停 / 恢复。恢复后不用等下一个事件，立刻补一次扫描，
     * 否则用户从支付页回到广告页要干等一秒才看到它动。
     */
    private void applyPause(int minutes) {
        if (prefs == null) return;
        if (minutes > 0) {
            prefs.pauseFor(minutes);
            // 已经排队的活必须当场撤掉：扫描、抢跳复击、点击校验、连环回退，
            // 否则暂停之后还会有一次"迟到的"点击打在用户正在操作的页面上。
            handler.removeCallbacks(scanRunnable);
            scanScheduled = false;
            handler.removeCallbacks(preemptTick);
            clearPreempt();
            clearClickAttempt();
            jumpChain.disarm();
            showStatusNotification();
            schedulePauseTick();
            notifyUser("已暂停 " + minutes + " 分钟，期间不扫描也不点击");
        } else {
            prefs.resume();
            showStatusNotification();
            schedulePauseTick();
            scheduleScan(0L);
            notifyUser("已恢复守护");
        }
    }

    /** 暂停期间每 20 秒刷新一次通知，让"还有几分钟"真的在走；到点自动恢复。 */
    private final Runnable pauseTick = new Runnable() {
        @Override public void run() {
            if (prefs == null) return;
            if (prefs.paused()) {
                showStatusNotification();
                handler.postDelayed(this, 20_000L);
            } else {
                // 到点：先把通知改回"正在守护"，再把扫描接上。
                handler.removeCallbacks(this);
                showStatusNotification();
                scheduleScan(0L);
                notifyUser("暂停结束，已恢复守护");
            }
        }
    };

    private void schedulePauseTick() {
        handler.removeCallbacks(pauseTick);
        if (prefs != null && prefs.paused()) handler.postDelayed(pauseTick, 20_000L);
    }

    private boolean executeClick(Snapshot snapshot, NodeModel targetModel, boolean forceGesture) {
        int clickableIndex = AdDecisionEngine.findClickableAncestor(snapshot.models, targetModel);
        boolean hasClickable = clickableIndex >= 0 && clickableIndex < snapshot.raw.size();
        if (hasClickable && !forceGesture) {
            AccessibilityNodeInfo clickable = snapshot.raw.get(clickableIndex);
            if (clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
        }
        // v1.4.3: 广告 SDK 自绘的关闭图标常常整棵子树都不可点击（c=0），
        // 这种情况下 ACTION_CLICK 无从谈起，只能在自己的 bounds 内做一次小范围手势。
        // 决策层已经把目标限定为"小尺寸、无文字、位于广告页面角落"，这里再加一道尺寸闸。
        Rect bounds = new Rect(targetModel.left, targetModel.top, targetModel.right, targetModel.bottom);
        if (bounds.isEmpty() || bounds.width() > 600 || bounds.height() > 600) return false;
        DisplayMetrics screen = getResources().getDisplayMetrics();
        if ((long) bounds.width() * bounds.height()
                > (long) screen.widthPixels * screen.heightPixels * 0.06f) return false;
        Path path = new Path();
        path.moveTo(bounds.exactCenterX(), bounds.exactCenterY());
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0L, 55L)).build();
        return dispatchGesture(gesture, null, null);
    }

    /**
     * v1.6.4: 合并「活动窗口 + 本应用子窗口」的控件树。
     *
     * <p>PopupWindow / Dialog / 广告 SDK 的浮层拥有自己的 Window，decorView 不在 Activity
     * 的 root 树里。只抓 {@code getRootInActiveWindow()} 时，屏幕上明明有一个居中小弹窗，
     * 树里却一个节点都没有 —— 引擎什么也不做，学习模式还会因为「画面没变化」而学不到。
     *
     * <p>只合并 {@code TYPE_APPLICATION} 且包名与活动窗口一致的窗口，最多 2 个：
     * 系统窗口、输入法、别的应用的浮层一律不碰。子窗口先入树，同分候选优先命中弹窗里的键。
     */
    private Snapshot captureSnapshot(boolean keepRaw) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        String mainPackage = root == null || root.getPackageName() == null
                ? "" : root.getPackageName().toString();
        Snapshot snapshot = new Snapshot();

        List<AccessibilityWindowInfo> windows;
        try {
            windows = getWindows();
        } catch (RuntimeException e) {
            windows = null;
        }
        if (windows != null && !mainPackage.isEmpty()) {
            int merged = 0;
            for (int i = 0; i < windows.size() && merged < 2; i++) {
                AccessibilityWindowInfo window = windows.get(i);
                if (window == null || window.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;
                if (root != null && window.getId() == root.getWindowId()) continue;
                AccessibilityNodeInfo windowRoot = null;
                try {
                    windowRoot = window.getRoot();
                } catch (RuntimeException ignored) { }
                if (windowRoot == null) continue;
                CharSequence name = windowRoot.getPackageName();
                // 只认本应用：别的应用（含系统级弹窗）的按钮，绝不替它点。
                if (name == null || !mainPackage.contentEquals(name)) {
                    windowRoot.recycle();
                    continue;
                }
                flattenNode(windowRoot, -1, snapshot, 0, keepRaw);
                merged++;
            }
        }
        if (root != null) flattenNode(root, -1, snapshot, 0, keepRaw);
        if (snapshot.models.isEmpty()) return null;
        snapshot.packageName = mainPackage;

        // 分屏 / 双开会把坐标推到屏幕外，几何判断随之全错。
        DisplayMetrics dm = getResources().getDisplayMetrics();
        List<NodeModel> fixed = BoundsNormalizer.toScreen(snapshot.models, dm.widthPixels, dm.heightPixels);
        if (fixed != snapshot.models) {
            snapshot.models.clear();
            snapshot.models.addAll(fixed);
        }
        return snapshot;
    }

    private Snapshot flatten(AccessibilityNodeInfo root) {
        return flatten(root, true);
    }

    private Snapshot flatten(AccessibilityNodeInfo root, boolean keepRaw) {
        Snapshot snapshot = new Snapshot();
        flattenNode(root, -1, snapshot, 0, keepRaw);
        // 分屏 / 双开 / 外接屏会把整棵树的坐标推到屏幕之外，几何判断随之全错。
        DisplayMetrics dm = getResources().getDisplayMetrics();
        List<NodeModel> fixed = BoundsNormalizer.toScreen(snapshot.models, dm.widthPixels, dm.heightPixels);
        if (fixed != snapshot.models) {
            snapshot.models.clear();
            snapshot.models.addAll(fixed);
        }
        return snapshot;
    }

    private int flattenNode(AccessibilityNodeInfo node, int parentIndex, Snapshot snapshot,
                            int depth, boolean keepRaw) {
        if (snapshot.models.size() >= MAX_NODES || depth > 35) return -1;
        int index = snapshot.models.size();
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        if (keepRaw) snapshot.raw.add(node);
        snapshot.models.add(new NodeModel(index, parentIndex, text(node.getText()),
                text(node.getContentDescription()), text(node.getViewIdResourceName()),
                text(node.getClassName()), node.isClickable(), node.isVisibleToUser(), node.isPassword(),
                bounds.left, bounds.top, bounds.right, bounds.bottom));
        for (int i = 0; i < node.getChildCount() && snapshot.models.size() < MAX_NODES; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) flattenNode(child, index, snapshot, depth + 1, keepRaw);
        }
        return index;
    }

    private static String text(CharSequence value) { return value == null ? "" : value.toString(); }

    private void reloadSettings() {
        rules = prefs.getRules();
        layoutAnchors = prefs.layoutAnchors();
        engineSettings = prefs.engineSettings();
        learnedCloses = prefs.learnedCloses();
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        reloadSettings();
        if ("notifications".equals(key) || "master".equals(key) || "total_count".equals(key)) {
            showStatusNotification();
        }
        // 首页的暂停按钮只写偏好，服务在这里跟上：该清的队列清掉，该恢复的扫描接上。
        if ("pause_until".equals(key)) {
            if (prefs.paused()) {
                handler.removeCallbacks(scanRunnable);
                scanScheduled = false;
                handler.removeCallbacks(preemptTick);
                clearPreempt();
                clearClickAttempt();
                jumpChain.disarm();
            }
            schedulePauseTick();
            showStatusNotification();
            if (!prefs.paused()) scheduleScan(0L);
        }
    }

    private void showStatusNotification() {
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager == null) return;
        if (!prefs.notificationsEnabled()) {
            manager.cancel(NOTIFICATION_ID);
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) return;
        if (Build.VERSION.SDK_INT >= 26) {
            // IMPORTANCE_MIN 的渠道在国产 ROM 里会被折叠进「静默/其他通知」，操作按钮
            // 要么看不见、要么点不动。要放学习按钮就必须用 LOW：有声不吵、但常驻可见。
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "自动跳过运行状态", NotificationManager.IMPORTANCE_LOW);
            channel.setShowBadge(false);
            channel.setSound(null, null);
            channel.enableVibration(false);
            channel.setLockscreenVisibility(Notification.VISIBILITY_SECRET);
            manager.createNotificationChannel(channel);
            // 老渠道留着会继续按 MIN 折叠，直接删；旧通知也一起清掉。
            try { manager.deleteNotificationChannel(LEGACY_CHANNEL_ID); } catch (RuntimeException ignored) { }
        }
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent diagnose = PendingIntent.getActivity(this, 3,
                new Intent(this, DumpActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        boolean paused = prefs.paused();
        boolean active = prefs.masterEnabled() && !paused;
        if (Build.VERSION.SDK_INT >= 23) {
            if (learning) {
                // 学习模式：第一个按钮直接变成"结束"，用户不用再下拉第二次。
                builder.addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.ic_stat_shield),
                        "结束学习", CaptureIntents.learnPending(this, CaptureIntents.LEARN_STOP, 5)).build());
                builder.addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.ic_stat_shield),
                        "诊断中心", diagnose).build());
            } else if (paused) {
                // 暂停态只留一个真正有用的动作：恢复。放"暂停更久"只会让人越陷越深。
                builder.addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.ic_stat_shield),
                        "立即恢复", CaptureIntents.pausePending(this, 0, 6)).build());
                builder.addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.ic_stat_shield),
                        "诊断中心", diagnose).build());
            } else {
                builder.addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.ic_stat_shield),
                        "学习", CaptureIntents.learnPending(this, CaptureIntents.LEARN_START, 4)).build());
                builder.addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.ic_stat_shield),
                        "暂停 15 分钟", CaptureIntents.pausePending(this, 15, 7)).build());
                builder.addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.ic_stat_shield),
                        "诊断中心", diagnose).build());
                // 抓取排第四：日常用不到，折叠进"更多"即可，但排查问题的人还找得到。
                builder.addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.ic_stat_shield),
                        "抓取当前页", CaptureIntents.capturePending(this, CaptureIntents.MODE_NOW, 1)).build());
            }
        }
        Notification notification = builder
                .setSmallIcon(R.drawable.ic_stat_shield)
                .setContentTitle(learning ? "瞬净正在学习"
                        : paused ? "瞬净已暂停" : active ? "瞬净正在守护" : "瞬净已关闭")
                .setContentText(learning
                        ? "切回广告页手动关掉它，关掉后自动结束"
                        : paused ? "还有 " + Pause.label(prefs.pauseRemaining())
                                + " 自动恢复 · 期间不扫描也不点击"
                        : active ? "本地识别 · 敏感页面保护 · 累计 " + prefs.totalCount() + " 次"
                        : "总开关已关闭，不会扫描或操作其他应用")
                .setContentIntent(pending).setOngoing(true).build();
        try { manager.notify(NOTIFICATION_ID, notification); } catch (SecurityException ignored) { }
    }

    private void showToast(String message) {
        if (!prefs.toastEnabled()) return;
        // v1.5.4: 连退好几层时同一句提示会连着弹，压成一条就够了。
        long now = SystemClock.elapsedRealtime();
        if (message != null && message.equals(lastToastText) && now - lastToastAt < 1_500L) return;
        lastToastText = message;
        lastToastAt = now;
        Toast toast = Toast.makeText(this, message, Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 180);
        toast.show();
    }

    @Override
    public void onInterrupt() { }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(beatRunnable);
        live = new java.lang.ref.WeakReference<AdSkipService>(null);
        if (prefs != null) prefs.clearBeat();
        handler.removeCallbacks(scanRunnable);
        handler.removeCallbacks(captureNowRunnable);
        handler.removeCallbacks(verifyClickRunnable);
        handler.removeCallbacks(chainHunt);
        handler.removeCallbacks(launchProbe);
        handler.removeCallbacks(preemptTick);
        handler.removeCallbacks(pauseTick);
        handler.removeCallbacks(storeHunt);
        storeHunting = false;
        storeOrigin = "";
        storeHops = 0;
        clearPreempt();
        chainHunting = false;
        jumpChain.disarm();
        recoveryToken++;
        if (visionClient != null) visionClient.shutdown();
        if (receiverRegistered) {
            try { unregisterReceiver(captureReceiver); } catch (RuntimeException ignored) { }
            receiverRegistered = false;
        }
        if (prefs != null) prefs.preferences().unregisterOnSharedPreferenceChangeListener(this);
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.cancel(NOTIFICATION_ID);
        super.onDestroy();
    }

    private static final class Snapshot {
        final List<AccessibilityNodeInfo> raw = new ArrayList<>();
        final List<NodeModel> models = new ArrayList<>();
        String packageName = "";
        void recycle() {
            for (int i = raw.size() - 1; i >= 0; i--) raw.get(i).recycle();
        }
    }
}
