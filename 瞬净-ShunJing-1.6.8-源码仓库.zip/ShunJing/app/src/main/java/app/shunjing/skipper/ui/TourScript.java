package app.shunjing.skipper.ui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * 首页「聚光灯导览」的脚本（1.6.7）。
 *
 * <p>与 1.6.6 的整页说明不同，这一版是**指着一个真实控件讲一句话**：
 * 每一步带一个 {@code target} key，由 {@link TourOverlay} 去首页找到对应控件、
 * 把它周围压暗、其余位置放气泡。所以这里的文案只能讲"这个按钮按下去会发生什么"，
 * 不能讲整个软件的能力 —— 那是用户自己会点出来的。
 *
 * <p>纯数据、不碰 Android：文案是最容易被改坏的部分，单元测试直接断言
 * 步骤顺序、目标 key 与关键说法（比如"极速会放弃奖励"不能写反）。
 */
public final class TourScript {

    /** 一步导览。target 为 null 表示不高亮任何控件（整页说明）。 */
    public static final class Step {
        public final String target;
        public final String tag;
        public final String title;
        public final String body;
        public final String hint;
        public final List<String> lines;

        Step(String target, String tag, String title, String body, String hint,
             List<String> lines) {
            this.target = target;
            this.tag = tag;
            this.title = title;
            this.body = body;
            this.hint = hint;
            this.lines = lines == null
                    ? Collections.<String>emptyList()
                    : Collections.unmodifiableList(lines);
        }
    }

    private TourScript() { }

    private static Step step(String target, String tag, String title, String body, String hint) {
        return new Step(target, tag, title, body, hint, null);
    }

    /** 目标 key：必须与 {@code MainActivity} 里注册的控件一一对应。 */
    public static final String T_SWITCH = "switch";
    public static final String T_ENABLE = "enable";
    public static final String T_PAUSE = "pause";
    public static final String T_MODE = "mode";
    public static final String T_DUMP = "dump";
    public static final String T_LEARN = "learn";
    public static final String T_MORE = "more";

    public static List<Step> steps() {
        List<Step> list = new ArrayList<>();

        list.add(step(T_SWITCH, "总开关", "自动跳过",
                "整个软件的总闸：关掉它，所有页面都不再自动点，开屏也一样。"
                        + "它只干一件事 —— 广告出现的两秒内把它关掉。",
                "现在是开着的。下面几块是它动手的分寸。"));

        list.add(step(T_ENABLE, "授权", "去开启无障碍守护",
                "它只靠无障碍干活：不 ROOT、不录屏、不联网也能用。系统里打开一次就够了。",
                "授权成功后这个按钮会消失，位置换成下面的「临时暂停」。"));

        list.add(step(T_PAUSE, "临时暂停", "临时暂停 15 分钟",
                "点一下，15 分钟内什么都不碰，到点自己恢复，不用回来手动开。",
                "打游戏、看广告领奖励、给别人演示的时候按这里。"));

        list.add(step(T_MODE, "运行模式", "安静 / 均衡 / 极速",
                "只改「敢不敢点」这一件事。已经会关的广告，不会因为换模式而失效。",
                "拿不准就用均衡。极速见到关闭键就点，激励视频会放弃奖励。"));

        list.add(step(T_DUMP, "诊断", "智能诊断",
                "广告没关掉，来这里抓一份现场。报告会直接说清：没认出是广告、"
                        + "认出来了不敢点，还是这页根本没有可点的控件。",
                "三种结论的解法不一样，照着报告做就行。"));

        list.add(step(T_LEARN, "学习", "学习怎么关广告",
                "遇到反复出现的弹窗：广告正在屏幕上时，下拉通知栏点「学习」，"
                        + "你亲手关一遍，它记住这个位置。",
                "是广告已经盖在屏幕上，不是在瞬净首页点。"));

        list.add(step(T_MORE, "其余入口", "云端视觉 · 应用名单 · 规则",
                "本地实在读不出来的页面，才需要开云端视觉；应用名单管哪些 App 生效；"
                        + "关闭词用来补「残忍离开」这种怪文案。",
                "日常用不到，真遇到关不掉的再回来点。"));

        list.add(new Step(null, "兜底", "关不掉的时候，按这个顺序",
                "多数情况在前三步就解决了，不用一上来就开云端。",
                "支付、扫码、密码页永远不点 —— 这一条没有开关。",
                Arrays.asList(
                        "① 换一档模式：均衡 → 极速，再给它 1~2 秒",
                        "② 广告在屏幕上时，通知栏点「学习」，自己关一遍",
                        "③ 「智能诊断」抓现场，看报告卡在哪一步",
                        "④ 报告说没有可点控件，再开「云端视觉 AI」",
                        "⑤ 都不行，把诊断和截图发出来")));

        return Collections.unmodifiableList(list);
    }

    public static int stepCount() {
        return steps().size();
    }
}
