package app.shunjing.skipper.engine;

import java.util.Locale;

/** Immutable, Android-free representation of one accessibility node. */
public final class NodeModel {
    public final int index;
    public final int parentIndex;
    public final String text;
    public final String contentDescription;
    public final String viewId;
    public final String className;
    public final boolean clickable;
    public final boolean visible;
    public final boolean password;
    public final int left;
    public final int top;
    public final int right;
    public final int bottom;

    public NodeModel(int index, int parentIndex, String text, String contentDescription,
                     String viewId, String className, boolean clickable, boolean visible,
                     boolean password, int left, int top, int right, int bottom) {
        this.index = index;
        this.parentIndex = parentIndex;
        this.text = safe(text);
        this.contentDescription = safe(contentDescription);
        this.viewId = safe(viewId);
        this.className = safe(className);
        this.clickable = clickable;
        this.visible = visible;
        this.password = password;
        this.left = left;
        this.top = top;
        this.right = right;
        this.bottom = bottom;
    }

    private static String safe(String value) {
        return value == null ? "" : value;
    }

    public String normalizedText() {
        return normalize(text);
    }

    public String normalizedDescription() {
        return normalize(contentDescription);
    }

    public boolean hasBounds() {
        return right > left && bottom > top;
    }

    public int area() {
        return hasBounds() ? (right - left) * (bottom - top) : Integer.MAX_VALUE;
    }

    public static String normalize(String value) {
        return safe(value).toLowerCase(Locale.ROOT)
                .replace('×', 'x')
                .replace('✕', 'x')
                .replace('✖', 'x')
                .replace('Ｘ', 'x')
                .replaceAll("[\\s\\u00A0]+", "")
                .trim();
    }
}
