package app.shunjing.skipper.engine;

/**
 * 「摇一摇抢跳」的复击策略。
 *
 * <p>为什么需要单独一层：{@link ShakeAdLocator} 找出来的是一枚 60~90px 的角落图标，
 * 按坐标点下去有几十毫秒的误差余量，隔着屏幕看几乎必然点中，但真机上手指刚碰屏、
 * 广告 SDK 已经开始响应加速度计了 —— 一次点空就等于把用户送走。
 *
 * <p>服务层的去重是"同一页、同一目标 1.8 秒内不再点"，那是为了防止"退回来又点、
 * 点了又跳"的来回弹；可对摇一摇页来说，1.8 秒早已跳完。所以这里单独给一个
 * <b>短窗口、少次数</b>的复击许可：
 *
 * <ul>
 *   <li>只在"上一次点的还是同一个摇一摇页"时有效，页面一变立刻作废；</li>
 *   <li>首次点击后 2.6 秒内、最多再补 2 次，每次间隔 280ms；</li>
 *   <li>复击点必须落在上一次目标中心 6% 屏内，页面重排过就不补；</li>
 *   <li>包名或 Activity 变了（说明已经跳走）立刻作废，不追着别的应用点。</li>
 * </ul>
 *
 * <p>这一层不判断"该不该点"，只回答"还能不能再补一下"。是否真的存在可点的
 * 关闭图标，仍由 {@link ShakeAdLocator} 每次重新定位 —— 补点不是免证据通道。
 */
public final class ShakePreemptGuard {

    /** 补点间隔。比服务层 180ms 的点击下限长，留出页面重绘的时间。 */
    public static final long RETRY_DELAY_MS = 280L;
    /** 首次点击后多久之内允许补点。摇一摇跳转通常发生在 1~3 秒内。 */
    public static final long WINDOW_MS = 2_600L;
    /** 首次之外最多补两次，一共三次。再多就是乱点了。 */
    public static final int MAX_ATTEMPTS = 3;

    private String packageName = "";
    private String activityName = "";
    private float targetX = 0f;
    private float targetY = 0f;
    private long armedAt = 0L;
    private long lastStrikeAt = 0L;
    private int attempts = 0;

    /**
     * 记下"刚点过这一处"。
     *
     * @param cx 目标中心 X（像素）
     * @param cy 目标中心 Y（像素）
     */
    public void arm(String pkg, String activity, float cx, float cy, long now) {
        packageName = pkg == null ? "" : pkg;
        activityName = activity == null ? "" : activity;
        targetX = cx;
        targetY = cy;
        armedAt = now;
        lastStrikeAt = now;
        attempts = 1;
    }

    public boolean armed() { return armedAt > 0L; }

    public int attempts() { return attempts; }

    public void disarm() {
        armedAt = 0L;
        attempts = 0;
        lastStrikeAt = 0L;
        packageName = "";
        activityName = "";
    }

    /**
     * 现在能不能补点。
     *
     * @param shakePage 当前这一帧仍然是摇一摇广告页
     * @return 0 表示立刻补；正数表示还要等多少毫秒；-1 表示不该补
     */
    public long dueIn(String pkg, String activity, boolean shakePage, long now) {
        if (armedAt <= 0L) return -1L;
        if (now - armedAt > WINDOW_MS) {
            disarm();
            return -1L;
        }
        if (attempts >= MAX_ATTEMPTS) {
            disarm();
            return -1L;
        }
        // 页面已经不是摇一摇页：要么关掉了，要么换页了。两种情况都不该再补。
        if (!shakePage) {
            disarm();
            return -1L;
        }
        String value = pkg == null ? "" : pkg;
        String activityValue = activity == null ? "" : activity;
        // 跳走了。绝不追到别的应用里补点。
        if (!value.equals(packageName) || !activityValue.equals(activityName)) {
            disarm();
            return -1L;
        }
        long due = lastStrikeAt + RETRY_DELAY_MS;
        long wait = due - now;
        return wait < 0L ? 0L : wait;
    }

    /** 复击点必须还是原来那一处，否则页面已经重排，补点会落到别的东西上。 */
    public boolean sameSpot(float cx, float cy, int screenWidth, int screenHeight) {
        if (screenWidth <= 0 || screenHeight <= 0) return false;
        float dx = Math.abs(cx - targetX) / screenWidth;
        float dy = Math.abs(cy - targetY) / screenHeight;
        return dx <= 0.06f && dy <= 0.06f;
    }

    /** 真的发出去了才计数；点不出去不该消耗额度。 */
    public void noteStrike(long now) {
        attempts++;
        lastStrikeAt = now;
    }
}
