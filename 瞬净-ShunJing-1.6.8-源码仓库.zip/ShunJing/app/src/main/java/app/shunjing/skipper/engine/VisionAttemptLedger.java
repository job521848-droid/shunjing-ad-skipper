package app.shunjing.skipper.engine;

import java.util.HashMap;
import java.util.Iterator;

/**
 * v1.5.5 —— 「这一页问过云端两次了，别再烧钱」的记录本。
 *
 * <p>旧实现是一个永久有效的 Map：同一页面指纹累计失败两次，就再也不问云端。这在
 * <b>冷启动</b>下没问题，但开屏广告是会重复出现的 —— 用户把一个 App 放后台，过一会
 * 再点开，广告重新加载，页面指纹和上次<b>一模一样</b>，于是云端从第一次点击起就被挡在门外，
 * 表现就是「刚装的时候能跳过，用久了反而罢工」。
 *
 * <p>这里给记录加上寿命和范围：
 * <ul>
 *   <li>每条记录 20 秒后自动作废 —— 下一轮开屏是新的机会；</li>
 *   <li>按「包名 + 页面指纹」记账，离开一个应用再回来时整包清空；</li>
 *   <li>仍然限制同一页最多问两次，避免在同一个弹窗上反复花钱。</li>
 * </ul>
 */
public final class VisionAttemptLedger {

    /** 一条失败记录的寿命。短于一次正常的「放后台再回来」，长于同一页面内的重试间隔。 */
    private static final long TTL_MS = 20_000L;
    private static final int MAX_ENTRIES = 60;

    private static final class Entry {
        int count;
        long at;
    }

    private final HashMap<String, Entry> entries = new HashMap<>();

    public static String key(String pkg, String fingerprint) {
        if (fingerprint == null || fingerprint.isEmpty()) return "";
        return (pkg == null ? "" : pkg) + "|" + fingerprint;
    }

    /** 这一页当前记了几次；过期记录按 0 算。 */
    public int count(String key, long now) {
        if (key == null || key.isEmpty()) return 0;
        Entry entry = entries.get(key);
        if (entry == null) return 0;
        if (now - entry.at > TTL_MS) {
            entries.remove(key);
            return 0;
        }
        return entry.count;
    }

    public void miss(String key, long now) {
        if (key == null || key.isEmpty()) return;
        Entry entry = entries.get(key);
        if (entry == null || now - entry.at > TTL_MS) {
            entry = new Entry();
            entries.put(key, entry);
        }
        entry.count++;
        entry.at = now;
        trim();
    }

    /** 这一页已经成功关掉了，记录作废。 */
    public void clear(String key) {
        if (key != null && !key.isEmpty()) entries.remove(key);
    }

    /** 离开一个应用 = 一次新会话：这个应用的失败记录不再代表"下次也没救"。 */
    public void clearPackage(String pkg) {
        if (pkg == null || pkg.isEmpty()) return;
        String prefix = pkg + "|";
        Iterator<String> iterator = entries.keySet().iterator();
        while (iterator.hasNext()) {
            if (iterator.next().startsWith(prefix)) iterator.remove();
        }
    }

    public int size() { return entries.size(); }

    private void trim() {
        if (entries.size() <= MAX_ENTRIES) return;
        Iterator<String> iterator = entries.keySet().iterator();
        if (iterator.hasNext()) {
            iterator.next();
            iterator.remove();
        }
    }
}
