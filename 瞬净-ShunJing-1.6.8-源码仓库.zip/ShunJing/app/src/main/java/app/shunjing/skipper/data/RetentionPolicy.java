package app.shunjing.skipper.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * v1.5.6 —— 「只保留最近 N 条」的统一规则。
 *
 * <p>日志和抓取记录都是<b>新在前</b>（下标 0 最新）。攒到几百条时，诊断页每打开一次
 * 都要逐条读文件、跑一遍识别引擎，主线程就会被拖住。裁掉尾巴比"事后优化渲染"直接得多。
 *
 * <p>抽成纯函数是为了能单测：裁错方向（留下最旧的一批）比不裁更糟。
 */
public final class RetentionPolicy {

    private RetentionPolicy() { }

    public static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    /** 新在前的列表，取前 {@code limit} 条；不足则原样返回一份副本。 */
    public static <T> List<T> newestFirst(List<T> items, int limit) {
        if (items == null || items.isEmpty()) return new ArrayList<>();
        int keep = clamp(limit, 1, items.size());
        return new ArrayList<>(items.subList(0, keep));
    }

    /** 从文件时间戳列表里挑出该删的（最旧的那部分）。 */
    public static <T> List<T> oldestBeyond(List<T> newestFirst, int limit) {
        if (newestFirst == null || newestFirst.isEmpty()) return Collections.emptyList();
        int keep = clamp(limit, 1, newestFirst.size());
        if (newestFirst.size() <= keep) return Collections.emptyList();
        return new ArrayList<>(newestFirst.subList(keep, newestFirst.size()));
    }
}
