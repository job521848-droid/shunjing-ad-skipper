package app.shunjing.skipper.engine;

import java.util.UUID;

public final class Rule {
    public enum MatchType { EXACT, CONTAINS, ID }
    public enum Category { SKIP, CLOSE, CUSTOM }

    public final String id;
    public final String phrase;
    public final MatchType matchType;
    public final Category category;
    public final boolean requiresAdContext;
    public final boolean builtIn;
    public final boolean enabled;
    public final String packageName;

    public Rule(String id, String phrase, MatchType matchType, Category category,
                boolean requiresAdContext, boolean builtIn, boolean enabled, String packageName) {
        this.id = id;
        this.phrase = phrase;
        this.matchType = matchType;
        this.category = category;
        this.requiresAdContext = requiresAdContext;
        this.builtIn = builtIn;
        this.enabled = enabled;
        this.packageName = packageName == null ? "" : packageName;
    }

    public static Rule custom(String phrase, MatchType matchType, boolean requiresAdContext,
                              String packageName) {
        return new Rule(UUID.randomUUID().toString(), phrase, matchType, Category.CUSTOM,
                requiresAdContext, false, true, packageName);
    }

    /** Rule that targets a view-id fragment, for close buttons rendered as pure images. */
    public static Rule idRule(String idFragment, String packageName) {
        return new Rule(UUID.randomUUID().toString(), idFragment, MatchType.ID, Category.CUSTOM,
                true, false, true, packageName);
    }

    public Rule withEnabled(boolean value) {
        return new Rule(id, phrase, matchType, category, requiresAdContext, builtIn, value, packageName);
    }

    public boolean matches(NodeModel node) {
        String expected = NodeModel.normalize(phrase);
        if (expected.isEmpty()) return false;
        if (matchType == MatchType.ID) {
            String id = NodeModel.normalize(node.viewId);
            if (id.isEmpty()) return false;
            return id.contains(expected) || id.endsWith(expected);
        }
        return matchesValue(node.normalizedText(), expected)
                || matchesValue(node.normalizedDescription(), expected);
    }

    private boolean matchesValue(String actual, String expected) {
        if (actual.isEmpty()) return false;
        return matchType == MatchType.EXACT ? actual.equals(expected) : actual.contains(expected);
    }
}
