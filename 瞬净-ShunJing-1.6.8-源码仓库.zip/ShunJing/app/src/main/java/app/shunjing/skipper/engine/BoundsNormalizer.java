package app.shunjing.skipper.engine;

import java.util.ArrayList;
import java.util.List;

/**
 * v1.5.3: 把"窗口坐标系"的控件树平移回屏幕坐标系。
 *
 * <p>分屏、应用双开、外接屏、以及部分 ROM 的多窗口实现，会让 {@code getBoundsInScreen}
 * 返回的坐标整体落在屏幕之外。优量汇的 {@code PortraitADActivity} 现场就是这样：
 * 屏幕 1272×2772，整棵广告树的 x 却从 1272 起步（[1272,0 → 2544,2772]）。
 *
 * <p>几何判断（角落、面积占比、坐标点击）全部按屏幕宽度算，坐标一旦错位就全部失效，
 * 表现就是"明明右上角有个叉，它就是不动"。这里只做平移，不缩放：当某个可见节点整个
 * 落在屏幕右/下方之外时，把以它为根的子树挪回原点，其余节点不受影响。
 *
 * <p>只在节点自身（含已累计的父偏移）仍然越界时才平移，所以正常的全屏页面一次都不会触发。
 */
public final class BoundsNormalizer {

    private BoundsNormalizer() { }

    public static List<NodeModel> toScreen(List<NodeModel> nodes, int screenWidth, int screenHeight) {
        if (nodes == null || nodes.isEmpty() || screenWidth <= 0 || screenHeight <= 0) return nodes;
        int n = nodes.size();
        int[] dx = new int[n];
        int[] dy = new int[n];
        boolean shifted = false;
        List<NodeModel> result = null;

        for (int i = 0; i < n; i++) {
            NodeModel node = nodes.get(i);
            int parentDx = 0, parentDy = 0;
            int parent = node.parentIndex;
            if (parent >= 0 && parent < n) {
                parentDx = dx[parent];
                parentDy = dy[parent];
            }
            int left = node.left + parentDx;
            int top = node.top + parentDy;
            int ddx = 0, ddy = 0;
            if (node.visible && node.hasBounds()) {
                if (left >= screenWidth) ddx = -left;
                if (top >= screenHeight) ddy = -top;
            }
            dx[i] = parentDx + ddx;
            dy[i] = parentDy + ddy;
            if (ddx != 0 || ddy != 0) shifted = true;
        }

        if (!shifted) return nodes;
        result = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            NodeModel node = nodes.get(i);
            if (dx[i] == 0 && dy[i] == 0) {
                result.add(node);
            } else {
                result.add(new NodeModel(node.index, node.parentIndex, node.text,
                        node.contentDescription, node.viewId, node.className, node.clickable,
                        node.visible, node.password, node.left + dx[i], node.top + dy[i],
                        node.right + dx[i], node.bottom + dy[i]));
            }
        }
        return result;
    }
}
