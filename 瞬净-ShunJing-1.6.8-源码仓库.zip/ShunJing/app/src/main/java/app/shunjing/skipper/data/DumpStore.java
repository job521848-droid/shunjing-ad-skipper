package app.shunjing.skipper.data;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

import app.shunjing.skipper.engine.NodeModel;
import app.shunjing.skipper.engine.PageDump;

/** Stores captured page dumps in the app-private files dir. No external storage, no network. */
public final class DumpStore {
    public static final int KEEP_MIN = 3;
    public static final int KEEP_MAX = 40;
    private static final int KEEP_DEFAULT = 10;
    private static final String PREFIX = "dump_";
    private static final String EXT = ".json";

    /** Lightweight list entry parsed from the file name; the tree is read only when opened. */
    public static final class Meta {
        public final File file;
        public final long time;
        public final String source;
        public final String packageName;
        public final int nodeCount;

        Meta(File file, long time, String source, String packageName, int nodeCount) {
            this.file = file;
            this.time = time;
            this.source = source;
            this.packageName = packageName;
            this.nodeCount = nodeCount;
        }
    }

    private final Context context;
    /** v1.5.6: 保留份数。诊断页每条都要读文件 + 跑一遍引擎，份数越多打开越慢。 */
    private int keepLimit = KEEP_DEFAULT;

    public DumpStore(Context context) {
        this.context = context.getApplicationContext();
    }

    public void setKeepLimit(int limit) {
        keepLimit = RetentionPolicy.clamp(limit, KEEP_MIN, KEEP_MAX);
    }

    /** 立即按当前上限裁剪（改完设置后调用）。 */
    public synchronized void pruneNow() {
        trim(dir());
    }

    private File dir() {
        File dir = new File(context.getFilesDir(), "dumps");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    public synchronized PageDump save(PageDump dump) {
        File dir = dir();
        JSONObject root = new JSONObject();
        try {
            root.put("version", 1);
            root.put("id", dump.id);
            root.put("time", dump.time);
            root.put("packageName", dump.packageName);
            root.put("activityName", dump.activityName);
            root.put("appLabel", dump.appLabel);
            root.put("source", dump.source);
            root.put("screenWidth", dump.screenWidth);
            root.put("screenHeight", dump.screenHeight);
            root.put("launchedRecently", dump.launchedRecently);
            JSONArray nodes = new JSONArray();
            for (NodeModel n : dump.nodes) {
                JSONObject item = new JSONObject();
                item.put("i", n.index);
                item.put("p", n.parentIndex);
                // Password fields are never persisted in clear text.
                item.put("t", n.password ? "" : n.text);
                item.put("d", n.password ? "" : n.contentDescription);
                item.put("id", n.viewId);
                item.put("c", n.className);
                item.put("cl", n.clickable);
                item.put("v", n.visible);
                item.put("pw", n.password);
                item.put("l", n.left);
                item.put("tp", n.top);
                item.put("r", n.right);
                item.put("bt", n.bottom);
                nodes.put(item);
            }
            root.put("nodes", nodes);
        } catch (JSONException e) {
            return dump;
        }

        String source = sourceToken(dump.source);
        String name = PREFIX + dump.time + "_" + source + "_" + dump.nodes.size()
                + "_" + hex(dump.packageName) + "_" + UUID.randomUUID().toString().substring(0, 6) + EXT;
        File target = new File(dir, name);
        try (FileOutputStream out = new FileOutputStream(target)) {
            out.write(root.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) {
            return dump;
        }
        trim(dir);
        return dump;
    }

    public synchronized List<Meta> list() {
        List<Meta> result = new ArrayList<>();
        File[] files = dir().listFiles((d, n) -> n.startsWith(PREFIX) && n.endsWith(EXT));
        if (files == null) return result;
        for (File file : files) {
            String stem = file.getName().substring(PREFIX.length());
            int end = stem.lastIndexOf(EXT);
            if (end > 0) stem = stem.substring(0, end);
            String[] parts = stem.split("_");
            if (parts.length < 4) continue;
            try {
                long time = Long.parseLong(parts[0]);
                String source = sourceFromToken(parts[1]);
                int count = Integer.parseInt(parts[2]);
                String pkg = unhex(parts[3]);
                result.add(new Meta(file, time, source, pkg, count));
            } catch (RuntimeException ignored) { }
        }
        Collections.sort(result, Comparator.comparingLong((Meta m) -> m.time).reversed());
        return result;
    }

    public synchronized PageDump load(File file) {
        StringBuilder builder = new StringBuilder();
        try (FileInputStream in = new FileInputStream(file)) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) > 0) builder.append(new String(buffer, 0, read, StandardCharsets.UTF_8));
        } catch (Exception e) {
            return null;
        }
        try {
            JSONObject root = new JSONObject(builder.toString());
            JSONArray array = root.getJSONArray("nodes");
            List<NodeModel> nodes = new ArrayList<>();
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.getJSONObject(i);
                nodes.add(new NodeModel(item.optInt("i"), item.optInt("p", -1),
                        item.optString("t", ""), item.optString("d", ""),
                        item.optString("id", ""), item.optString("c", ""),
                        item.optBoolean("cl", false), item.optBoolean("v", true),
                        item.optBoolean("pw", false), item.optInt("l"), item.optInt("tp"),
                        item.optInt("r"), item.optInt("bt")));
            }
            return new PageDump(root.optString("id", file.getName()), root.optLong("time"),
                    root.optString("packageName", ""), root.optString("activityName", ""),
                    root.optString("appLabel", ""),
                    root.optString("source", PageDump.SOURCE_MANUAL),
                    root.optInt("screenWidth"), root.optInt("screenHeight"),
                    root.optBoolean("launchedRecently", false), nodes);
        } catch (JSONException e) {
            return null;
        }
    }

    public synchronized PageDump load(Meta meta) { return load(meta.file); }

    public synchronized void delete(File file) {
        try { file.delete(); } catch (SecurityException ignored) { }
    }

    public synchronized void clear() {
        File[] files = dir().listFiles((d, n) -> n.startsWith(PREFIX) && n.endsWith(EXT));
        if (files != null) for (File file : files) file.delete();
    }

    public synchronized int count() {
        File[] files = dir().listFiles((d, n) -> n.startsWith(PREFIX) && n.endsWith(EXT));
        return files == null ? 0 : files.length;
    }

    private void trim(File dir) {
        File[] files = dir.listFiles((d, n) -> n.startsWith(PREFIX) && n.endsWith(EXT));
        if (files == null || files.length <= keepLimit) return;
        List<File> sorted = new ArrayList<>();
        Collections.addAll(sorted, files);
        // 按文件名里的毫秒时间戳排序（新 → 旧）。lastModified 只到秒，同一秒抓两份会乱序，
        // 一旦排反就会把最新的删掉、留下最旧的。
        Collections.sort(sorted, (a, b) -> Long.compare(stampOf(b), stampOf(a)));
        for (File file : RetentionPolicy.oldestBeyond(sorted, keepLimit)) file.delete();
    }

    private static long stampOf(File file) {
        String name = file.getName();
        int cut = name.indexOf('_');
        if (cut > PREFIX.length()) {
            try {
                return Long.parseLong(name.substring(PREFIX.length(), cut));
            } catch (NumberFormatException ignored) { }
        }
        return file.lastModified();
    }

    private static String sourceToken(String source) {
        if (PageDump.SOURCE_AUTO.equals(source)) return "auto";
        if (PageDump.SOURCE_NEXT.equals(source)) return "next";
        return "manual";
    }

    private static String sourceFromToken(String token) {
        if ("auto".equals(token)) return PageDump.SOURCE_AUTO;
        if ("next".equals(token)) return PageDump.SOURCE_NEXT;
        return PageDump.SOURCE_MANUAL;
    }

    private static final char[] HEX = "0123456789abcdef".toCharArray();

    private static String hex(String value) {
        if (value == null || value.isEmpty()) return "00";
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        StringBuilder b = new StringBuilder(bytes.length * 2);
        for (byte v : bytes) {
            b.append(HEX[(v >> 4) & 0xF]).append(HEX[v & 0xF]);
        }
        return b.toString();
    }

    private static String unhex(String value) {
        if (value == null || "00".equals(value) || value.length() % 2 != 0) return "";
        byte[] bytes = new byte[value.length() / 2];
        for (int i = 0; i < bytes.length; i++) {
            int hi = Character.digit(value.charAt(i * 2), 16);
            int lo = Character.digit(value.charAt(i * 2 + 1), 16);
            if (hi < 0 || lo < 0) return "";
            bytes[i] = (byte) ((hi << 4) | lo);
        }
        return new String(bytes, StandardCharsets.UTF_8);
    }
}
