package app.shunjing.skipper.engine;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Offline "expert system" that explains why an ad was not skipped and produces verified fixes.
 * Pure Java (no Android dependency) so the whole reasoning chain is unit-testable.
 */
public final class DumpAnalyzer {
    private static final String[] CLOSE_HINTS = {
            "跳过", "skip", "关闭", "close", "×", "✕", "✖", "不感兴趣", "略过", "忽略",
            "dismiss", "nothanks", "不再显示", "关闭弹窗", "关闭悬浮"
    };
    private static final String[] STRONG_SKIP = {
            "跳过广告", "跳过此广告", "跳过本广告", "关闭广告", "关闭此广告", "skipad", "skip", "跳过"
    };
    private static final String[] AD_ID_HINTS = {
            "ad_close", "adclose", "close_ad", "ad_skip", "splash_skip", "skip", "close",
            "splash", "advert", "ad_view", "ad_container", "tt_", "ksad", "gdt_", "csj", "pangolin"
    };
    private static final String[] AD_TEXT_HINTS = {
            "广告", "advertisement", "sponsored", "推广", "赞助", "不感兴趣", "为什么会看到",
            "打开第三方", "跳转第三方", "下载应用", "摇一摇", "扭一扭", "限时福利"
    };
    private static final String[] REWARD_HINTS = {
            "激励视频", "观看视频得", "看视频得", "领取奖励", "获得奖励", "奖励翻倍"
    };
    private static final String[] SENSITIVE_HINTS = {
            "扫码", "扫一扫", "二维码", "付款码", "支付密码", "验证码", "输入密码", "授权登录", "确认支付"
    };

    public Diagnosis analyze(PageDump dump, List<Rule> rules, EngineSettings settings,
                             boolean masterEnabled, boolean appEnabled) {
        return analyze(dump, rules, settings, masterEnabled, appEnabled,
                java.util.Collections.<LayoutAnchorRule>emptyList());
    }

    public Diagnosis analyze(PageDump dump, List<Rule> rules, EngineSettings settings,
                             boolean masterEnabled, boolean appEnabled,
                             List<LayoutAnchorRule> anchors) {
        ScreenModel screen = new ScreenModel(dump.packageName, dump.activityName,
                dump.launchedRecently,
                BoundsNormalizer.toScreen(dump.nodes, dump.screenWidth, dump.screenHeight));
        List<String> evidence = new ArrayList<>();
        boolean sensitive = AdDecisionEngine.isSensitive(screen);
        boolean protectedPackage = AdDecisionEngine.isProtectedPackage(dump.packageName);
        boolean textAdContext = AdDecisionEngine.hasAdContext(screen);
        boolean adContext = AdDecisionEngine.hasAdContext(screen, settings);
        boolean rewarded = AdDecisionEngine.hasRewardContext(screen, settings);
        List<String> structuralSignals = settings.structuralAdEvidence
                ? StructuralAdEvidence.signals(screen) : new ArrayList<String>();

        evidence.add("页面 " + dump.packageName + " / " + shortActivity(dump.activityName));
        evidence.add("控件 " + dump.nodes.size() + " 个，其中带文字或描述的 "
                + dump.labeledNodeCount() + " 个");
        evidence.add(adContext ? "✓ 已检测到广告上下文" : "✗ 页面上未找到广告上下文");
        if (!textAdContext && !structuralSignals.isEmpty()) {
            evidence.add("✓ 结构性广告证据：" + String.join(" + ", structuralSignals));
        }
        if (sensitive) evidence.add("✗ 命中敏感页面保护词");
        if (rewarded) evidence.add("· 激励视频 / 奖励场景（策略："
                + rewardModeLabel(settings.rewardMode) + "）");
        if (!masterEnabled) evidence.add("✗ 自动跳过总开关处于关闭状态");
        if (!appEnabled) evidence.add("✗ 该应用已在应用管理里单独停用");
        if (protectedPackage) evidence.add("✗ 系统界面或瞬净自身，默认不处理");

        List<Diagnosis.Candidate> candidates = findCandidates(dump);
        WebAdTemplateLocator.Hit templateHit = AdDecisionEngine.isLauncherPackage(dump.packageName)
                ? null
                : WebAdTemplateLocator.find(screen, dump.screenWidth, dump.screenHeight);
        if (templateHit != null && !containsIndex(candidates, templateHit.nodeIndex)) {
            NodeModel node = dump.nodes.get(templateHit.nodeIndex);
            candidates.add(new Diagnosis.Candidate(templateHit.nodeIndex,
                    "模板广告关闭键（与「反馈」同排）" + simpleClass(node.className),
                    node.viewId, bounds(node), node.clickable,
                    AdDecisionEngine.findClickableAncestor(dump.nodes, node) >= 0, false));
        }
        if (!candidates.isEmpty()) evidence.add("定位到 " + candidates.size() + " 个疑似关闭控件");

        // Hard blockers first — never suggest weakening these.
        if (!masterEnabled) {
            return build(Diagnosis.Verdict.MASTER_OFF, "总开关没开，识别没有运行",
                    "本次页面不会被扫描，任何规则都不会生效。", evidence, candidates,
                    blockersMaster(dump), adContext, sensitive);
        }
        if (!appEnabled) {
            return build(Diagnosis.Verdict.APP_DISABLED, "这个应用被单独停用了",
                    "在应用管理中把它重新启用即可恢复自动跳过。", evidence, candidates,
                    blockersApp(dump), adContext, sensitive);
        }
        if (AdDecisionEngine.isLauncherPackage(dump.packageName)) {
            evidence.add("✗ 系统桌面 / 最近任务：不是广告页面，按包名硬保护");
            return build(Diagnosis.Verdict.LAUNCHER, "这是系统桌面（最近任务），不是广告页",
                    "快照里没有任何广告控件：卡片头部点一下会切到那个应用，「更多」是卡片菜单，"
                            + "缩略图整屏铺开。任何“关闭按钮”识别在这里都只会点错东西，"
                            + "所以按包名硬锁定，连自动留样都不做。"
                            + "若这是摇一摇广告跳转后留下的画面，说明采样比广告晚了 1~2 秒。",
                    evidence, candidates, launcherAdvice(dump), adContext, sensitive);
        }
        if (protectedPackage || sensitive) {
            return build(Diagnosis.Verdict.PROTECTED, "敏感 / 系统页面，已主动锁定",
                    "这是防误触设计：扫码、二维码、支付、密码、验证码、授权登录等页面一律不自动点击，"
                            + "以免把你正常功能里的叉号当成广告关掉。不建议为此放宽保护。",
                    evidence, candidates, protectedAdvice(dump), adContext, sensitive);
        }
        if (rewarded && !settings.allowsRewardedClose(dump.packageName,
                StructuralAdEvidence.hasVisibleEndCard(screen))) {
            boolean endCard = StructuralAdEvidence.hasVisibleEndCard(screen);
            String headline = endCard ? "结束卡已出现，但策略仍拦截" : "激励视频保护生效";
            String explanation = endCard
                    ? "视频播放结束卡片已出现，奖励通常已到账。若想此时自动关闭，可切换为「播完再关」。"
                    : "当前策略为「" + rewardModeLabel(settings.rewardMode)
                    + "」。默认不自动关闭播放中的激励视频，避免你拿不到奖励；若你愿意放弃奖励，可切换策略或只为此应用开启。";
            return build(Diagnosis.Verdict.REWARDED, headline, explanation,
                    evidence, candidates, rewardedAdvice(dump, rules, settings), adContext, sensitive);
        }

        AdDecisionEngine engine = new AdDecisionEngine();
        Decision decision = engine.evaluate(screen, rules, settings, anchors,
                dump.screenWidth, dump.screenHeight);
        if (decision.type == Decision.Type.CLICK) {
            NodeModel hit = dump.nodes.get(decision.nodeIndex);
            if ("web_ad_template_close".equals(decision.ruleId)) {
                evidence.add("✓ 模板对偶定位命中控件 #" + decision.nodeIndex + "（"
                        + decision.reason + "）");
                return build(Diagnosis.Verdict.SKIPPABLE,
                        "找到了：模板广告的「反馈 ⟷ 关闭」对偶键",
                        "整页是穿山甲 WebView 模板，59 个节点全部 c=0，没有一处「关闭 / ×」字样，"
                                + "所以文字规则一条都打不中。模板把「反馈」画在卡片顶部条左侧，"
                                + "关闭键画在同一排最右侧，两者垂直中心对齐——这是《广告法》要求"
                                + "「广告应显著标明关闭标志」后各 SDK 固化的版式。v1.5.1 按这对关系"
                                + "定位到 #" + decision.nodeIndex + "，用该控件自身范围做一次坐标手势。"
                                + "注意本页还写着「点击或上滑打开」，所以只会点这一个小图标，"
                                + "绝不在整屏乱点；万一模板把它换成了「更多」，2.2 秒内被拽走会自动退回。",
                        evidence, candidates, templateAdvice(dump, decision.nodeIndex), adContext,
                        sensitive);
            }
            evidence.add("✓ 当前规则已命中控件 #" + decision.nodeIndex
                    + "（" + decision.reason + "，文字「" + preview(hit.text) + "」）");
            return build(Diagnosis.Verdict.SKIPPABLE, "规则其实已经覆盖这个控件",
                    "按当前规则本应自动点击。v1.3 会验证点击后页面是否真的变化：倒计时数字变化不算成功，"
                            + "连续失败会补一次坐标手势并进入本地/云端复核。若仍失败，常见原因是两阶段关闭、"
                            + "ACTION_CLICK 被广告 SDK 吞掉，或控件渲染晚于当前快照。",
                    evidence, candidates, timingAdvice(dump, rules, settings), adContext, sensitive);
        }

        boolean anyReadable = hasReadableCloseControl(dump, candidates);
        if (!anyReadable) {
            return build(Diagnosis.Verdict.NO_TEXT_IMAGE_ONLY, "纯图片 / 无可读文字的关闭控件",
                    "页面上找不到带文字或描述的跳过按钮，很可能是纯图片叉号或 WebView 自绘控件，"
                            + "文字规则无法覆盖。下面按控件位置与 ID 特征给出可行方案。",
                    evidence, candidates, imageOnlyAdvice(dump, rules, settings, candidates),
                    adContext, sensitive);
        }

        List<Suggestion> suggestions = new ArrayList<>();
        Set<String> seenPhrases = new HashSet<>();
        boolean masked = false;
        for (Diagnosis.Candidate candidate : candidates) {
            NodeModel node = dump.nodes.get(candidate.index);
            String raw = !node.text.trim().isEmpty() ? node.text : node.contentDescription;
            // 脱敏现场里文字被替换成「[文字已隐藏·长度2]」。它看起来像个能用的词，
            // 实际永远匹配不到任何控件——照它加规则等于加一条死规则。
            if (isMaskedText(raw)) { masked = true; continue; }
            String phrase = cleanPhrase(raw);
            if (!phrase.isEmpty() && seenPhrases.add(phrase.toLowerCase(Locale.ROOT))) {
                boolean strong = isStrongSkip(phrase);
                // Strong ad words may fire globally; everything else stays app-scoped and
                // still requires independent ad evidence. Relaxation is a separate, explicit choice.
                boolean needsContext = !strong;
                Rule rule = Rule.custom(phrase, phrase.length() <= 2 ? Rule.MatchType.EXACT : Rule.MatchType.CONTAINS,
                        needsContext, strong ? "" : dump.packageName);
                boolean ok = verify(dump, rules, settings, rule);
                if (ok) {
                    suggestions.add(Suggestion.withRule(Suggestion.Kind.ADD_PHRASE,
                            "添加关闭词「" + phrase + "」",
                            (strong ? "该词本身含明确广告语义，可直接触发，反应最快。"
                                    : "限定仅在此应用生效，并要求页面存在广告线索，避免误点其他软件。")
                                    + " 已回验：加入后能命中控件 #" + candidate.index + "。",
                            strong ? "全局生效，但该词含义明确，误触概率低。"
                                    : "仅限 " + dump.packageName + "；扫码、支付等敏感页面仍强制保护。",
                            rule, true));
                }
            }
            if (candidate.idLooksLikeAd) {
                String idFragment = idFragment(node.viewId);
                if (!idFragment.isEmpty() && seenPhrases.add("id:" + idFragment)) {
                    Rule idRule = Rule.idRule(idFragment, dump.packageName);
                    if (verify(dump, rules, settings, idRule)) {
                        suggestions.add(Suggestion.withRule(Suggestion.Kind.ADD_ID_RULE,
                                "按控件 ID 识别「" + idFragment + "」",
                                "这个关闭按钮即使没有文字，也能靠稳定的控件 ID 命中。已回验有效，且仅在此应用生效。",
                                "仅限 " + dump.packageName + "；仍要求页面存在广告线索。",
                                idRule, true));
                    }
                }
            }
        }

        if (suggestions.isEmpty() && !adContext) {
            Diagnosis.Candidate symbol = firstSymbolCandidate(dump, candidates);
            if (symbol != null) {
                NodeModel node = dump.nodes.get(symbol.index);
                String phrase = cleanPhrase(!node.text.trim().isEmpty() ? node.text : node.contentDescription);
                if (phrase.isEmpty()) phrase = "×";
                Rule relaxed = Rule.custom(phrase,
                        phrase.length() <= 2 ? Rule.MatchType.EXACT : Rule.MatchType.CONTAINS,
                        false, dump.packageName);
                if (verify(dump, rules, settings, relaxed)) {
                    suggestions.add(Suggestion.withRule(Suggestion.Kind.RELAX_FOR_APP,
                            "仅为此应用放宽：无需广告证据",
                            "页面没有广告字样，所以保守策略没敢点。这条规则只对 "
                                    + dump.packageName + " 生效，跳过广告证据检查。已回验有效。",
                            "风险较高：该应用里普通弹窗的关闭按钮也可能被点。请确认这个应用不会在扫码/支付页出现同类叉号后再启用；敏感页面仍强制保护。",
                            relaxed, true));
                }
            }
        }

        addScopeSuggestions(dump, rules, suggestions);
        if (!settings.closeIconsEnabled) {
            suggestions.add(Suggestion.withToggle(Suggestion.Kind.TOGGLE_CLOSE_ICONS,
                    "开启「通用叉号识别」",
                    "当前已关闭通用叉号识别，带广告上下文的 × / 关闭 不会触发。",
                    "开启后仍要求广告上下文，不会在普通页面乱点。", "close_icons"));
        }
        if (suggestions.isEmpty() && masked) {
            suggestions.add(Suggestion.info("这条现场的文字被脱敏了，加不出能用的词",
                    "控件文字都变成了「[文字已隐藏·长度N]」，它不是真实文案，照它加规则永远不会命中。"
                            + "关掉导出时的脱敏重新抓一次（广告还在屏幕上时抓），或者把这份控件树直接发给开发者。"));
        }
        if (suggestions.isEmpty()) {
            suggestions.add(Suggestion.info("未找到可直接回验的规则",
                    "控件可能不可点击、被父容器拦截或渲染时机过晚。建议导出结构化报告做进一步分析。"));
        }
        suggestions.add(Suggestion.action(Suggestion.Kind.EXPORT_AI, "交给 AI 深度分析",
                "导出含完整控件树的结构化报告，粘贴给任意大模型获取更细的方案。"));

        Diagnosis.Verdict verdict = adContext ? Diagnosis.Verdict.NO_MATCHING_RULE
                : Diagnosis.Verdict.NO_AD_EVIDENCE;
        String headline = adContext ? "页面有广告，但关闭按钮没被规则覆盖"
                : "页面没有广告证据，保守策略没敢点";
        String explanation = adContext
                ? "广告特征已存在，缺的是能匹配该关闭控件的规则。下面每条建议都已重新跑过识别引擎验证。"
                : "为防误触，单独的「× / 关闭」必须搭配广告证据才会点击。若你确认这就是广告页，可添加限定应用的规则。";
        return build(verdict, headline, explanation, evidence, candidates, suggestions, adContext, sensitive);
    }

    // ---------------------------------------------------------------- candidates

    public static List<Diagnosis.Candidate> findCandidates(PageDump dump) {
        List<Diagnosis.Candidate> result = new ArrayList<>();
        int w = dump.screenWidth > 0 ? dump.screenWidth : 1080;
        int h = dump.screenHeight > 0 ? dump.screenHeight : 2400;
        for (int i = 0; i < dump.nodes.size(); i++) {
            NodeModel node = dump.nodes.get(i);
            if (!node.visible || node.password || !node.hasBounds()) continue;
            if (looksLikeBack(node)) continue;
            String text = node.normalizedText();
            String desc = node.normalizedDescription();
            String id = node.viewId.toLowerCase(Locale.ROOT);
            boolean closeText = containsAny(text, CLOSE_HINTS) || containsAny(desc, CLOSE_HINTS)
                    || isCloseSymbol(text) || isCloseSymbol(desc);
            boolean idAd = containsAny(id, AD_ID_HINTS);
            boolean cornerSmall = isCornerSmall(node, w, h);
            if (!closeText && !idAd && !cornerSmall) continue;
            boolean ancestor = AdDecisionEngine.findClickableAncestor(dump.nodes, node) >= 0;
            // v1.6.5：候选编号必须用「在列表里的位置」，不能用 node.index ——
            // 后者来自解析时的编号，导出的快照里与位置一致，但手工构造/合并过的
            // 控件树可能不一致，越界一次就让整份诊断崩掉。
            result.add(new Diagnosis.Candidate(i, label(node, closeText, w, h),
                    node.viewId, bounds(node), node.clickable, ancestor, idAd));
        }
        return result;
    }

    /**
     * v1.6.4: 返回 / 导航类 ID。
     *
     * <p>它们是左上角的小方块，几何上和「广告角落关闭键」完全一样。胖乖生活那份抓取里，
     * 真正的 × 在右下角（不在树里），被列成"疑似关闭控件"的 #13 其实是 id=view_back
     * 的返回箭头 —— 按它点一次就直接退出页面。这类误报比漏报更糟，必须在候选阶段就排掉。
     */
    private static final String[] BACK_ID_HINTS = {
            "view_back", "iv_back", "btn_back", "img_back", "icon_back", "back_icon",
            "back_btn", "toolbar_back", "action_back", "navigation_back", "ab_back",
            "widget_back", "layout_back", "close_page", "exit_page"
    };

    private static boolean looksLikeBack(NodeModel node) {
        String id = node.viewId.toLowerCase(Locale.ROOT);
        // 注意：没有 id 时不能直接放过 —— 返回箭头经常是个纯 View，id 都没有。
        if (!id.isEmpty() && !id.contains("background") && containsAny(id, BACK_ID_HINTS)) return true;
        // 没写 id、但贴在左上角的"干净"小方块：返回箭头的典型长相。
        // 只在它贴近屏幕左边缘（≤3%）且接近正方形时排除，避免误伤真正的左上角关闭键。
        int width = node.right - node.left;
        int height = node.bottom - node.top;
        return node.left <= 4 && width > 0 && height > 0
                && Math.abs(width - height) <= Math.max(width, height) * 0.25;
    }

    private static boolean isCornerSmall(NodeModel node, int w, int h) {
        int width = node.right - node.left;
        int height = node.bottom - node.top;
        if (width <= 0 || height <= 0) return false;
        boolean small = width <= w * 0.18f && height <= h * 0.09f;
        boolean rightSide = node.left >= w * 0.68f;
        boolean leftSide = node.right <= w * 0.32f;
        if (!small || !(rightSide || leftSide)) return false;
        // v1.6.5：以前只认上半屏。下载类广告的 × 在合规条上方、屏幕右下角（约 90% 高度处），
        // 于是"有 × 却说没有角落小控件"。上下两带都收，左右不变。
        boolean top = node.top <= h * 0.22f;
        // 下半屏只收"读了也读不出东西"的纯图标。合规条里那个写着「广告」的角标同样贴在
        // 右下角、同样是 56×38 的小方块，把它算成关闭候选，会让整份报告走进"有可读文字"
        // 的分支，反而掩盖真正的问题。
        boolean bottom = node.top >= h * 0.78f
                && node.normalizedText().isEmpty() && node.normalizedDescription().isEmpty();
        return top || bottom;
    }

    private static String label(NodeModel node, boolean closeText, int w, int h) {
        String raw = !node.text.trim().isEmpty() ? node.text.trim() : node.contentDescription.trim();
        if (!raw.isEmpty()) return "「" + preview(raw) + "」 " + simpleClass(node.className);
        if (closeText) return "无文字关闭控件 " + simpleClass(node.className);
        // 以前不论左右都写「右上角」，把左上角的返回键也这么叫，读报告的人会直接点错。
        boolean rightSide = (node.left + node.right) / 2f >= w * 0.5f;
        boolean bottomSide = (node.top + node.bottom) / 2f >= h * 0.5f;
        return (bottomSide ? (rightSide ? "右下角" : "左下角") : (rightSide ? "右上角" : "左上角"))
                + "小控件 " + simpleClass(node.className);
    }

    private static String bounds(NodeModel node) {
        return "[" + node.left + "," + node.top + " → " + node.right + "," + node.bottom + "]";
    }

    private static boolean hasReadableCloseControl(PageDump dump, List<Diagnosis.Candidate> candidates) {
        for (Diagnosis.Candidate c : candidates) {
            NodeModel n = dump.nodes.get(c.index);
            // Only human-readable labels count here; id-only image buttons belong to the
            // NO_TEXT_IMAGE_ONLY branch, which still produces id-based rules.
            if (!n.normalizedText().isEmpty() || !n.normalizedDescription().isEmpty()) return true;
        }
        return false;
    }

    private static Diagnosis.Candidate firstSymbolCandidate(PageDump dump, List<Diagnosis.Candidate> candidates) {
        for (Diagnosis.Candidate c : candidates) {
            if (!c.hasClickableAncestor && !c.clickable) continue;
            NodeModel n = dump.nodes.get(c.index);
            String t = n.normalizedText() + n.normalizedDescription();
            if (t.isEmpty() || t.equals("x") || t.contains("close") || t.contains("关闭")) return c;
        }
        return null;
    }

    // ---------------------------------------------------------------- suggestions

    private List<Suggestion> blockersMaster(PageDump dump) {
        List<Suggestion> list = new ArrayList<>();
        list.add(Suggestion.withToggle(Suggestion.Kind.TOGGLE_MASTER, "开启自动跳过总开关",
                "开启后立即恢复扫描与识别。", "", "master"));
        list.add(Suggestion.action(Suggestion.Kind.EXPORT_AI, "交给 AI 深度分析", "导出结构化报告。"));
        return list;
    }

    private List<Suggestion> blockersApp(PageDump dump) {
        List<Suggestion> list = new ArrayList<>();
        list.add(Suggestion.action(Suggestion.Kind.ENABLE_APP, "重新启用 " + dump.packageName,
                "在应用管理中恢复该应用的自动跳过。"));
        list.add(Suggestion.action(Suggestion.Kind.EXPORT_AI, "交给 AI 深度分析", "导出结构化报告。"));
        return list;
    }

    private List<Suggestion> templateAdvice(PageDump dump, int index) {
        List<Suggestion> list = new ArrayList<>();
        list.add(Suggestion.info("这条规则不需要你手动添加",
                "「H5 模板广告定位」在识别与点击里默认开启（安静模式除外）。它只在广告上下文成立、"
                        + "且所有文字规则都落空时才工作，所以不会影响你现在已经生效的那些跳过词。"));
        list.add(Suggestion.info("为什么不能改成点整屏",
                "本页底部写着「点击或上滑打开」，点错任意一处都会跳去落地页或第三方应用。"
                        + "所以规则只认「与反馈同排、贴右边缘、无文字、小尺寸」这一枚图标（本次是 #"
                        + index + "），一个像素都不外扩。"));
        list.add(Suggestion.info("能力边界",
                "如果某个 SDK 的模板既没有「反馈」对偶、也没有「广告」角标或模板 id，"
                        + "本应用不会猜位置。这类页面请开启云端视觉 AI，由截图识别兜底。"));
        list.add(Suggestion.action(Suggestion.Kind.OPEN_SETTINGS, "打开守护设置",
                "确认「H5 模板广告定位」为开启状态。"));
        return list;
    }

    private static boolean containsIndex(List<Diagnosis.Candidate> candidates, int index) {
        for (Diagnosis.Candidate c : candidates) if (c.index == index) return true;
        return false;
    }

    private List<Suggestion> launcherAdvice(PageDump dump) {
        List<Suggestion> list = new ArrayList<>();
        list.add(Suggestion.info("这类页面不需要任何规则",
                "最近任务列表永远不该被当成广告页。给它加关闭词或 ID 规则，等于让引擎去点卡片头部"
                        + "（直接切到别的应用）或「更多」菜单（分屏 / 锁定 / 移除卡片）。"
                        + "所以桌面包整个列入硬保护，规则、几何定位、留样都不生效。"));
        list.add(Suggestion.info("摇一摇广告要治的是“跳转”，不是跳转之后的页面",
                "现在：只要在广告页看到「摇一摇 / 扭一扭 / 摇动手机」并伴随跳转类文案，"
                        + "就进入 8 秒待命；一旦真的跳出去（换包，或同包换到 web / h5 落地页），"
                        + "立即按返回退回广告页，再交给本地规则或云端处理。"
                        + "前提是「摇一摇误跳转回退」保持开启。"));
        list.add(Suggestion.info("留样时机要前移",
                "自动留样记录的是“关不掉的那一刻”。这份快照已经落到桌面，说明采样晚了一两秒，"
                        + "抓到的是跳转结果而不是广告本身。复现时请在广告仍停在屏幕上时，"
                        + "用通知栏的「抓取当前页」手动留一屏。"));
        list.add(Suggestion.action(Suggestion.Kind.OPEN_SETTINGS, "打开守护设置",
                "确认「摇一摇误跳转回退」为开启状态。"));
        return list;
    }

    private List<Suggestion> protectedAdvice(PageDump dump) {        List<Suggestion> list = new ArrayList<>();
        list.add(Suggestion.info("这是刻意保护，不建议关闭",
                "你之前特别要求不要把扫码二维码页面的叉号当成广告关掉。此类页面被硬锁定，"
                        + "即使添加自定义词也不会触发。若确认是误判，请把报告导出后人工核对页面内容。"));
        list.add(Suggestion.action(Suggestion.Kind.OPEN_SETTINGS, "查看安全边界设置",
                "在设置中确认始终保护的页面类型。"));
        list.add(Suggestion.action(Suggestion.Kind.EXPORT_AI, "交给 AI 深度分析", "导出结构化报告。"));
        return list;
    }

    private List<Suggestion> rewardedAdvice(PageDump dump, List<Rule> rules, EngineSettings settings) {
        List<Suggestion> list = new ArrayList<>();
        if (settings.rewardMode == EngineSettings.RewardMode.PROTECT) {
            list.add(Suggestion.setRewardMode("改为「播完再关」（推荐）",
                    "只在激励视频结束卡出现后自动关闭，奖励已到账。其余时间不打扰。",
                    "低风险：不会在播放中放弃奖励。", "END_CARD_ONLY"));
        }
        list.add(Suggestion.addRewardApp("仅允许 " + dump.packageName + " 自动放弃奖励",
                "按应用粒度授权：只对这个应用见到关闭控件就关，其他应用仍保留奖励。",
                "该应用的复活、积分或奖励可能无法到账。", dump.packageName));
        list.add(Suggestion.setRewardMode("全局改为「自动放弃」",
                "所有应用的激励视频一律自动关闭。你已确认愿意牺牲奖励换取开屏无感。",
                "高风险：所有应用的奖励都可能无法到账；建议优先用上面按应用授权。", "AUTO_ABANDON"));
        EngineSettings relaxed = settings.withRewardMode(EngineSettings.RewardMode.AUTO_ABANDON);
        Decision previewDecision = new AdDecisionEngine().evaluate(dump.toScreen(), rules, relaxed);
        list.add(Suggestion.info(previewDecision.type == Decision.Type.CLICK
                ? "回验：放宽后当前页面可被跳过" : "回验：放宽后当前页面仍无匹配控件",
                previewDecision.type == Decision.Type.CLICK
                        ? "已模拟放宽策略并重新识别，确认能命中关闭控件。"
                        : "即使放宽策略，页面上也缺少可识别的关闭控件，可能仍需补充关闭词。"));
        list.add(Suggestion.action(Suggestion.Kind.EXPORT_AI, "交给 AI 深度分析", "导出结构化报告。"));
        return list;
    }

    private List<Suggestion> timingAdvice(PageDump dump, List<Rule> rules, EngineSettings settings) {
        List<Suggestion> list = new ArrayList<>();
        boolean structural = settings.structuralAdEvidence
                && !StructuralAdEvidence.signals(dump.toScreen()).isEmpty();
        list.add(Suggestion.info("优先排查两阶段关闭（最常见）",
                "点「跳过」后常弹出「残忍离开 / 放弃奖励」二次确认框，该弹层没有广告字样，"
                        + "会让「需广告上下文」的规则失效。v1.2 已加入结构性广告证据与点击后 1.1 秒内的二次确认跟进，"
                        + "请确认设置里「结构性广告证据」「二次确认跟进」均已开启。"));
        if (structural) {
            list.add(Suggestion.info("✓ 本页结构证据已成立",
                    "已识别 " + String.join(" + ", StructuralAdEvidence.signals(dump.toScreen()))
                            + "，二次确认弹层即使被脱敏也能继承广告上下文。"));
        }
        addScopeSuggestions(dump, rules, list);
        list.add(Suggestion.info("再排查时机与复核设置",
                "v1.3 已修正倒计时事件导致扫描被不断推迟的问题，并支持「跳过」在第 1 秒提前出现。"
                        + "若页面结构特殊，可在守护设置确认「失败后自适应定位」已开启；"
                        + "纯图片或自绘按钮可进一步配置可选云端视觉复核。也请把应用加入电池优化白名单，"
                        + "并确认系统无障碍里「瞬净」仍处于开启状态。"));
        list.add(Suggestion.action(Suggestion.Kind.OPEN_SETTINGS, "打开守护设置", "调整响应间隔与后台保活。"));
        list.add(Suggestion.action(Suggestion.Kind.EXPORT_AI, "交给 AI 深度分析", "导出结构化报告。"));
        return list;
    }

    /** Suggests narrowing any global second-confirmation word down to this package. */
    private void addScopeSuggestions(PageDump dump, List<Rule> rules, List<Suggestion> out) {
        for (Rule rule : rules) {
            if (rule.builtIn || !rule.packageName.isEmpty() || !rule.enabled) continue;
            if (isMaskedText(rule.phrase)) continue;
            if (!isSecondConfirmationWord(rule.phrase)) continue;
            out.add(Suggestion.scopeRule(
                    "将「" + rule.phrase + "」限定到 " + dump.packageName,
                    "该词是激励视频二次确认用语，全局生效会在别的应用里也触发。收窄到本应用后，"
                            + "配合结构性广告证据照样能命中，但不再影响其他软件。",
                    "低风险：只收窄作用域，不关闭敏感页保护、不取消广告上下文要求。",
                    rule.id, dump.packageName));
        }
    }

    private static boolean isSecondConfirmationWord(String phrase) {
        String p = phrase.toLowerCase(Locale.ROOT);
        for (String word : SECOND_CONFIRM_WORDS) if (p.contains(word)) return true;
        return false;
    }

    private static final String[] SECOND_CONFIRM_WORDS = {
            "残忍离开", "放弃奖励", "狠心离开", "坚持退出", "放弃", "离开", "继续观看", "再看"
    };

    private List<Suggestion> imageOnlyAdvice(PageDump dump, List<Rule> rules,
                                              EngineSettings settings,
                                              List<Diagnosis.Candidate> candidates) {
        List<Suggestion> list = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        if (candidates.isEmpty()) {
            // v1.6.4：整页连一个"像关闭键"的控件都没有时，问题通常不在规则，而在这一层
            // 根本没进控件树（SDK 自绘 / 对无障碍隐藏），或者快照抓在广告弹出之前。
            // v1.6.5：先看是不是"叠加式下载广告"——那种页面的关闭键在右下角，旧的四角
            // 判定只认上半屏，于是明明有 × 也被说成"没有广告层"。
            int labeled = 0;
            for (NodeModel n : dump.nodes) {
                if (!n.normalizedText().isEmpty() || !n.normalizedDescription().isEmpty()) labeled++;
            }
            if (OverlayAdEvidence.matches(dump.toScreen())) {
                list.add(Suggestion.info("这是叠加式下载广告，1.6.5 起会自动关",
                        "页面里有监管要求的那行披露（应用名称 / 开发者 / 版本 / 权限详情），"
                                + "再叠加视频素材或下载诱导文案，已经可以被认定为广告。"
                                + "关闭键是右下角那枚无文字的图片，位置固定，"
                                + "新版「叠层弹窗自动定位」会直接按坐标点它 —— 前提是该开关处于开启状态。"));
                list.add(Suggestion.action(Suggestion.Kind.OPEN_SETTINGS, "确认「叠层弹窗自动定位」已开启",
                        "这条路径需要这个开关。"));
            } else {
                list.add(Suggestion.info("这份快照里没有广告层",
                        "整页 " + dump.nodes.size() + " 个控件、带文字的 " + labeled
                                + " 个，四角也没有像关闭键的小图标。"
                                + "广告层可能不在控件树里（SDK 自绘或对无障碍隐藏），"
                                + "或者这张快照抓在广告出现之前。请在广告正在显示时，从通知栏点「抓取当前页」重抓一次；"
                                + "若重抓后仍然找不到，这一层对无障碍不可见，只能交给云端视觉 AI —— 截图能看到它。"));
            }
        }
        for (Diagnosis.Candidate c : candidates) {
            if (c.idLooksLikeAd) {
                String fragment = idFragment(dump.nodes.get(c.index).viewId);
                if (!fragment.isEmpty() && seen.add(fragment)) {
                    Rule idRule = Rule.idRule(fragment, dump.packageName);
                    if (verify(dump, rules, settings, idRule)) {
                        list.add(Suggestion.withRule(Suggestion.Kind.ADD_ID_RULE,
                                "按控件 ID 识别「" + fragment + "」",
                                "图片按钮没有文字，但控件 ID 稳定。已回验加入后能命中。",
                                "仅限 " + dump.packageName + "，并要求广告上下文。", idRule, true));
                    }
                }
            }
        }

        // v1.2: a scoped geometric rule for pure-image close buttons on centered ad cards.
        // Only offered when structural ad evidence actually corroborates the page.
        List<String> signals = settings.structuralAdEvidence
                ? StructuralAdEvidence.signals(dump.toScreen()) : new ArrayList<String>();
        if (!signals.isEmpty() && !dump.activityName.isEmpty()) {
            String fragment = dump.activityName;
            LayoutAnchorRule anchor = LayoutAnchorRule.create(dump.packageName, fragment,
                    "居中卡片右上角无文字图片关闭控件");
            int target = anchor.findTarget(dump.toScreen(), true,
                    dump.screenWidth, dump.screenHeight);
            if (target >= 0 && verifyLayout(dump, rules, settings, anchor)) {
                list.add(Suggestion.withLayoutRule(
                        "按布局锚点识别纯图片关闭控件 #" + target,
                        "已回验：限定 " + dump.packageName + " 且仅 " + shortActivity(fragment)
                                + " 页面；要求广告上下文（" + String.join(" + ", signals)
                                + "）；只匹配居中卡片右上角、可点击、无文字/描述/ID 的小图片控件，"
                                + "并对该节点执行 ACTION_CLICK，失败才回退坐标手势。",
                        "启发式而非语义识别：该应用内若出现结构完全相同的正常弹窗，可能误关。"
                                + "默认关闭、需你显式开启；扫码/支付等敏感页仍被硬锁定，不会触发。",
                        anchor, true));
                if (!settings.layoutAnchorsEnabled) {
                    list.add(Suggestion.withToggle(Suggestion.Kind.TOGGLE_LAYOUT_ANCHORS,
                            "开启「布局锚点识别」总开关",
                            "布局锚点规则默认不生效，需显式打开总开关。开启后仍要求广告上下文与单应用单页面限定。",
                            "仅对已添加的布局锚点规则生效，不会在普通页面按坐标盲点。", "layout_anchors"));
                }
            }
        }

        if (list.isEmpty() || (list.size() == 1 && list.get(0).kind == Suggestion.Kind.ADD_ID_RULE)) {
            list.add(Suggestion.info("能力边界说明",
                    "对完全无文字、无描述、无 ID 特征、也不满足「广告 SDK 页面 + 居中卡片 + 角落小图」"
                            + "结构特征的自绘叉号（Flutter / WebView / 游戏引擎），无障碍无法可靠区分它与正常按钮，"
                            + "本应用不会盲目点击，以免误关你的功能。建议关闭脱敏重抓一屏以确认控件 ID 与文案。"));
        }
        if (!settings.closeIconsEnabled) {
            list.add(Suggestion.withToggle(Suggestion.Kind.TOGGLE_CLOSE_ICONS, "开启通用叉号识别",
                    "允许在广告上下文成立时点击角落小控件。", "仍要求广告证据。", "close_icons"));
        }
        list.add(Suggestion.action(Suggestion.Kind.EXPORT_AI, "交给 AI 深度分析",
                "导出含控件坐标与 ID 的报告。布局、ID 与坐标为明文，对几何判断有效；"
                        + "文字脱敏后 AI 读不到关闭文案，建议关闭脱敏重抓一屏再导出。"));
        return list;
    }

    /** Re-run the real decision engine with one extra rule to prove the fix works. */
    private boolean verify(PageDump dump, List<Rule> rules, EngineSettings settings, Rule extra) {
        List<Rule> extended = new ArrayList<>(rules);
        extended.add(extra);
        Decision decision = new AdDecisionEngine().evaluate(dump.toScreen(), extended, settings);
        return decision.type == Decision.Type.CLICK;
    }

    /** Re-run with layout anchors enabled to prove a geometric rule really fires. */
    private boolean verifyLayout(PageDump dump, List<Rule> rules, EngineSettings settings,
                                 LayoutAnchorRule anchor) {
        EngineSettings enabled = settings.withLayoutAnchors(true);
        Decision decision = new AdDecisionEngine().evaluate(dump.toScreen(), rules, enabled,
                java.util.Collections.singletonList(anchor),
                dump.screenWidth, dump.screenHeight);
        return decision.type == Decision.Type.CLICK
                && anchor.id.equals(decision.ruleId);
    }

    // ---------------------------------------------------------------- helpers

    private Diagnosis build(Diagnosis.Verdict verdict, String headline, String explanation,
                            List<String> evidence, List<Diagnosis.Candidate> candidates,
                            List<Suggestion> suggestions, boolean adContext, boolean sensitive) {
        return new Diagnosis(verdict, headline, explanation, evidence, candidates, suggestions,
                adContext, sensitive);
    }

    public static String cleanPhrase(String raw) {
        if (raw == null) return "";
        String value = raw.trim();
        value = value.replaceAll("(?i)[\\s\\d]*\\d+\\s*(s|秒)?\\s*$", "").trim();
        value = value.replaceAll("[（(].*?[)）]", "").trim();
        if (value.length() > 20) value = value.substring(0, 20);
        return value;
    }

    /** 导出时开启「脱敏」留下的占位符，不是控件的真实文案。 */
    public static boolean isMaskedText(String raw) {
        if (raw == null) return false;
        String value = raw.trim();
        return value.startsWith("[文字已隐藏") || value.startsWith("[已隐藏")
                || value.contains("文字已脱敏");
    }

    private static boolean isStrongSkip(String phrase) {
        String p = phrase.toLowerCase(Locale.ROOT);
        for (String s : STRONG_SKIP) if (p.contains(s)) return true;
        return false;
    }

    public static String idFragment(String viewId) {
        if (viewId == null || viewId.isEmpty()) return "";
        int slash = viewId.lastIndexOf('/');
        String value = slash >= 0 ? viewId.substring(slash + 1) : viewId;
        int colon = value.lastIndexOf(':');
        if (colon >= 0) value = value.substring(colon + 1);
        return value.length() > 28 ? value.substring(value.length() - 28) : value;
    }

    private static String rewardModeLabel(EngineSettings.RewardMode mode) {
        if (mode == null) return "保护奖励";
        switch (mode) {
            case AUTO_ABANDON: return "自动放弃奖励";
            case END_CARD_ONLY: return "播完再关";
            default: return "保护奖励";
        }
    }

    private static String shortActivity(String name) {
        if (name == null || name.isEmpty()) return "未知页面";
        int dot = name.lastIndexOf('.');
        return dot >= 0 && name.length() - dot < 40 ? name.substring(dot + 1) : name;
    }

    private static String simpleClass(String name) {
        if (name == null || name.isEmpty()) return "View";
        int dot = name.lastIndexOf('.');
        return dot >= 0 ? name.substring(dot + 1) : name;
    }

    private static String preview(String value) {
        if (value == null) return "";
        String v = value.replace('\n', ' ').trim();
        return v.length() > 24 ? v.substring(0, 24) + "…" : v;
    }

    private static boolean isCloseSymbol(String normalized) {
        return "x".equals(normalized) || "×".equals(normalized)
                || "✕".equals(normalized) || "✖".equals(normalized)
                || "x)".equals(normalized);
    }

    private static boolean containsAny(String value, String[] needles) {
        if (value == null || value.isEmpty()) return false;
        for (String needle : needles) if (value.contains(needle)) return true;
        return false;
    }
}
