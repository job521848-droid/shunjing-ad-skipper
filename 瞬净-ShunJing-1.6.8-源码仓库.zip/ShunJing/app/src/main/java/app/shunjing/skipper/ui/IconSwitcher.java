package app.shunjing.skipper.ui;

import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;

import app.shunjing.skipper.ShunJingApp;
import app.shunjing.skipper.data.Preset;

/**
 * 桌面图标随模式换色。
 *
 * <p>Android 的桌面图标是静态资源，运行时改不了；标准做法是声明三个 {@code activity-alias}，
 * 每次只启用一个。
 *
 * <p><b>关键约束</b>：禁用「正在承载当前任务」的别名，在 ColorOS / OriginOS 上会被系统
 * 当成组件消失，直接把任务结束——表现就是"点了几下突然回到桌面"。所以这里绝不在前台
 * 动组件，只记下目标档位，等应用完全退到后台（{@link ShunJingApp} 计数归零）再切换。
 * 那时用户已经不在应用里，任务被回收也不会被看见；下次从新图标进来是一次干净启动。
 */
public final class IconSwitcher {
    public static final String QUIET = "app.shunjing.skipper.ui.LauncherQuiet";
    public static final String BALANCED = "app.shunjing.skipper.ui.LauncherBalanced";
    public static final String FAST = "app.shunjing.skipper.ui.LauncherFast";

    private static final String FILE = "local_state";
    private static final String KEY = "icon_variant";
    private static final String KEY_PENDING = "icon_variant_pending";
    private static final long BACKGROUND_DELAY_MS = 700L;

    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    /** 本进程已经应用过的档位：避免每次回到首页都做三次组件状态 IPC。 */
    private static String applied;
    private static boolean scheduled;

    private IconSwitcher() { }

    /**
     * 请求把桌面图标换成与模式匹配的档位。
     *
     * <p>前台只登记，不动组件；后台立即执行。
     */
    public static void apply(Context context, Preset.Mode mode) {
        if (context == null) return;
        Context app = context.getApplicationContext();
        SharedPreferences prefs = app.getSharedPreferences(FILE, Context.MODE_PRIVATE);
        String target = variantOf(prefs.getString(KEY, BALANCED), mode);
        if (target.equals(prefs.getString(KEY_PENDING, ""))
                && target.equals(prefs.getString(KEY, "")) && target.equals(applied)) return;
        prefs.edit().putString(KEY_PENDING, target).apply();
        if (!ShunJingApp.isForeground()) schedule(app, 240L);
    }

    /** 由 {@link ShunJingApp} 在最后一个页面 stop 后调用。 */
    public static void onAppBackgrounded(Context context) {
        if (context == null) return;
        schedule(context.getApplicationContext(), BACKGROUND_DELAY_MS);
    }

    private static void schedule(Context app, long delay) {
        if (scheduled) return;
        scheduled = true;
        MAIN.postDelayed(() -> {
            scheduled = false;
            if (ShunJingApp.isForeground()) return; // 又回来了，放弃这次切换
            applyNow(app);
        }, delay);
    }

    private static void applyNow(Context app) {
        SharedPreferences prefs = app.getSharedPreferences(FILE, Context.MODE_PRIVATE);
        String target = prefs.getString(KEY_PENDING, null);
        if (target == null) return;
        // 进程启动后第一次退到后台时，即使记录值一致也重新下发一次：防止升级或某些 ROM
        // 把三个别名全禁用，桌面上一个图标都不剩。
        if (target.equals(applied) && applied != null) return;
        try {
            PackageManager manager = app.getPackageManager();
            String pkg = app.getPackageName();
            manager.setComponentEnabledSetting(new ComponentName(pkg, target),
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                    PackageManager.DONT_KILL_APP);
            for (String alias : new String[]{QUIET, BALANCED, FAST}) {
                if (alias.equals(target)) continue;
                manager.setComponentEnabledSetting(new ComponentName(pkg, alias),
                        PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        PackageManager.DONT_KILL_APP);
            }
            prefs.edit().putString(KEY, target).remove(KEY_PENDING).apply();
            applied = target;
        } catch (RuntimeException ignored) {
            // 某些 ROM 会拦截组件状态变更；图标保持原样比崩掉好。
        }
    }

    /** 自定义模式不换图标：它是"你自己调的"，没有对应的档位色。 */
    private static String variantOf(String current, Preset.Mode mode) {
        if (mode == Preset.Mode.SAFE) return QUIET;
        if (mode == Preset.Mode.FAST) return FAST;
        if (mode == Preset.Mode.CUSTOM) return current == null ? BALANCED : current;
        return BALANCED;
    }
}
