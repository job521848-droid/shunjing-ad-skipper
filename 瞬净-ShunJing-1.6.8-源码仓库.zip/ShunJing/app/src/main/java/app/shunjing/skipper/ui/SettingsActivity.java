package app.shunjing.skipper.ui;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import app.shunjing.skipper.R;
import app.shunjing.skipper.data.Prefs;
import app.shunjing.skipper.data.Preset;
import app.shunjing.skipper.engine.EngineSettings;
import app.shunjing.skipper.engine.LayoutAnchorRule;

/**
 * v1.4 重新组织：先给"模式"，再给四个日常开关，其余全部折叠。
 * 目标是打开这一页不需要读二十行说明。
 */
public final class SettingsActivity extends BaseActivity {
    private Prefs prefs;
    private final Map<String, Switch> toggles = new HashMap<>();
    private SegmentBar segment;
    private TextView modeSummary;
    private TextView modeState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        LinearLayout root = Ui.root(this);
        root.addView(Ui.header(this, "高级设置", "日常用不到；需要微调时再展开", true));
        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // ------------------------------------------------------------ 模式
        LinearLayout modeCard = Ui.card(this);
        modeCard.addView(Ui.caption(this, "模式"));
        segment = new SegmentBar(this, new String[]{"安静", "均衡", "极速"},
                Preset.indexOf(Preset.modeOf(prefs)));
        LinearLayout.LayoutParams segParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 46));
        segParams.topMargin = Ui.dp(this, 10);
        modeCard.addView(segment, segParams);
        modeSummary = Ui.text(this, "", 12, getColor(R.color.text_secondary));
        modeSummary.setPadding(0, Ui.dp(this, 10), 0, 0);
        modeCard.addView(modeSummary);
        modeState = Ui.text(this, "", 11, getColor(R.color.warning));
        modeState.setPadding(0, Ui.dp(this, 6), 0, 0);
        modeCard.addView(modeState);
        segment.setOnSelectListener(index -> {
            Preset.Mode next = Preset.fromIndex(index);
            Preset.apply(prefs, next);
            refreshToggles();
            refreshMode();
            Feedback.modeSwitch(this, next, prefs);
        });
        content.addView(modeCard);

        // ------------------------------------------------------------ 常用
        LinearLayout common = Ui.card(this);
        common.addView(Ui.caption(this, "常用"));
        addToggleRow(common, "跳过时提示", "成功关掉广告后弹一句 Toast，默认不打扰", "toast", false);
        addToggleRow(common, "摇一摇误跳转回退", "摇一摇广告把你甩到别的 App 时，8 秒内自动退回广告页", "shake_back", true);
        addToggleRow(common, "摇一摇抢跳", "第一次没点中时，自动对同一处再补两下，抢在跳转前关掉", "shake_preempt", true);
        addToggleRow(common, "广告跳进商店时退回", "广告把你送进应用商店，立刻返回原页面；自己逛商店不受影响。默认关闭",
                "store_back", false);
        addToggleRow(common, "跳过失败自动留样", "没关掉时自动存一份现场，诊断时才有的看", "auto_capture", true);
        Button learned = Ui.secondary(this, "学习记录");
        learned.setOnClickListener(v -> startActivity(new Intent(this, LearnedActivity.class)));
        LinearLayout.LayoutParams learnedParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        learnedParams.topMargin = Ui.dp(this, 10);
        common.addView(learned, learnedParams);
        content.addView(common);

        // ------------------------------------------------------------ 新手引导
        LinearLayout guide = Ui.card(this);
        guide.addView(Ui.caption(this, "新手引导"));
        guide.addView(Ui.listRow(this, "重看一遍首页说明",
                "六页：三种模式、学习、诊断、日志、安全边界", v -> {
                    // 不在这里直接弹：设置页没有首页那层容器，弹出来会跟返回动画打架。
                    prefs.requestGuide();
                    finish();
                }));
        content.addView(guide);

        // ------------------------------------------------------------ 识别与点击
        LinearLayout detect = Ui.collapsible(this, content, "识别与点击",
                "决定“什么算广告、什么时候点”", false);
        addToggleRow(detect, "极速开屏", "启动后 12 秒内识别简洁的“跳过 + 倒计时”", "fast_splash", true);
        addToggleRow(detect, "通用叉号识别", "广告上下文成立时点击“× / 关闭”", "close_icons", true);
        addToggleRow(detect, "叠层弹窗自动定位", "红包 / 签到类弹窗的叉号悬浮在卡片外也能点", "overlay_close", true);
        addToggleRow(detect, "H5 模板广告定位", "穿山甲这类网页广告整页没有文字按钮，靠「反馈⟷关闭」对偶找 ×",
                "web_ad_template", true);
        addToggleRow(detect, "结构性广告证据", "靠广告 SDK 的页面结构与控件特征判断，不依赖“广告”二字", "structural_evidence", true);
        addToggleRow(detect, "二次确认跟进", "点完 1.1 秒内若弹出“残忍离开”，继续处理", "confirm_followup", true);

        // ------------------------------------------------------------ 失败复核
        LinearLayout recovery = Ui.collapsible(this, content, "失败复核",
                "点了没反应时才有用", false);
        addToggleRow(recovery, "失败后自适应定位", "页面没变化时先补一次手势，再重新找关闭按钮", "adaptive_recovery", true);
        recovery.addView(note("默认关闭。本地没找到可点控件、点了页面没变化，或只是「看着像广告」时，"
                + "按「接管时机」（0.3 / 0.65 / 3 秒）交给云端看一眼；只有支付 / 扫码页禁止上传截图，"
                + "返回的坐标还要过敏感页、系统页面、尺寸与下载/支付类危险按钮校验——"
                + "仅疑似时置信度需 0.80 以上。\n\n云端服务的接入与 Key 在首页「云端视觉 AI」里配置。"));

        // ------------------------------------------------------------ 激励视频
        LinearLayout rewarded = Ui.collapsible(this, content, "激励视频",
                "影响“看不看广告换奖励”", false);
        RadioGroup modes = new RadioGroup(this);
        modes.setOrientation(RadioGroup.VERTICAL);
        addMode(modes, EngineSettings.RewardMode.PROTECT, "保护奖励",
                "播放中的激励视频一律不自动关闭。");
        addMode(modes, EngineSettings.RewardMode.END_CARD_ONLY, "播完再关",
                "只在结束卡出现后关闭，奖励已到账。");
        addMode(modes, EngineSettings.RewardMode.AUTO_ABANDON, "放弃奖励换速度",
                "见到关闭控件就关，奖励不要了。");
        rewarded.addView(modes);
        EngineSettings.RewardMode current = prefs.rewardMode();
        for (int i = 0; i < modes.getChildCount(); i++) {
            View child = modes.getChildAt(i);
            if (child instanceof RadioButton && current.name().equals(child.getTag())) {
                ((RadioButton) child).setChecked(true);
            }
        }
        modes.setOnCheckedChangeListener((group, checkedId) -> {
            View v = group.findViewById(checkedId);
            if (v != null && v.getTag() instanceof String) {
                try {
                    prefs.setRewardMode(EngineSettings.RewardMode.valueOf((String) v.getTag()));
                    refreshMode();
                } catch (IllegalArgumentException ignored) { }
            }
        });
        Button manageApps = Ui.secondary(this, "管理「提前放弃」的应用名单");
        manageApps.setOnClickListener(v -> showRewardWhitelist());
        rewarded.addView(manageApps, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        rewarded.addView(note("名单只影响「播完再关」：名单内应用见到关闭控件即关，其他应用仍等结束卡。"));

        // ------------------------------------------------------------ 布局锚点
        LinearLayout anchors = Ui.collapsible(this, content, "纯图片叉号（布局锚点）",
                "给某个 App 的某个页面单独记一个位置", false);
        addToggleRow(anchors, "布局锚点总开关", "开启后仅对已添加的规则生效", "layout_anchors", false);
        Button anchorButton = Ui.secondary(this, "管理布局锚点规则");
        anchorButton.setOnClickListener(v -> showLayoutAnchors());
        anchors.addView(anchorButton, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        anchors.addView(note("规则由「智能诊断」在纯图片广告页一键生成并回验，无需手填几何参数。"));

        // ------------------------------------------------------------ 体感反馈
        LinearLayout feel = Ui.collapsible(this, content, "体感反馈",
                "换挡时的音效与震动", false);
        addToggleRow(feel, "切换音效", "三档音高不同：安静下行、均衡上行、极速三连", "feedback_sound", true);
        addToggleRow(feel, "切换震动", "力度递进：轻点 / 两下 / 短促三连", "feedback_haptic", true);
        addToggleRow(feel, "跳过成功提示", "每成功跳过一次给一声轻响，默认关闭", "feedback_skip", false);
        addToggleRow(feel, "启动动效", "冷启动时播放一段合拢动画并带两下轻震，关掉则直接进首页",
                "boot_animation", true);
        Button preview = Ui.secondary(this, "试听当前模式");
        preview.setOnClickListener(v -> Feedback.preview(this, Preset.modeOf(prefs), prefs));
        feel.addView(preview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        feel.addView(note("音效与震动都在本机合成，不需要联网，也不申请额外权限；"
                + "手机处于静音或震动模式时按系统规则处理。"));

        // ------------------------------------------------------------ 后台
        LinearLayout background = Ui.collapsible(this, content, "后台与权限",
                "通知、无障碍、电池优化", false);
        addToggleRow(background, "静默运行通知", "通知栏显示守护状态，无声无震动", "notifications", true);
        Button accessibility = Ui.primary(this, "打开无障碍设置");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        background.addView(accessibility, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        Button battery = Ui.secondary(this, "后台运行 / 电池优化设置");
        battery.setOnClickListener(v -> {
            try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); }
            catch (RuntimeException e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
        });
        background.addView(battery, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        // ------------------------------------------------------------ 诊断
        addCrashSection(content);

        // ------------------------------------------------------------ 隐私
        LinearLayout privacy = Ui.collapsible(this, content, "隐私与能力边界",
                "数据去哪了、什么做不到", false);
        privacy.addView(note("常规识别、失败复核与诊断都在本机完成，不联网；页面快照只存在应用私有目录（当前保留 "
                + prefs.dumpKeepLimit() + " 份，可在「智能诊断 → 自动清理」调整），"
                + "密码字段永不写入，可随时清空。\n\n"
                + "只有你主动配置并开启云端视觉后，广告页截图与控件结构才会发送给你填写的服务商；截图不落盘、"
                + "不进日志也不进导出文件，API Key 不会出现在任何导出内容里。\n\n"
                + "可处理：开屏、插屏、弹窗、倒计时内提前出现的跳过、带文字/描述的悬浮关闭、红包与签到类运营弹窗。\n"
                + "不承诺：完全自绘且无障碍读不到的按钮、系统限制读取的页面、网络层广告过滤。"));

        setContentView(root);
        refreshMode();
    }

    private TextView note(String value) {
        TextView view = Ui.text(this, value, 11, getColor(R.color.text_secondary));
        view.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 2));
        return view;
    }

    /** 「突然回到桌面」要么是崩溃，要么是系统回收了任务；这里把两者区分开。 */
    private void addCrashSection(LinearLayout content) {
        LinearLayout diag = Ui.collapsible(this, content, "诊断",
                "上次异常退出与组件切换记录", false);
        final long at = app.shunjing.skipper.CrashLog.lastCrashAt(this);
        final String text = app.shunjing.skipper.CrashLog.lastCrashText(this);
        if (at <= 0L || text.isEmpty()) {
            diag.addView(note("没有记录到异常退出。若仍然偶尔「退回到桌面」，那多半是系统结束了任务，"
                    + "而不是程序崩溃：桌面图标换色现在只在应用退到后台后执行，"
                    + "不会再禁用承载当前页面的组件。"));
            return;
        }
        java.text.SimpleDateFormat format =
                new java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.CHINA);
        diag.addView(note("上次异常：" + format.format(new java.util.Date(at))));
        Button view = Ui.secondary(this, "查看详细信息");
        view.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("上次异常")
                .setMessage(text)
                .setPositiveButton("知道了", null)
                .setNeutralButton("清除记录", (dialog, which) -> {
                    app.shunjing.skipper.CrashLog.clear(this);
                    recreate();
                })
                .show());
        diag.addView(view, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void addMode(RadioGroup group, EngineSettings.RewardMode mode, String title, String detail) {
        RadioButton button = new RadioButton(this);
        button.setText(title);
        button.setTag(mode.name());
        button.setId(View.generateViewId());
        button.setTextSize(14);
        button.setTextColor(getColor(R.color.text_primary));
        button.setPadding(0, Ui.dp(this, 6), 0, 0);
        group.addView(button);
        TextView sub = Ui.text(this, "    " + detail, 11, getColor(R.color.text_secondary));
        sub.setPadding(0, 0, 0, Ui.dp(this, 4));
        group.addView(sub);
    }

    /** 标题 + 说明在左，开关在右：比"开关自带长文案"省一半竖向空间。 */
    private void addToggleRow(LinearLayout parent, String title, String description,
                              String key, boolean fallback) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, Ui.dp(this, 9), 0, Ui.dp(this, 9));

        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        TextView head = Ui.text(this, title, 14, getColor(R.color.text_primary));
        column.addView(head);
        if (description != null && !description.isEmpty()) {
            TextView sub = Ui.text(this, description, 11, getColor(R.color.text_secondary));
            sub.setPadding(0, Ui.dp(this, 2), 0, 0);
            column.addView(sub);
        }
        row.addView(column, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Switch toggle = new Switch(this);
        toggle.setChecked(prefs.preferences().getBoolean(key, fallback));
        toggle.setPadding(Ui.dp(this, 8), 0, 0, 0);
        toggle.setOnCheckedChangeListener((button, checked) -> {
            prefs.preferences().edit().putBoolean(key, checked).apply();
            if (key.equals("notifications") && checked && Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 20);
            }
            refreshMode();
        });
        row.addView(toggle);
        toggles.put(key, toggle);
        parent.addView(row);
    }

    private void refreshToggles() {
        for (Map.Entry<String, Switch> entry : toggles.entrySet()) {
            boolean value = prefs.preferences().getBoolean(entry.getKey(),
                    entry.getValue().isChecked());
            entry.getValue().setChecked(value);
        }
    }

    private void refreshMode() {
        Preset.Mode mode = Preset.detect(prefs);
        segment.syncSelected(Preset.indexOf(mode));
        segment.setAccent(Accent.of(mode), Accent.endOf(mode));
        modeSummary.setText(mode.summary);
        if (mode == Preset.Mode.CUSTOM) {
            modeState.setText("当前为自定义配置：手动改动过开关，不再等同于任何预置。");
            modeState.setVisibility(View.VISIBLE);
        } else {
            modeState.setVisibility(View.GONE);
        }
    }

    private void showRewardWhitelist() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(Ui.dp(this, 22), Ui.dp(this, 10), Ui.dp(this, 22), 0);
        List<String> apps = new ArrayList<>(prefs.rewardAutoAbandonApps());
        Collections.sort(apps);
        form.addView(Ui.text(this, apps.isEmpty() ? "当前名单为空" : "已授权应用：",
                14, getColor(R.color.text_primary)));
        for (String pkg : apps) {
            TextView row = Ui.text(this, "· " + pkg, 13, getColor(R.color.text_secondary));
            row.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
            final String target = pkg;
            row.setOnClickListener(v -> {
                prefs.setRewardAutoAbandonApp(target, false);
                Toast.makeText(this, "已移除 " + target, Toast.LENGTH_SHORT).show();
            });
            form.addView(row);
        }
        form.addView(Ui.text(this, "点击条目可移除。也可在「智能诊断」里对某条快照一键「仅授权此应用」。",
                12, getColor(R.color.text_secondary)));
        new AlertDialog.Builder(this).setTitle("提前放弃奖励 · 应用名单")
                .setView(form).setPositiveButton("关闭", null).show();
    }

    private void showLayoutAnchors() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(Ui.dp(this, 22), Ui.dp(this, 10), Ui.dp(this, 22), 0);
        List<LayoutAnchorRule> rules = prefs.layoutAnchors();
        form.addView(Ui.text(this, rules.isEmpty() ? "暂无布局锚点规则" : "已添加 " + rules.size() + " 条：",
                14, getColor(R.color.text_primary)));
        for (LayoutAnchorRule rule : rules) {
            TextView row = Ui.text(this, "· " + rule.activityFragment + "\n   " + rule.packageName,
                    13, getColor(R.color.text_secondary));
            row.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8));
            final LayoutAnchorRule target = rule;
            row.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle("删除布局锚点")
                    .setMessage("删除后该页面的纯图片关闭按钮将不再被识别。")
                    .setNegativeButton("取消", null)
                    .setPositiveButton("删除", (d, w) -> {
                        prefs.deleteLayoutAnchor(target.id);
                        Toast.makeText(this, "已删除", Toast.LENGTH_SHORT).show();
                    }).show());
            form.addView(row);
        }
        form.addView(Ui.text(this, "点击条目可删除。规则均限定单个应用与单个页面。",
                12, getColor(R.color.text_secondary)));
        new AlertDialog.Builder(this).setTitle("布局锚点规则")
                .setView(form).setPositiveButton("关闭", null).show();
    }
}
