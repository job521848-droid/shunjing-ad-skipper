package app.shunjing.skipper.ui;

import android.content.Context;
import android.provider.Settings;

/**
 * 动效的统一节奏表。
 *
 * <p>这一版把"手感"当成可调参数，而不是各处随手写 260L / 420L：
 * <ul>
 *   <li>落位用阻尼弹簧（2.9% 过冲），到位时"啪"一下停住，不来回晃；</li>
 *   <li>所有时长都乘系统的「动画时长缩放」，用户在开发者选项里调 0.5x / 关闭动画，
 *       这里跟着变 —— 无障碍用户不该被强制看动画；</li>
 *   <li>曲线写成纯函数，能被单元测试直接验证，改数值不用真机试。</li>
 * </ul>
 */
public final class Motion {

    /** 阻尼比 0.75：过冲约 2.9%，够有弹性，又不会像果冻一样晃。 */
    private static final double ZETA = 0.75d;
    /** 自然频率 9.5 rad/s：约 210ms 到达峰值，420ms 完全静止。 */
    private static final double OMEGA = 9.5d;
    private static final double OMEGA_D = OMEGA * Math.sqrt(1d - ZETA * ZETA);

    public static final long TAP = 0L;
    public static final long SLIDE = 420L;
    public static final long COLOR = 460L;
    public static final long BURST = 900L;
    public static final long FADE = 260L;

    private Motion() { }

    /**
     * 弹簧位移曲线：t∈[0,1] → 0..1（中段略过冲）。
     *
     * <p>f(t) = 1 − e^(−ζωt)·(cos(ω_d t) + ζω/ω_d · sin(ω_d t))
     */
    public static float spring(float t) {
        if (t <= 0f) return 0f;
        if (t >= 1f) return 1f;
        double decay = Math.exp(-ZETA * OMEGA * t);
        double value = 1d - decay * (Math.cos(OMEGA_D * t)
                + (ZETA * OMEGA / OMEGA_D) * Math.sin(OMEGA_D * t));
        // 末端收敛到 1，避免 t 接近 1 时残留 1e-4 的抖动。
        return (float) Math.max(0d, Math.min(1.05d, value));
    }

    /** 先慢后快的收束：蓄力段用它，越接近临界点越快。 */
    public static float easeInQuad(float t) {
        float x = clamp01(t);
        return x * x;
    }

    /** 起手快、尾部极慢：能量扩散用它，视觉上"甩出去然后停住"。 */
    public static float easeOutCubic(float t) {
        float x = clamp01(t);
        float inv = 1f - x;
        return 1f - inv * inv * inv;
    }

    public static float easeOutQuint(float t) {
        float x = clamp01(t);
        float inv = 1f - x;
        return 1f - inv * inv * inv * inv * inv;
    }

    public static float clamp01(float v) {
        return v < 0f ? 0f : (v > 1f ? 1f : v);
    }

    /**
     * 系统动画缩放。0 表示"移除动画"，此时全部动效直接跳到终态。
     *
     * <p>读不到（部分 ROM 限制 Settings.Global）时按 1.0 处理，宁可多播动画也不要卡住。
     */
    public static float scale(Context context) {
        if (context == null) return 1f;
        try {
            float value = Settings.Global.getFloat(context.getContentResolver(),
                    Settings.Global.ANIMATOR_DURATION_SCALE, 1f);
            if (Float.isNaN(value) || value < 0f) return 1f;
            return Math.min(2f, value);
        } catch (RuntimeException ignored) {
            return 1f;
        }
    }

    public static boolean reduced(Context context) {
        return scale(context) <= 0.01f;
    }

    /** 按系统缩放换算实际时长；关闭动画时返回 0，属性动画会立刻到终态。 */
    public static long duration(Context context, long base) {
        float scale = scale(context);
        if (scale <= 0.01f) return 0L;
        return Math.max(1L, Math.round(base * scale));
    }
}
