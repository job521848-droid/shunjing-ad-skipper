package app.shunjing.skipper.engine;

public final class Decision {
    public enum Type { NONE, CLICK }
    public static final Decision NONE = new Decision(Type.NONE, -1, "", "");

    public final Type type;
    public final int nodeIndex;
    public final String ruleId;
    public final String reason;

    public Decision(Type type, int nodeIndex, String ruleId, String reason) {
        this.type = type;
        this.nodeIndex = nodeIndex;
        this.ruleId = ruleId;
        this.reason = reason;
    }

    public static Decision click(int nodeIndex, String ruleId, String reason) {
        return new Decision(Type.CLICK, nodeIndex, ruleId, reason);
    }
}
