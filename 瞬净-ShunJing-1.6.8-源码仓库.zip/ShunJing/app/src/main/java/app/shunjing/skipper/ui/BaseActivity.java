package app.shunjing.skipper.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;

import app.shunjing.skipper.R;
import app.shunjing.skipper.data.Prefs;
import app.shunjing.skipper.data.Preset;

public abstract class BaseActivity extends Activity {

    /** 页面刚铺好时整屏淡入；子元素的错落出现由各页面自己决定节奏。 */
    private static final long ENTER_DURATION = 260L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 每个页面按当前模式取强调色：换档后背离开的页面也是同一套色。
        Ui.setAccent(Accent.of(Preset.modeOf(new Prefs(this))));
        Window window = getWindow();
        window.setStatusBarColor(getColor(R.color.ink));
        window.setNavigationBarColor(getColor(R.color.ink));
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }

    @Override
    public void setContentView(View view) {
        super.setContentView(view);
        enter(view);
    }

    @Override
    public void setContentView(int layoutResID) {
        super.setContentView(layoutResID);
        enter(findViewById(android.R.id.content));
    }

    private void enter(View view) {
        if (view == null) return;
        view.setAlpha(0f);
        view.setTranslationY(Ui.dp(this, 10));
        view.animate().alpha(1f).translationY(0f)
                .setDuration(ENTER_DURATION)
                .setInterpolator(new DecelerateInterpolator(1.6f))
                .start();
    }

    /** 页面切换：从右侧轻轻推进来，旧页面稍微退后一点。 */
    @Override
    public void startActivity(Intent intent) {
        super.startActivity(intent);
        overridePendingTransition(R.anim.page_in, R.anim.page_out);
    }

    @Override
    public void startActivityForResult(Intent intent, int requestCode) {
        super.startActivityForResult(intent, requestCode);
        overridePendingTransition(R.anim.page_in, R.anim.page_out);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(0, R.anim.page_out);
    }
}
