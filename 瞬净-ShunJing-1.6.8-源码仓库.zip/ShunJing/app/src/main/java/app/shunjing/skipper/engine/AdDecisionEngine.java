package app.shunjing.skipper.engine;

import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Conservative rule engine. Explicit ad-skip labels are fast-path candidates; generic close
 * controls require independent ad evidence. Sensitive workflows always win over every rule.
 *
 * <p>v1.2 additions (all opt-in, none weaken the hard lock):
 * <ul>
 *   <li>Structural ad evidence for text-less SDK pages (Activity + corroborating signal).</li>
 *   <li>Three-state rewarded-ad policy: protect / end-card-only / auto-abandon.</li>
 *   <li>Layout-anchor rules for pure-image close buttons, scoped to one package + Activity.</li>
 * </ul>
 */
public final class AdDecisionEngine {
    /**
     * v1.6.3：「真的会花钱」的页面。这是云端 AI 唯一的上传禁令，也是点击硬锁的第一层。
     *
     * <p>旧表里还塞了「用户协议」「隐私政策」「广告管理」「广告偏好」——那四个词几乎
     * 每一张开屏广告的页脚都有，结果整页被判成敏感：引擎不动、AI 不许截图，用户看到
     * 的现象就是「广告关不掉，还提示系统禁止截图」。它们本来也不代表任何可损失的
     * 操作，删掉不影响安全边界。
     */
    private static final String[] PAYMENT_WORDS = {
            "扫码", "扫一扫", "二维码", "条形码", "放入框内", "对焦", "付款码", "收款码",
            "支付密码", "输入密码", "登录密码", "验证码", "指纹验证", "人脸识别", "授权登录",
            "确认支付", "正在支付", "银行卡"
    };
    /**
     * 系统级危险操作。这类页面里不会出现广告，锁住它们只是「顺手」，不构成对 AI 的限制。
     * 与 {@link #PAYMENT_WORDS} 分开：AI 上传只受支付页约束，危险系统页不参与截图禁令。
     */
    private static final String[] SYSTEM_WORDS = {
            "权限设置", "设备管理器", "usb调试", "确认卸载", "是否删除"
    };
    private static final String[] ONBOARDING_WORDS = {
            "新手指引", "新手教程", "功能介绍", "欢迎使用", "立即体验", "下一步"
    };
    private static final String[] AD_WORDS = {
            "广告", "advertisement", "sponsored", "推广", "赞助", "广告反馈", "不感兴趣",
            "为什么会看到", "打开第三方", "跳转第三方", "点击跳转", "下载应用", "应用详情",
            "摇一摇", "扭一扭", "摇动手机", "转动手机", "限时福利"
    };
    private static final String[] AD_ID_WORDS = {
            "splash", "advert", "ad_close", "adclose", "close_ad", "ad_container", "ad_view",
            "iv_ad", "btn_ad", "tt_", "ksad", "gdt_", "csj", "mintegral", "anythink", "sigmob"
    };
    private static final String[] REWARD_WORDS = {
            "激励视频", "观看视频得", "看视频得", "领取奖励", "获得奖励", "奖励翻倍", "复活机会"
    };
    /**
     * v1.4: 运营弹窗（红包 / 签到 / 抽奖 / 限时福利）常用词。它们不是广告文案，但配合
     * "居中卡片 + 右上角悬浮纯图关闭按钮"的严格几何后，足以认定这是一个可安全关闭的浮层。
     */
    private static final String[] PROMO_WORDS = {
            "每天有惊喜", "惊喜", "红包", "福利", "领取", "签到", "抽奖", "限时", "活动",
            "礼包", "金币", "奖励", "摇一摇", "摇动手机", "扭一扭", "查看详情", "立即参与"
    };
    private static final String[] REWARD_ACTIVITY_MARKERS = {
            "rewardvideoactivity", "rewardadactivity", "rewardactivity", "ksrewardvideoactivity"
    };
    private static final String[] REWARD_ID_MARKERS = {
            "js_reward_card", "reward_play", "reward_card", "reward_end", "middle_end_card"
    };
    private static final String[] PROTECTED_PACKAGE_PREFIXES = {
            "app.shunjing.skipper", "com.android.systemui", "com.android.settings",
            "com.android.packageinstaller", "com.android.permissioncontroller", "com.android.camera",
            "com.android.dialer", "com.android.server.telecom", "com.google.android.packageinstaller",
            "com.android.keyguard", "com.android.incallui", "com.android.providers",
            "com.android.mms", "com.android.contacts", "com.google.android.gms"
    };
    /**
     * v1.6：桌面 / 最近任务（Recents）是"看起来像全屏广告、点一下就出事"的典型页面：
     * 卡片头部可点击、右上角有"更多"菜单、缩略图整屏铺开。它永远不是广告页，
     * 任何规则和几何定位器都不该在它上面生效——所以按包名硬保护，连留样都不做。
     */
    private static final String[] LAUNCHER_PACKAGES = {
            "com.android.launcher", "com.android.launcher3", "com.android.quickstep",
            "com.oppo.launcher", "com.coloros.launcher", "com.oplus.launcher",
            "com.oplus.quickstep", "com.oneplus.launcher", "com.miui.home", "com.miui.launcher",
            "com.huawei.android.launcher", "com.hihonor.android.launcher", "com.bbk.launcher2",
            "com.vivo.launcher", "com.sec.android.app.launcher",
            "com.google.android.apps.nexuslauncher", "com.teslacoilsw.launcher",
            "com.microsoft.launcher", "com.transsion.hilauncher", "com.nothing.launcher",
            "com.realme.launcher", "com.zhiliaoapp.musically.launcher"
    };

    /** Backwards-compatible entry point used by unit tests and callers without anchors. */
    public Decision evaluate(ScreenModel screen, List<Rule> rules, EngineSettings settings) {
        return evaluate(screen, rules, settings, Collections.<LayoutAnchorRule>emptyList(), 0, 0);
    }

    public Decision evaluate(ScreenModel screen, List<Rule> rules, EngineSettings settings,
                             List<LayoutAnchorRule> anchors, int screenWidth, int screenHeight) {
        return evaluate(screen, rules, settings, anchors, screenWidth, screenHeight, false);
    }

    /**
     * @param inheritedAdContext short-lived, causality-based evidence: true only for a few
     *     hundred milliseconds after a confirmed ad click, while still inside an ad-SDK
     *     Activity (used to catch "残忍离开" second-confirmation dialogs that carry no
     *     ad wording of their own). Never set for normal browsing; hard lock still wins.
     */
    public Decision evaluate(ScreenModel screen, List<Rule> rules, EngineSettings settings,
                             List<LayoutAnchorRule> anchors, int screenWidth, int screenHeight,
                             boolean inheritedAdContext) {
        // HARD LOCK — evaluated first, unchanged. No evidence, rule or setting can bypass it.
        if (screen.nodes.isEmpty() || isProtectedPackage(screen.packageName) || isSensitive(screen)) {
            return Decision.NONE;
        }
        boolean adContext = inheritedAdContext || hasAdContext(screen, settings);
        boolean rewarded = hasRewardContext(screen, settings);
        boolean endCard = StructuralAdEvidence.hasVisibleEndCard(screen);
        if (rewarded && !settings.allowsRewardedClose(screen.packageName, endCard)) return Decision.NONE;
        boolean onboarding = isOnboarding(screen);

        Decision best = Decision.NONE;
        int bestScore = 0;
        int bestArea = Integer.MAX_VALUE;
        // 广告 SDK 常把「跳过广告」做成一整块自绘文字，无障碍层 c=0，ACTION_CLICK 无从谈起。
        // 这类目标单独收集，只在没有任何可点击候选时才用坐标盲点，且必须命中自带广告语义
        // 的词（"跳过广告 / 关闭广告 / skipad"），"关闭 / ×"这类泛词一律不走这条路。
        Decision ghost = Decision.NONE;
        int ghostScore = 0;
        for (NodeModel node : screen.nodes) {
            if (!node.visible || node.password || !node.hasBounds()) continue;
            boolean clickable = findClickableAncestor(screen.nodes, node) >= 0;
            boolean ghostable = !clickable && canGhostTap(node, screenWidth, screenHeight);
            if (!clickable && !ghostable) continue;
            for (Rule rule : rules) {
                if (!rule.enabled || !rule.matches(node)) continue;
                if (!rule.packageName.isEmpty() && !rule.packageName.equals(screen.packageName)) continue;
                if (rule.category == Rule.Category.CLOSE && !settings.closeIconsEnabled) continue;

                int score = score(rule, node, screen, adContext, onboarding, settings);
                if (score == 0) continue;
                if (!clickable) {
                    boolean explicitAdWord = rule.category == Rule.Category.SKIP && !rule.requiresAdContext;
                    // v1.5.3: 「跳过」这类需要广告上下文的词，以前在 c=0 的节点上一律被拦死。
                    // 校园跑这类开屏把整棵广告树画在不可点击的容器里，右上角那个两字跳过键
                    // 既没有 id 也没有可点祖先，唯一可行的动作是按坐标点它。放行必须同时满足
                    // 三条：语义（规则本身是 SKIP）、证据（广告上下文成立）、几何（贴右上角
                    // 且小尺寸）。敏感页硬锁在这之前已经返回，任何情况下都轮不到这里。
                    boolean cornerSkip = !explicitAdWord && rule.category == Rule.Category.SKIP
                            && adContext && isCornerSkipLabel(node, screenWidth, screenHeight);
                    if (!explicitAdWord && !cornerSkip) continue;
                    if (!(adContext || hasShakeAd(screen))) continue;
                    if (score > ghostScore) {
                        ghostScore = score;
                        ghost = cornerSkip
                                ? Decision.click(node.index, "corner_skip",
                                        "跳过广告 · 贴角小字，按坐标点击")
                                : Decision.click(node.index, rule.id, "跳过广告 · 控件不可点击，按坐标点击");
                    }
                    continue;
                }
                int area = Math.max(1, node.area());
                if (score > bestScore || (score == bestScore && area < bestArea)) {
                    bestScore = score;
                    bestArea = area;
                    best = Decision.click(node.index, rule.id, reason(rule, adContext));
                }
            }
        }
        if (best.type != Decision.Type.CLICK && ghost.type == Decision.Type.CLICK) best = ghost;
        // v1.5.3: 开屏底部的大块可点击区域是广告主热区（点了就跳落地页），不是跳过键。
        // 角落小字与它同时成立时，按角落那个来——宁可点一次空，也不把人送去下载页。
        else if (best.type == Decision.Type.CLICK && ghost.type == Decision.Type.CLICK
                && "corner_skip".equals(ghost.ruleId)
                && isBottomHotzone(screen.nodes.get(best.nodeIndex), screenWidth, screenHeight)) {
            best = ghost;
        }

        // Some SDKs split "跳" / "过" / countdown into separate sibling nodes. This path is
        // limited to launch or independently established ad context and never clicks digits.
        if (best.type != Decision.Type.CLICK && settings.fastSplashEnabled && !onboarding
                && (adContext || screen.launchedRecently)) {
            int dynamic = DynamicSkipDetector.findSplitSkipTarget(screen, adContext);
            if (dynamic >= 0) best = Decision.click(dynamic, "dynamic_split_skip",
                    "倒计时动态跳过 · 分字控件");
        }

        // 摇一摇 / 扭一摇互动广告页：整屏都是广告落地页，关闭图标贴在屏幕角落。
        // 文案组合本身就是强证据，但仍是最后手段之一，不覆盖任何已命中的文字规则。
        if (best.type != Decision.Type.CLICK && !onboarding && hasShakeAd(screen)) {
            ShakeAdLocator.Hit shake = ShakeAdLocator.find(screen, screenWidth, screenHeight);
            if (shake != null) {
                best = Decision.click(shake.nodeIndex, "shake_ad_close", shake.reason);
            }
        }

        // v1.5.1: WebView 模板广告（穿山甲 / 优量汇 / 广点通）。整棵树 c=0、没有一个"关闭"
        // 字样，文字规则与布局锚点全部够不着；模板固定把「反馈」放左、「关闭」放右，同一排。
        // 这条路径只依赖这对版式关系，并且只在广告上下文成立、且前面所有文字规则都落空时启用。
        if (best.type != Decision.Type.CLICK && settings.webAdTemplateEnabled && !onboarding
                && adContext) {
            WebAdTemplateLocator.Hit web =
                    WebAdTemplateLocator.find(screen, screenWidth, screenHeight);
            if (web != null) {
                best = Decision.click(web.nodeIndex, "web_ad_template_close", web.reason);
            }
        }

        // v1.5.3: 广告 SDK 代理页右上角的纯图标关闭键。优量汇 PortraitADActivity 与风马
        // InterstitialView_NNNNN 都用同一个模板：91×91 容器套 56×56 ImageView，整条父链 c=0，
        // 无文字、无 id，文字规则和布局锚点都够不着，只有坐标点击能命中。
        if (best.type != Decision.Type.CLICK && settings.webAdTemplateEnabled && !onboarding
                && adContext) {
            CornerCloseLocator.Hit corner =
                    CornerCloseLocator.find(screen, screenWidth, screenHeight);
            if (corner != null) {
                best = Decision.click(corner.nodeIndex, "corner_close_icon", corner.reason);
            }
        }

        // v1.6.5: 叠加式下载广告。视频/大图素材 + 监管合规条 + 右下角一枚 68×68 的纯图片 ×，
        // 整棵树 c=0、无 id，Activity 是 android.app.Dialog。上面三个定位器分别卡在
        // 「要可点祖先」「要在右上角」「要 SDK 代理页」，一个都进不来。
        if (best.type != Decision.Type.CLICK && settings.overlayCloseEnabled && !onboarding
                && OverlayAdEvidence.matches(screen)) {
            DownloadAdCloseLocator.Hit download =
                    DownloadAdCloseLocator.find(screen, screenWidth, screenHeight);
            if (download != null) {
                best = Decision.click(download.nodeIndex, "download_ad_close", download.reason);
            }
        }

        // Overlay popups (red-packet / check-in / H5 activity cards) draw their close icon as a
        // bare ImageView that often floats OUTSIDE the card's top-right corner: no text, no id,
        // no description. Rules and layout anchors both miss it, which looks like "the app saw
        // the X but did nothing". Strict geometry + ad context + no dangerous action words.
        if (best.type != Decision.Type.CLICK && settings.overlayCloseEnabled && !onboarding
                && (adContext || screen.launchedRecently || hasPromoContext(screen))) {
            OverlayCloseLocator.Hit overlay = OverlayCloseLocator.find(screen, screenWidth, screenHeight);
            if (overlay != null) {
                best = Decision.click(overlay.nodeIndex, "overlay_close", overlay.reason);
            }
        }

        // Layout anchors are the LAST resort: only when no readable rule matched, and only
        // when explicitly enabled. They still require ad context + package + Activity scope.
        if (best.type != Decision.Type.CLICK && settings.layoutAnchorsEnabled && adContext
                && anchors != null) {
            for (LayoutAnchorRule anchor : anchors) {
                int index = anchor.findTarget(screen, true, screenWidth, screenHeight);
                if (index < 0 || index >= screen.nodes.size()) continue;
                NodeModel target = screen.nodes.get(index);
                if (!target.visible || target.password || !target.hasBounds()) continue;
                if (findClickableAncestor(screen.nodes, target) < 0) continue;
                best = Decision.click(index, anchor.id, "布局锚点 · 纯图片关闭");
                break;
            }
        }
        return best;
    }

    /**
     * v1.6.5：新手指引只在「短标签」上认。
     *
     * <p>下载类广告底部那行监管合规条是 90+ 字的一句话：「应用名称：…；应用版本：…；
     * 开发者：…；适用年龄：16+；权限详情 | 隐私协议 | 功能介绍 | 备案信息」。
     * 旧写法直接在整页语料里找词，命中了其中的「功能介绍」，于是整页被判成新手引导，
     * 之后所有几何定位（叠层弹窗、右上角图标、H5 模板、摇一摇）都带着 {@code !onboarding}
     * 的前置条件，全部静默 —— 广告就在眼前，软件一动不动。
     *
     * <p>真正的引导页是「新手指引」「下一步」这类短按钮/短标题；把它们限制在
     * 10 字以内的节点上，长句里的顺带提及不会再误伤。
     */
    private static boolean isOnboarding(ScreenModel screen) {
        for (NodeModel node : screen.nodes) {
            if (!node.visible) continue;
            String value = node.normalizedText();
            if (value.isEmpty()) value = node.normalizedDescription();
            if (value.isEmpty()) continue;
            // 下载广告的合规条一定带「应用名称」，整句 90+ 字，最后还挂着「功能介绍」。
            // 这一句永远不当成新手引导。
            if (value.contains("应用名称")) continue;
            if (value.length() > 40) continue;
            if (containsAny(value, ONBOARDING_WORDS)) return true;
        }
        return false;
    }

    private int score(Rule rule, NodeModel node, ScreenModel screen, boolean adContext,
                      boolean onboarding, EngineSettings settings) {
        if (rule.category == Rule.Category.CUSTOM) {
            if (rule.requiresAdContext && !adContext) return 0;
            return rule.requiresAdContext ? 82 : 96;
        }
        if (rule.category == Rule.Category.CLOSE) {
            return adContext ? 72 : 0;
        }
        if (!rule.requiresAdContext) return 120;
        if (adContext) return 105;
        if (settings.fastSplashEnabled && screen.launchedRecently && !onboarding && isCompactSkip(node)) {
            return 90;
        }
        return 0;
    }

    private String reason(Rule rule, boolean adContext) {
        if (rule.category == Rule.Category.CUSTOM) return "自定义关闭词";
        if (rule.category == Rule.Category.CLOSE) return "广告上下文 + 关闭控件";
        return adContext ? "广告页跳过" : "开屏极速跳过";
    }

    /** 盲点目标的面积上限：超过屏幕 6% 的通常是容器而不是按钮。 */
    private boolean canGhostTap(NodeModel node, int screenWidth, int screenHeight) {
        if (screenWidth <= 0 || screenHeight <= 0) return false;
        return node.area() <= screenWidth * (long) screenHeight * 0.06;
    }

    /**
     * v1.5.3: 贴右上角的小尺寸「跳过」标签。
     *
     * <p>只做几何判定——是否真的是跳过词由调用方的 SKIP 规则保证，是否真的是广告页由
     * 广告上下文保证。面积上限 2% 用来排除"整块卡片 / 整屏容器"被当成按钮。
     */
    private boolean isCornerSkipLabel(NodeModel node, int screenWidth, int screenHeight) {
        if (screenWidth <= 0 || screenHeight <= 0) return false;
        if (node.area() > screenWidth * (long) screenHeight * 0.02) return false;
        int centerY = (node.top + node.bottom) / 2;
        if (centerY > screenHeight * 12 / 100) return false;
        return node.right >= screenWidth * 88 / 100;
    }

    /**
     * 底部三分之一里的大块可点击区域，在开屏页基本等于"广告主落地页热区"。
     */
    private boolean isBottomHotzone(NodeModel node, int screenWidth, int screenHeight) {
        if (node == null || screenWidth <= 0 || screenHeight <= 0) return false;
        if (node.area() < screenWidth * (long) screenHeight * 0.003) return false;
        int centerY = (node.top + node.bottom) / 2;
        return centerY > screenHeight * 60 / 100;
    }

    private boolean isCompactSkip(NodeModel node) {
        return DynamicSkipDetector.isCompactSkipLabel(node);
    }

    /** 支付 / 扫码 / 密码 / 生物识别。云端 AI 的上传禁令只认这一层。 */
    public static boolean isPaymentOrScan(ScreenModel screen) {
        if (screen == null) return false;
        String activity = screen.activityName.toLowerCase(Locale.ROOT);
        if (activity.contains("scanactivity") || activity.contains("scanner") || activity.contains("qrcode")
                || activity.contains("barcode") || activity.contains("captureactivity")
                || activity.contains("payactivity") || activity.contains("cashier")) return true;
        for (NodeModel node : screen.nodes) {
            if (node.password) return true;
            String value = (node.text + " " + node.contentDescription + " " + node.viewId).toLowerCase(Locale.ROOT);
            if (containsAny(value, PAYMENT_WORDS)) return true;
            if (node.className.toLowerCase(Locale.ROOT).contains("inputmethod")) return true;
        }
        return false;
    }

    /**
     * Text/keyword based sensitive-page detection. Never disabled, never overridden.
     *
     * <p>= 支付页 ∪ 系统危险页。用于「能不能在这里动手点击」，比 AI 上传禁令更宽。
     */
    public static boolean isSensitive(ScreenModel screen) {
        if (isPaymentOrScan(screen)) return true;
        if (screen == null) return false;
        for (NodeModel node : screen.nodes) {
            String value = (node.text + " " + node.contentDescription + " " + node.viewId).toLowerCase(Locale.ROOT);
            if (containsAny(value, SYSTEM_WORDS)) return true;
        }
        return false;
    }

    /** Legacy text-only evidence, kept for callers that do not have settings. */
    public static boolean hasAdContext(ScreenModel screen) {
        String corpus = screenCorpus(screen);
        if (containsAny(corpus, AD_WORDS)) return true;
        for (NodeModel node : screen.nodes) {
            String id = (node.viewId + " " + node.className).toLowerCase(Locale.ROOT);
            if (containsAny(id, AD_ID_WORDS)) return true;
        }
        return false;
    }

    /** Adds opt-in structural evidence. A bare package name is never enough. */
    public static boolean hasAdContext(ScreenModel screen, EngineSettings settings) {
        if (hasAdContext(screen)) return true;
        if (settings == null) return false;
        // v1.6.5：叠加式下载广告（Dialog 里播视频 + 监管合规条 + 下载文案）。
        // 它不是 SDK 代理页，没有任何 SDK 家族 ID，旧的 StructuralAdEvidence 一条都不成立，
        // 结果 ctx=1 的规则全静默。这条证据由合规条 / 视频素材 / 下载文案三项合成，
        // 单一项（比如只有一句「查看详情」）达不到阈值。
        if (OverlayAdEvidence.matches(screen)) return true;
        return settings.structuralAdEvidence && StructuralAdEvidence.matches(screen);
    }

    public static boolean hasShakeAd(ScreenModel screen) {
        String corpus = screenCorpus(screen);
        boolean shake = corpus.contains("摇一摇") || corpus.contains("扭一扭")
                || corpus.contains("摇动手机") || corpus.contains("转动手机")
                || corpus.contains("晃动手机") || corpus.contains("翻转手机")
                || corpus.contains("摇动") || corpus.contains("扭动");
        boolean intent = corpus.contains("跳转") || corpus.contains("打开") || corpus.contains("详情")
                || corpus.contains("第三方") || corpus.contains("广告");
        return shake && intent;
    }

    /** v1.4: 运营活动页证据。单独使用时绝不足以点击，只作为叠层定位的辅助前提。 */
    public static boolean hasPromoContext(ScreenModel screen) {
        return containsAny(screenCorpus(screen), PROMO_WORDS);
    }

    public static boolean hasRewardContext(ScreenModel screen) {
        return containsAny(screenCorpus(screen), REWARD_WORDS);
    }

    /** Text evidence OR an unmistakable rewarded-video Activity / SDK id structure. */
    public static boolean hasRewardContext(ScreenModel screen, EngineSettings settings) {
        if (hasRewardContext(screen)) return true;
        if (settings == null || !settings.structuralAdEvidence) return false;
        String activity = screen.activityName.toLowerCase(Locale.ROOT);
        for (String marker : REWARD_ACTIVITY_MARKERS) if (activity.contains(marker)) return true;
        for (NodeModel node : screen.nodes) {
            String id = node.viewId.toLowerCase(Locale.ROOT);
            for (String marker : REWARD_ID_MARKERS) if (id.contains(marker)) return true;
        }
        return false;
    }

    private static String screenCorpus(ScreenModel screen) {
        StringBuilder builder = new StringBuilder(screen.activityName.toLowerCase(Locale.ROOT));
        for (NodeModel node : screen.nodes) {
            builder.append(' ').append(node.text).append(' ').append(node.contentDescription)
                    .append(' ').append(node.viewId);
        }
        return builder.toString().toLowerCase(Locale.ROOT);
    }

    private static boolean containsAny(String value, String[] needles) {
        for (String needle : needles) if (value.contains(needle)) return true;
        return false;
    }

    public static boolean isProtectedPackage(String packageName) {
        if (packageName == null || packageName.isEmpty() || packageName.equals("android")) return true;
        if (isLauncherPackage(packageName)) return true;
        for (String prefix : PROTECTED_PACKAGE_PREFIXES) if (packageName.startsWith(prefix)) return true;
        return false;
    }

    /** 桌面 / 最近任务。前缀匹配，覆盖 com.android.launcher 与 com.android.launcher3。 */
    public static boolean isLauncherPackage(String packageName) {
        if (packageName == null || packageName.isEmpty()) return false;
        for (String launcher : LAUNCHER_PACKAGES) {
            if (packageName.equals(launcher) || packageName.startsWith(launcher + ".")) return true;
        }
        return false;
    }

    public static int findClickableAncestor(List<NodeModel> nodes, NodeModel node) {
        NodeModel current = node;
        for (int depth = 0; depth < 6 && current != null; depth++) {
            if (current.clickable) return current.index;
            if (current.parentIndex < 0 || current.parentIndex >= nodes.size()) return -1;
            current = nodes.get(current.parentIndex);
        }
        return -1;
    }
}
