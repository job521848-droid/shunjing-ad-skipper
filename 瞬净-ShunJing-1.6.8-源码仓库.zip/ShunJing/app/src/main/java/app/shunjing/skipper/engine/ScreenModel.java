package app.shunjing.skipper.engine;

import java.util.Collections;
import java.util.List;

public final class ScreenModel {
    public final String packageName;
    public final String activityName;
    public final boolean launchedRecently;
    public final List<NodeModel> nodes;

    public ScreenModel(String packageName, String activityName, boolean launchedRecently,
                       List<NodeModel> nodes) {
        this.packageName = packageName == null ? "" : packageName;
        this.activityName = activityName == null ? "" : activityName;
        this.launchedRecently = launchedRecently;
        this.nodes = nodes == null ? Collections.emptyList() : nodes;
    }
}
