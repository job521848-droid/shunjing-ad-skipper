package app.shunjing.skipper.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import app.shunjing.skipper.R;
import app.shunjing.skipper.data.Pause;
import app.shunjing.skipper.data.Prefs;
import app.shunjing.skipper.data.Preset;
import app.shunjing.skipper.service.StatusUtils;

public final class MainActivity extends BaseActivity {
    private Prefs prefs;
    private GuardOrbView orb;
    private PulseDot pulseDot;
    private TextView statusTitle;
    private TextView statusDescription;
    private TextView statsLine;
    private TextView modeSummary;
    private TextView modeBadge;
    private TechRootLayout root;
    private LinearLayout content;
    private SegmentBar segment;
    private View modeAccentBar;
    private LinearLayout modeCard;
    private Button enableButton;
    private Button pauseButton;
    private Switch masterSwitch;
    private boolean syncing;
    private BootOverlay bootOverlay;
    private android.widget.FrameLayout shell;
    private TourOverlay guideOverlay;
    private ScrollView scroll;
    private View rowDump;
    private View rowLearn;
    private LinearLayout toolsRest;
    private android.animation.ValueAnimator sweepAnim;
    private boolean statsRunning;
    private Preset.Mode lastMode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        root = (TechRootLayout) Ui.root(this);
        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // ---------------------------------------------------------------- 品牌
        LinearLayout brand = new LinearLayout(this);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_stat_shield);
        logo.setColorFilter(Ui.accentOf(this));
        int accent = Ui.accentOf(this);
        android.graphics.drawable.GradientDrawable box = new android.graphics.drawable.GradientDrawable();
        box.setCornerRadius(dp(12));
        box.setColor(0xFF0E1C2C);
        box.setStroke(dp(1), withAlpha(accent, 90));
        logo.setBackground(box);
        logo.setPadding(dp(10), dp(10), dp(10), dp(10));
        brand.addView(logo, new LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)));
        LinearLayout brandText = new LinearLayout(this);
        brandText.setOrientation(LinearLayout.VERTICAL);
        brandText.setPadding(Ui.dp(this, 12), 0, 0, 0);
        TextView name = Ui.title(this, "瞬净");
        name.setTextSize(21);
        brandText.addView(name);
        brandText.addView(Ui.caption(this, "SHUNJING · 本地广告防御"));
        brand.addView(brandText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView version = Ui.pill(this, versionLabel(), withAlpha(accent, 110));
        version.setTextColor(getColor(R.color.text_secondary));
        brand.addView(version);
        content.addView(brand);

        // ---------------------------------------------------------------- 状态
        LinearLayout hero = Ui.card(this);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        orb = new GuardOrbView(this);
        hero.addView(orb, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 168)));
        statusTitle = Ui.title(this, "");
        statusTitle.setGravity(Gravity.CENTER);
        statusTitle.setTextSize(22);
        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setGravity(Gravity.CENTER);
        pulseDot = new PulseDot(this);
        LinearLayout.LayoutParams dotParams = new LinearLayout.LayoutParams(dp(9), dp(9));
        dotParams.rightMargin = dp(8);
        statusRow.addView(pulseDot, dotParams);
        statusRow.addView(statusTitle);
        hero.addView(statusRow);
        statusDescription = Ui.text(this, "", 12, getColor(R.color.text_secondary));
        statusDescription.setGravity(Gravity.CENTER);
        statusDescription.setPadding(Ui.dp(this, 10), Ui.dp(this, 6), Ui.dp(this, 10), dp(2));
        hero.addView(statusDescription);

        statsLine = Ui.stat(this, "", 12, getColor(R.color.text_secondary));
        statsLine.setGravity(Gravity.CENTER);
        statsLine.setPadding(0, Ui.dp(this, 2), 0, Ui.dp(this, 10));
        hero.addView(statsLine);

        masterSwitch = new Switch(this);
        masterSwitch.setText("自动跳过");
        masterSwitch.setTextColor(getColor(R.color.text_primary));
        masterSwitch.setTextSize(15);
        masterSwitch.setPadding(0, Ui.dp(this, 2), 0, Ui.dp(this, 6));
        applySwitchTint();
        masterSwitch.setOnCheckedChangeListener((button, checked) -> {
            if (syncing) return;
            prefs.setMasterEnabled(checked);
            // 关总开关等于"今天不干了"，顺手把临时暂停也清掉；
            // 否则过一会儿再打开，会莫名其妙又处于暂停态，像是开关坏了。
            if (!checked) prefs.resume();
            refreshStatus();
        });
        hero.addView(masterSwitch, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        enableButton = Ui.primary(this, "去开启无障碍守护");
        enableButton.setOnClickListener(v -> openAccessibilitySettings());
        hero.addView(enableButton, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        // 临时暂停：支付、看广告领奖励、打游戏时用。放在首页而不是二级页，
        // 因为这个动作往往发生在"马上要用手机"的几秒里，翻菜单就来不及了。
        pauseButton = Ui.secondary(this, "临时暂停 15 分钟");
        pauseButton.setTextSize(13);
        pauseButton.setMinHeight(Ui.dp(this, 42));
        pauseButton.setVisibility(View.GONE);
        pauseButton.setOnClickListener(v -> {
            if (prefs.paused()) {
                prefs.resume();
                Feedback.modeSwitch(this, Preset.Mode.BALANCED, prefs);
            } else {
                prefs.pauseFor(15);
                Feedback.modeSwitch(this, Preset.Mode.SAFE, prefs);
            }
            refreshStatus();
        });
        LinearLayout.LayoutParams pauseParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pauseParams.topMargin = Ui.dp(this, 2);
        hero.addView(pauseButton, pauseParams);
        content.addView(hero);

        // ---------------------------------------------------------------- 模式
        modeCard = Ui.card(this);
        LinearLayout modeHead = new LinearLayout(this);
        modeHead.setGravity(Gravity.CENTER_VERTICAL);
        modeAccentBar = new View(this);
        LinearLayout.LayoutParams barParams = new LinearLayout.LayoutParams(
                Ui.dp(this, 3), Ui.dp(this, 18));
        barParams.setMargins(0, 0, Ui.dp(this, 10), 0);
        modeHead.addView(modeAccentBar, barParams);
        TextView modeTitle = Ui.text(this, "运行模式", 15, getColor(R.color.text_primary));
        modeTitle.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        modeHead.addView(modeTitle, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        modeBadge = Ui.pill(this, "均衡", getColor(R.color.cyan));
        modeBadge.setVisibility(View.GONE);
        modeHead.addView(modeBadge);
        modeCard.addView(modeHead);

        Preset.Mode current = Preset.modeOf(prefs);
        segment = new SegmentBar(this, new String[]{"安静", "均衡", "极速"},
                Preset.indexOf(current));
        LinearLayout.LayoutParams segParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 46));
        segParams.topMargin = Ui.dp(this, 12);
        modeCard.addView(segment, segParams);

        modeSummary = Ui.text(this, "", 12, getColor(R.color.text_secondary));
        modeSummary.setPadding(0, Ui.dp(this, 10), 0, 0);
        modeCard.addView(modeSummary);
        segment.setOnSelectListener(index -> {
            // 只刷新模式区：运行状态与模式无关，重算统计会卡住主线程。
            Preset.Mode next = Preset.fromIndex(index);
            Preset.Mode before = Preset.modeOf(prefs);
            Preset.apply(prefs, next);
            refreshMode(true);
            if (next != before) {
                playShift(next);
                // 只登记，真正的组件切换在应用退到后台时执行（前台禁用别名会被部分 ROM 结束任务）
                IconSwitcher.apply(this, next);
            }
        });
        content.addView(modeCard);

        // ---------------------------------------------------------------- 入口
        LinearLayout tools = Ui.card(this);
        TextView toolsCaption = Ui.caption(this, "更多");
        tools.addView(toolsCaption);
        rowDump = Ui.listRow(this, "智能诊断", "抓现场，自动分析关不掉的原因并给出修复方案",
                v -> open(DumpActivity.class));
        tools.addView(rowDump);
        tools.addView(Ui.divider(this));
        rowLearn = Ui.listRow(this, "学习怎么关广告", "三步：广告出现 → 通知栏点「学习」→ 手动关掉",
                v -> showLearnGuide());
        tools.addView(rowLearn);
        tools.addView(Ui.divider(this));

        // 后四项装一层：新手导览里它们是一步"其余入口"，整块高亮比逐个点更省事，
        // 也符合"日常用不到"这个事实 —— 不引导用户去点它们。
        toolsRest = new LinearLayout(this);
        toolsRest.setOrientation(LinearLayout.VERTICAL);
        toolsRest.addView(Ui.listRow(this, "云端视觉 AI", "本地关不掉时让 AI 看一眼 · 需自备 API Key",
                v -> open(CloudVisionActivity.class)));
        toolsRest.addView(Ui.divider(this));
        toolsRest.addView(Ui.listRow(this, "应用名单", "哪些 App 生效，哪些保持原样",
                v -> open(AppsActivity.class)));
        toolsRest.addView(Ui.divider(this));
        toolsRest.addView(Ui.listRow(this, "关闭词与规则", "遇到特殊文案时，自己补一个词就能关",
                v -> open(RulesActivity.class)));
        toolsRest.addView(Ui.divider(this));
        toolsRest.addView(Ui.listRow(this, "高级设置", "响应速度、失败复核、关闭词与动效",
                v -> open(SettingsActivity.class)));
        tools.addView(toolsRest, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        content.addView(tools);

        // ---------------------------------------------------------------- 安全边界
        LinearLayout safety = Ui.collapsible(this, content, "安全边界",
                "扫码、支付、密码页面永远不会被点", false);
        safety.setPadding(0, Ui.dp(this, 6), 0, 0);
        safety.addView(Ui.text(this,
                "· 扫码 / 二维码 / 支付 / 银行卡 / 密码 / 验证码 / 授权登录页面整体锁定\n"
                        + "· 普通“× / 关闭”必须同时有广告上下文才点\n"
                        + "· 运营弹窗只在“居中卡片 + 右上角悬浮小图标”同时成立时才点\n"
                        + "· 点击后页面没变化才算失败，倒计时 3→2 不算成功\n"
                        + "· 云端视觉默认关闭，仅支付 / 扫码页禁止上传，坐标还要过本地校验",
                12, getColor(R.color.text_secondary)));

        TextView footer = Ui.text(this, "ANDROID 7.0+  ·  无需 ROOT  ·  本地优先", 11,
                getColor(R.color.text_secondary));
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, Ui.dp(this, 18), 0, Ui.dp(this, 8));
        content.addView(footer);

        // 首页铺在下面，开场动效盖在上面：这样"推开"之后是真的首页，不是另一层壳。
        shell = new android.widget.FrameLayout(this);
        shell.addView(root, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        // 直接走 Activity 的实现：BaseActivity 的整屏淡入会和开场动效打架。
        super.setContentView(shell);

        if (prefs.bootAnimationEnabled() && !Motion.reduced(this)) {
            final BootOverlay overlay = new BootOverlay(this, Ui.accentOf(this), prefs);
            bootOverlay = overlay;
            shell.addView(overlay, new android.widget.FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            // 首页先藏在幕布后面：压暗、微缩到 0.972。退场时它跟着同一条时间轴
            // 推近到 1.0 —— 观感是"幕布拉开、页面迎面过来"，而不是"遮罩拿开、
            // 卡片再从下面一条条掉出来"（后者就是之前那种僵硬感）。
            root.setAlpha(0f);
            root.setScaleX(0.972f);
            root.setScaleY(0.972f);
            overlay.play(
                    // 遮罩还盖着的时候先让卡片在底下排好队，露出时它们已经就位。
                    () -> playIntro(content),
                    progress -> {
                        root.setAlpha(0.45f + 0.55f * Motion.easeOutCubic(progress));
                        float scale = 0.972f + 0.028f * progress;
                        root.setScaleX(scale);
                        root.setScaleY(scale);
                    },
                    () -> {
                        shell.removeView(overlay);
                        bootOverlay = null;
                    });
        } else {
            playIntro(content);
        }

        // 首次进入：等开场动效把页面推开之后再讲。两件事抢同一块屏幕只会互相打断，
        // 而且引导的第一句话就是"What is this"，得先让人看见首页。
        scheduleFirstRunGuide();
    }

    /** 第一次装上、还没看过引导时排一次；看过了就什么都不做。 */
    private void scheduleFirstRunGuide() {
        if (prefs.guideSeen()) return;
        long intro = prefs.bootAnimationEnabled() && !Motion.reduced(this)
                ? Motion.duration(this, BootTimeline.TOTAL) + 260L
                : Motion.duration(this, 700L);
        shell.postDelayed(() -> {
            if (isFinishing() || isDestroyed()) return;
            showGuide();
        }, intro);
    }

    /**
     * 弹出引导层。重复调用是安全的：已经在显示时直接返回，避免从设置页连点两次叠两层。
     */
    private void showGuide() {
        if (guideOverlay != null || isFinishing() || isDestroyed()) return;
        // key 与 TourScript 里的常量一一对应；拿不到 / 被隐藏的控件由 TourOverlay 自己跳过。
        java.util.Map<String, View> targets = new java.util.LinkedHashMap<>();
        targets.put(TourScript.T_SWITCH, masterSwitch);
        targets.put(TourScript.T_ENABLE, enableButton);
        targets.put(TourScript.T_PAUSE, pauseButton);
        targets.put(TourScript.T_MODE, segment);
        targets.put(TourScript.T_DUMP, rowDump);
        targets.put(TourScript.T_LEARN, rowLearn);
        targets.put(TourScript.T_MORE, toolsRest);
        TourOverlay overlay = new TourOverlay(this, Ui.accentOf(this), scroll, targets, () -> {
            guideOverlay = null;
            prefs.markGuideSeen();
        });
        guideOverlay = overlay;
        shell.addView(overlay, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        overlay.show();
    }

    @Override
    public void onBackPressed() {
        // 引导挡在最上层时，返回键先关引导，不要把整个 App 退掉。
        if (guideOverlay != null) {
            guideOverlay.close();
            return;
        }
        super.onBackPressed();
    }

    private int dp(int value) { return Ui.dp(this, value); }

    /** v1.5.6: 版本号从清单读，不再写死在代码里（之前一直停在 V1.5.2）。 */
    private String versionLabel() {
        try {
            String name = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            return name == null || name.isEmpty() ? "V—" : "V" + name;
        } catch (android.content.pm.PackageManager.NameNotFoundException e) {
            return "V—";
        }
    }

    private void open(Class<?> destination) {
        startActivity(new Intent(this, destination));
    }

    /**
     * 学习入口只做说明，不直接启动学习。
     *
     * <p>首页点一下是回不到广告页的 —— 从首页切到目标 App 再等广告出来，那几秒里开屏
     * 早就过去了，学了也是白学。真正能用的时机只有"广告正在屏幕上"，那时候人才会下拉
     * 通知栏。所以这里改成教用户什么时候、在哪里点。
     */
    private void showLearnGuide() {
        new android.app.AlertDialog.Builder(this)
                .setTitle("学习怎么关广告")
                .setMessage("① 等广告真的出现在屏幕上（不是 App 首页）\n\n"
                        + "② 下拉通知栏，点通知里的「学习」\n\n"
                        + "③ 自己用手把广告关掉 —— 关掉后不用再点任何按钮，它会自动收尾\n\n"
                        + "学到的是「这个 App 这一页上，哪个位置能关广告」，"
                        + "换页面、换 App 都不会乱点。")
                .setNegativeButton("知道了", null)
                .setPositiveButton("看学习记录", (d, w) -> open(LearnedActivity.class))
                .show();
    }

    /** 开关的滑块与轨道跟着模式色走，别再是系统默认的紫色。 */
    private void applySwitchTint() {
        if (masterSwitch == null) return;
        int accent = Ui.accentOf(this);
        masterSwitch.setThumbTintList(new ColorStateList(
                new int[][]{
                        new int[]{android.R.attr.state_checked},
                        new int[]{}
                },
                new int[]{accent, getColor(R.color.text_secondary)}));
        masterSwitch.setTrackTintList(new ColorStateList(
                new int[][]{
                        new int[]{android.R.attr.state_checked},
                        new int[]{}
                },
                new int[]{withAlpha(accent, 110), withAlpha(getColor(R.color.divider), 120)}));
    }

    private static int withAlpha(int color, int alpha) {
        return android.graphics.Color.argb(alpha,
                android.graphics.Color.red(color),
                android.graphics.Color.green(color),
                android.graphics.Color.blue(color));
    }

    private void openAccessibilitySettings() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED && prefs.notificationsEnabled()) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 12);
        }
        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
    }

    @Override
    protected void onPause() {
        super.onPause();
        // 离屏就别再每 20 秒唤醒一次了，回来时 onResume 会重新排。
        if (pauseButton != null) pauseButton.removeCallbacks(pauseRefresh);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 设置页点了「重看新手引导」：等返回动画走完再弹，否则会被页面切换盖住。
        if (prefs.consumeGuideRequest()) {
            shell.postDelayed(() -> {
                if (isFinishing() || isDestroyed()) return;
                showGuide();
            }, Motion.duration(this, 300L));
        }
        refreshMode();
        refreshStatus();
        updateStatsAsync();
        // 桌面图标换色会触发 launcher 刷新，延后一点，别和首屏动画抢主线程。
        final Preset.Mode iconMode = Preset.modeOf(prefs);
        new android.os.Handler(android.os.Looper.getMainLooper())
                .postDelayed(() -> IconSwitcher.apply(this, iconMode), 420L);
    }

    private void refreshMode() { refreshMode(false); }

    private void refreshMode(boolean animate) {
        Preset.Mode mode = Preset.modeOf(prefs);
        segment.syncSelected(Preset.indexOf(mode));
        modeSummary.setText(mode.summary);
        modeBadge.setVisibility(mode == Preset.Mode.CUSTOM ? View.VISIBLE : View.GONE);
        modeBadge.setText("自定义");
        modeBadge.setTextColor(getColor(R.color.warning));
        modeBadge.setBackground(Ui.badge(this, getColor(R.color.warning)));
        applyAccent(mode, animate && mode != lastMode);
        lastMode = mode;
    }

    /**
     * 换挡编排：把四个效果排到一条时间轴上，而不是同一帧一起炸开。
     *
     * <pre>
     * 0ms    触感 + 合成音 + 档位光条跳一下   ← 手指抬起的瞬间就该有回应
     * 0ms    圆环换色 + 蓄力（前 160ms 只收不放）
     * 80ms   卡片斜向扫光
     * 120ms  模式说明文字从下方升起
     * </pre>
     *
     * 一次只播一套；连点两档时上一套会被取消，不会叠成噪音。
     */
    private void playShift(Preset.Mode mode) {
        Feedback.modeSwitch(this, mode, prefs);

        orb.burst();
        pulseAccentBar();
        sweepModeCard();
        liftModeSummary();
    }

    /** 档位光条像 VU 表一样顶一下再回落，换挡才有"指针跳了"的实感。 */
    private void pulseAccentBar() {
        if (modeAccentBar == null) return;
        modeAccentBar.animate().cancel();
        modeAccentBar.setScaleY(1f);
        if (Motion.reduced(this)) return;
        modeAccentBar.setPivotY(dp(9));
        modeAccentBar.animate().scaleY(1.55f)
                .setDuration(Motion.duration(this, 90L))
                .setInterpolator(new android.view.animation.DecelerateInterpolator(1.5f))
                .withEndAction(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    modeAccentBar.animate().scaleY(1f)
                            .setDuration(Motion.duration(this, 300L))
                            .setInterpolator(new android.view.animation.OvershootInterpolator(2.4f))
                            .start();
                }).start();
    }

    /** 一道斜向光带扫过模式卡：0→1.08 让光带完全离开右边界，不会留半截。 */
    private void sweepModeCard() {
        android.graphics.drawable.Drawable background = modeCard.getBackground();
        if (!(background instanceof TechCardDrawable)) return;
        TechCardDrawable card = (TechCardDrawable) background;
        if (Motion.reduced(this)) {
            card.setSweep(-1f);
            return;
        }
        // 连点两档时先把上一道扫光停掉，否则两个动画同时写 sweep，光带会抖。
        if (sweepAnim != null) sweepAnim.cancel();
        sweepAnim = android.animation.ValueAnimator.ofFloat(0f, 1.08f);
        sweepAnim.setDuration(Motion.duration(this, 660L));
        sweepAnim.setStartDelay(Motion.duration(this, 80L));
        sweepAnim.setInterpolator(new android.view.animation.DecelerateInterpolator(1.1f));
        sweepAnim.addUpdateListener(a -> card.setSweep((float) a.getAnimatedValue()));
        sweepAnim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator a) {
                card.setSweep(-1f);
            }
        });
        sweepAnim.start();
    }

    /** 说明文字换了一句话，从下方 6dp 升起并淡入 —— 比直接替换文字更容易被眼睛接住。 */
    private void liftModeSummary() {
        modeSummary.animate().cancel();
        if (Motion.reduced(this)) {
            modeSummary.setAlpha(1f);
            modeSummary.setTranslationY(0f);
            return;
        }
        modeSummary.setAlpha(0.2f);
        modeSummary.setTranslationY(dp(6));
        modeSummary.animate().alpha(1f).translationY(0f)
                .setStartDelay(Motion.duration(this, 120L))
                .setDuration(Motion.duration(this, Motion.FADE))
                .setInterpolator(new android.view.animation.DecelerateInterpolator(1.7f))
                .start();
    }

    /**
     * 整页换色：守护核心、分段条、档位光条、主按钮全部跟随。
     * 只有真正换档时才播过渡，回到首页时不会又闪一次。
     */
    private void applyAccent(Preset.Mode mode, boolean animate) {
        int start = Accent.of(mode);
        int end = Accent.endOf(mode);
        orb.setAccent(start, animate);
        segment.setAccent(start, end);
        modeAccentBar.setBackground(Ui.accentBar(this, start));
        enableButton.setBackground(Ui.primaryGradient(this, start, end));
        Ui.setAccent(start);
        if (root != null) root.setAccent(start);
        // 整页卡片一起换挡：只换模式卡会让旁边几张卡还留着上一档的描边色，很出戏。
        tintCards(start);
        applySwitchTint();
        if (animate) modeBadge.setBackground(Ui.badge(this, start));
    }

    /** 递归把每张卡片的描边与内发光换成当前档位色。卡片数量有限，一次遍历代价很小。 */
    private void tintCards(int accent) {
        if (content == null) return;
        for (int i = 0; i < content.getChildCount(); i++) {
            tintCard(content.getChildAt(i), accent);
        }
    }

    private static void tintCard(View view, int accent) {
        android.graphics.drawable.Drawable background = view.getBackground();
        if (background instanceof TechCardDrawable) ((TechCardDrawable) background).setAccent(accent);
        if (!(view instanceof ViewGroup)) return;
        ViewGroup group = (ViewGroup) view;
        for (int i = 0; i < group.getChildCount(); i++) {
            tintCard(group.getChildAt(i), accent);
        }
    }

    private void refreshStatus() {
        boolean accessibility = StatusUtils.isAccessibilityEnabled(this);
        boolean master = prefs.masterEnabled();
        // v1.5.8: 系统说"已开启"不等于服务真的在跑。荣耀 / 华为会把服务悄悄停掉，
        // 开关还是开的，实际一个事件都收不到 —— 表现就是"开了完全没用"。
        boolean stale = accessibility && master && prefs.serviceStale();
        boolean paused = master && !stale && prefs.paused();
        boolean active = accessibility && master && !stale && !paused;
        orb.setActive(active);
        if (pulseDot != null) {
            pulseDot.setDotColor(stale ? getColor(R.color.danger)
                    : active ? Ui.accentOf(this) : getColor(R.color.text_secondary));
            pulseDot.setPulsing(active || stale);
        }
        if (stale) {
            statusTitle.setText("守护已掉线");
        } else if (paused) {
            statusTitle.setText("已临时暂停");
        } else if (active) {
            statusTitle.setText("守护运行中");
        } else {
            statusTitle.setText(master ? "等待授权" : "守护已关闭");
        }
        statusTitle.setTextColor(getColor(active ? R.color.text_primary : R.color.warning));
        statusDescription.setText(active
                ? "事件驱动 · 支付扫码保护 · 开屏无感"
                : stale ? "系统把无障碍服务停了：进去关掉再打开一次"
                : paused ? "还有 " + Pause.label(prefs.pauseRemaining()) + " 自动恢复 · 点这里立即恢复"
                : master ? "在系统设置里开启一次「瞬净 · 自动跳过」" : "打开下面的开关即可恢复");
        statusDescription.setTextColor(getColor(paused ? R.color.cyan : R.color.text_secondary));
        statusDescription.setOnClickListener(paused ? v -> {
            prefs.resume();
            refreshStatus();
        } : null);
        statusDescription.setClickable(paused);
        syncing = true;
        masterSwitch.setChecked(master);
        syncing = false;
        enableButton.setText(stale ? "重新开启守护" : "去开启无障碍守护");
        enableButton.setVisibility(accessibility && !stale ? View.GONE : View.VISIBLE);
        if (pauseButton != null) {
            pauseButton.setText(paused ? "立即恢复守护" : "临时暂停 15 分钟");
            pauseButton.setTextColor(getColor(paused ? R.color.cyan : R.color.text_primary));
            pauseButton.setVisibility(accessibility && !stale ? View.VISIBLE : View.GONE);
            // 停在首页时剩余时间也要走：20 秒一次足够，别为了倒计时每秒重绘整页。
            pauseButton.removeCallbacks(pauseRefresh);
            if (paused) pauseButton.postDelayed(pauseRefresh, 20_000L);
        }
    }

    private final Runnable pauseRefresh = this::refreshStatus;

    /** 日志可能上百条，JSON 解析放后台线程，不在主线程做。 */
    private void updateStatsAsync() {
        if (statsRunning) return;
        statsRunning = true;
        new Thread(() -> {
            final int today = prefs.todayCount();
            final int total = prefs.totalCount();
            runOnUiThread(() -> {
                statsRunning = false;
                if (isFinishing() || isDestroyed()) return;
                statsLine.setText(today == 0 && total == 0
                        ? "还没有记录，下次开 App 时看效果"
                        : "近 24 小时 " + today + " 次  ·  累计 " + total + " 次");
            });
        }, "stats").start();
    }

    /** 首页卡片依次淡入上移，只在首次创建时播一次。 */
    @Override
    protected void onDestroy() {
        if (pauseButton != null) pauseButton.removeCallbacks(pauseRefresh);
        if (bootOverlay != null) bootOverlay.cancel();
        if (guideOverlay != null) guideOverlay.animate().cancel();
        if (sweepAnim != null) sweepAnim.cancel();
        super.onDestroy();
    }

    /**
     * 首页卡片依次淡入上移，只在首次创建时播一次。
     *
     * <p>1.6.1 起这段通常被开场动效"提前"调用（遮罩还盖着）：卡片在底下排好队，
     * 幕布拉开时看到的是已经就位的页面，而不是正在往下掉的卡片。所以节奏压短、位移减小，
     * 让它在遮掩下走完也不显得赶。
     */
    private void playIntro(LinearLayout content) {
        for (int i = 0; i < content.getChildCount(); i++) {
            View child = content.getChildAt(i);
            child.setAlpha(0f);
            child.setTranslationY(dp(12));
            child.animate().alpha(1f).translationY(0f).setDuration(300L)
                    .setStartDelay(34L * i)
                    .setInterpolator(new android.view.animation.DecelerateInterpolator(1.5f))
                    .start();
        }
    }
}
