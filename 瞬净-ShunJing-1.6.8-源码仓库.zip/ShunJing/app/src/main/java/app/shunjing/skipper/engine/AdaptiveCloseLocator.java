package app.shunjing.skipper.engine;

import java.util.Locale;

/**
 * Local second-pass locator used only after a confirmed ad click did not change the page.
 * It deliberately returns -1 when candidates are ambiguous instead of guessing.
 */
public final class AdaptiveCloseLocator {
    private static final String[] CLOSE_ID = {"close", "dismiss", "skip", "exit", "叉", "关闭", "跳过"};
    private static final String[] CTA = {
            "下载", "安装", "打开", "领取", "立即", "详情", "购买", "登录", "注册", "同意",
            "允许", "授权", "支付", "提交", "播放", "暂停", "静音", "更多", "download", "install", "open"
    };

    public static final class Result {
        public final int nodeIndex;
        public final int score;
        public final String reason;
        Result(int nodeIndex, int score, String reason) {
            this.nodeIndex = nodeIndex;
            this.score = score;
            this.reason = reason;
        }
    }

    private AdaptiveCloseLocator() { }

    public static Result find(ScreenModel screen, int excludedNodeIndex, int width, int height) {
        if (screen == null || screen.nodes.isEmpty() || AdDecisionEngine.isSensitive(screen)
                || AdDecisionEngine.isProtectedPackage(screen.packageName)) return null;
        int w = width > 0 ? width : inferWidth(screen), h = height > 0 ? height : inferHeight(screen);
        if (w <= 0 || h <= 0) return null;
        NodeModel excluded = excludedNodeIndex >= 0 && excludedNodeIndex < screen.nodes.size()
                ? screen.nodes.get(excludedNodeIndex) : null;
        Result best = null, second = null;
        for (NodeModel n : screen.nodes) {
            if (n.index == excludedNodeIndex || sameBounds(n, excluded)) continue;
            if (!n.visible || n.password || !n.hasBounds()) continue;
            if (AdDecisionEngine.findClickableAncestor(screen.nodes, n) < 0) continue;
            int score = score(n, screen, w, h);
            if (score < 76) continue;
            Result candidate = new Result(n.index, score, "失败后本地复核 · 候选关闭控件");
            if (best == null || score > best.score
                    || (score == best.score && n.area() < screen.nodes.get(best.nodeIndex).area())) {
                second = best;
                best = candidate;
            } else if (second == null || score > second.score) {
                second = candidate;
            }
        }
        if (best == null) return null;
        // A high-confidence ID or an unambiguous corner icon is required. Two similar icons
        // are ambiguous (e.g. mute + close), so leave them to the visual model or the user.
        if (second != null && best.score - second.score < 12 && best.score < 100) return null;
        return best;
    }

    private static int score(NodeModel n, ScreenModel screen, int w, int h) {
        String text = (n.normalizedText() + n.normalizedDescription());
        String id = n.viewId.toLowerCase(Locale.ROOT);
        String cls = n.className.toLowerCase(Locale.ROOT);
        if (containsAny(text, CTA) || containsAny(id, CTA)) return 0;
        int bw = n.right - n.left, bh = n.bottom - n.top;
        if (bw > w * 0.24f || bh > h * 0.12f || bw < w * 0.018f || bh < h * 0.008f) return 0;
        if ((long) bw * bh > (long) w * h * 0.06f) return 0;
        int score = 0;
        boolean closeId = containsAny(id, CLOSE_ID);
        boolean closeText = text.equals("x") || text.equals("关闭") || text.equals("跳过")
                || text.contains("关闭广告") || text.contains("跳过广告");
        if (closeId) score += 48;
        if (closeText) score += 44;
        boolean image = cls.contains("image") || cls.contains("button") || cls.contains("textview");
        if (image) score += 12;
        float cx = (n.left + n.right) / 2f, cy = (n.top + n.bottom) / 2f;
        boolean topCorner = cy < h * 0.30f && (cx < w * 0.24f || cx > w * 0.76f);
        if (topCorner) score += 34;
        if (nearCardCorner(n, screen, w, h)) score += 36;
        if (n.clickable) score += 10;
        if (text.isEmpty() && id.isEmpty() && !topCorner && !nearCardCorner(n, screen, w, h)) return 0;
        return score;
    }

    private static boolean nearCardCorner(NodeModel n, ScreenModel screen, int w, int h) {
        NodeModel parent = n.parentIndex >= 0 && n.parentIndex < screen.nodes.size()
                ? screen.nodes.get(n.parentIndex) : null;
        if (parent == null || !parent.visible || !parent.hasBounds()) return false;
        int pw = parent.right - parent.left, ph = parent.bottom - parent.top;
        if (pw < w * 0.45f || pw > w * 0.96f || ph < h * 0.15f || ph > h * 0.86f) return false;
        boolean nearTop = Math.abs(n.top - parent.top) <= h * 0.035f;
        boolean nearSide = Math.abs(n.right - parent.right) <= w * 0.05f
                || Math.abs(n.left - parent.left) <= w * 0.05f;
        return nearTop && nearSide;
    }

    private static boolean sameBounds(NodeModel a, NodeModel b) {
        return a != null && b != null && a.left == b.left && a.top == b.top
                && a.right == b.right && a.bottom == b.bottom;
    }

    private static boolean containsAny(String value, String[] words) {
        for (String word : words) if (value.contains(word)) return true;
        return false;
    }

    private static int inferWidth(ScreenModel screen) {
        int value = 0;
        for (NodeModel n : screen.nodes) if (n.visible) value = Math.max(value, n.right);
        return value;
    }

    private static int inferHeight(ScreenModel screen) {
        int value = 0;
        for (NodeModel n : screen.nodes) if (n.visible) value = Math.max(value, n.bottom);
        return value;
    }
}
