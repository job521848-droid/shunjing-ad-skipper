package app.shunjing.skipper.data;

/** 常见的 OpenAI 兼容多模态服务商预设。用户只需粘贴 Key，地址与模型名自动填好。 */
public final class VisionProvider {
    public final String label;
    public final String endpoint;
    public final String model;
    public final String tip;
    /** 控制台首页。用户要去这里注册、开模型、创建 API Key。 */
    public final String console;

    private VisionProvider(String label, String endpoint, String model, String tip, String console) {
        this.label = label;
        this.endpoint = endpoint;
        this.model = model;
        this.tip = tip;
        this.console = console;
    }

    /** 顺序即界面上的分段顺序，最后一项固定为"自定义"。 */
    public static final VisionProvider[] PRESETS = {
            new VisionProvider("智谱", "https://open.bigmodel.cn/api/paas/v4/chat/completions",
                    "glm-4v-flash", "国内直连，glm-4v-flash 有免费额度，注册最简单",
                    "https://bigmodel.cn/usercenter/apikeys"),
            new VisionProvider("百炼", "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
                    "qwen-vl-plus", "阿里云百炼，新账号有免费 Token，速度稳",
                    "https://bailian.console.aliyun.com/"),
            new VisionProvider("硅基", "https://api.siliconflow.cn/v1/chat/completions",
                    "Qwen/Qwen2.5-VL-72B-Instruct", "硅基流动，模型名以控制台为准，注册送额度",
                    "https://cloud.siliconflow.cn/account/ak"),
    };

    public static final int CUSTOM = PRESETS.length;

    public static String[] labels() {
        String[] result = new String[PRESETS.length + 1];
        for (int i = 0; i < PRESETS.length; i++) result[i] = PRESETS[i].label;
        result[PRESETS.length] = "自定义";
        return result;
    }

    /** 根据当前已保存的地址反推预设，找不到就是自定义。 */
    public static int indexOfEndpoint(String endpoint) {
        if (endpoint == null) return CUSTOM;
        String value = endpoint.trim();
        for (int i = 0; i < PRESETS.length; i++) {
            if (PRESETS[i].endpoint.equalsIgnoreCase(value)) return i;
        }
        return CUSTOM;
    }

    public static VisionProvider at(int index) {
        return index >= 0 && index < PRESETS.length ? PRESETS[index] : null;
    }
}
