package app.shunjing.skipper.engine;

import java.util.List;

/**
 * 用户亲手教出来的一条「这个位置就是关闭键」。
 *
 * <p>为什么需要它：广告页面千奇百怪，规则永远补不完，而每个页面都让作者远程抓树、改代码、
 * 发新版是不现实的。用户自己在广告页点一次，比任何启发式都准。
 *
 * <p>安全边界（三条同时成立才允许点击）：
 * <ul>
 *   <li>包名必须相同；Activity 有记录时也必须相同 —— 绝不跨应用、绝不跨页面泛化；</li>
 *   <li>位置、尺寸必须与教学时吻合（中心偏差 ≤6% 屏、面积在 0.35~2.6 倍之间）；</li>
 *   <li>目标本身仍是「小控件」（面积 ≤2% 屏），底部那种整条热区永远选不出来。</li>
 * </ul>
 * 点击前仍要求广告上下文成立（由调用方把关），敏感页硬锁优先级最高。
 */
public final class LearnedClose {
    public final String packageName;
    public final String activityName;
    public final String label;
    public final String viewId;
    public final String className;
    /** 相对屏幕的 0~1 比例，换分辨率后依然有效。 */
    public final float leftRatio;
    public final float topRatio;
    public final float rightRatio;
    public final float bottomRatio;
    public final long createdAt;
    public final int hits;

    public LearnedClose(String packageName, String activityName, String label, String viewId,
                        String className, float leftRatio, float topRatio,
                        float rightRatio, float bottomRatio, long createdAt, int hits) {
        this.packageName = packageName == null ? "" : packageName;
        this.activityName = activityName == null ? "" : activityName;
        this.label = label == null ? "" : label;
        this.viewId = viewId == null ? "" : viewId;
        this.className = className == null ? "" : className;
        this.leftRatio = leftRatio;
        this.topRatio = topRatio;
        this.rightRatio = rightRatio;
        this.bottomRatio = bottomRatio;
        this.createdAt = createdAt;
        this.hits = hits;
    }

    public static LearnedClose fromNode(String pkg, String activity, String label,
                                        NodeModel node, int screenWidth, int screenHeight) {
        if (node == null || screenWidth <= 0 || screenHeight <= 0) return null;
        return new LearnedClose(pkg, activity, label, node.viewId, node.className,
                clamp(node.left / (float) screenWidth), clamp(node.top / (float) screenHeight),
                clamp(node.right / (float) screenWidth), clamp(node.bottom / (float) screenHeight),
                System.currentTimeMillis(), 0);
    }

    private static float clamp(float value) {
        if (value < 0f) return 0f;
        if (value > 1f) return 1f;
        return value;
    }

    public LearnedClose withHit() {
        return new LearnedClose(packageName, activityName, label, viewId, className,
                leftRatio, topRatio, rightRatio, bottomRatio, createdAt, hits + 1);
    }

    /** 同包 + 同 Activity 才有资格被匹配。 */
    public boolean appliesTo(ScreenModel screen) {
        if (screen == null) return false;
        if (!packageName.equals(screen.packageName)) return false;
        if (activityName.isEmpty() || screen.activityName.isEmpty()) return true;
        return activityName.equals(screen.activityName);
    }

    /** 返回命中的节点下标，没有则 -1。 */
    public int find(ScreenModel screen, int screenWidth, int screenHeight) {
        if (!appliesTo(screen) || screenWidth <= 0 || screenHeight <= 0) return -1;

        float targetCx = (leftRatio + rightRatio) / 2f;
        float targetCy = (topRatio + bottomRatio) / 2f;
        float targetArea = Math.max(0.0001f, (rightRatio - leftRatio) * (bottomRatio - topRatio));

        int best = -1;
        int bestScore = 0;
        for (NodeModel node : screen.nodes) {
            if (!node.visible || node.password || !node.hasBounds()) continue;
            float area = node.area() / (float) ((long) screenWidth * screenHeight);
            // 大热区永远不是关闭键：整条横幅、整块卡片都不许被这里选中。
            if (area <= 0f || area > 0.02f) continue;
            if (area > targetArea * 2.6f || area < targetArea * 0.35f) continue;

            float cx = (node.left + node.right) / 2f / screenWidth;
            float cy = (node.top + node.bottom) / 2f / screenHeight;
            float dx = Math.abs(cx - targetCx);
            float dy = Math.abs(cy - targetCy);
            // 没记到 Activity 时，位置闸门收紧到 2.5%，补偿"可能不在同一页"的风险。
            float tolerance = activityName.isEmpty() ? 0.025f : 0.06f;
            if (dx > tolerance || dy > tolerance) continue;

            int score = 100 - (int) ((dx + dy) * 400f);
            if (!viewId.isEmpty() && viewId.equals(node.viewId)) score += 70;
            if (node.normalizedText().isEmpty()) score += 10;
            if (score > bestScore) {
                bestScore = score;
                best = node.index;
            }
        }
        return best;
    }
}
