package app.shunjing.skipper.engine;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 把「用户从点开始学习，到手动关掉广告」这几帧画面，反推成一条可复用的关闭位置。
 *
 * <p>为什么是「几帧」而不是「两帧」：学习开始时用户往往还停在通知栏、桌面，或者目标 App
 * 的主页上（广告还没弹出来）。如果只记住"第一帧"，记下的就是主页；等广告关掉又回到主页，
 * 前后一比对当然是"页面没有变化"。所以这里保留一段帧历史，找出其中**最后一次明显变化**，
 * 那才是"广告页 → 关闭后的页面"。
 *
 * <p>两条信号，优先用第一条：
 * <ol>
 *   <li>学习期间有控件被点击（无障碍的 TYPE_VIEW_CLICKED 带了源节点），并且那个控件
 *       确实从画面上消失了 —— 最准，直接采用；</li>
 *   <li>否则比较变化前后的两帧，找出「原来有、后来没了」的贴角小控件 —— 校园跑那种整树
 *       c=0 的 H5 广告只能走这条路，精度到「哪一块消失了」，由坐标点击兜底。</li>
 * </ol>
 *
 * <p>反过来，下面几种情况必须明确放弃而不是硬猜：页面根本没变化（广告没关掉）、
 * 消失的候选有一堆分不出高下（说明是整页替换，不是某个关闭键）。
 */
public final class LearningAnalyzer {

    /** 相似度低于这个值才算"页面真的换了"；高于它就是没关掉。 */
    private static final double CHANGED_SIM = 0.86d;

    /** 学习期间的一帧画面。 */
    public static final class Frame {
        public final List<NodeModel> nodes;
        public final long at;
        /** 这一帧紧跟在一次滑动之后：滑动也会让画面大变，不能当成关闭。 */
        public final boolean afterScroll;

        public Frame(List<NodeModel> nodes, long at, boolean afterScroll) {
            this.nodes = nodes == null ? new ArrayList<NodeModel>() : nodes;
            this.at = at;
            this.afterScroll = afterScroll;
        }

        public Frame(List<NodeModel> nodes, long at) {
            this(nodes, at, false);
        }
    }

    public static final class Result {
        public final LearnedClose learned;
        public final String message;
        public final boolean pageChanged;

        private Result(LearnedClose learned, String message, boolean pageChanged) {
            this.learned = learned;
            this.message = message;
            this.pageChanged = pageChanged;
        }

        public boolean ok() {
            return learned != null;
        }
    }

    private LearningAnalyzer() { }

    private static Result fail(String message, boolean changed) {
        return new Result(null, message, changed);
    }

    /**
     * 帧历史版：从一串画面里挑出"最后一次明显变化"，再按点击 / 消失角标两条路反推。
     *
     * <p>这是学习模式真正走的入口。{@link #analyze} 保留给"只拿到首尾两帧"的场景和单测。
     */
    public static Result analyzeFrames(String packageName, String activityName, String label,
                                       List<Frame> frames, List<NodeModel> clicks,
                                       int screenWidth, int screenHeight) {
        if (frames == null || frames.isEmpty()) return fail("没能在广告页上取到画面", false);
        if (screenWidth <= 0 || screenHeight <= 0) return fail("屏幕尺寸异常", false);
        if (frames.size() < 2) return fail("学习期间只看到一帧画面，没法比较前后变化", false);

        int cut = -1;
        double cutSim = 1d;
        for (int i = 1; i < frames.size(); i++) {
            Frame prev = frames.get(i - 1);
            Frame next = frames.get(i);
            if (next.afterScroll) continue;
            double sim = similarity(prev.nodes, next.nodes);
            // 用 <= 取"最后一次"：广告弹出来也是一次大变，但它发生在关闭之前，
            // 只有末尾那次才是用户关广告造成的。
            if (sim < CHANGED_SIM && sim <= cutSim) {
                cut = i;
                cutSim = sim;
            }
        }
        if (cut < 0) {
            // 用户点了，但整段学习期间控件树一帧都没变。最常见的两种原因：
            // 广告已经关掉了（那确实没变化），或者广告层由 SDK 自绘 / 对无障碍隐藏
            // （截图能看见，控件树里看不见）。含糊地说"没关掉"会让人反复重试，
            // 说清是哪一种，用户才知道下一步该换成云端视觉。
            if (clicks != null && !clicks.isEmpty()) {
                return fail("你点的位置没有改变无障碍画面：这个广告层多半是自绘的，"
                        + "控件树里看不到它。改用云端视觉 AI 可以从截图里找到这个 ×", false);
            }
            return fail("页面没有变化，广告可能还没关掉", false);
        }

        List<NodeModel> before = frames.get(cut - 1).nodes;
        List<NodeModel> after = frames.get(cut).nodes;
        return resolve(packageName, activityName, label, before, after, clicks,
                screenWidth, screenHeight);
    }

    public static Result analyze(String packageName, String activityName, String label,
                                 List<NodeModel> before, List<NodeModel> after,
                                 List<NodeModel> clicks, int screenWidth, int screenHeight) {
        if (before == null || before.isEmpty()) return fail("没能在广告页上取到画面", false);
        if (after == null || after.isEmpty()) return fail("没能取到结束时的画面", false);
        if (screenWidth <= 0 || screenHeight <= 0) return fail("屏幕尺寸异常", false);

        double similarity = similarity(before, after);
        if (similarity >= CHANGED_SIM) return fail("页面没有变化，广告可能还没关掉", false);
        return resolve(packageName, activityName, label, before, after, clicks,
                screenWidth, screenHeight);
    }

    private static Result resolve(String packageName, String activityName, String label,
                                  List<NodeModel> before, List<NodeModel> after,
                                  List<NodeModel> clicks, int screenWidth, int screenHeight) {
        // 1) 用户点过东西，而且那东西确实不见了：优先信它。
        NodeModel clicked = lastClick(before, after, clicks);
        if (clicked != null) {
            LearnedClose learned = LearnedClose.fromNode(packageName, activityName, label,
                    clicked, screenWidth, screenHeight);
            if (learned != null) return new Result(learned, "已学会你刚才点的位置", true);
        }

        // 2) 没有任何点击记录：从「消失的那一块」里找贴角小控件。
        NodeModel vanished = pickVanishedCorner(before, after, screenWidth, screenHeight);
        if (vanished != null) {
            LearnedClose learned = LearnedClose.fromNode(packageName, activityName, label,
                    vanished, screenWidth, screenHeight);
            if (learned != null) return new Result(learned, "已从页面变化推断出关闭位置", true);
        }
        return fail("看不出你点的是哪一处，这个页面可能整页一起换了", true);
    }

    /**
     * 学习期间可能点了好几下（先点错、再点对）。取最后一次，但要求那个位置上的控件
     * 事后确实不见了 —— 否则说明那一下没起作用（点的是广告本体、跳转后又回来了）。
     */
    private static NodeModel lastClick(List<NodeModel> before, List<NodeModel> after,
                                       List<NodeModel> clicks) {
        if (clicks == null || clicks.isEmpty()) return null;
        for (int i = clicks.size() - 1; i >= 0; i--) {
            NodeModel click = clicks.get(i);
            if (click == null || !click.hasBounds()) continue;
            if (click.area() <= 0) continue;
            NodeModel target = nearest(before, click);
            if (target == null) target = click;
            if (survives(after, target)) continue;   // 点完还在，说明没关掉任何东西
            return target;
        }
        return null;
    }

    /** 找 before 里与点击位置最接近的节点（同一个控件在树里的那一份）。 */
    private static NodeModel nearest(List<NodeModel> nodes, NodeModel click) {
        if (nodes == null) return null;
        float cx = (click.left + click.right) / 2f;
        float cy = (click.top + click.bottom) / 2f;
        float size = Math.max(1f, Math.max(click.right - click.left, click.bottom - click.top));
        NodeModel best = null;
        float bestDistance = size * 1.2f;
        for (NodeModel node : nodes) {
            if (!node.visible || !node.hasBounds() || node.password) continue;
            float ncx = (node.left + node.right) / 2f;
            float ncy = (node.top + node.bottom) / 2f;
            float distance = Math.max(Math.abs(ncx - cx), Math.abs(ncy - cy));
            if (distance <= bestDistance) {
                bestDistance = distance;
                best = node;
            }
        }
        return best;
    }

    /** 这个节点在 after 里还在不在（允许几像素抖动）。 */
    private static boolean survives(List<NodeModel> after, NodeModel target) {
        if (after == null) return false;
        String key = key(target);
        float cx = (target.left + target.right) / 2f;
        float cy = (target.top + target.bottom) / 2f;
        float size = Math.max(1f, Math.max(target.right - target.left, target.bottom - target.top));
        for (NodeModel node : after) {
            if (!node.visible || !node.hasBounds()) continue;
            if (key.equals(key(node))) return true;
            if (!node.className.equals(target.className)) continue;
            float ncx = (node.left + node.right) / 2f;
            float ncy = (node.top + node.bottom) / 2f;
            if (Math.max(Math.abs(ncx - cx), Math.abs(ncy - cy)) <= size * 0.4f) return true;
        }
        return false;
    }

    /**
     * 在两帧之间找「原本在、后来没了」的贴角小控件。
     *
     * <p>为了不被整页替换带偏，只接受：面积 ≤2% 屏、位于上部 35%、离左右边缘近，
     * 且最优与次优分数必须拉开差距，否则视为分不清而放弃。
     */
    private static NodeModel pickVanishedCorner(List<NodeModel> before, List<NodeModel> after,
                                                int screenWidth, int screenHeight) {
        Set<String> afterKeys = keys(after);
        NodeModel best = null;
        int bestScore = 0;
        NodeModel second = null;
        int secondScore = 0;

        for (NodeModel node : before) {
            if (!node.visible || node.password || !node.hasBounds()) continue;
            if (afterKeys.contains(key(node))) continue;
            int width = node.right - node.left;
            int height = node.bottom - node.top;
            if (width < 16 || height < 16) continue;
            float area = node.area() / (float) ((long) screenWidth * screenHeight);
            if (area > 0.02f) continue;

            float cx = (node.left + node.right) / 2f / screenWidth;
            float cy = (node.top + node.bottom) / 2f / screenHeight;
            if (cy > 0.35f) continue;
            if (cx < 0.55f && cx > 0.45f) continue;   // 正中不是关闭键的常规位置

            // 越贴角越好；关闭键绝大多数在右上角，所以右半屏再加一点。
            float corner = Math.min(cx + cy, (1f - cx) + cy);
            int score = (int) ((1f - corner) * 100f);
            if (cx > 0.5f) score += 6;
            if (node.normalizedText().isEmpty()) score += 8;
            // 同一个角落里还常驻一个"广告"角标，它也会随广告一起消失。
            // 不看字面就会把角标当成关闭键 —— 这正是"学歪"最典型的来源。
            score += wordingScore(node);

            if (score > bestScore) {
                second = best;
                secondScore = bestScore;
                best = node;
                bestScore = score;
            } else if (score > secondScore) {
                second = node;
                secondScore = score;
            }
        }
        if (best == null) return null;
        // 两个候选差不多像，说明看到的是整页替换，不是某个关闭键 —— 宁可放弃。
        if (second != null && bestScore - secondScore < 12) return null;
        return best;
    }

    /** 关闭语义加分，"广告"角标减分。 */
    private static int wordingScore(NodeModel node) {
        String text = node.normalizedText() + " " + node.normalizedDescription();
        if (text.contains("跳过") || text.contains("skip")) return 40;
        if (text.contains("关闭") || text.contains("close") || text.equals("x")) return 34;
        if (text.contains("广告") || text.contains("sponsor") || text.contains("advert")) return -35;
        return 0;
    }

    /**
     * 这一帧里有多少个"广告特征"节点。自动结束只在广告特征明显减少时才触发，
     * 避免把"广告刚弹出来"当成"广告被关掉"。
     */
    public static int adSignals(List<NodeModel> nodes) {
        if (nodes == null) return 0;
        int count = 0;
        for (NodeModel node : nodes) {
            if (!node.visible) continue;
            String text = node.normalizedText() + " " + node.normalizedDescription()
                    + " " + NodeModel.normalize(node.viewId);
            if (text.contains("跳过")) { count++; continue; }
            if (text.contains("广告") || text.contains("sponsor") || text.contains("advert")) { count++; continue; }
            if (text.contains("splash") || text.contains("interstitial")
                    || text.contains("ad_container") || text.contains(":id/ad")) { count++; }
        }
        return count;
    }

    /** before 里有、after 里没了的小控件数量。整层广告消失通常一次掉好几个。 */
    public static int vanishedCount(List<NodeModel> before, List<NodeModel> after) {
        if (before == null || before.isEmpty()) return 0;
        Set<String> afterKeys = keys(after);
        int count = 0;
        for (NodeModel node : before) {
            if (!node.visible || !node.hasBounds() || node.password) continue;
            if (!afterKeys.contains(key(node))) count++;
        }
        return count;
    }

    public static double similarity(List<NodeModel> before, List<NodeModel> after) {        if (before == null || before.isEmpty()) return 0d;
        Set<String> afterKeys = keys(after);
        int total = 0;
        int hit = 0;
        for (NodeModel node : before) {
            if (!node.visible || !node.hasBounds()) continue;
            total++;
            if (afterKeys.contains(key(node))) hit++;
        }
        return total == 0 ? 0d : hit / (double) total;
    }

    private static Set<String> keys(List<NodeModel> nodes) {
        Set<String> keys = new HashSet<>();
        if (nodes == null) return keys;
        for (NodeModel node : nodes) {
            if (!node.visible || !node.hasBounds()) continue;
            keys.add(key(node));
        }
        return keys;
    }

    /** 坐标量化到 8px，容忍渲染时的一两像素抖动。 */
    static String key(NodeModel node) {
        return node.className + "|" + (node.left / 8) + "|" + (node.top / 8) + "|"
                + (node.right / 8) + "|" + (node.bottom / 8);
    }
}
