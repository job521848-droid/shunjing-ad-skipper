package app.shunjing.skipper.engine;

import static org.junit.Assert.*;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** v1.2: three-state rewarded policy, structural evidence, layout anchors, hard-lock priority. */
public class V12FeaturesTest {
    private final AdDecisionEngine engine = new AdDecisionEngine();
    private final List<Rule> defaults = DefaultRules.create();

    private static NodeModel node(int index, int parent, String text, String desc, String id,
                                  String className, boolean clickable, boolean visible,
                                  int left, int top, int right, int bottom) {
        return new NodeModel(index, parent, text, desc, id, className, clickable, visible,
                false, left, top, right, bottom);
    }

    private static EngineSettings settings(EngineSettings.RewardMode mode,
                                           boolean structural, boolean anchors) {
        return new EngineSettings(true, true, mode, Collections.<String>emptySet(),
                structural, true, anchors);
    }

    // ---------------------------------------------------------------- 1. three-state reward

    @Test
    public void protectModeNeverClosesRewardedVideo() {
        ScreenModel screen = rewardedScreen(false);
        assertEquals(Decision.Type.NONE, engine.evaluate(screen, defaults,
                settings(EngineSettings.RewardMode.PROTECT, true, false)).type);
    }

    @Test
    public void autoAbandonClosesRewardedVideo() {
        ScreenModel screen = rewardedScreen(false);
        assertEquals(Decision.Type.CLICK, engine.evaluate(screen, defaults,
                settings(EngineSettings.RewardMode.AUTO_ABANDON, true, false)).type);
    }

    @Test
    public void endCardOnlyWaitsForEndCard() {
        EngineSettings s = settings(EngineSettings.RewardMode.END_CARD_ONLY, true, false);
        assertEquals(Decision.Type.NONE,
                engine.evaluate(rewardedScreen(false), defaults, s).type);
        assertEquals(Decision.Type.CLICK,
                engine.evaluate(rewardedScreen(true), defaults, s).type);
    }

    @Test
    public void perAppWhitelistOnlyAffectsThatPackage() {
        Set<String> allowed = new LinkedHashSet<>();
        allowed.add("com.tingfeng.tool");
        EngineSettings s = new EngineSettings(true, true, EngineSettings.RewardMode.END_CARD_ONLY,
                allowed, true, true, false);
        assertEquals(Decision.Type.CLICK, engine.evaluate(rewardedScreen(false), defaults, s).type);
        // A different package is still protected while its video is playing.
        ScreenModel other = new ScreenModel("com.other.app",
                "com.kwad.sdk.api.proxy.app.KsRewardVideoActivity", false,
                Arrays.asList(
                        node(0, -1, "", "", "com.kwad.dy.sdk:id/ksad_root_container",
                                "android.widget.FrameLayout", false, true, 0, 0, 1272, 2772),
                        node(1, 0, "关闭广告", "", "", "android.widget.Button", true, true,
                                1076, 185, 1174, 251)));
        assertEquals(Decision.Type.NONE, engine.evaluate(other, defaults, s).type);
    }

    private static ScreenModel rewardedScreen(boolean endCardVisible) {
        List<NodeModel> nodes = new ArrayList<>();
        nodes.add(node(0, -1, "", "", "com.kwad.dy.sdk:id/ksad_root_container",
                "android.widget.FrameLayout", false, true, 0, 0, 1272, 2772));
        nodes.add(node(1, 0, "关闭广告", "", "com.kwad.dy.sdk:id/ksad_video_player",
                "android.widget.Button", true, true, 1076, 185, 1174, 251));
        nodes.add(node(2, 0, "", "", "com.kwad.dy.sdk:id/ksad_middle_end_card",
                "android.widget.LinearLayout", false, endCardVisible, 0, 2716, 1272, 2772));
        return new ScreenModel("com.tingfeng.tool",
                "com.kwad.sdk.api.proxy.app.KsRewardVideoActivity", true, nodes);
    }

    // ---------------------------------------------------------------- 2. structural evidence

    @Test
    public void structuralEvidenceNeedsBothSdkActivityAndCorroboratingSignal() {
        // Activity alone is not enough.
        ScreenModel activityOnly = new ScreenModel("com.tingfeng.tool",
                "com.kwad.sdk.api.proxy.app.KsRewardVideoActivity", false,
                Collections.singletonList(node(0, -1, "", "", "", "android.widget.FrameLayout",
                        false, true, 0, 0, 1272, 2772)));
        assertFalse(StructuralAdEvidence.matches(activityOnly));

        // SDK ids alone, without an ad Activity, is not enough either.
        ScreenModel idsOnly = new ScreenModel("com.tingfeng.tool", "com.tingfeng.tool.MainActivity",
                false, Collections.singletonList(node(0, -1, "", "",
                "com.kwad.dy.sdk:id/ksad_video_player", "android.widget.FrameLayout",
                false, true, 0, 0, 1272, 2772)));
        assertFalse(StructuralAdEvidence.matches(idsOnly));

        // Both together => evidence.
        assertTrue(StructuralAdEvidence.matches(rewardedScreen(false)));
    }

    @Test
    public void barePackageNameIsNeverAdEvidence() {
        ScreenModel normal = new ScreenModel("com.tingfeng.tool",
                "com.tingfeng.tool.MainActivity", false,
                Arrays.asList(
                        node(0, -1, "", "", "com.tingfeng.tool:id/action_bar_root",
                                "android.widget.LinearLayout", false, true, 0, 0, 1272, 2772),
                        node(1, 0, "关闭", "", "", "android.widget.Button", true, true,
                                1076, 185, 1174, 251)));
        assertFalse(AdDecisionEngine.hasAdContext(normal, settings(
                EngineSettings.RewardMode.PROTECT, true, false)));
        assertEquals(Decision.Type.NONE,
                engine.evaluate(normal, defaults, settings(EngineSettings.RewardMode.PROTECT, true, false)).type);
    }

    @Test
    public void inheritedContextOnlyWorksForSecondConfirmationAndNeverBypassesHardLock() {
        // A text-less confirmation dialog: without inherited context it is silent.
        List<NodeModel> dialog = Arrays.asList(
                node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, 1272, 2772),
                node(1, 0, "残忍离开", "", "", "android.widget.Button", true, true, 400, 1600, 872, 1720));
        List<Rule> rules = new ArrayList<>(defaults);
        rules.add(Rule.custom("残忍离开", Rule.MatchType.EXACT, true, "com.tingfeng.tool"));
        ScreenModel screen = new ScreenModel("com.tingfeng.tool",
                "com.kwad.sdk.api.proxy.app.KsRewardVideoActivity", false, dialog);
        EngineSettings s = settings(EngineSettings.RewardMode.AUTO_ABANDON, true, false);
        assertEquals(Decision.Type.NONE, engine.evaluate(screen, rules, s,
                Collections.<LayoutAnchorRule>emptyList(), 1272, 2772, false).type);
        assertEquals(Decision.Type.CLICK, engine.evaluate(screen, rules, s,
                Collections.<LayoutAnchorRule>emptyList(), 1272, 2772, true).type);

        // Hard lock still wins even WITH inherited context.
        List<NodeModel> payment = Arrays.asList(
                node(0, -1, "确认支付 输入密码", "", "", "android.widget.FrameLayout", false, true, 0, 0, 1272, 2772),
                node(1, 0, "残忍离开", "", "", "android.widget.Button", true, true, 400, 1600, 872, 1720));
        ScreenModel payScreen = new ScreenModel("com.tingfeng.tool",
                "com.kwad.sdk.api.proxy.app.KsRewardVideoActivity", false, payment);
        assertEquals(Decision.Type.NONE, engine.evaluate(payScreen, rules, s,
                Collections.<LayoutAnchorRule>emptyList(), 1272, 2772, true).type);
    }

    // ---------------------------------------------------------------- 3. layout anchors (闪动校园)

    private static ScreenModel shandongScreen() {
        // Faithful subset of the 24-node 闪动校园 / dsp.open.BaseProxyActivity snapshot.
        return new ScreenModel("com.huachenjie.shandong_school",
                "com.ipd.dsp.open.BaseProxyActivity", true,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, 1272, 2772),
                        node(5, 4, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, 1272, 2716),
                        node(6, 5, "", "", "", "android.widget.LinearLayout", false, true, 159, 518, 1113, 2339),
                        node(7, 6, "", "", "", "android.widget.ImageView", true, true, 989, 518, 1095, 624),
                        node(8, 6, "", "", "", "android.widget.FrameLayout", false, true, 159, 642, 1113, 2339),
                        node(16, 12, "", "", "", "android.widget.LinearLayout", true, true, 243, 2087, 1029, 2255),
                        node(18, 16, "立即下载应用", "", "", "android.widget.TextView", false, true, 518, 2087, 910, 2255),
                        node(20, 5, "", "", "", "android.widget.LinearLayout", false, true, 1082, 2610, 1216, 2674),
                        node(21, 20, "", "", "", "android.widget.ImageView", false, true, 1096, 2621, 1138, 2663),
                        node(22, 20, "广告", "", "", "android.widget.TextView", false, true, 1146, 2623, 1202, 2661)));
    }

    @Test
    public void layoutAnchorFindsTheRealCloseControlAndNotTheCta() {
        LayoutAnchorRule rule = LayoutAnchorRule.create("com.huachenjie.shandong_school",
                "com.ipd.dsp.open.BaseProxyActivity", "test");
        ScreenModel screen = shandongScreen();
        assertEquals(7, rule.findTarget(screen, true, 1272, 2772));
        // The large "立即下载" CTA (#16) must never be selected.
        assertNotEquals(16, rule.findTarget(screen, true, 1272, 2772));
    }

    @Test
    public void layoutAnchorRequiresAdContextPackageAndActivity() {
        LayoutAnchorRule rule = LayoutAnchorRule.create("com.huachenjie.shandong_school",
                "com.ipd.dsp.open.BaseProxyActivity", "test");
        ScreenModel screen = shandongScreen();
        assertEquals(-1, rule.findTarget(screen, false, 1272, 2772));
        LayoutAnchorRule otherPkg = LayoutAnchorRule.create("com.other.app",
                "com.ipd.dsp.open.BaseProxyActivity", "test");
        assertEquals(-1, otherPkg.findTarget(screen, true, 1272, 2772));
        LayoutAnchorRule otherActivity = LayoutAnchorRule.create("com.huachenjie.shandong_school",
                "com.huachenjie.shandong_school.MainActivity", "test");
        assertEquals(-1, otherActivity.findTarget(screen, true, 1272, 2772));
        // Global (empty package) layout rules are forbidden by construction.
        LayoutAnchorRule global = LayoutAnchorRule.create("", "BaseProxy", "test");
        assertEquals(-1, global.findTarget(screen, true, 1272, 2772));
    }

    @Test
    public void layoutAnchorIsOffByDefaultAndOptInOnly() {
        ScreenModel screen = shandongScreen();
        LayoutAnchorRule rule = LayoutAnchorRule.create("com.huachenjie.shandong_school",
                "com.ipd.dsp.open.BaseProxyActivity", "test");
        List<LayoutAnchorRule> anchors = Collections.singletonList(rule);
        EngineSettings off = settings(EngineSettings.RewardMode.PROTECT, true, false);
        assertEquals(Decision.Type.NONE,
                engine.evaluate(screen, defaults, off, anchors, 1272, 2772).type);
        EngineSettings on = settings(EngineSettings.RewardMode.PROTECT, true, true);
        Decision decision = engine.evaluate(screen, defaults, on, anchors, 1272, 2772);
        assertEquals(Decision.Type.CLICK, decision.type);
        assertEquals(7, decision.nodeIndex);
    }

    @Test
    public void layoutAnchorNeverFiresOnQrOrPaymentPages() {
        LayoutAnchorRule rule = LayoutAnchorRule.create("com.huachenjie.shandong_school",
                "com.ipd.dsp.open.BaseProxyActivity", "test");
        List<LayoutAnchorRule> anchors = Collections.singletonList(rule);
        EngineSettings on = settings(EngineSettings.RewardMode.AUTO_ABANDON, true, true);
        // Same geometry, but the card contains a QR scanner hint.
        ScreenModel qr = new ScreenModel("com.huachenjie.shandong_school",
                "com.ipd.dsp.open.BaseProxyActivity", true,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, 1272, 2772),
                        node(6, 0, "", "", "", "android.widget.LinearLayout", false, true, 159, 518, 1113, 2339),
                        node(7, 6, "", "", "", "android.widget.ImageView", true, true, 989, 518, 1095, 624),
                        node(9, 6, "扫一扫 将二维码放入框内", "", "", "android.widget.TextView", false, true, 200, 900, 1000, 1000),
                        node(20, 0, "", "", "", "android.widget.LinearLayout", false, true, 1082, 2610, 1216, 2674),
                        node(21, 20, "", "", "", "android.widget.ImageView", false, true, 1096, 2621, 1138, 2663),
                        node(22, 20, "广告", "", "", "android.widget.TextView", false, true, 1146, 2623, 1202, 2661)));
        assertEquals(-1, rule.findTarget(qr, true, 1272, 2772));
        assertEquals(Decision.Type.NONE,
                engine.evaluate(qr, defaults, on, anchors, 1272, 2772, true).type);

        // Payment page with inherited context + all switches on: still locked.
        ScreenModel pay = new ScreenModel("com.huachenjie.shandong_school",
                "com.huachenjie.shandong_school.ScanActivity", false,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, 1272, 2772),
                        node(6, 0, "", "", "", "android.widget.LinearLayout", false, true, 159, 518, 1113, 2339),
                        node(7, 6, "", "", "", "android.widget.ImageView", true, true, 989, 518, 1095, 624),
                        node(9, 6, "确认支付 支付密码 验证码", "", "", "android.widget.TextView", false, true, 200, 900, 1000, 1000)));
        assertEquals(Decision.Type.NONE,
                engine.evaluate(pay, defaults, on, anchors, 1272, 2772, true).type);
    }

    @Test
    public void layoutAnchorDoesNotFireWithoutCenteredCardOrCornerIcon() {
        LayoutAnchorRule rule = LayoutAnchorRule.create("com.huachenjie.shandong_school",
                "com.ipd.dsp.open.BaseProxyActivity", "test");
        // Full-screen page with a top-right image but no centered card.
        ScreenModel fullscreen = new ScreenModel("com.huachenjie.shandong_school",
                "com.ipd.dsp.open.BaseProxyActivity", true,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, 1272, 2772),
                        node(1, 0, "", "", "", "android.widget.LinearLayout", false, true, 0, 0, 1272, 2772),
                        node(2, 1, "", "", "", "android.widget.ImageView", true, true, 989, 518, 1095, 624)));
        assertEquals(-1, rule.findTarget(fullscreen, true, 1272, 2772));
    }

    // ---------------------------------------------------------------- 4. diagnosis suggestions

    @Test
    public void diagnosisOffersVerifiedLayoutRuleForPureImageAd() {
        List<NodeModel> nodes = new ArrayList<>();
        for (NodeModel n : shandongScreen().nodes) nodes.add(n);
        PageDump dump = new PageDump("id", 1700000000000L, "com.huachenjie.shandong_school",
                "com.ipd.dsp.open.BaseProxyActivity", "闪动校园", PageDump.SOURCE_NEXT,
                1272, 2772, true, nodes);
        Diagnosis diagnosis = new DumpAnalyzer().analyze(dump, defaults,
                settings(EngineSettings.RewardMode.PROTECT, true, false), true, true);
        assertTrue(diagnosis.adContext);
        boolean found = false;
        for (Suggestion s : diagnosis.suggestions) {
            if (s.kind == Suggestion.Kind.ADD_LAYOUT_RULE) {
                found = true;
                assertTrue("布局锚点建议必须已回验", s.verified);
                assertNotNull(s.layoutRule);
                assertEquals("com.huachenjie.shandong_school", s.layoutRule.packageName);
            }
        }
        assertTrue("纯图片广告页应给出可采纳的布局锚点规则", found);
    }

    @Test
    public void globalSecondConfirmationWordGetsScopeSuggestion() {
        List<Rule> rules = new ArrayList<>(defaults);
        Rule global = new Rule("custom-cruel", "残忍离开", Rule.MatchType.EXACT,
                Rule.Category.CUSTOM, true, false, true, "");
        rules.add(global);
        PageDump dump = new PageDump("id", 1700000000000L, "com.tingfeng.tool",
                "com.kwad.sdk.api.proxy.app.KsRewardVideoActivity", "囧次元",
                PageDump.SOURCE_MANUAL, 1272, 2772, false,
                Arrays.asList(
                        node(0, -1, "", "", "com.kwad.dy.sdk:id/ksad_root_container",
                                "android.widget.FrameLayout", false, true, 0, 0, 1272, 2772),
                        node(1, 0, "残忍离开", "", "", "android.widget.Button", true, true, 400, 1600, 872, 1720)));
        Diagnosis diagnosis = new DumpAnalyzer().analyze(dump, rules,
                settings(EngineSettings.RewardMode.AUTO_ABANDON, true, false), true, true);
        boolean found = false;
        for (Suggestion s : diagnosis.suggestions) {
            if (s.kind == Suggestion.Kind.SCOPE_RULE) {
                found = true;
                assertEquals("com.tingfeng.tool", s.targetPackage);
            }
        }
        assertTrue("全局二次确认词应给出收窄建议", found);
    }
}
