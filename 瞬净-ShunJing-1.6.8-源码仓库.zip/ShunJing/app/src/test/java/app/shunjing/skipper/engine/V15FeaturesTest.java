package app.shunjing.skipper.engine;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.Arrays;

import app.shunjing.skipper.data.Preset;
import app.shunjing.skipper.ui.Accent;

/** v1.5：云端接管时机 + 云端坐标安全校验。 */
public class V15FeaturesTest {
    private static final int W = 1080, H = 2340;
    private static final long NEVER = Long.MAX_VALUE;

    // ------------------------------------------------------------ 接管时机

    @Test
    public void eagerTakesOverAroundHalfSecond() {
        assertFalse(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.EAGER, true, true, false, 400L, 3, NEVER));
        assertTrue(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.EAGER, true, true, false, 700L, 2, NEVER));
    }

    @Test
    public void conservativeNeedsSecondsAndManyIdleScans() {
        assertFalse(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.CONSERVATIVE, true, true, false, 700L, 20, NEVER));
        assertFalse(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.CONSERVATIVE, true, true, false, 3500L, 3, NEVER));
        assertTrue(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.CONSERVATIVE, true, true, false, 3500L, 10, NEVER));
    }

    @Test
    public void aggressiveFiresAlmostImmediately() {
        assertTrue(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.AGGRESSIVE, true, true, false, 310L, 1, NEVER));
    }

    @Test
    public void neverTakesOverOnSensitivePageOrWithoutAdContext() {
        assertFalse(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.AGGRESSIVE, true, true, true, 5_000L, 50, NEVER));
        assertFalse(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.AGGRESSIVE, true, false, false, 5_000L, 50, NEVER));
        assertFalse(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.AGGRESSIVE, false, true, false, 5_000L, 50, NEVER));
    }

    @Test
    public void pageCooldownIsRespected() {
        assertFalse(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.EAGER, true, true, false, 5_000L, 50, 1_000L));
        assertTrue(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.EAGER, true, true, false, 5_000L, 50, 6_100L));
    }

    @Test
    public void failedClickPathUsesShorterWait() {
        assertFalse(VisionTriggerPolicy.shouldTakeOverAfterFailedClick(
                VisionTriggerPolicy.Sensitivity.EAGER, true, true, false, 2_000L));
        assertTrue(VisionTriggerPolicy.shouldTakeOverAfterFailedClick(
                VisionTriggerPolicy.Sensitivity.EAGER, true, true, false, 6_100L));
        assertFalse(VisionTriggerPolicy.shouldTakeOverAfterFailedClick(
                VisionTriggerPolicy.Sensitivity.EAGER, true, true, true, 60_000L));
    }

    @Test
    public void minConfidenceDropsWithSensitivity() {
        assertFalse(VisionTriggerPolicy.allowsCoordinateOnly(
                VisionTriggerPolicy.Sensitivity.CONSERVATIVE, 0.62f));
        assertTrue(VisionTriggerPolicy.allowsCoordinateOnly(
                VisionTriggerPolicy.Sensitivity.EAGER, 0.62f));
        assertTrue(VisionTriggerPolicy.allowsCoordinateOnly(
                VisionTriggerPolicy.Sensitivity.AGGRESSIVE, 0.50f));
    }

    // ------------------------------------------------------------ 坐标校验

    @Test
    public void imageOnlyCloseIconWithoutClickableAncestorIsAccepted() {
        ScreenModel screen = adScreen(node(1, 0, "", "", "", "android.widget.ImageView",
                false, true, false, 900, 2100, 1020, 2220));
        int result = VisionRecoveryPolicy.findSafeTarget(screen, 960, 2160, W, H);
        assertEquals(1, result);
        // 旧路径（必须可点击）仍然拒绝它，说明新增路径确实放宽了能力。
        assertEquals(-1, VisionRecoveryPolicy.findSafeNode(screen, 960, 2160, W, H));
    }

    @Test
    public void sensitivePageRejectsAnyCoordinate() {
        ScreenModel screen = new ScreenModel("com.demo", "ScanActivity", false,
                Arrays.asList(
                        node(0, -1, "扫一扫", "", "", "android.widget.FrameLayout",
                                false, true, false, 0, 0, W, H),
                        node(1, 0, "", "", "", "android.widget.ImageView",
                                false, true, false, 900, 2100, 1020, 2220)));
        assertEquals(-1, VisionRecoveryPolicy.findSafeTarget(screen, 960, 2160, W, H));
        assertFalse(VisionRecoveryPolicy.allowCoordinateOnly(screen, 960, 2160, 0.99f,
                VisionTriggerPolicy.Sensitivity.AGGRESSIVE));
    }

    @Test
    public void downloadButtonIsNeverAccepted() {
        ScreenModel screen = adScreen(node(1, 0, "立即下载", "", "", "android.widget.TextView",
                true, true, false, 700, 2000, 1000, 2120));
        assertEquals(-1, VisionRecoveryPolicy.findSafeTarget(screen, 850, 2060, W, H));
        assertFalse(VisionRecoveryPolicy.allowCoordinateOnly(screen, 850, 2060, 0.99f,
                VisionTriggerPolicy.Sensitivity.AGGRESSIVE));
    }

    @Test
    public void fullScreenContainerIsRejectedByAreaCap() {
        ScreenModel screen = adScreen(node(1, 0, "", "", "", "android.widget.FrameLayout",
                false, true, false, 0, 0, W, H));
        assertEquals(-1, VisionRecoveryPolicy.findSafeTarget(screen, W / 2, H / 2, W, H));
    }

    @Test
    public void coordinateOnlyNeedsVisualAdContext() {
        ScreenModel plain = new ScreenModel("com.demo", "SettingsActivity", false,
                Arrays.asList(node(0, -1, "", "", "", "android.widget.FrameLayout",
                        false, true, false, 0, 0, W, H)));
        assertFalse(VisionRecoveryPolicy.allowCoordinateOnly(plain, W / 2, H / 2, 0.99f,
                VisionTriggerPolicy.Sensitivity.AGGRESSIVE));
    }

    // ------------------------------------------------------------ 配色

    @Test
    public void accentFollowsModeOrder() {
        assertEquals(Accent.QUIET, Accent.of(Preset.Mode.SAFE));
        assertEquals(Accent.BALANCED, Accent.of(Preset.Mode.BALANCED));
        assertEquals(Accent.FAST, Accent.of(Preset.Mode.FAST));
        assertEquals(0, Accent.level(Preset.Mode.SAFE));
        assertEquals(2, Accent.level(Preset.Mode.FAST));
    }

    // ------------------------------------------------------------ 工具

    private static ScreenModel adScreen(NodeModel... nodes) {
        NodeModel[] all = new NodeModel[nodes.length + 1];
        all[0] = node(0, -1, "广告", "", "", "android.widget.FrameLayout",
                false, true, false, 0, 0, W, H);
        System.arraycopy(nodes, 0, all, 1, nodes.length);
        return new ScreenModel("com.demo", "AdActivity", true, Arrays.asList(all));
    }

    private static NodeModel node(int index, int parent, String text, String desc, String id,
                                  String className, boolean clickable, boolean visible,
                                  boolean password, int left, int top, int right, int bottom) {
        return new NodeModel(index, parent, text, desc, id, className, clickable, visible,
                password, left, top, right, bottom);
    }
}
