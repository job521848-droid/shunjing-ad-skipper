package app.shunjing.skipper.engine;

import static org.junit.Assert.*;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class AdDecisionEngineTest {
    private final AdDecisionEngine engine = new AdDecisionEngine();
    private final List<Rule> defaults = DefaultRules.create();

    @Test
    public void skipsSplashCountdownWithoutOtherAdLabel() {
        ScreenModel screen = screen("demo.campus", true,
                node(0, -1, "", "", "", "android.widget.FrameLayout", true, 0, 0, 1080, 2400),
                node(1, 0, "跳过 3", "", "", "android.widget.TextView", false, 900, 90, 1040, 160));
        Decision decision = engine.evaluate(screen, defaults, EngineSettings.defaults());
        assertEquals(Decision.Type.CLICK, decision.type);
        assertEquals(1, decision.nodeIndex);
    }

    @Test
    public void doesNotSkipOnboardingWhenFastSplashIsEnabled() {
        ScreenModel screen = screen("demo.newapp", true,
                node(0, -1, "欢迎使用 新手指引 下一步", "", "", "android.widget.FrameLayout", true, 0, 0, 1080, 2400),
                node(1, 0, "跳过", "", "", "android.widget.Button", true, 900, 90, 1040, 160));
        assertEquals(Decision.Type.NONE, engine.evaluate(screen, defaults, EngineSettings.defaults()).type);
    }

    @Test
    public void neverClosesQrScannerEvenWhenAdWordExists() {
        ScreenModel screen = screen("com.example.scan", false,
                node(0, -1, "扫一扫 将二维码放入框内", "广告", "", "android.widget.FrameLayout", true, 0, 0, 1080, 2400),
                node(1, 0, "", "关闭", "", "android.widget.ImageButton", true, 930, 60, 1030, 160));
        assertEquals(Decision.Type.NONE, engine.evaluate(screen, defaults, EngineSettings.defaults()).type);
    }

    @Test
    public void ignoresOrdinaryCloseButtonWithoutAdContext() {
        ScreenModel screen = screen("com.example.reader", false,
                node(0, -1, "扫码结果", "", "", "android.widget.FrameLayout", true, 0, 0, 1080, 2400),
                node(1, 0, "", "×", "", "android.widget.ImageButton", true, 930, 60, 1030, 160));
        assertEquals(Decision.Type.NONE, engine.evaluate(screen, defaults, EngineSettings.defaults()).type);
    }

    @Test
    public void ignoresCloseOnNormalDialog() {
        ScreenModel screen = screen("com.example.reader", false,
                node(0, -1, "阅读设置", "", "", "android.widget.FrameLayout", true, 0, 0, 1080, 2400),
                node(1, 0, "", "关闭", "", "android.widget.ImageButton", true, 930, 60, 1030, 160));
        assertEquals(Decision.Type.NONE, engine.evaluate(screen, defaults, EngineSettings.defaults()).type);
    }

    @Test
    public void closesInterstitialOnlyWithAdEvidence() {
        ScreenModel screen = screen("demo.campus", false,
                node(0, -1, "限时福利 广告", "", "", "android.widget.FrameLayout", true, 0, 0, 1080, 2400),
                node(1, 0, "", "×", "demo.campus:id/ad_close", "android.widget.ImageButton", true, 930, 60, 1030, 160));
        assertEquals(Decision.Type.CLICK, engine.evaluate(screen, defaults, EngineSettings.defaults()).type);
    }

    @Test
    public void protectsPaymentAndPasswordPages() {
        ScreenModel screen = screen("demo.pay", false,
                node(0, -1, "确认支付 支付密码 广告", "", "", "android.widget.FrameLayout", true, 0, 0, 1080, 2400),
                node(1, 0, "跳过广告", "", "", "android.widget.Button", true, 400, 1000, 680, 1120));
        assertEquals(Decision.Type.NONE, engine.evaluate(screen, defaults, EngineSettings.defaults()).type);
    }

    @Test
    public void customRuleCanRequireAdContext() {
        Rule custom = Rule.custom("点我消失", Rule.MatchType.EXACT, true, "demo.campus");
        List<Rule> rules = new ArrayList<>(defaults);
        rules.add(custom);
        ScreenModel noAd = screen("demo.campus", false,
                node(0, -1, "点我消失", "", "", "android.widget.Button", true, 100, 100, 400, 220));
        assertEquals(Decision.Type.NONE, engine.evaluate(noAd, rules, EngineSettings.defaults()).type);
        ScreenModel ad = screen("demo.campus", false,
                node(0, -1, "广告", "", "", "android.widget.FrameLayout", true, 0, 0, 1080, 2400),
                node(1, 0, "点我消失", "", "", "android.widget.Button", true, 100, 100, 400, 220));
        assertEquals(Decision.Type.CLICK, engine.evaluate(ad, rules, EngineSettings.defaults()).type);
    }

    @Test
    public void rewardedVideoIsProtectedByDefault() {
        ScreenModel screen = screen("demo.game", false,
                node(0, -1, "观看视频得奖励 激励视频 广告", "", "", "android.widget.FrameLayout", true, 0, 0, 1080, 2400),
                node(1, 0, "关闭广告", "", "", "android.widget.Button", true, 850, 80, 1040, 170));
        assertEquals(Decision.Type.NONE, engine.evaluate(screen, defaults, EngineSettings.defaults()).type);
        assertEquals(Decision.Type.CLICK, engine.evaluate(screen, defaults,
                new EngineSettings(true, true, true)).type);
    }

    @Test
    public void shakeDetectionNeedsBothShakeAndJumpEvidence() {
        ScreenModel shakeAd = screen("demo.campus", true,
                node(0, -1, "摇一摇 打开第三方应用", "", "", "android.widget.TextView", true, 0, 0, 500, 100));
        assertTrue(AdDecisionEngine.hasShakeAd(shakeAd));
        ScreenModel normal = screen("demo.campus", false,
                node(0, -1, "摇一摇 搜索附近的人", "", "", "android.widget.TextView", true, 0, 0, 500, 100));
        assertFalse(AdDecisionEngine.hasShakeAd(normal));
    }

    private static ScreenModel screen(String pkg, boolean recent, NodeModel... nodes) {
        return new ScreenModel(pkg, pkg + ".MainActivity", recent, Arrays.asList(nodes));
    }

    private static NodeModel node(int index, int parent, String text, String description, String id,
                                  String className, boolean clickable, int left, int top, int right, int bottom) {
        return new NodeModel(index, parent, text, description, id, className, clickable, true,
                false, left, top, right, bottom);
    }
}
