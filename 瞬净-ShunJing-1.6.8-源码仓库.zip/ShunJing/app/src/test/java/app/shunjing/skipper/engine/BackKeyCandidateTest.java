package app.shunjing.skipper.engine;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * v1.6.4 回归：返回键不能被当成广告关闭键。
 *
 * <p>现场是胖乖生活（com.qiekj.user）的一份抓取：真正的 × 在右下角，但不在控件树里；
 * 诊断报告的「疑似关闭控件 #13」其实是 id=view_back 的左上角返回箭头。它和广告角落
 * 关闭键在几何上完全一样（小方块、贴边），但按下去会直接退出页面。这种误报比漏报更糟。
 */
public class BackKeyCandidateTest {
    private static final int W = 1272, H = 2772;

    private static NodeModel node(int index, int parent, String text, String desc, String id,
                                  String className, boolean clickable,
                                  int left, int top, int right, int bottom) {
        return new NodeModel(index, parent, text, desc, id, className, clickable, true,
                false, left, top, right, bottom);
    }

    private static PageDump dump(NodeModel... nodes) {
        return new PageDump("id", 1700000000000L, "com.qiekj.user",
                "com.qiekj.user.MainActivity", "胖乖生活", PageDump.SOURCE_AUTO,
                W, H, true, Arrays.asList(nodes));
    }

    private static NodeModel root() {
        return node(0, -1, "", "", "", "android.widget.FrameLayout", false, 0, 0, W, H);
    }

    @Test
    public void viewBackArrowIsNotACloseCandidate() {
        // 原样复现 #13：[14,159 → 170,315]，id=com.qiekj.user:id/view_back
        PageDump d = dump(root(),
                node(1, 0, "", "", "com.qiekj.user:id/view_back", "android.view.View", true,
                        14, 159, 170, 315));
        List<Diagnosis.Candidate> candidates = DumpAnalyzer.findCandidates(d);
        for (Diagnosis.Candidate c : candidates) {
            assertFalse("返回键不该出现在关闭候选里", c.index == 1);
        }
        assertTrue(candidates.isEmpty());
    }

    @Test
    public void anonymousTopLeftArrowIsAlsoExcluded() {
        // 没写 id、贴左边缘的正方形小 View —— 返回箭头的常见长相。
        PageDump d = dump(root(),
                node(1, 0, "", "", "", "android.view.View", true, 0, 150, 120, 270));
        assertTrue(DumpAnalyzer.findCandidates(d).isEmpty());
    }

    @Test
    public void topRightIconStillCounts() {
        PageDump d = dump(root(),
                node(1, 0, "", "", "", "android.widget.ImageView", true, 1080, 180, 1190, 290));
        List<Diagnosis.Candidate> candidates = DumpAnalyzer.findCandidates(d);
        assertTrue(candidates.size() == 1);
        assertTrue(candidates.get(0).label.contains("右上角"));
    }

    @Test
    public void backgroundIdIsNotMistakenForBack() {
        // "iv_background" 里也有 back 四个字母，但它不是返回键。
        PageDump d = dump(root(),
                node(1, 0, "", "", "com.qiekj.user:id/iv_background", "android.widget.ImageView",
                        true, 900, 180, 1010, 290));
        List<Diagnosis.Candidate> candidates = DumpAnalyzer.findCandidates(d);
        assertTrue(candidates.size() == 1);
        assertTrue(candidates.get(0).label.contains("右上角"));
    }

    @Test
    public void emptyPageExplainsMissingAdLayer() {
        PageDump d = dump(root(),
                node(1, 0, "", "", "com.qiekj.user:id/view_back", "android.view.View", true,
                        14, 159, 170, 315));
        Diagnosis diagnosis = new DumpAnalyzer().analyze(d, DefaultRules.create(),
                EngineSettings.defaults(), true, true);
        boolean explained = false;
        for (Suggestion s : diagnosis.suggestions) {
            if (s.title.contains("没有广告层")) explained = true;
        }
        assertTrue("候选为空时必须说清是快照/可见性问题，而不是让用户去调规则", explained);
    }
}
