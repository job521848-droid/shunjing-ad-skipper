package app.shunjing.skipper.data;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/** v1.5.8: 荣耀这类系统会把无障碍服务悄悄停掉，靠心跳分辨"真在跑"和"看着在跑"。 */
public class ServiceHeartbeatTest {

    private static final long MINUTE = 60_000L;

    @Test
    public void neverStartedCountsAsStale() {
        assertTrue("从没写过心跳，就是没连上", Prefs.isStale(0L, 1_000L));
    }

    @Test
    public void freshBeatIsAlive() {
        long now = 10_000_000L;
        assertFalse("刚写的心跳不能判成掉线", Prefs.isStale(now - 20_000L, now));
        assertFalse("还没到阈值", Prefs.isStale(now - 4 * MINUTE, now));
    }

    @Test
    public void expiredBeatIsStale() {
        long now = 10_000_000L;
        assertTrue("超过五分钟没心跳", Prefs.isStale(now - 6 * MINUTE, now));
        assertTrue("跨了很久", Prefs.isStale(now - 240 * MINUTE, now));
    }

    @Test
    public void clockGoingBackwardsDoesNotFakeADropout() {
        long now = 10_000_000L;
        // 用户手动改时间、或夏令时回拨：心跳时间比现在还晚，不能因此判定服务死了。
        assertFalse(Prefs.isStale(now + 5 * MINUTE, now));
    }
}
