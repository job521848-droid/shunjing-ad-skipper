package app.shunjing.skipper.engine;

import static org.junit.Assert.*;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class DumpAnalyzerTest {
    private final DumpAnalyzer analyzer = new DumpAnalyzer();
    private final List<Rule> defaults = DefaultRules.create();
    private final EngineSettings settings = EngineSettings.defaults();

    private static PageDump dump(String pkg, boolean recent, NodeModel... nodes) {
        return new PageDump("id", 1700000000000L, pkg, pkg + ".AdActivity", "测试应用",
                PageDump.SOURCE_MANUAL, 1080, 2400, recent, Arrays.asList(nodes));
    }

    private static NodeModel node(int index, int parent, String text, String description, String id,
                                  String className, boolean clickable, int left, int top,
                                  int right, int bottom) {
        return new NodeModel(index, parent, text, description, id, className, clickable,
                true, false, left, top, right, bottom);
    }

    private static NodeModel root() {
        return node(0, -1, "", "", "", "android.widget.FrameLayout", false, 0, 0, 1080, 2400);
    }

    private static boolean hasKind(Diagnosis d, Suggestion.Kind kind) {
        for (Suggestion s : d.suggestions) if (s.kind == kind) return true;
        return false;
    }

    private static Rule firstRule(Diagnosis d, Suggestion.Kind kind) {
        for (Suggestion s : d.suggestions) if (s.kind == kind && s.rule != null) return s.rule;
        return null;
    }

    @Test
    public void explainsMissingCloseWordAndSuggestsVerifiedRule() {
        // Ad context exists, but the close label is not covered by any built-in rule.
        PageDump d = dump("demo.campus", false,
                node(0, -1, "限时福利 推广", "", "", "android.widget.FrameLayout", false, 0, 0, 1080, 2400),
                node(1, 0, "点我关闭", "", "demo.campus:id/btn_dismiss", "android.widget.Button",
                        true, 880, 80, 1040, 170));
        Diagnosis diagnosis = analyzer.analyze(d, defaults, settings, true, true);
        assertEquals(Diagnosis.Verdict.NO_MATCHING_RULE, diagnosis.verdict);
        assertTrue(diagnosis.adContext);
        Rule rule = firstRule(diagnosis, Suggestion.Kind.ADD_PHRASE);
        assertNotNull("应给出可采纳的关闭词规则", rule);
        for (Suggestion s : diagnosis.suggestions) {
            if (s.kind == Suggestion.Kind.ADD_PHRASE) assertTrue("建议必须经过回验", s.verified);
        }
        assertEquals("点我关闭", rule.phrase);
        assertTrue("非强语义词应限定应用", rule.packageName.equals("demo.campus"));
        assertTrue("非强语义词应要求广告上下文", rule.requiresAdContext);
    }

    @Test
    public void strongSkipWordIsGlobalAndFast() {
        PageDump d = dump("demo.campus", false,
                node(0, -1, "", "", "", "android.widget.FrameLayout", false, 0, 0, 1080, 2400),
                node(1, 0, "跳过广告 5", "", "", "android.widget.Button", true, 880, 80, 1040, 170));
        Diagnosis diagnosis = analyzer.analyze(d, defaults, settings, true, true);
        // A "跳过广告" label is already covered by built-in rules without ad context.
        assertEquals(Diagnosis.Verdict.SKIPPABLE, diagnosis.verdict);
    }

    @Test
    public void suggestsIdRuleForImageOnlyCloseButton() {
        // 普通页面（Activity 名不含 SDK 特征）：纯图片关闭键够不着几何兜底，只能给 ID 规则。
        // 注意这里不能再用 "AdActivity"——v1.5.3 起 SDK 代理页右上角的纯图标会被直接点掉。
        PageDump d = new PageDump("id", 1700000000000L, "demo.campus", "demo.campus.MainActivity",
                "测试应用", PageDump.SOURCE_MANUAL, 1080, 2400, false,
                Arrays.asList(
                        node(0, -1, "广告", "", "", "android.widget.FrameLayout", false, 0, 0, 1080, 2400),
                        node(1, 0, "", "", "demo.campus:id/ad_close_btn", "android.widget.ImageButton",
                                true, 960, 70, 1050, 160)));
        Diagnosis diagnosis = analyzer.analyze(d, defaults, settings, true, true);
        assertEquals(Diagnosis.Verdict.NO_TEXT_IMAGE_ONLY, diagnosis.verdict);
        Rule rule = firstRule(diagnosis, Suggestion.Kind.ADD_ID_RULE);
        assertNotNull("纯图片按钮应给出 ID 规则", rule);
        assertEquals(Rule.MatchType.ID, rule.matchType);
        assertTrue(rule.matches(d.nodes.get(1)));
    }

    @Test
    public void adProxyPageCornerIconNeedsNoRuleAtAll() {
        // 同一个页面，但 Activity 是广告 SDK 代理页：右上角 90×90 纯图标由几何兜底处理，
        // 不需要用户再加任何规则。
        PageDump d = dump("demo.campus", false,
                node(0, -1, "广告", "", "", "android.widget.FrameLayout", false, 0, 0, 1080, 2400),
                node(1, 0, "", "", "", "android.widget.ImageButton", false, 960, 70, 1050, 160));
        Diagnosis diagnosis = analyzer.analyze(d, defaults, settings, true, true);
        assertEquals(Diagnosis.Verdict.SKIPPABLE, diagnosis.verdict);
        assertTrue(diagnosis.headline.contains("#1") || diagnosis.evidence.toString().contains("#1"));
    }

    @Test
    public void neverSuggestsWeakeningQrScannerProtection() {
        PageDump d = dump("com.example.scan", false,
                node(0, -1, "扫一扫 将二维码放入框内", "", "", "android.widget.FrameLayout", false, 0, 0, 1080, 2400),
                node(1, 0, "", "关闭", "", "android.widget.ImageButton", true, 930, 60, 1030, 160));
        Diagnosis diagnosis = analyzer.analyze(d, defaults, settings, true, true);
        assertEquals(Diagnosis.Verdict.PROTECTED, diagnosis.verdict);
        assertTrue(diagnosis.sensitive);
        for (Suggestion s : diagnosis.suggestions) {
            assertNull("敏感页不得生成任何自动点击规则", s.rule);
        }
        assertFalse(hasKind(diagnosis, Suggestion.Kind.RELAX_FOR_APP));
    }

    @Test
    public void explainsNoAdEvidenceWithoutGlobalRelaxation() {
        PageDump d = dump("demo.reader", false,
                node(0, -1, "阅读设置", "", "", "android.widget.FrameLayout", false, 0, 0, 1080, 2400),
                node(1, 0, "", "×", "", "android.widget.ImageButton", true, 930, 60, 1030, 160));
        Diagnosis diagnosis = analyzer.analyze(d, defaults, settings, true, true);
        assertEquals(Diagnosis.Verdict.NO_AD_EVIDENCE, diagnosis.verdict);
        assertFalse(diagnosis.adContext);
        for (Suggestion s : diagnosis.suggestions) {
            if (s.rule != null) {
                assertFalse("放宽规则不得全局生效", s.rule.packageName.isEmpty());
            }
        }
    }

    @Test
    public void reportsMasterSwitchOff() {
        PageDump d = dump("demo.campus", false,
                node(0, -1, "广告", "", "", "android.widget.FrameLayout", false, 0, 0, 1080, 2400),
                node(1, 0, "跳过广告", "", "", "android.widget.Button", true, 880, 80, 1040, 170));
        Diagnosis diagnosis = analyzer.analyze(d, defaults, settings, false, true);
        assertEquals(Diagnosis.Verdict.MASTER_OFF, diagnosis.verdict);
        assertTrue(hasKind(diagnosis, Suggestion.Kind.TOGGLE_MASTER));
    }

    @Test
    public void reportsDisabledApp() {
        PageDump d = dump("demo.campus", false,
                node(0, -1, "广告", "", "", "android.widget.FrameLayout", false, 0, 0, 1080, 2400),
                node(1, 0, "跳过广告", "", "", "android.widget.Button", true, 880, 80, 1040, 170));
        Diagnosis diagnosis = analyzer.analyze(d, defaults, settings, true, false);
        assertEquals(Diagnosis.Verdict.APP_DISABLED, diagnosis.verdict);
        assertTrue(hasKind(diagnosis, Suggestion.Kind.ENABLE_APP));
    }

    @Test
    public void rewardedVideoProtectionOffersThreeStatePolicy() {
        PageDump d = dump("demo.game", false,
                node(0, -1, "观看视频得奖励 激励视频", "", "", "android.widget.FrameLayout", false, 0, 0, 1080, 2400),
                node(1, 0, "关闭广告", "", "", "android.widget.Button", true, 850, 80, 1040, 170));
        Diagnosis diagnosis = analyzer.analyze(d, defaults, settings, true, true);
        assertEquals(Diagnosis.Verdict.REWARDED, diagnosis.verdict);
        assertTrue(hasKind(diagnosis, Suggestion.Kind.SET_REWARD_MODE));
        assertTrue(hasKind(diagnosis, Suggestion.Kind.ADD_REWARD_APP));
        // Never suggest disabling the sensitive-page lock or a global evidence-free rule.
        for (Suggestion s : diagnosis.suggestions) {
            if (s.rule != null) assertTrue(s.rule.requiresAdContext);
        }
    }

    @Test
    public void cleanPhraseStripsCountdownAndBrackets() {
        assertEquals("跳过", DumpAnalyzer.cleanPhrase("跳过 5"));
        assertEquals("跳过", DumpAnalyzer.cleanPhrase("跳过 3s"));
        assertEquals("关闭", DumpAnalyzer.cleanPhrase("关闭(5)"));
        assertEquals("", DumpAnalyzer.cleanPhrase(""));
    }

    @Test
    public void idFragmentKeepsOnlyTheLeafName() {
        assertEquals("ad_close", DumpAnalyzer.idFragment("demo.campus:id/ad_close"));
        assertEquals("skip_btn", DumpAnalyzer.idFragment("demo.campus:id/skip_btn"));
    }

    @Test
    public void verifiedRuleActuallyFixesTheDecision() {
        PageDump d = dump("demo.campus", false,
                node(0, -1, "限时福利 推广", "", "", "android.widget.FrameLayout", false, 0, 0, 1080, 2400),
                node(1, 0, "点我关闭", "", "demo.campus:id/btn_dismiss", "android.widget.Button",
                        true, 880, 80, 1040, 170));
        assertEquals(Decision.Type.NONE,
                new AdDecisionEngine().evaluate(d.toScreen(), defaults, settings).type);
        Diagnosis diagnosis = analyzer.analyze(d, defaults, settings, true, true);
        Rule rule = firstRule(diagnosis, Suggestion.Kind.ADD_PHRASE);
        assertNotNull(rule);
        List<Rule> extended = new ArrayList<>(defaults);
        extended.add(rule);
        assertEquals(Decision.Type.CLICK,
                new AdDecisionEngine().evaluate(d.toScreen(), extended, settings).type);
    }

    @Test
    public void reportContainsTreeAndCanMaskText() {
        PageDump d = dump("demo.campus", false,
                node(0, -1, "限时福利 推广", "", "", "android.widget.FrameLayout", false, 0, 0, 1080, 2400),
                node(1, 0, "点我关闭", "", "demo.campus:id/btn_dismiss", "android.widget.Button",
                        true, 880, 80, 1040, 170));
        Diagnosis diagnosis = analyzer.analyze(d, defaults, settings, true, true);
        String plain = DumpReport.build(d, diagnosis, defaults, settings, false);
        assertTrue(plain.contains("完整控件树"));
        assertTrue(plain.contains("btn_dismiss"));
        assertTrue(plain.contains("点我关闭"));
        String masked = DumpReport.build(d, diagnosis, defaults, settings, true);
        assertFalse("脱敏报告不得包含页面文字", masked.contains("点我关闭"));
        assertTrue(masked.contains("文字已隐藏"));
        assertTrue("脱敏仍需保留控件 ID", masked.contains("btn_dismiss"));
        assertNotNull(DumpReport.summary(d, diagnosis));
    }

    @Test
    public void passwordFieldsNeverLeakIntoReport() {
        NodeModel passwordNode = new NodeModel(1, 0, "我的密码123", "", "demo:id/pwd",
                "android.widget.EditText", true, true, true, 100, 300, 900, 420);
        PageDump d = dump("demo.pay", false, root(), passwordNode);
        Diagnosis diagnosis = analyzer.analyze(d, defaults, settings, true, true);
        String report = DumpReport.build(d, diagnosis, defaults, settings, false);
        assertFalse(report.contains("我的密码123"));
        assertTrue(report.contains("密码字段已隐藏"));
    }
}
