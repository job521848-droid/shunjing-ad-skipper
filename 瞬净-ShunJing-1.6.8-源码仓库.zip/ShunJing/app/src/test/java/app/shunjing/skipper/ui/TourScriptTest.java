package app.shunjing.skipper.ui;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 导览脚本的守门测试。
 *
 * <p>引导文案是最容易被改坏的东西：少一步、指错控件、把「极速会放弃奖励」说反，
 * 用户就会按错误的预期使用。这里把几件必须成立的事钉死。
 */
public class TourScriptTest {

    private static TourScript.Step stepByTarget(String target) {
        for (TourScript.Step step : TourScript.steps()) {
            if (target.equals(step.target)) return step;
        }
        return null;
    }

    private static String corpus(TourScript.Step step) {
        StringBuilder builder = new StringBuilder();
        builder.append(step.title).append(' ').append(step.body);
        if (step.hint != null) builder.append(' ').append(step.hint);
        for (String line : step.lines) builder.append(' ').append(line);
        return builder.toString();
    }

    @Test
    public void coversEveryHomeControlOnce() {
        List<TourScript.Step> steps = TourScript.steps();
        assertEquals(8, steps.size());

        Set<String> seen = new HashSet<>();
        for (int i = 0; i < steps.size() - 1; i++) {
            String target = steps.get(i).target;
            assertNotNull("第 " + (i + 1) + " 步必须有高亮目标", target);
            assertTrue("目标重复：" + target, seen.add(target));
        }
        // 最后一步是整页说明，不高亮任何控件。
        assertNull(steps.get(steps.size() - 1).target);
    }

    @Test
    public void targetsAreKnownKeys() {
        Set<String> keys = new HashSet<>(Arrays.asList(
                TourScript.T_SWITCH, TourScript.T_ENABLE, TourScript.T_PAUSE,
                TourScript.T_MODE, TourScript.T_DUMP, TourScript.T_LEARN, TourScript.T_MORE));
        for (TourScript.Step step : TourScript.steps()) {
            if (step.target == null) continue;
            assertTrue("未知的目标 key：" + step.target, keys.contains(step.target));
        }
    }

    @Test
    public void everyStepSaysSomething() {
        for (TourScript.Step step : TourScript.steps()) {
            assertFalse(step.tag.isEmpty());
            assertFalse(step.title.isEmpty());
            assertTrue("正文太短：" + step.tag, step.body.length() >= 12);
        }
    }

    @Test
    public void modeStepWarnsAboutReward() {
        TourScript.Step step = stepByTarget(TourScript.T_MODE);
        assertNotNull(step);
        String text = corpus(step);
        assertTrue(text.contains("安静"));
        assertTrue(text.contains("均衡"));
        assertTrue(text.contains("极速"));
        // 这句必须保留：切极速会放弃激励视频奖励，短剧解锁可能失败。
        assertTrue(text.contains("放弃奖励"));
    }

    @Test
    public void learnStepPointsAtNotification() {
        TourScript.Step step = stepByTarget(TourScript.T_LEARN);
        assertNotNull(step);
        String text = corpus(step);
        assertTrue(text.contains("通知栏"));
        assertTrue(text.contains("学习"));
    }

    @Test
    public void recoveryStepIsOrdered() {
        TourScript.Step step = TourScript.steps().get(TourScript.steps().size() - 1);
        assertEquals(5, step.lines.size());
        assertTrue(step.lines.get(0).contains("模式"));
        assertTrue(step.lines.get(1).contains("学习"));
        assertTrue(step.lines.get(2).contains("诊断"));
        assertTrue(step.lines.get(4).contains("发出来"));
    }

    @Test
    public void safetyLineNeverDisappears() {
        String all = "";
        for (TourScript.Step step : TourScript.steps()) all += corpus(step);
        assertTrue("必须保留支付/扫码页不上传的说明", all.contains("支付"));
        assertTrue(all.contains("扫码"));
    }

    @Test
    public void noOverpromising() {
        StringBuilder all = new StringBuilder();
        for (TourScript.Step step : TourScript.steps()) all.append(corpus(step));
        String text = all.toString();
        assertFalse(text.contains("保证"));
        assertFalse(text.contains("100%"));
        assertFalse(text.contains("全部广告"));
    }
}
