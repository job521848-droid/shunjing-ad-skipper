package app.shunjing.skipper.engine;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * v1.6 回归：桌面硬锁、疑似页评分、摇一摇跳转回退、云端触发放宽后的安全边界。
 *
 * <p>现场来源：用户抓到的 com.android.launcher / ListView 快照（1272×2772，65 节点），
 * 引擎判 NO_AD_EVIDENCE，但页面上根本没有广告——那是最近任务列表。
 */
public class V16FeaturesTest {
    private static final int W = 1272, H = 2772;
    private static final long NEVER = Long.MAX_VALUE;
    private final AdDecisionEngine engine = new AdDecisionEngine();
    private final List<Rule> defaults = DefaultRules.create();

    private static NodeModel node(int index, int parent, String text, String desc, String id,
                                  String className, boolean clickable, boolean visible,
                                  int left, int top, int right, int bottom) {
        return new NodeModel(index, parent, text, desc, id, className, clickable, visible,
                false, left, top, right, bottom);
    }

    private static EngineSettings settings() {
        return new EngineSettings(true, true, EngineSettings.RewardMode.PROTECT,
                Collections.<String>emptySet(), true, true, false);
    }

    /** 最近任务列表：卡片头部、"更多"菜单、整屏缩略图，一个广告都没有。 */
    private static ScreenModel recentsScreen() {
        return new ScreenModel("com.android.launcher", "android.widget.ListView", true,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, 1272, 2772),
                        node(1, 0, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, 1272, 2772),
                        node(2, 1, "", "无最近任务", "com.android.launcher:id/overview_panel",
                                "android.widget.ListView", false, true, 0, 0, 1272, 2772),
                        node(3, 2, "", "瞬净", "", "android.widget.FrameLayout", true, true, 0, 199, 402, 2340),
                        node(4, 3, "", "", "com.android.launcher:id/oplus_task_header",
                                "android.widget.FrameLayout", true, true, 0, 101, 41, 294),
                        node(5, 3, "", "", "com.android.launcher:id/snapshot",
                                "android.view.View", false, true, 0, 382, 402, 2340),
                        node(6, 3, "", "更多", "com.android.launcher:id/oplus_task_header_menu_button_stack",
                                "android.widget.ImageButton", true, true, 0, 382, 89, 504)));
    }

    /** 无任何广告文案的全屏 H5 落地页：旧版会在这里直接 return，云端永远叫不醒。 */
    private static ScreenModel suspectH5Screen() {
        return new ScreenModel("com.example.game", "com.example.game.ui.WebViewActivity", true,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, 1272, 2772),
                        node(1, 0, "", "", "", "android.webkit.WebView", false, true, 0, 100, 1272, 2600),
                        node(2, 1, "", "", "", "android.view.View", false, true, 40, 150, 1200, 2500),
                        node(3, 0, "", "", "", "android.widget.ImageView", false, true, 1150, 150, 1230, 230)));
    }

    /** 普通 App 首页：有列表骨架、有底部导航，绝不该被问云端。 */
    private static ScreenModel normalHomeScreen() {
        return new ScreenModel("com.tencent.mm", "com.tencent.mm.ui.LauncherUI", true,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, 1080, 2340),
                        node(1, 0, "", "", "", "androidx.recyclerview.widget.RecyclerView", false, true, 0, 200, 1080, 2100),
                        node(2, 1, "张三", "", "", "android.widget.TextView", true, true, 100, 300, 900, 400),
                        node(3, 0, "首页", "", "", "android.widget.TextView", true, true, 0, 2150, 216, 2340),
                        node(4, 0, "发现", "", "", "android.widget.TextView", true, true, 216, 2150, 432, 2340),
                        node(5, 0, "我的", "", "", "android.widget.TextView", true, true, 648, 2150, 864, 2340),
                        node(6, 0, "消息", "", "", "android.widget.TextView", true, true, 432, 2150, 648, 2340)));
    }

    // ------------------------------------------------------------ 桌面硬保护

    @Test
    public void launcherPackagesAreHardLocked() {
        assertTrue(AdDecisionEngine.isLauncherPackage("com.android.launcher"));
        assertTrue(AdDecisionEngine.isLauncherPackage("com.android.launcher3"));
        assertTrue(AdDecisionEngine.isLauncherPackage("com.miui.home"));
        assertTrue(AdDecisionEngine.isLauncherPackage("com.oppo.launcher"));
        assertTrue(AdDecisionEngine.isProtectedPackage("com.android.launcher"));
        assertFalse(AdDecisionEngine.isLauncherPackage("com.android.chrome"));
        assertFalse(AdDecisionEngine.isProtectedPackage("com.tencent.mm"));
    }

    @Test
    public void recentsScreenNeverProducesAClick() {
        ScreenModel screen = recentsScreen();
        Decision decision = engine.evaluate(screen, defaults, settings(),
                Collections.<LayoutAnchorRule>emptyList(), W, H);
        assertEquals(Decision.Type.NONE, decision.type);
        assertFalse(AdDecisionEngine.hasAdContext(screen, settings()));
        assertEquals(0, AdSuspectDetector.score(screen));
        assertFalse(AdSuspectDetector.isSuspect(screen));
    }

    @Test
    public void diagnosingALauncherDumpSaysLauncherNotAd() {
        PageDump dump = new PageDump("id", 0L, "com.android.launcher", "android.widget.ListView",
                "系统桌面", PageDump.SOURCE_AUTO, W, H, true, recentsScreen().nodes);
        Diagnosis diagnosis = new DumpAnalyzer().analyze(dump, defaults, settings(), true, true);
        assertEquals(Diagnosis.Verdict.LAUNCHER, diagnosis.verdict);
        for (Suggestion suggestion : diagnosis.suggestions) {
            assertFalse("桌面上不该出现任何加规则的建议",
                    suggestion.kind == Suggestion.Kind.ADD_PHRASE
                            || suggestion.kind == Suggestion.Kind.ADD_ID_RULE
                            || suggestion.kind == Suggestion.Kind.RELAX_FOR_APP);
        }
    }

    // ------------------------------------------------------------ 疑似页评分

    @Test
    public void fullScreenWebViewWithoutAdWordsIsSuspect() {
        ScreenModel screen = suspectH5Screen();
        assertFalse("确实没有广告证据", AdDecisionEngine.hasAdContext(screen, settings()));
        assertTrue(AdSuspectDetector.isSuspect(screen));
        assertTrue(AdSuspectDetector.score(screen) >= AdSuspectDetector.THRESHOLD);
    }

    @Test
    public void normalAppHomeIsNotSuspect() {
        assertFalse(AdSuspectDetector.isSuspect(normalHomeScreen()));
    }

    @Test
    public void sensitiveScreenIsNeverSuspect() {
        ScreenModel qr = new ScreenModel("com.tencent.mm", "com.tencent.mm.ui.QrCodeActivity", true,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, 1080, 2340),
                        node(1, 0, "扫码", "", "", "android.widget.TextView", true, true, 0, 100, 400, 200),
                        node(2, 0, "", "", "", "android.widget.ImageView", false, true, 900, 100, 1000, 200)));
        assertEquals(0, AdSuspectDetector.score(qr));
    }

    // ------------------------------------------------------------ 摇一摇跳转回退

    @Test
    public void crossAppJumpIsRevertedOnce() {
        ShakeJumpGuard guard = new ShakeJumpGuard();
        ScreenModel ad = suspectH5Screen();
        guard.arm(ad, "fp-ad", 1_000L);
        assertEquals(ShakeJumpGuard.Result.NONE, guard.checkCrossApp(ad.packageName, 1_200L, 0L));
        assertEquals(ShakeJumpGuard.Result.CROSS_APP,
                guard.checkCrossApp("com.android.chrome", 1_600L, 0L));
        // 已经消耗掉，不会连着退两次
        assertEquals(ShakeJumpGuard.Result.NONE, guard.checkCrossApp("com.android.chrome", 1_800L, 0L));
    }

    @Test
    public void lateJumpWithinEightSecondsStillCaught() {
        ShakeJumpGuard guard = new ShakeJumpGuard();
        guard.arm(suspectH5Screen(), "fp-ad", 1_000L);
        assertEquals(ShakeJumpGuard.Result.CROSS_APP, guard.checkCrossApp("com.heytap.market", 7_500L, 0L));
    }

    @Test
    public void jumpOutsideWindowIsIgnored() {
        ShakeJumpGuard guard = new ShakeJumpGuard();
        guard.arm(suspectH5Screen(), "fp-ad", 1_000L);
        assertEquals(ShakeJumpGuard.Result.NONE, guard.checkCrossApp("com.heytap.market", 12_000L, 0L));
    }

    @Test
    public void userClickDisarmsTheGuard() {
        ShakeJumpGuard guard = new ShakeJumpGuard();
        guard.arm(suspectH5Screen(), "fp-ad", 1_000L);
        // 用户在 300ms 前刚点过屏幕：那是他自己要打开的，绝不抢
        assertEquals(ShakeJumpGuard.Result.NONE, guard.checkCrossApp("com.android.chrome", 1_300L, 1_000L));
        assertFalse(guard.armed());
    }

    @Test
    public void samePackageLandingIsCaughtButNormalPageIsNot() {
        ShakeJumpGuard guard = new ShakeJumpGuard();
        guard.arm(suspectH5Screen(), "fp-ad", 1_000L);
        assertEquals(ShakeJumpGuard.Result.SAME_APP_LANDING,
                guard.checkSamePageChange("com.example.game", "com.example.game.ui.LandingWebActivity",
                        "fp-landing", 1_500L, 0L));

        ShakeJumpGuard other = new ShakeJumpGuard();
        other.arm(suspectH5Screen(), "fp-ad", 1_000L);
        assertEquals(ShakeJumpGuard.Result.NONE,
                other.checkSamePageChange("com.example.game", "com.example.game.MainActivity",
                        "fp-main", 1_500L, 0L));
    }

    @Test
    public void revertCountIsCapped() {
        ShakeJumpGuard guard = new ShakeJumpGuard();
        guard.arm(suspectH5Screen(), "fp-ad", 1_000L);
        assertEquals(ShakeJumpGuard.Result.CROSS_APP, guard.checkCrossApp("com.a", 1_200L, 0L));
        guard.arm(suspectH5Screen(), "fp-ad", 2_000L);
        assertEquals(ShakeJumpGuard.Result.CROSS_APP, guard.checkCrossApp("com.b", 2_200L, 0L));
        guard.arm(suspectH5Screen(), "fp-ad", 3_000L);
        assertEquals("同一波广告最多退 2 次", ShakeJumpGuard.Result.NONE,
                guard.checkCrossApp("com.c", 3_200L, 0L));
    }

    // ------------------------------------------------------------ 云端触发与落地

    @Test
    public void suspectPageCanWakeCloudWithoutStrongEvidence() {
        assertFalse(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.EAGER, true, false, true, false, 900L, 2, NEVER));
        assertTrue(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.EAGER, true, false, true, false, 1_300L, 2, NEVER));
        assertTrue(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.AGGRESSIVE, true, false, true, false, 600L, 1, NEVER));
        // 敏感页、云端没配好，一律不接管
        assertFalse(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.AGGRESSIVE, true, false, true, true, 9_000L, 90, NEVER));
        assertFalse(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.AGGRESSIVE, false, false, true, false, 9_000L, 90, NEVER));
        // 既没有强证据也不像广告 → 连问都不问
        assertFalse(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.AGGRESSIVE, true, false, false, false, 9_000L, 90, NEVER));
    }

    @Test
    public void suspectOnlyCoordinateTapNeedsHigherConfidence() {
        ScreenModel screen = suspectH5Screen();
        int x = 1190, y = 190;
        assertTrue(VisionRecoveryPolicy.allowCoordinateOnly(screen, x, y, 0.86f,
                VisionTriggerPolicy.Sensitivity.AGGRESSIVE, 0.48f, true));
        assertFalse("仅疑似时必须 0.80 以上", VisionRecoveryPolicy.allowCoordinateOnly(screen, x, y, 0.72f,
                VisionTriggerPolicy.Sensitivity.AGGRESSIVE, 0.48f, true));
    }

    @Test
    public void suspectOnlyNeverTapsDangerousControls() {
        ScreenModel screen = new ScreenModel("com.example.game", "com.example.game.ui.WebViewActivity", true,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, 1272, 2772),
                        node(1, 0, "", "", "", "android.webkit.WebView", false, true, 0, 100, 1272, 2600),
                        node(2, 1, "", "", "", "android.view.View", false, true, 40, 150, 1200, 2500),
                        node(3, 0, "", "", "", "android.widget.ImageView", false, true, 1150, 150, 1230, 230),
                        node(4, 0, "立即下载", "", "btn_download", "android.widget.Button", true, true, 300, 2300, 900, 2440)));
        assertFalse(VisionRecoveryPolicy.allowCoordinateOnly(screen, 600, 2370, 0.95f,
                VisionTriggerPolicy.Sensitivity.AGGRESSIVE, 0.48f, true));
    }

    @Test
    public void launcherIsNeverEligibleForCloudTap() {
        ScreenModel screen = recentsScreen();
        assertFalse(VisionRecoveryPolicy.allowCoordinateOnly(screen, 40, 200, 0.99f,
                VisionTriggerPolicy.Sensitivity.AGGRESSIVE, 0.48f, true));
    }

    @Test
    public void shakeAdOnRealDumpStillClicksBeforeAnyCloudCall() {
        // 摇一摇页面本地能点，就不该走到"疑似"这条路
        ScreenModel ad = new ScreenModel("com.huachenjie.shandong_school",
                "com.huachenjie.shandong_school.home.HomeActivity", true,
                new ArrayList<>(Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 141, 1272, 2772),
                        node(1, 0, "", "", "", "android.widget.FrameLayout", false, true, 0, 141, 1272, 2772),
                        node(2, 1, "", "", "", "android.widget.ImageView", false, true, 0, 141, 1272, 2500),
                        node(3, 1, "摇一摇或点击跳转至第三方应用，请注意保护个人隐私", "", "",
                                "android.widget.TextView", false, true, 68, 2559, 1028, 2630),
                        node(4, 1, "", "", "", "android.widget.ImageView", false, true, 1140, 2600, 1210, 2670))));
        Decision decision = engine.evaluate(ad, defaults, settings(),
                Collections.<LayoutAnchorRule>emptyList(), W, H);
        assertEquals(Decision.Type.CLICK, decision.type);
        assertEquals("shake_ad_close", decision.ruleId);
    }
}
