package app.shunjing.skipper.engine;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * v1.5.1 回归：穿山甲 WebView 模板广告（com.xiaoyang.ydxy / 校园跑）。
 *
 * <p>现场来源：用户抓的真实快照，1272×2772，59 个节点 <b>全部 c=0</b>，
 * 全树只有 6 个节点带文字（穿山甲 / 反馈 / 广告 / 点击或上滑打开 /
 * 跳转至详情页或第三方应用），没有一处「关闭 / ×」。
 *
 * <p>关闭键在 #38（Image [1130,1194 → 1183,1240]），它被 #37、#36 两层容器包着，
 * 三层都不可点击。唯一能定位它的信号是模板的「反馈 ⟷ 关闭」同排对偶：
 * 「反馈」#35 在左 [45,1191 → 133,1243]，关闭键在右，两者垂直中心都是 1217。
 */
public class V151WebAdTest {
    private static final int W = 1272, H = 2772;
    private final AdDecisionEngine engine = new AdDecisionEngine();
    private final List<Rule> defaults = DefaultRules.create();

    private static NodeModel n(int index, int parent, String text, String desc, String id,
                               String cls, boolean clickable, int l, int t, int r, int b) {
        return new NodeModel(index, parent, text, desc, id, cls, clickable, true, false,
                l, t, r, b);
    }

    /** 真实树里 #16 / #58 是 v=0 的零尺寸占位，必须占位以保持 index == 下标。 */
    private static NodeModel hidden(int index, int parent, String cls, int l, int t, int r, int b) {
        return new NodeModel(index, parent, "", "", "", cls, false, false, false, l, t, r, b);
    }

    private static EngineSettings settings() {
        return new EngineSettings(true, true, EngineSettings.RewardMode.AUTO_ABANDON,
                Collections.<String>emptySet(), true, true, false, true, true);
    }

    /** 用户提供的真实控件树，坐标与 id 原样保留。 */
    private static ScreenModel schoolRunAd() {
        List<NodeModel> nodes = new ArrayList<>(Arrays.asList(
                n(0, -1, "", "", "", "android.widget.FrameLayout", false, 0, 141, 1272, 2772),
                n(1, 0, "", "", "", "android.widget.LinearLayout", false, 0, 141, 1272, 2772),
                n(2, 1, "", "", "android:id/content", "android.widget.FrameLayout", false, 0, 141, 1272, 2772),
                n(3, 2, "", "", "", "android.widget.FrameLayout", false, 0, 141, 1272, 2772),
                n(4, 3, "", "", "", "android.widget.FrameLayout", false, 0, 141, 1272, 2772),
                n(5, 4, "", "", "", "android.widget.FrameLayout", false, 0, 141, 1272, 2772),
                n(6, 5, "", "", "", "android.widget.FrameLayout", false, 0, 141, 1272, 2772),
                n(7, 6, "", "", "", "android.widget.FrameLayout", false, 0, 351, 1272, 2772),
                n(8, 4, "", "", "", "android.widget.FrameLayout", false, 0, 141, 1272, 2772),
                n(9, 8, "", "", "", "android.widget.FrameLayout", false, 0, 141, 1272, 2772),
                n(10, 9, "", "", "", "android.widget.LinearLayout", false, 0, 141, 1272, 2772),
                n(11, 10, "", "", "", "android.widget.FrameLayout", false, 0, 141, 1272, 2772),
                n(12, 4, "", "", "", "android.widget.FrameLayout", false, 0, 141, 1272, 2772),
                n(13, 12, "", "", "", "android.widget.FrameLayout", false, 0, 141, 1272, 2772),
                n(14, 13, "", "", "", "android.widget.FrameLayout", false, 0, 141, 1272, 2772),
                n(15, 14, "", "", "", "android.widget.FrameLayout", false, 0, 141, 1271, 2772),
                hidden(16, 15, "android.view.View", 0, 141, 0, 141),
                n(17, 15, "", "", "", "android.widget.FrameLayout", false, 0, 141, 1271, 2772),
                n(18, 17, "", "", "", "android.widget.FrameLayout", false, 0, 141, 1271, 2772),
                n(19, 18, "", "", "", "android.webkit.WebView", false, 0, 141, 1271, 2772),
                n(20, 19, "穿山甲", "", "", "android.webkit.WebView", false, 0, 141, 1272, 2774),
                n(21, 20, "", "", "", "android.view.View", false, 0, 141, 1272, 2774),
                n(22, 21, "", "", "render-view", "android.view.View", false, 0, 141, 1272, 2774),
                n(23, 22, "", "", "ad-container-0", "android.view.View", false, 0, 141, 1272, 2774),
                n(24, 23, "", "", "cl-1", "android.view.View", false, 0, 141, 1272, 2774),
                n(25, 24, "", "", "10dc0e", "android.view.View", false, 0, 141, 1272, 2774),
                n(26, 25, "", "", "122722", "android.widget.TextView", false, 0, 141, 1272, 1100),
                n(27, 25, "", "", "1aad72", "android.view.View", false, 0, 1096, 1272, 1817),
                n(28, 27, "", "", "8cbc57", "android.view.View", false, 0, 1096, 1272, 1817),
                n(29, 28, "", "", "9ddbeb", "android.view.View", false, 0, 1096, 1272, 1817),
                n(30, 29, "", "", "8f04fa", "android.view.View", false, 0, 1096, 1272, 1817),
                n(31, 30, "", "62fb748dbffe4ce6ba7f6a99fc075b4d~tplv-qgppglrh0x-noop", "",
                        "android.widget.Image", false, 0, 1096, 1272, 1817),
                n(32, 27, "", "", "a31cf3", "android.view.View", false, 0, 1100, 1272, 1331),
                n(33, 32, "", "", "735b26", "android.view.View", false, 0, 1100, 1272, 1331),
                n(34, 33, "", "", "aa39b4", "android.view.View", false, 14, 1177, 171, 1257),
                n(35, 34, "反馈", "", "665045", "android.widget.TextView", false, 45, 1191, 133, 1243),
                n(36, 33, "", "", "01dce7", "android.view.View", false, 1057, 1114, 1260, 1317),
                n(37, 36, "", "", "7b5368", "android.view.View", false, 1113, 1177, 1200, 1257),
                n(38, 37, "", "", "", "android.widget.Image", false, 1130, 1194, 1183, 1240),
                n(39, 27, "", "", "b0fd03", "android.view.View", false, 0, 1751, 178, 1817),
                n(40, 39, "", "", "50fa95", "android.view.View", false, 0, 1751, 178, 1817),
                n(41, 40, "", "", "5dbeb4", "android.view.View", false, 10, 1744, 87, 1821),
                n(42, 41, "", "", "", "android.widget.Image", false, 10, 1744, 87, 1821),
                n(43, 40, "广告", "", "e98af2", "android.widget.TextView", false, 84, 1754, 164, 1810),
                n(44, 25, "", "", "995fe6", "android.view.View", false, 0, 1814, 1272, 2774),
                n(45, 44, "", "", "08121a", "android.view.View", false, 0, 1793, 1272, 2774),
                n(46, 45, "", "", "6bb38b", "android.view.View", false, 0, 1793, 1272, 2774),
                n(47, 46, "", "", "93de5a", "android.view.View", false, 0, 1908, 1272, 2774),
                n(48, 47, "", "", "39dc59", "android.widget.TextView", false, 469, 1908, 948, 2388),
                n(49, 46, "", "", "b9764c", "android.view.View", false, 0, 2129, 1272, 2774),
                n(50, 49, "点击或上滑打开", "", "9e667e", "android.widget.TextView", false, 402, 2398, 868, 2479),
                n(51, 49, "", "", "c54acd", "android.view.View", false, 0, 2475, 1272, 2563),
                n(52, 51, "跳转至详情页或第三方应用", "", "bc472e", "android.widget.TextView", false, 325, 2500, 945, 2563),
                n(53, 44, "", "", "", "android.widget.TextView", false, 1267, 2773, 1267, 2773),
                n(54, 25, "", "", "adc1908", "android.view.View", false, 0, 141, 1272, 141),
                n(55, 54, "", "", "b582351", "android.widget.TextView", false, 0, 141, 1272, 141),
                n(56, 15, "", "", "", "android.widget.FrameLayout", false, 0, 141, 1271, 2772),
                n(57, 15, "", "", "", "android.widget.FrameLayout", false, 0, 141, 1271, 2772),
                hidden(58, 57, "android.widget.FrameLayout", 0, 141, 0, 141)));
        return new ScreenModel("com.xiaoyang.ydxy", "android.widget.ListView", true, nodes);
    }

    @Test
    public void closesTemplateAdByFeedbackPair() {
        Decision decision = engine.evaluate(schoolRunAd(), defaults, settings(),
                Collections.<LayoutAnchorRule>emptyList(), W, H);
        assertEquals(Decision.Type.CLICK, decision.type);
        assertEquals("web_ad_template_close", decision.ruleId);
        // 一定是 #38（最内层那个 Image），不是包着它的 #37 / #36。
        assertEquals(38, decision.nodeIndex);
    }

    @Test
    public void locatorReportsTheInnermostLeaf() {
        WebAdTemplateLocator.Hit hit = WebAdTemplateLocator.find(schoolRunAd(), W, H);
        assertTrue(hit != null);
        assertEquals(38, hit.nodeIndex);
        assertTrue(hit.score >= 80);
    }

    @Test
    public void disabledSwitchMeansNoTemplateClick() {
        EngineSettings off = settings().withWebAdTemplate(false);
        Decision decision = engine.evaluate(schoolRunAd(), defaults, off,
                Collections.<LayoutAnchorRule>emptyList(), W, H);
        assertFalse(decision.type == Decision.Type.CLICK);
    }

    /** 广告上下文不成立时，模板定位器一概不参与——它不能自己认定广告。 */
    @Test
    public void noAdContextNoTemplateClick() {
        List<NodeModel> nodes = new ArrayList<>(schoolRunAd().nodes);
        // 抹掉「广告」角标和所有 ad-container / render-view 模板 id
        for (int i = 0; i < nodes.size(); i++) {
            NodeModel node = nodes.get(i);
            String id = node.viewId;
            if (id.contains("ad-container") || id.contains("render-view")) id = "";
            String text = "广告".equals(node.text) ? "" : node.text;
            nodes.set(i, new NodeModel(node.index, node.parentIndex, text, node.contentDescription,
                    id, node.className, node.clickable, node.visible, node.password,
                    node.left, node.top, node.right, node.bottom));
        }
        ScreenModel screen = new ScreenModel("com.xiaoyang.ydxy", "android.widget.ListView",
                true, nodes);
        assertFalse(WebAdTemplateLocator.find(screen, W, H) != null);
        Decision decision = engine.evaluate(screen, defaults, settings(),
                Collections.<LayoutAnchorRule>emptyList(), W, H);
        assertFalse(decision.type == Decision.Type.CLICK);
    }

    /** 敏感页硬锁优先：即使结构完全一样，只要出现验证码/支付字样就不点。 */
    @Test
    public void sensitivePageIsLockedEvenWithFeedbackPair() {
        List<NodeModel> nodes = new ArrayList<>(schoolRunAd().nodes);
        nodes.add(n(60, 46, "请输入验证码", "", "", "android.widget.TextView", false,
                300, 2000, 900, 2060));
        ScreenModel screen = new ScreenModel("com.xiaoyang.ydxy", "android.widget.ListView",
                true, nodes);
        assertFalse(WebAdTemplateLocator.find(screen, W, H) != null);
    }

    /** 没有「反馈」就没有对偶可依 —— 不猜位置。 */
    @Test
    public void withoutFeedbackAnchorNothingIsGuessed() {
        List<NodeModel> nodes = new ArrayList<>();
        for (NodeModel node : schoolRunAd().nodes) {
            String text = "反馈".equals(node.text) ? "" : node.text;
            nodes.add(new NodeModel(node.index, node.parentIndex, text, node.contentDescription,
                    node.viewId, node.className, node.clickable, node.visible, node.password,
                    node.left, node.top, node.right, node.bottom));
        }
        assertFalse(WebAdTemplateLocator.find(new ScreenModel("com.xiaoyang.ydxy",
                "android.widget.ListView", true, nodes), W, H) != null);
    }

    // ---------------------------------------------------------------- 点击后果守卫

    @Test
    public void strayClickIsRevertedWithinWindow() {
        ClickOutcomeGuard guard = new ClickOutcomeGuard();
        guard.arm("com.xiaoyang.ydxy", 1_000L);
        assertTrue(guard.shouldRevert("com.android.chrome", 2_000L, 0L));
        // 只能退一次
        guard.arm("com.xiaoyang.ydxy", 2_100L);
        assertFalse(guard.shouldRevert("com.taobao.taobao", 2_500L, 0L));
    }

    @Test
    public void homeKeyIsNotAStrayClick() {
        ClickOutcomeGuard guard = new ClickOutcomeGuard();
        guard.arm("com.xiaoyang.ydxy", 1_000L);
        assertFalse(guard.shouldRevert("com.android.launcher", 1_800L, 0L));
    }

    @Test
    public void userTouchWinsOverAutoRevert() {
        ClickOutcomeGuard guard = new ClickOutcomeGuard();
        guard.arm("com.xiaoyang.ydxy", 1_000L);
        assertFalse(guard.shouldRevert("com.taobao.taobao", 1_500L, 1_200L));
    }

    @Test
    public void windowExpires() {
        ClickOutcomeGuard guard = new ClickOutcomeGuard();
        guard.arm("com.xiaoyang.ydxy", 1_000L);
        assertFalse(guard.shouldRevert("com.taobao.taobao", 9_000L, 0L));
    }
}
