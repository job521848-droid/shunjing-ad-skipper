package app.shunjing.skipper.engine;

import static org.junit.Assert.*;

import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * 真实 dump 回归：闪动校园 HomeActivity（1272×2772，51 个节点，全树 c=0）。
 * 关闭图标是 #50，68×68 纯图 ImageView，贴在广告面右下角。
 */
public class RealDumpTest {
    private final AdDecisionEngine engine = new AdDecisionEngine();
    private final List<Rule> defaults = DefaultRules.create();
    private static final int W = 1272, H = 2772;

    private static NodeModel node(int index, int parent, String text, String desc, String id,
                                  String className, boolean clickable, boolean visible,
                                  boolean password, int left, int top, int right, int bottom) {
        return new NodeModel(index, parent, text, desc, id, className, clickable, visible,
                password, left, top, right, bottom);
    }

    private static EngineSettings settings() {
        return new EngineSettings(true, true, EngineSettings.RewardMode.PROTECT,
                Collections.<String>emptySet(), true, true, false);
    }

    @Test
    public void realShandongShakeDumpPicksNode50() {
        ScreenModel screen = new ScreenModel("com.huachenjie.shandong_school",
                "com.huachenjie.shandong_school.home.HomeActivity", true,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, false, 0, 141, 1272, 2772),
                        node(1, 0, "", "", "", "android.widget.FrameLayout", false, true, false, 0, 141, 1272, 2772),
                        node(2, 1, "", "", "android:id/content", "android.widget.FrameLayout", false, true, false, 0, 141, 1272, 2772),
                        node(3, 2, "", "", "", "android.widget.FrameLayout", false, true, false, 0, 141, 1272, 2772),
                        node(4, 3, "", "", "", "android.widget.FrameLayout", false, true, false, 0, 141, 1272, 2772),
                        node(5, 4, "", "", "", "android.widget.FrameLayout", false, true, false, 0, 1881, 1272, 2772),
                        node(6, 4, "", "", "", "android.widget.FrameLayout", false, true, false, 0, 141, 1272, 2772),
                        node(7, 4, "", "", "", "android.widget.FrameLayout", false, true, false, 803, 1250, 1202, 1885),
                        node(8, 7, "", "", "", "android.view.ViewGroup", false, true, false, 803, 1250, 1202, 1885),
                        node(9, 8, "", "", "", "android.view.ViewGroup", false, true, false, 803, 1250, 1202, 1728),
                        node(10, 9, "", "", "", "android.widget.ImageView", false, true, false, 803, 1250, 1202, 1728),
                        node(11, 9, "", "", "", "android.view.ViewGroup", false, true, false, 803, 1292, 1202, 1413),
                        node(12, 11, "x", "", "", "android.widget.TextView", false, true, false, 967, 1292, 1000, 1413),
                        node(13, 11, "x", "", "", "android.widget.TextView", false, true, false, 1000, 1329, 1038, 1374),
                        node(14, 9, "xxxxx", "", "", "android.widget.TextView", false, true, false, 803, 1464, 1202, 1524),
                        node(15, 9, "", "", "", "android.view.ViewGroup", false, true, false, 834, 1581, 1165, 1675),
                        node(16, 15, "xxxx", "", "", "android.widget.TextView", false, true, false, 889, 1588, 1111, 1668),
                        node(17, 9, "xxx", "", "", "android.widget.TextView", false, true, false, 803, 1684, 1202, 1712),
                        node(18, 8, "", "", "", "android.view.ViewGroup", false, true, false, 950, 1780, 1055, 1885),
                        node(19, 18, "", "", "", "android.view.ViewGroup", false, true, false, 976, 1806, 1029, 1859),
                        node(20, 18, "", "", "", "android.view.ViewGroup", false, true, false, 976, 1806, 1029, 1859),
                        node(21, 4, "", "", "", "android.widget.FrameLayout", false, true, false, 0, 2433, 1272, 2772),
                        node(22, 21, "", "", "", "android.widget.LinearLayout", false, true, false, 68, 2559, 1028, 2630),
                        node(23, 22, "摇一摇或点击跳转至第三方应用，请注意保护个人隐私", "", "", "android.widget.TextView", false, true, false, 68, 2559, 1028, 2630),
                        node(24, 21, "", "", "", "android.widget.ImageView", false, true, false, 1055, 2576, 1204, 2630),
                        node(25, 4, "", "", "", "android.widget.FrameLayout", false, true, false, 32, 388, 1240, 2525),
                        node(26, 25, "", "", "", "android.widget.FrameLayout", false, true, false, 32, 388, 1240, 2525),
                        node(27, 26, "", "", "", "android.widget.FrameLayout", false, true, false, 32, 388, 1113, 2309),
                        node(28, 27, "", "", "", "android.widget.FrameLayout", false, true, false, 352, 1120, 793, 1663),
                        node(29, 28, "", "", "", "android.widget.FrameLayout", false, true, false, 531, 1411, 783, 1663),
                        node(30, 29, "", "", "", "android.widget.ImageView", false, true, false, 531, 1411, 783, 1663),
                        node(31, 29, "", "", "", "android.widget.FrameLayout", false, true, false, 531, 1411, 615, 1495),
                        node(32, 28, "", "", "", "android.widget.FrameLayout", false, true, false, 531, 1452, 615, 1533),
                        node(33, 26, "", "", "", "android.widget.LinearLayout", false, true, false, 32, 493, 1240, 1833),
                        node(34, 33, "", "", "", "android.widget.LinearLayout", false, true, false, 151, 493, 1121, 1048),
                        node(35, 34, "", "", "", "android.widget.ImageView", false, true, false, 548, 493, 723, 668),
                        node(36, 34, "xx", "", "", "android.widget.TextView", false, true, false, 584, 738, 688, 800),
                        node(37, 34, "xxxxxxxxx", "", "", "android.widget.TextView", false, true, false, 433, 835, 838, 888),
                        node(38, 34, "", "", "", "android.widget.FrameLayout", false, true, false, 464, 958, 808, 1048),
                        node(39, 38, "", "", "", "android.widget.ImageView", false, true, false, 464, 958, 808, 1048),
                        node(40, 33, "", "", "", "android.widget.FrameLayout", false, true, false, 32, 1153, 1240, 1833),
                        node(41, 40, "", "", "", "android.widget.ImageView", false, true, false, 32, 1153, 1240, 1833),
                        node(42, 40, "", "", "", "android.widget.FrameLayout", false, true, false, 32, 1153, 1240, 1833),
                        node(43, 42, "", "", "", "android.widget.FrameLayout", false, true, false, 32, 1153, 1240, 1832),
                        node(44, 43, "", "", "", "android.view.TextureView", false, true, false, 32, 1153, 1240, 1832),
                        node(45, 4, "", "", "", "android.widget.FrameLayout", false, true, false, 289, 2170, 982, 2356),
                        node(46, 45, "", "", "", "android.widget.FrameLayout", false, true, false, 289, 2170, 982, 2282),
                        node(47, 46, "xxxxxxxxxxx", "", "", "android.widget.TextView", false, true, false, 289, 2189, 982, 2262),
                        node(48, 45, "xxxx", "", "", "android.widget.TextView", false, true, false, 537, 2286, 733, 2356),
                        node(49, 4, "", "", "", "android.widget.FrameLayout", false, true, false, 1136, 2480, 1204, 2548),
                        node(50, 49, "", "", "", "android.widget.ImageView", false, true, false, 1136, 2480, 1204, 2548)
                ));
        Decision decision = engine.evaluate(screen, defaults, settings(),
                Collections.<LayoutAnchorRule>emptyList(), W, H);
        assertEquals(Decision.Type.CLICK, decision.type);
        assertEquals(50, decision.nodeIndex);
        assertEquals("shake_ad_close", decision.ruleId);
    }
}
