package app.shunjing.skipper.engine;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * v1.5.14：摇一摇广告页的「抢跳复击」。
 *
 * <p>真实痛点：关闭图标是一枚 60~90px 的角落图片，按坐标点下去有几十毫秒误差；
 * 点空一次，服务层的同目标冷却要等 1.8 秒，而摇一摇 1~3 秒内就会跳走 —— 等于没机会。
 * 这里给的是「同一处、隔 280ms、最多补两次」的窄窗口，且任何一次页面变化都必须立刻收手。
 */
public class ShakePreemptGuardTest {

    private static final String PKG = "com.xiaoyang.ydxy";
    private static final String ACT = "com.xiaoyang.ydxy.SplashActivity";
    private static final int W = 1080, H = 2400;

    private ShakePreemptGuard armedAt(long now) {
        ShakePreemptGuard guard = new ShakePreemptGuard();
        guard.arm(PKG, ACT, 980f, 2100f, now);
        return guard;
    }

    @Test
    public void waitsBeforeStrikingAgain() {
        long now = 20_000L;
        ShakePreemptGuard guard = armedAt(now);
        // 刚点完不能立刻再点：要留出页面重绘的时间。
        assertEquals(ShakePreemptGuard.RETRY_DELAY_MS, guard.dueIn(PKG, ACT, true, now));
        assertEquals(0L, guard.dueIn(PKG, ACT, true, now + ShakePreemptGuard.RETRY_DELAY_MS));
    }

    @Test
    public void givesUpWhenTheAdIsGone() {
        long now = 20_000L;
        ShakePreemptGuard guard = armedAt(now);
        // 摇一摇文案消失 = 广告被关掉了（或者换页了），这时候再点就是乱点。
        assertEquals(-1L, guard.dueIn(PKG, ACT, false, now + 400L));
        assertFalse(guard.armed());
    }

    @Test
    public void givesUpWhenTheUserWasCarriedAway() {
        long now = 20_000L;
        ShakePreemptGuard guard = armedAt(now);
        assertEquals(-1L, guard.dueIn("com.android.browser", ACT, true, now + 400L));
        assertFalse(guard.armed());
    }

    @Test
    public void givesUpWhenOnlyTheActivityChanged() {
        long now = 20_000L;
        ShakePreemptGuard guard = armedAt(now);
        assertEquals(-1L, guard.dueIn(PKG, PKG + ".WebLandingActivity", true, now + 400L));
    }

    @Test
    public void stopsAfterTwoExtraStrikes() {
        long now = 20_000L;
        ShakePreemptGuard guard = armedAt(now);
        assertEquals(0L, guard.dueIn(PKG, ACT, true, now + 300L));
        guard.noteStrike(now + 300L);
        assertEquals(0L, guard.dueIn(PKG, ACT, true, now + 600L));
        guard.noteStrike(now + 600L);
        assertEquals(3, guard.attempts());
        // 首次 + 两次补点，到此为止。
        assertEquals(-1L, guard.dueIn(PKG, ACT, true, now + 900L));
        assertFalse(guard.armed());
    }

    @Test
    public void expiresAfterTheWindow() {
        long now = 20_000L;
        ShakePreemptGuard guard = armedAt(now);
        assertEquals(0L, guard.dueIn(PKG, ACT, true, now + 300L));
        guard.noteStrike(now + 300L);
        // 窗口外：就算还停在摇一摇页，也不再补了，交给常规扫描。
        assertEquals(-1L, guard.dueIn(PKG, ACT, true, now + ShakePreemptGuard.WINDOW_MS + 1L));
    }

    @Test
    public void onlyRetriesTheSameSpot() {
        long now = 20_000L;
        ShakePreemptGuard guard = armedAt(now);
        assertTrue(guard.sameSpot(980f, 2100f, W, H));
        // 6% 屏内（1080 * 6% = 64px）算同一处。
        assertTrue(guard.sameSpot(1030f, 2150f, W, H));
        // 页面重排把图标挪到左边：不是原来那一处，不许补。
        assertFalse(guard.sameSpot(120f, 2100f, W, H));
    }

    @Test
    public void disarmResetsEverything() {
        long now = 20_000L;
        ShakePreemptGuard guard = armedAt(now);
        guard.noteStrike(now + 300L);
        guard.disarm();
        assertEquals(0, guard.attempts());
        assertEquals(-1L, guard.dueIn(PKG, ACT, true, now + 400L));
    }
}
