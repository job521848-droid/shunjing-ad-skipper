package app.shunjing.skipper.ui;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * 启动动效节奏的回归测试。
 *
 * <p>上一版只有 1.04 秒、结尾一刀切，用户反馈"还没看清就跳过了，跟首页接得也硬"。
 * 这里的断言就是那两条反馈的锚点：总时长够看、退场窗口够长、首页在幕布拉开前已经入场。
 * 以后调手感可以改数值，但别让这三条同时失守。
 */
public class BootTimelineTest {

    @Test
    public void totalIsLongEnoughToRead() {
        // 2 秒以内看不清名字；3 秒以上会开始等。落在 2.0~2.8 秒之间。
        assertTrue("开场太短: " + BootTimeline.TOTAL, BootTimeline.TOTAL >= 2_000L);
        assertTrue("开场太长: " + BootTimeline.TOTAL, BootTimeline.TOTAL <= 2_800L);
    }

    @Test
    public void stagesAreInReadingOrder() {
        assertTrue(BootTimeline.BARS_IN < BootTimeline.BARS_LOCK);
        assertTrue(BootTimeline.BARS_IN < BootTimeline.ORB_IN);
        assertTrue(BootTimeline.ORB_IN < BootTimeline.IMPACT);
        assertTrue("冲击必须晚于环显形，否则炸的是空气", BootTimeline.ORB_IN < BootTimeline.ORB_FULL);
        assertTrue("标题必须在冲击之后", BootTimeline.IMPACT < BootTimeline.WORD_FULL);
        assertTrue("副标题应该在标题之后", BootTimeline.WORD_FULL < BootTimeline.SUB_FULL);
        assertTrue(BootTimeline.STATUS_SWAP < BootTimeline.PREPARE);
        assertTrue(BootTimeline.PREPARE < BootTimeline.EXIT);
        assertTrue(BootTimeline.EXIT < BootTimeline.TOTAL);
    }

    @Test
    public void homeGetsEnoughTimeToEnterBehindTheCurtain() {
        // 卡片是错落入场的，遮罩拉开之前至少要给它 300ms，否则露出时还在往下掉。
        assertTrue("首页入场窗口太短", BootTimeline.EXIT - BootTimeline.PREPARE >= 300L);
    }

    @Test
    public void exitWindowIsLongEnoughToFeelLikeASceneChange() {
        // 退场是"底色淡出 + 光条划开 + 标题上移"三段叠加，太短就又变回硬切。
        assertTrue("退场太短: " + (BootTimeline.TOTAL - BootTimeline.EXIT),
                BootTimeline.TOTAL - BootTimeline.EXIT >= 380L);
        // 但也不能占掉整段的一半，否则前面全白演。
        assertTrue("退场占比过大", BootTimeline.TOTAL - BootTimeline.EXIT < BootTimeline.TOTAL / 2);
    }

    @Test
    public void exitProgressIsClampedAndMonotonic() {
        assertEquals(0f, BootTimeline.exit(0L), 0.0001f);
        assertEquals(0f, BootTimeline.exit(BootTimeline.EXIT), 0.0001f);
        assertEquals(1f, BootTimeline.exit(BootTimeline.TOTAL), 0.0001f);
        assertEquals(1f, BootTimeline.exit(BootTimeline.TOTAL + 500L), 0.0001f);
        assertEquals(0f, BootTimeline.exit(-200L), 0.0001f);

        float previous = -1f;
        for (long t = 0L; t <= BootTimeline.TOTAL; t += 10L) {
            float value = BootTimeline.exit(t);
            assertTrue("必须单调递增，t=" + t, value >= previous - 0.0001f);
            previous = value;
        }
    }

    @Test
    public void spanHandlesZeroAndOverflow() {
        assertEquals(0f, BootTimeline.span(100L, 100L, 200L), 0.0001f);
        assertEquals(0.5f, BootTimeline.span(200L, 100L, 200L), 0.0001f);
        assertEquals(1f, BootTimeline.span(300L, 100L, 200L), 0.0001f);
        assertEquals(1f, BootTimeline.span(9_000L, 100L, 200L), 0.0001f);
        // 长度为 0 时不能除出 NaN，否则属性动画会拿 NaN 去 setAlpha。
        assertEquals(0f, BootTimeline.span(99L, 100L, 0L), 0.0001f);
        assertEquals(1f, BootTimeline.span(100L, 100L, 0L), 0.0001f);
    }
}
