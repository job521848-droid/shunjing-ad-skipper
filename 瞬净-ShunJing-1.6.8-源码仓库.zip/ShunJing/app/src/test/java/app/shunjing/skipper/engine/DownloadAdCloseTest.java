package app.shunjing.skipper.engine;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Test;

/**
 * v1.6.5 回归：胖乖生活（com.qiekj.user）的「梦幻西游」叠加式下载广告。
 *
 * <p>现场特征：Activity 是 {@code android.app.Dialog}，32 个节点全部 c=0，
 * 关闭键是右下角 68×68 的纯 ImageView（#28/#29 父子同框），底部是监管合规条，
 * 中间是 TextureView 视频，文案是「上滑或点击按钮查看详情 / 下载游戏」。
 *
 * <p>旧版本三条路同时失效：合规条里的「功能介绍」把整页判成新手引导、
 * adContext 为 false、三个定位器都要「可点祖先」或「SDK 代理页」。
 */
public class DownloadAdCloseTest {

    private static NodeModel n(int index, int parent, String cls, boolean clickable,
                               String text, String id, int l, int t, int r, int b) {
        return new NodeModel(index, parent, text, "", id, cls, clickable, true, false, l, t, r, b);
    }

    /** 完全按现场快照复刻的 32 个节点（文字按截图还原）。 */
    private static ScreenModel dump() {
        List<NodeModel> nodes = new ArrayList<>();
        String f = "android.widget.FrameLayout";
        nodes.add(n(0, -1, f, false, "", "", 0, 141, 1272, 2772));
        nodes.add(n(1, 0, f, false, "", "", 0, 141, 1272, 2772));
        nodes.add(n(2, 1, f, false, "", "android:id/content", 0, 141, 1272, 2772));
        nodes.add(n(3, 2, f, false, "", "", 0, 141, 1272, 2772));
        nodes.add(n(4, 3, f, false, "", "", 0, 141, 1272, 2772));
        nodes.add(n(5, 4, f, false, "", "", 0, 1940, 1272, 2772));
        nodes.add(n(6, 4, f, false, "", "", 0, 141, 1272, 2772));
        nodes.add(n(7, 4, f, false, "", "", 93, 914, 1178, 1999));
        nodes.add(n(8, 7, f, false, "", "", 93, 914, 1178, 1226));
        nodes.add(n(9, 8, "android.widget.LinearLayout", false, "", "", 194, 965, 1076, 1226));
        nodes.add(n(10, 9, "android.widget.TextView", false, "梦幻再续前缘", "", 473, 965, 797, 1028));
        nodes.add(n(11, 9, "android.widget.TextView", false,
                "兄弟们，别犹豫了，赶紧来梦幻西游再续前缘！", "", 206, 1049, 1064, 1097));
        nodes.add(n(12, 7, "android.widget.ImageView", false, "", "", 93, 1226, 1178, 1837));
        nodes.add(n(13, 7, f, false, "", "", 93, 1226, 1178, 1837));
        nodes.add(n(14, 13, f, false, "", "", 93, 1226, 1178, 1836));
        nodes.add(n(15, 14, "android.view.TextureView", false, "", "", 93, 1226, 1178, 1836));
        nodes.add(n(16, 7, "android.widget.ImageView", false, "", "", 567, 1151, 703, 1287));
        nodes.add(n(17, 4, f, false, "", "", 415, 1596, 856, 2139));
        nodes.add(n(18, 17, f, false, "", "", 415, 1596, 856, 1925));
        nodes.add(n(19, 17, f, false, "", "", 594, 1596, 846, 1848));
        nodes.add(n(20, 19, "android.widget.ImageView", false, "", "", 594, 1596, 846, 1848));
        nodes.add(n(21, 19, f, false, "", "", 594, 1596, 678, 1680));
        nodes.add(n(22, 17, f, false, "", "", 594, 1638, 678, 1883));
        nodes.add(n(23, 4, f, false, "", "", 803, 1250, 1202, 1885));
        nodes.add(n(24, 4, f, false, "", "", 300, 2226, 971, 2412));
        nodes.add(n(25, 24, f, false, "", "", 300, 2226, 971, 2338));
        nodes.add(n(26, 25, "android.widget.TextView", false, "上滑或点击按钮查看详情", "", 300, 2246, 971, 2318));
        nodes.add(n(27, 24, "android.widget.TextView", false, "下载游戏", "", 541, 2342, 729, 2412));
        nodes.add(n(28, 4, f, false, "", "", 1134, 2473, 1202, 2541));
        nodes.add(n(29, 28, "android.widget.ImageView", false, "", "", 1134, 2473, 1202, 2541));
        nodes.add(n(30, 4, "android.widget.TextView", false,
                "应用名称：梦幻西游；应用版本：10.4；开发者：广州博冠信息科技有限公司；"
                        + "适用年龄：16+；权限详情 | 隐私协议 | 功能介绍 | 备案信息 | 广告",
                "", 70, 2566, 1030, 2630));
        nodes.add(n(31, 4, "android.widget.ImageView", false, "", "", 1048, 2569, 1202, 2625));
        return new ScreenModel("com.qiekj.user", "android.app.Dialog", true, nodes);
    }

    @Test public void disclosureStripIsAdEvidence() {
        assertTrue("合规条 + 视频 + 下载文案必须能被认定为下载广告",
                OverlayAdEvidence.matches(dump()));
    }

    @Test public void disclosureWithoutCtaOrVideoIsNotEnough() {
        // 「关于」页：应用名称 + 版本号，但没有视频素材也没有下载诱导。分数 4 < 阈值 5。
        List<NodeModel> nodes = new ArrayList<>();
        nodes.add(n(0, -1, "android.widget.FrameLayout", false, "", "", 0, 0, 1272, 2772));
        nodes.add(n(1, 0, "android.widget.TextView", false,
                "应用名称：瞬净 应用版本：1.6.5 开发者：本地", "", 100, 300, 1100, 400));
        ScreenModel screen = new ScreenModel("app.shunjing.skipper", "app.shunjing.skipper.ui.AboutActivity",
                false, nodes);
        assertFalse(OverlayAdEvidence.matches(screen));
    }

    @Test public void onboardingWordInsideDisclosureDoesNotDisableGeometry() {
        // 合规条里含「功能介绍」。旧写法会把整页判成新手引导，导致所有几何路径静默。
        ScreenModel screen = dump();
        Decision decision = new AdDecisionEngine().evaluate(screen, Collections.<Rule>emptyList(),
                EngineSettings.defaults(), Collections.<LayoutAnchorRule>emptyList(), 1272, 2772, false);
        assertEquals(Decision.Type.CLICK, decision.type);
    }

    @Test public void clicksTheBottomRightIconNotTheAdBadge() {
        Decision decision = new AdDecisionEngine().evaluate(dump(), Collections.<Rule>emptyList(),
                EngineSettings.defaults(), Collections.<LayoutAnchorRule>emptyList(), 1272, 2772, false);
        assertEquals(Decision.Type.CLICK, decision.type);
        assertEquals("download_ad_close", decision.ruleId);
        // #28 是容器、#29 是同框的 ImageView；点哪一个都落在同一块 68×68 上，
        // 但必须避开底部合规条里的「广告」角标（#31，154px 宽）。
        assertTrue(decision.nodeIndex == 28 || decision.nodeIndex == 29);
    }

    @Test public void sensitivePageStillLocksEverything() {
        List<NodeModel> nodes = new ArrayList<>(dump().nodes);
        nodes.add(n(32, 4, "android.widget.TextView", false, "请输入支付密码", "", 100, 2000, 1100, 2100));
        ScreenModel screen = new ScreenModel("com.qiekj.user", "android.app.Dialog", true, nodes);
        Decision decision = new AdDecisionEngine().evaluate(screen, Collections.<Rule>emptyList(),
                EngineSettings.defaults(), Collections.<LayoutAnchorRule>emptyList(), 1272, 2772, false);
        assertEquals(Decision.Type.NONE, decision.type);
    }

    @Test public void ambiguousIconsAreNotClicked() {
        // 再放一枚同样大小、但位置不同的图标：这条路径只认唯一解。
        List<NodeModel> nodes = new ArrayList<>(dump().nodes);
        nodes.add(n(32, 4, "android.widget.ImageView", false, "", "", 1100, 2000, 1168, 2068));
        ScreenModel screen = new ScreenModel("com.qiekj.user", "android.app.Dialog", true, nodes);
        assertNull(DownloadAdCloseLocator.find(screen, 1272, 2772));
    }

    @Test public void suspectScoreReachesAiThreshold() {
        // 即便没有合规条（某些广告不写），也应当够到"值得问云端一次"的门槛。
        assertTrue(AdSuspectDetector.score(dump()) >= AdSuspectDetector.THRESHOLD);
        ScreenModel screen = dump();
        assertTrue(AdSuspectDetector.isSuspect(screen));
    }

    @Test public void locatorIsNotNullForThisLayout() {
        assertNotNull(DownloadAdCloseLocator.find(dump(), 1272, 2772));
    }
}
