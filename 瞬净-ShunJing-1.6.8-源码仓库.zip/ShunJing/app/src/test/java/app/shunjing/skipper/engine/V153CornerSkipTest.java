package app.shunjing.skipper.engine;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * v1.5.3 回归：校园跑（com.xiaoyang.ydxy）开屏广告，46 个节点。
 *
 * <p>现场特点：整棵广告树都挂在 {@code splashAdContainer} 下，<b>没有一个节点可点击</b>
 * （只有 #42 / #43 两个底部按钮 c=1）。唯一像跳过键的是 #40：
 * TextView [1103,257 → 1187,306]，两个字，贴右上角，既无 id 也无点击祖先。
 *
 * <p>旧版把「跳过」写在需要广告上下文的规则里，而坐标点击兜底只放行"免证据的广告词"，
 * 于是这条路径永远走不到 #40——这就是"明明有跳过键却不动"的原因。
 *
 * <p>本测试同时守住三条底线：#42（140×140 的跳转热区）绝不点；没有广告上下文时绝不点；
 * 敏感页仍然整体锁死。
 */
public class V153CornerSkipTest {
    private static final int W = 1272, H = 2772;
    private static final String PKG = "com.xiaoyang.ydxy";

    private final AdDecisionEngine engine = new AdDecisionEngine();
    private final List<Rule> defaults = DefaultRules.create();

    private static NodeModel n(int index, int parent, String text, String desc, String id,
                               String cls, boolean clickable, int l, int t, int r, int b) {
        return new NodeModel(index, parent, text, desc, id, cls, clickable, true, false, l, t, r, b);
    }

    private static NodeModel hidden(int index, int parent, String cls) {
        return new NodeModel(index, parent, "", "", "", cls, false, false, false, 0, 0, 0, 0);
    }

    private static EngineSettings settings() {
        return new EngineSettings(true, true, EngineSettings.RewardMode.AUTO_ABANDON,
                Collections.<String>emptySet(), true, true, true, true, true);
    }

    /**
     * 用户提供的真实控件树。除 #40 填了「跳过」外，其余文字保持脱敏后的样子——
     * 广告上下文靠 {@code splashAdContainer} 这个 id 成立，不依赖任何文案。
     */
    private static ScreenModel schoolRunSplash() {
        List<NodeModel> nodes = new ArrayList<>(Arrays.asList(
                n(0, -1, "", "", "", "android.widget.FrameLayout", false, 0, 0, 1272, 2772),
                n(1, 0, "", "", "", "android.widget.LinearLayout", false, 0, 0, 1272, 2716),
                n(2, 1, "", "", "", "android.widget.FrameLayout", false, 0, 0, 1272, 2716),
                n(3, 2, "", "", "com.xiaoyang.ydxy:id/action_bar_root", "android.widget.LinearLayout", false, 0, 0, 1272, 2716),
                n(4, 3, "", "", "android:id/content", "android.widget.FrameLayout", false, 0, 0, 1272, 2716),
                n(5, 4, "", "", "", "android.view.ViewGroup", false, 0, 0, 1272, 2716),
                n(6, 5, "", "", "com.xiaoyang.ydxy:id/ivLauncherBg", "android.widget.ImageView", false, 0, 0, 1272, 2716),
                n(7, 5, "", "", "com.xiaoyang.ydxy:id/splashAdContainer", "android.widget.FrameLayout", false, 0, 0, 1272, 2716),
                n(8, 7, "", "", "", "android.widget.FrameLayout", false, 0, 0, 1272, 2716),
                hidden(9, 8, "android.view.View"),
                n(10, 8, "", "", "", "android.widget.FrameLayout", false, 0, 0, 1272, 2716),
                n(11, 10, "", "", "", "android.widget.FrameLayout", false, 0, 0, 1272, 2716),
                n(12, 10, "", "", "", "android.widget.FrameLayout", false, 0, 0, 1272, 2716),
                n(13, 12, "", "", "", "android.widget.FrameLayout", false, 0, 0, 1272, 2716),
                n(14, 13, "", "", "", "android.widget.FrameLayout", false, 0, 0, 1272, 2716),
                n(15, 13, "", "", "", "android.widget.FrameLayout", false, 0, 0, 1272, 2716),
                n(16, 13, "", "", "", "android.widget.FrameLayout", false, 0, 0, 1272, 2716),
                n(17, 16, "", "", "", "android.widget.FrameLayout", false, 0, 0, 1272, 2716),
                n(18, 17, "", "[文字已隐藏·长度11]", "", "android.view.ViewGroup", false, 0, 0, 1271, 2716),
                n(19, 18, "", "[文字已隐藏·长度6]", "", "android.view.ViewGroup", false, 0, 0, 1271, 2716),
                n(20, 19, "", "[文字已隐藏·长度6]", "", "android.view.ViewGroup", false, 0, 0, 1271, 2716),
                n(21, 20, "", "[文字已隐藏·长度6]", "", "android.view.ViewGroup", false, 0, 0, 1271, 2716),
                n(22, 21, "", "[文字已隐藏·长度6]", "", "android.widget.ImageView", false, 0, 0, 1271, 2716),
                n(23, 19, "", "[文字已隐藏·长度6]", "", "android.view.ViewGroup", false, 0, 0, 1271, 2716),
                n(24, 23, "", "[文字已隐藏·长度6]", "", "android.view.ViewGroup", false, 0, 0, 1271, 2716),
                n(25, 24, "", "[文字已隐藏·长度6]", "", "android.view.ViewGroup", false, 219, 1777, 1052, 2383),
                n(26, 25, "", "[文字已隐藏·长度6]", "", "android.view.ViewGroup", false, 426, 1777, 846, 2197),
                n(27, 26, "", "[文字已隐藏·长度6]", "", "android.widget.ImageView", false, 489, 1777, 846, 2197),
                n(28, 26, "", "[文字已隐藏·长度6]", "", "android.widget.ImageView", false, 601, 1777, 671, 2197),
                n(29, 25, "[文字已隐藏·长度4]", "[文字已隐藏·长度6]", "", "android.widget.TextView", false, 509, 2232, 761, 2305),
                n(30, 25, "[文字已隐藏·长度17]", "[文字已隐藏·长度6]", "", "android.widget.TextView", false, 219, 2326, 1052, 2383),
                n(31, 19, "", "[文字已隐藏·长度6]", "", "android.view.ViewGroup", false, 0, 0, 1271, 490),
                n(32, 31, "", "[文字已隐藏·长度6]", "", "android.view.ViewGroup", false, 0, 0, 1271, 490),
                n(33, 32, "", "[文字已隐藏·长度6]", "", "android.view.ViewGroup", false, 36, 194, 1236, 440),
                n(34, 33, "", "[文字已隐藏·长度6]", "", "android.view.ViewGroup", false, 36, 194, 1236, 433),
                n(35, 34, "", "[文字已隐藏·长度6]", "", "android.widget.ImageView", false, 566, 418, 706, 429),
                n(36, 33, "", "[文字已隐藏·长度6]", "", "android.widget.ImageView", false, 92, 255, 215, 378),
                n(37, 33, "", "[文字已隐藏·长度6]", "", "android.view.ViewGroup", false, 216, 251, 1180, 384),
                n(38, 37, "[文字已隐藏·长度4]", "[文字已隐藏·长度6]", "", "android.widget.TextView", false, 258, 251, 923, 314),
                n(39, 37, "[文字已隐藏·长度22]", "[文字已隐藏·长度6]", "", "android.widget.TextView", false, 258, 321, 1179, 384),
                // #40：真正的跳过键。两个字的 TextView，贴右上角，c=0 且没有可点祖先。
                n(40, 33, "跳过", "", "", "android.widget.TextView", false, 1103, 257, 1187, 306),
                n(41, 32, "", "[文字已隐藏·长度6]", "", "android.view.ViewGroup", false, 53, 193, 1218, 438),
                // #42 / #43：底部的图标热区与说明文字，点它等于点广告主落地页。
                n(42, 10, "", "", "", "android.view.View", true, 56, 2348, 196, 2488),
                n(43, 10, "", "", "", "android.widget.TextView", true, 70, 2527, 182, 2576),
                n(44, 0, "", "", "", "android.view.View", false, 0, 1386, 1272, 2772),
                n(45, 0, "", "", "android:id/navigationBarBackground", "android.view.View", false, 0, 2716, 1272, 2772)
        ));
        return new ScreenModel(PKG, "android.widget.FrameLayout", true, nodes);
    }

    private Decision decide(ScreenModel screen) {
        return engine.evaluate(screen, defaults, settings(), Collections.<LayoutAnchorRule>emptyList(),
                W, H, false);
    }

    @Test
    public void clicksTheCornerSkipLabelInsteadOfGivingUp() {
        Decision d = decide(schoolRunSplash());
        assertEquals(Decision.Type.CLICK, d.type);
        assertEquals("跳过键是 #40，不是别的任何节点", 40, d.nodeIndex);
        assertEquals("corner_skip", d.ruleId);
    }

    @Test
    public void neverTouchesTheBottomHotzone() {
        // #42 是 140×140 的可点击图标，位于 #44 覆盖层内，点它等于点广告主落地页。
        // 就算它真的写着「跳过」，也不能拿它当关闭键——角落的 #40 才是。
        ScreenModel screen = schoolRunSplash();
        List<NodeModel> nodes = new ArrayList<>(screen.nodes);
        NodeModel old = nodes.get(42);
        nodes.set(42, new NodeModel(old.index, old.parentIndex, "跳过", "跳过", old.viewId,
                old.className, old.clickable, true, false, old.left, old.top, old.right, old.bottom));
        Decision d = decide(new ScreenModel(PKG, "android.widget.FrameLayout", true, nodes));
        assertEquals("底部热区即便带跳过字样也不点，改点角落", 40, d.nodeIndex);
    }

    @Test
    public void needsAdEvidenceEvenForCornerLabels() {
        // 去掉 splashAdContainer 这个 id，页面就只剩一堆脱敏文字：没有任何广告证据。
        // 此时角落里的「跳过」也不许点——这正是硬约束里"规则不能全局免证据"。
        ScreenModel screen = schoolRunSplash();
        List<NodeModel> nodes = new ArrayList<>(screen.nodes);
        NodeModel container = nodes.get(7);
        nodes.set(7, new NodeModel(7, container.parentIndex, "", "", "", "android.widget.FrameLayout",
                false, true, false, 0, 0, 1272, 2716));
        Decision d = decide(new ScreenModel(PKG, "android.widget.FrameLayout", true, nodes));
        assertFalse("没有广告上下文就不该动", d.type == Decision.Type.CLICK);
    }

    @Test
    public void sensitivePagesStayLocked() {
        // 同一个跳过键出现在扫码页：硬锁先返回，任何证据都不放行。
        ScreenModel screen = schoolRunSplash();
        List<NodeModel> nodes = new ArrayList<>(screen.nodes);
        nodes.set(29, n(29, 25, "扫码", "", "", "android.widget.TextView", false, 509, 2232, 761, 2305));
        Decision d = decide(new ScreenModel(PKG, "android.widget.FrameLayout", true, nodes));
        assertEquals(Decision.Type.NONE, d.type);
    }

    @Test
    public void maskedPlaceholdersNeverBecomeRules() {
        PageDump dump = new PageDump("d1", 0L, PKG, "android.widget.FrameLayout", "校园跑",
                PageDump.SOURCE_AUTO, W, H, true, schoolRunSplash().nodes);
        Diagnosis diagnosis = new DumpAnalyzer().analyze(dump, defaults, settings(), true, true);
        for (Suggestion s : diagnosis.suggestions) {
            if (s.rule == null) continue;
            assertFalse("脱敏占位符不能变成关闭词：" + s.rule.phrase,
                    DumpAnalyzer.isMaskedText(s.rule.phrase));
        }
        assertTrue(DumpAnalyzer.isMaskedText("[文字已隐藏·长度2]"));
        assertFalse(DumpAnalyzer.isMaskedText("跳过"));
    }

    // ------------------------------------------------------------------ 案例 2 / 3

    private static final String PKG2 = "com.dskiow.cjsq.p1";
    private static final String GDT = "com.qq.e.ads.PortraitADActivity";

    /**
     * 囧次元 / 优量汇开屏（36 节点，原文）。整棵广告树的 x 从 1272 起步：
     * 这是窗口坐标系，不是屏幕坐标系，任何按屏幕宽度做的几何判断都会落到屏幕外。
     */
    private static ScreenModel gdtSplash() {
        List<NodeModel> nodes = new ArrayList<>(Arrays.asList(
                n(0, -1, "", "", "", "android.widget.FrameLayout", false, 0, 0, 1272, 2772),
                n(1, 0, "", "", "", "android.widget.LinearLayout", false, 1272, 0, 2544, 2772),
                n(2, 1, "", "", "android:id/content", "android.widget.FrameLayout", false, 1272, 0, 2544, 2772),
                n(3, 2, "", "", "", "android.widget.LinearLayout", false, 1272, 141, 2544, 2716),
                n(4, 3, "", "", "", "android.widget.FrameLayout", false, 1272, 141, 2544, 2716),
                n(5, 4, "", "", "", "android.widget.FrameLayout", false, 1272, 141, 2544, 2716),
                n(6, 5, "", "", "", "android.widget.RelativeLayout", false, 1272, 141, 2544, 2716),
                n(7, 6, "", "", "", "android.widget.FrameLayout", false, 1272, 141, 2544, 2716),
                n(8, 7, "", "", "", "android.widget.FrameLayout", false, 1272, 141, 2544, 2403),
                n(9, 8, "", "", "", "android.widget.ImageView", false, 1272, 141, 2544, 2403),
                n(10, 8, "", "", "", "android.widget.FrameLayout", false, 1272, 1826, 2544, 2403),
                n(11, 7, "", "", "", "android.widget.FrameLayout", false, 1272, 282, 2544, 2716),
                n(12, 11, "", "", "", "android.widget.FrameLayout", false, 1272, 282, 2544, 2716),
                n(13, 12, "", "", "", "android.widget.LinearLayout", false, 1272, 2296, 2544, 2716),
                n(14, 13, "", "", "", "android.widget.FrameLayout", false, 1306, 2296, 2510, 2689),
                n(15, 14, "", "", "", "android.widget.FrameLayout", false, 1306, 2296, 2510, 2689),
                n(16, 14, "", "", "", "android.widget.FrameLayout", false, 1340, 2330, 2476, 2655),
                n(17, 16, "", "", "", "android.widget.ImageView", false, 1340, 2330, 1476, 2466),
                n(18, 16, "", "", "", "android.widget.FrameLayout", false, 1516, 2330, 2194, 2398),
                n(19, 18, "广告", "", "", "android.widget.TextView", false, 1516, 2333, 2194, 2395),
                n(20, 16, "", "", "", "android.widget.ImageView", false, 2327, 2330, 2476, 2381),
                n(21, 16, "", "", "", "android.widget.FrameLayout", false, 1516, 2405, 2476, 2463),
                n(22, 21, "", "", "", "android.widget.TextView", false, 1516, 2407, 2476, 2460),
                n(23, 16, "", "", "", "android.widget.FrameLayout", false, 1340, 2519, 2476, 2655),
                n(24, 23, "", "", "", "android.widget.FrameLayout", false, 1340, 2519, 2476, 2655),
                n(25, 24, "", "", "", "android.view.View", false, 1340, 2519, 2476, 2655),
                n(26, 23, "", "", "", "android.widget.LinearLayout", false, 1481, 2519, 2334, 2655),
                n(27, 26, "", "", "", "android.widget.ImageView", false, 1481, 2519, 1614, 2655),
                n(28, 26, "", "", "", "android.widget.TextView", false, 1628, 2519, 2334, 2655),
                n(29, 7, "", "", "", "android.widget.FrameLayout", false, 1272, 282, 2544, 441),
                n(30, 29, "", "", "", "android.widget.LinearLayout", false, 1889, 350, 2476, 441),
                // #31 是“跳过 5s”这类文案；#32 是它的 91×91 容器，#34 是 56×56 的叉号。
                n(31, 30, "跳过 5s", "", "", "android.widget.TextView", false, 1889, 350, 2350, 441),
                n(32, 30, "", "", "", "android.widget.FrameLayout", false, 2385, 350, 2476, 441),
                n(33, 32, "", "", "", "android.widget.FrameLayout", false, 2385, 350, 2476, 441),
                n(34, 33, "", "", "", "android.widget.ImageView", false, 2402, 367, 2458, 423),
                hidden(35, 7, "android.widget.ImageView")
        ));
        return new ScreenModel(PKG2, GDT, true, nodes);
    }

    @Test
    public void shiftedWindowIsNormalizedBeforeAnyGeometry() {
        ScreenModel raw = gdtSplash();
        assertEquals("坐标没平移时整棵树都在屏幕外，什么都点不到",
                Decision.Type.NONE, decide(raw).type);

        List<NodeModel> fixed = BoundsNormalizer.toScreen(raw.nodes, W, H);
        Decision after = engine.evaluate(new ScreenModel(PKG2, GDT, true, fixed), defaults,
                settings(), Collections.<LayoutAnchorRule>emptyList(), W, H, false);
        assertEquals(Decision.Type.CLICK, after.type);
        assertEquals("右上角那个 56×56 的叉号才是关闭键", 34, after.nodeIndex);
        assertEquals("corner_close_icon", after.ruleId);
    }

    @Test
    public void sdkPlacementActivityCountsAsAdEvidence() {        assertTrue(StructuralAdEvidence.sdkPlacementId(
                "com.windmill.sdk.widget.InterstitialView_4012001"));
        assertFalse(StructuralAdEvidence.sdkPlacementId("com.example.sdk.MainActivity"));
        assertFalse("普通 Activity 不能靠名字蹭成广告页",
                StructuralAdEvidence.sdkPlacementId("com.example.app.SplashActivity"));
    }

    @Test
    public void onlyTheOffScreenSubtreeIsShifted() {
        // 案例 1（风马 116 节点）的形态：#0 是全屏根，只有 #29 这棵"顶部提示条"子树
        // 落在第二窗口（x 从 1272 起步）。整屏都在屏内时不能有任何平移。
        List<NodeModel> nodes = new ArrayList<>(Arrays.asList(
                n(0, -1, "", "", "", "android.widget.FrameLayout", false, 0, 0, 1272, 2772),
                n(1, 0, "", "", "", "android.widget.FrameLayout", false, 0, 0, 1272, 2716),
                n(2, 1, "", "", "", "android.widget.FrameLayout", false, 0, 0, 1272, 2716),
                n(3, 1, "", "", "", "android.widget.FrameLayout", false, 1272, 282, 2544, 441),
                n(4, 3, "", "", "", "android.widget.ImageView", false, 2402, 367, 2458, 423)
        ));
        List<NodeModel> fixed = BoundsNormalizer.toScreen(nodes, W, H);
        assertEquals("屏内节点不动", 0, fixed.get(0).left);
        assertEquals("越界子树整体左移一个屏宽", 0, fixed.get(3).left);
        assertEquals(1130, fixed.get(4).left);
        assertEquals(1186, fixed.get(4).right);
    }

}
