package app.shunjing.skipper.data;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * v1.5.6：保留策略。裁错方向（留下最旧、删掉最新）比不裁更糟，所以单独锁一遍。
 */
public class RetentionPolicyTest {

    @Test
    public void clampsBothEnds() {
        assertEquals(5, RetentionPolicy.clamp(1, 5, 120));
        assertEquals(120, RetentionPolicy.clamp(9_999, 5, 120));
        assertEquals(10, RetentionPolicy.clamp(10, 5, 120));
    }

    @Test
    public void keepsTheNewestEntriesAtTheHead() {
        // 列表约定：下标 0 是最新的一条。
        List<String> newestFirst = Arrays.asList("t9", "t8", "t7", "t6", "t5", "t4");
        List<String> kept = RetentionPolicy.newestFirst(newestFirst, 3);
        assertEquals(Arrays.asList("t9", "t8", "t7"), kept);
    }

    @Test
    public void keepsEverythingWhenUnderTheLimit() {
        List<String> newestFirst = Arrays.asList("t2", "t1");
        assertEquals(2, RetentionPolicy.newestFirst(newestFirst, 10).size());
    }

    @Test
    public void dropsTheOldTail() {
        List<String> newestFirst = Arrays.asList("t9", "t8", "t7", "t6");
        List<String> dropped = RetentionPolicy.oldestBeyond(newestFirst, 2);
        assertEquals(Arrays.asList("t7", "t6"), dropped);
    }

    @Test
    public void nothingToDropWhenAtOrBelowTheLimit() {
        assertTrue(RetentionPolicy.oldestBeyond(Arrays.asList("t2", "t1"), 5).isEmpty());
        assertTrue(RetentionPolicy.oldestBeyond(new ArrayList<>(), 5).isEmpty());
    }

    @Test
    public void trimsAHundredEntriesToTenNewest() {
        List<Integer> all = new ArrayList<>();
        for (int i = 100; i >= 1; i--) all.add(i); // 100 最新，1 最旧
        List<Integer> kept = RetentionPolicy.newestFirst(all, 10);
        assertEquals(10, kept.size());
        assertEquals(Integer.valueOf(100), kept.get(0));
        assertEquals(Integer.valueOf(91), kept.get(9));
    }
}
