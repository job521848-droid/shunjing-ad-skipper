package app.shunjing.skipper.engine;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * v1.5.9 学习模式：让用户在广告页手动点一次，程序反推关闭位置。
 *
 * <p>原则在这里同样成立 —— 宁可学不会，也不能学歪。所以失败路径比成功路径更重要：
 * 页面没变化、候选分不清、跨应用、大热区，都必须明确放弃。
 */
public class LearningAnalyzerTest {

    private static final int W = 1272;
    private static final int H = 2772;
    private static final String PKG = "com.xiaoyang.ydxy";
    private static final String ACT = "com.xiaoyang.ydxy.SplashActivity";

    private static NodeModel n(int index, int parent, String text, String id, String cls,
                               int l, int t, int r, int b) {
        return new NodeModel(index, parent, text, "", id, cls, false, true, false, l, t, r, b);
    }

    /** 典型开屏：整棵树 c=0，右上角一个两字跳过键。 */
    private static List<NodeModel> splash() {
        return new ArrayList<>(Arrays.asList(
                n(0, -1, "", "", "android.widget.FrameLayout", 0, 0, W, H),
                n(1, 0, "", "com.xiaoyang.ydxy:id/splashAdContainer",
                        "android.widget.FrameLayout", 0, 0, W, 2716),
                n(2, 1, "", "", "android.widget.FrameLayout", 0, 0, W, 2716),
                n(3, 2, "", "", "android.widget.ImageView", 0, 0, W, 2716),
                n(4, 2, "跳过", "", "android.widget.TextView", 1103, 257, 1187, 306),
                n(5, 2, "广告", "", "android.widget.TextView", 60, 250, 130, 300),
                n(6, 2, "", "", "android.view.View", 56, 2348, 196, 2488)));
    }

    /** 广告关掉后的 App 首页：结构完全不同。 */
    private static List<NodeModel> home() {
        return new ArrayList<>(Arrays.asList(
                n(0, -1, "", "", "android.widget.FrameLayout", 0, 0, W, H),
                n(1, 0, "", "com.xiaoyang.ydxy:id/content", "android.widget.LinearLayout", 0, 0, W, 2716),
                n(2, 1, "开始跑步", "", "android.widget.Button", 200, 1200, 1072, 1320),
                n(3, 1, "我的", "", "android.widget.TextView", 100, 2600, 300, 2680)));
    }

    @Test
    public void learnsThePositionTheUserTapped() {
        NodeModel tapped = splash().get(4);
        LearningAnalyzer.Result result = LearningAnalyzer.analyze(
                PKG, ACT, "校园跑", splash(), home(), Collections.singletonList(tapped), W, H);

        assertTrue("点了跳过键、页面也变了，应该学会：" + result.message, result.ok());
        LearnedClose learned = result.learned;
        assertEquals(PKG, learned.packageName);
        assertEquals(ACT, learned.activityName);
        // 相对坐标应落在右上角
        assertTrue(learned.rightRatio > 0.8f);
        assertTrue(learned.bottomRatio < 0.2f);
    }

    @Test
    public void refusesWhenNothingChanged() {
        LearningAnalyzer.Result result = LearningAnalyzer.analyze(
                PKG, ACT, "校园跑", splash(), splash(), Collections.<NodeModel>emptyList(), W, H);
        assertFalse("广告没关掉就不该学会任何东西", result.ok());
        assertFalse(result.pageChanged);
    }

    @Test
    public void refusesWhenFinishFrameIsMissing() {
        LearningAnalyzer.Result result = LearningAnalyzer.analyze(
                PKG, ACT, "校园跑", splash(), null, Collections.<NodeModel>emptyList(), W, H);
        assertFalse(result.ok());
    }

    @Test
    public void fallsBackToTheVanishedCornerWhenNothingWasClickable() {
        // 整树 c=0，用户用手指点，没有任何 TYPE_VIEW_CLICKED 可用 —— 只能靠两帧差异。
        LearningAnalyzer.Result result = LearningAnalyzer.analyze(
                PKG, ACT, "校园跑", splash(), home(), Collections.<NodeModel>emptyList(), W, H);
        assertTrue("应该从消失的贴角小控件里推断出来：" + result.message, result.ok());
        LearnedClose learned = result.learned;
        assertTrue(learned.rightRatio > 0.8f);
        assertTrue(learned.bottomRatio < 0.2f);
    }

    @Test
    public void givesUpWhenSeveralCandidatesLookAlike() {
        // 两个大小、位置都很像的控件一起消失：分不清是哪个，必须放弃。
        List<NodeModel> before = new ArrayList<>(Arrays.asList(
                n(0, -1, "", "", "android.widget.FrameLayout", 0, 0, W, H),
                n(1, 0, "", "", "android.widget.ImageView", 1000, 200, 1080, 280),
                n(2, 0, "", "", "android.widget.ImageView", 1100, 240, 1180, 320)));
        LearningAnalyzer.Result result = LearningAnalyzer.analyze(
                PKG, ACT, "校园跑", before, home(), Collections.<NodeModel>emptyList(), W, H);
        assertFalse("两个候选分不出高下，不该硬猜", result.ok());
    }

    @Test
    public void learnedCloseOnlyMatchesTheSameAppAndPage() {
        LearnedClose learned = LearnedClose.fromNode(PKG, ACT, "校园跑", splash().get(4), W, H);
        assertNotNull(learned);

        ScreenModel same = new ScreenModel(PKG, ACT, true, splash());
        assertTrue("同包同页面应该命中", learned.find(same, W, H) == 4);

        ScreenModel otherApp = new ScreenModel("com.tencent.mm", ACT, true, splash());
        assertEquals("换应用绝不能命中", -1, learned.find(otherApp, W, H));

        ScreenModel otherPage = new ScreenModel(PKG, "com.xiaoyang.ydxy.MainActivity", true, splash());
        assertEquals("换页面绝不能命中", -1, learned.find(otherPage, W, H));
    }

    @Test
    public void learnedCloseIgnoresBigHotzones() {
        List<NodeModel> nodes = new ArrayList<>(splash());
        // 同位置放一个铺满整屏的可点击区域：面积太大，不能当关闭键。
        nodes.set(4, n(4, 2, "", "", "android.view.View", 0, 0, W, H));
        LearnedClose learned = LearnedClose.fromNode(PKG, ACT, "校园跑", splash().get(4), W, H);
        assertEquals("大热区永远不是关闭键", -1, learned.find(new ScreenModel(PKG, ACT, true, nodes), W, H));
    }

    @Test
    public void learnedCloseToleratesSmallLayoutShifts() {
        List<NodeModel> shifted = new ArrayList<>(splash());
        shifted.set(4, n(4, 2, "跳过", "", "android.widget.TextView", 1116, 264, 1200, 313));
        LearnedClose learned = LearnedClose.fromNode(PKG, ACT, "校园跑", splash().get(4), W, H);
        assertTrue("几像素的位移不该导致失效", learned.find(new ScreenModel(PKG, ACT, true, shifted), W, H) == 4);
    }

    @Test
    public void learnedCloseRejectsFarAwayNodes() {
        List<NodeModel> moved = new ArrayList<>(splash());
        // 关闭键跑到屏幕中下方：位置差太远，不算同一个东西。
        moved.set(4, n(4, 2, "跳过", "", "android.widget.TextView", 560, 1500, 644, 1549));
        LearnedClose learned = LearnedClose.fromNode(PKG, ACT, "校园跑", splash().get(4), W, H);
        assertEquals(-1, learned.find(new ScreenModel(PKG, ACT, true, moved), W, H));
    }

    @Test
    public void similarityIsHighForSameFrame() {
        assertTrue(LearningAnalyzer.similarity(splash(), splash()) > 0.95d);
        assertTrue(LearningAnalyzer.similarity(splash(), home()) < 0.4d);
    }

    @Test
    public void missingActivityTightensThePositionGate() {
        // 没记到 Activity 时只允许 2.5% 的位移，避免在同包的别的页面上误点。
        LearnedClose learned = new LearnedClose(PKG, "", "校园跑", "", "android.widget.TextView",
                1103f / W, 257f / H, 1187f / W, 306f / H, 0L, 0);
        List<NodeModel> shifted = new ArrayList<>(splash());
        shifted.set(4, n(4, 2, "跳过", "", "android.widget.TextView", 1143, 257, 1227, 306));
        assertEquals("位移 3% 已经超出无 Activity 时的容差",
                -1, learned.find(new ScreenModel(PKG, ACT, true, shifted), W, H));
    }

    // ---------------------------------------------------------------- v1.5.11 帧历史

    private static LearningAnalyzer.Frame frame(long at, List<NodeModel> nodes) {
        return new LearningAnalyzer.Frame(nodes, at);
    }

    /**
     * 用户最先看到的是主页（广告还没弹），点完学习才等来广告、再关掉。
     * 只比首尾两帧会觉得"什么都没发生"，帧历史能找回中间那次真正的变化。
     */
    @Test
    public void learnsWhenLearningStartedOnTheAppHomePage() {
        List<LearningAnalyzer.Frame> frames = Arrays.asList(
                frame(0, home()),        // 锁定时的页面：广告还没出来
                frame(1_000, splash()),  // 广告弹出来
                frame(4_000, home()));   // 用户关掉，回到首页
        NodeModel tapped = splash().get(4);
        LearningAnalyzer.Result result = LearningAnalyzer.analyzeFrames(
                PKG, ACT, "校园跑", frames, Collections.singletonList(tapped), W, H);

        assertTrue("应该从帧历史里找到关闭动作：" + result.message, result.ok());
        assertTrue(result.learned.rightRatio > 0.8f);
        assertTrue(result.learned.bottomRatio < 0.2f);
    }

    @Test
    public void frameHistoryAlsoWorksWithoutClickEvents() {
        List<LearningAnalyzer.Frame> frames = Arrays.asList(
                frame(0, home()), frame(1_000, splash()), frame(4_000, home()));
        LearningAnalyzer.Result result = LearningAnalyzer.analyzeFrames(
                PKG, ACT, "校园跑", frames, Collections.<NodeModel>emptyList(), W, H);

        assertTrue("H5 广告拿不到点击事件，也要能从消失的角标推断：" + result.message, result.ok());
        assertTrue(result.learned.rightRatio > 0.8f);
    }

    @Test
    public void refusesWhenFrameHistoryNeverChanges() {
        List<NodeModel> steady = home();
        List<LearningAnalyzer.Frame> frames = Arrays.asList(
                frame(0, steady), frame(1_000, home()), frame(3_000, home()));
        LearningAnalyzer.Result result = LearningAnalyzer.analyzeFrames(
                PKG, ACT, "校园跑", frames, Collections.<NodeModel>emptyList(), W, H);

        assertFalse("广告没关掉就不该学会任何东西", result.ok());
        assertFalse(result.pageChanged);
    }

    /** 点了广告本体、被拉去落地页又回来：那个位置事后还在，不能当成关闭键。 */
    @Test
    public void ignoresClickThatDidNotRemoveAnything() {
        List<NodeModel> before = new ArrayList<>(Arrays.asList(
                n(0, -1, "", "", "android.widget.FrameLayout", 0, 0, W, H),
                n(1, 0, "立即下载", "", "android.widget.Button", 200, 2300, 1072, 2450),
                n(2, 0, "", "", "android.widget.ImageView", 1140, 180, 1210, 250)));
        List<NodeModel> after = new ArrayList<>(Arrays.asList(
                n(0, -1, "", "", "android.widget.FrameLayout", 0, 0, W, H),
                n(1, 0, "立即下载", "", "android.widget.Button", 200, 2300, 1072, 2450)));
        LearningAnalyzer.Result result = LearningAnalyzer.analyzeFrames(
                PKG, ACT, "校园跑",
                Arrays.asList(frame(0, before), frame(2_000, after)),
                Collections.singletonList(before.get(1)), W, H);

        assertTrue("右下角那枚真正消失的角标才是关闭键", result.ok());
        assertTrue("不能学成那条没消失的下载横幅", result.learned.topRatio < 0.2f);
    }

    /** 滑动之后那一帧整页节点都变了，不能当成"广告被关掉"。 */
    @Test
    public void ignoresChangeThatFollowsAScroll() {
        List<LearningAnalyzer.Frame> frames = Arrays.asList(
                frame(0, splash()),
                new LearningAnalyzer.Frame(home(), 1_500, true));
        LearningAnalyzer.Result result = LearningAnalyzer.analyzeFrames(
                PKG, ACT, "校园跑", frames, Collections.<NodeModel>emptyList(), W, H);

        assertFalse("滑动造成的画面变化不算关闭", result.ok());
    }

    @Test
    public void countsAdSignalsToTellLoadingFromClosing() {
        assertTrue(LearningAnalyzer.adSignals(splash()) >= 2);
        assertEquals(0, LearningAnalyzer.adSignals(home()));
    }
}