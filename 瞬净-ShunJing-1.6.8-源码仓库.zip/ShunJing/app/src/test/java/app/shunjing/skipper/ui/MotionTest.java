package app.shunjing.skipper.ui;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * 动效曲线的回归测试。
 *
 * <p>这几条数字是"手感"的锚点：过冲太大像果冻，太小又显得生硬；收敛慢了会拖沓。
 * 改参数时先看这些断言有没有被打破，比在真机上一遍遍点更省事。
 */
public class MotionTest {

    @Test
    public void springStartsAtZeroAndEndsAtOne() {
        assertEquals(0f, Motion.spring(0f), 0.0001f);
        assertEquals(1f, Motion.spring(1f), 0.0001f);
        // 越界输入不该抛异常，也不该给出离谱的值
        assertEquals(0f, Motion.spring(-0.5f), 0.0001f);
        assertEquals(1f, Motion.spring(3f), 0.0001f);
    }

    @Test
    public void springOvershootsSlightlyButNotLikeJelly() {
        float peak = 0f;
        for (int i = 0; i <= 100; i++) {
            peak = Math.max(peak, Motion.spring(i / 100f));
        }
        // 2%~4% 过冲：看得见弹性，又不会来回晃
        assertTrue("过冲太小显得生硬: " + peak, peak > 1.012f);
        assertTrue("过冲太大像果冻: " + peak, peak < 1.045f);
    }

    @Test
    public void springSettlesBeforeTheEnd() {
        // 最后 10% 应该已经贴住终点，否则手指抬起了还在飘
        for (int i = 90; i <= 100; i++) {
            assertEquals("t=" + i + "%", 1f, Motion.spring(i / 100f), 0.008f);
        }
    }

    @Test
    public void springNeverGoesNegative() {
        for (int i = 0; i <= 200; i++) {
            assertTrue("t=" + i, Motion.spring(i / 200f) >= -0.001f);
        }
    }

    @Test
    public void springPassesHalfwayEarly() {
        // 手感要求"起手快"：一半时间里应该走完 80% 以上，否则会觉得拖
        assertTrue(Motion.spring(0.5f) > 0.8f);
    }

    @Test
    public void easeOutCubicIsMonotonicAndFrontLoaded() {
        float previous = -1f;
        for (int i = 0; i <= 100; i++) {
            float value = Motion.easeOutCubic(i / 100f);
            assertTrue("必须单调递增", value >= previous);
            previous = value;
        }
        assertEquals(0f, Motion.easeOutCubic(0f), 0.0001f);
        assertEquals(1f, Motion.easeOutCubic(1f), 0.0001f);
        assertTrue("三次缓出应该先快后慢", Motion.easeOutCubic(0.5f) > 0.75f);
    }

    @Test
    public void easeOutQuintIsEvenMoreFrontLoaded() {
        assertTrue(Motion.easeOutQuint(0.5f) > Motion.easeOutCubic(0.5f));
        assertEquals(1f, Motion.easeOutQuint(1f), 0.0001f);
    }

    @Test
    public void easeInQuadAccelerates() {
        assertTrue("前段应该慢", Motion.easeInQuad(0.25f) < 0.1f);
        assertTrue("后段应该快", Motion.easeInQuad(0.75f) > 0.5f);
        assertEquals(1f, Motion.easeInQuad(1f), 0.0001f);
    }

    @Test
    public void clamp01CapsBothEnds() {
        assertEquals(0f, Motion.clamp01(-3f), 0f);
        assertEquals(1f, Motion.clamp01(3f), 0f);
        assertEquals(0.42f, Motion.clamp01(0.42f), 0f);
    }

    @Test
    public void nullContextFallsBackToFullSpeed() {
        // 拿不到 Context 时不能把动画时长算成 0，否则界面会突然失去所有过渡
        assertEquals(1f, Motion.scale(null), 0.0001f);
        assertEquals(420L, Motion.duration(null, 420L));
    }
}
