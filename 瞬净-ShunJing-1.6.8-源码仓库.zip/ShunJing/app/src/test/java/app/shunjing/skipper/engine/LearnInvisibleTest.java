package app.shunjing.skipper.engine;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * v1.6.4 回归：学习失败时要说清原因。
 *
 * <p>用户点了关闭，但控件树从头到尾一帧都没变 —— 因为广告层由 SDK 自绘或对无障碍隐藏。
 * 旧文案只说「页面没有变化，广告可能还没关掉」，用户会以为是自己的操作问题，反复重试。
 */
public class LearnInvisibleTest {
    private static final int W = 1272, H = 2772;

    private static NodeModel node(int index, String text, String className,
                                  int left, int top, int right, int bottom) {
        return new NodeModel(index, index == 0 ? -1 : 0, text, "", "", className, false, true,
                false, left, top, right, bottom);
    }

    private static List<NodeModel> page() {
        return new ArrayList<>(Arrays.asList(
                node(0, "", "android.widget.FrameLayout", 0, 0, W, H),
                node(1, "我的设备", "android.widget.TextView", 100, 120, 600, 200),
                node(2, "查看附近设备", "android.widget.TextView", 100, 300, 700, 380)));
    }

    private static List<LearningAnalyzer.Frame> sameFrames() {
        return Arrays.asList(
                new LearningAnalyzer.Frame(page(), 1_000L),
                new LearningAnalyzer.Frame(page(), 1_400L),
                new LearningAnalyzer.Frame(page(), 1_800L));
    }

    @Test
    public void clickWithoutTreeChangeExplainsInvisibleAdLayer() {
        List<NodeModel> clicks = Collections.singletonList(
                new NodeModel(0, -1, "", "", "", "android.view.View", true, true, false,
                        950, 1900, 1060, 2010));
        LearningAnalyzer.Result result = LearningAnalyzer.analyzeFrames(
                "com.qiekj.user", "com.qiekj.user.MainActivity", "胖乖生活",
                sameFrames(), clicks, W, H);
        assertFalse(result.ok());
        assertFalse(result.pageChanged);
        assertTrue("必须点明是自绘/不可见，而不是含糊的「没关掉」",
                result.message.contains("自绘") || result.message.contains("看不到"));
    }

    @Test
    public void noClickKeepsTheHonestGenericMessage() {
        LearningAnalyzer.Result result = LearningAnalyzer.analyzeFrames(
                "com.qiekj.user", "com.qiekj.user.MainActivity", "胖乖生活",
                sameFrames(), Collections.<NodeModel>emptyList(), W, H);
        assertFalse(result.ok());
        assertTrue(result.message.contains("没有变化"));
    }
}
