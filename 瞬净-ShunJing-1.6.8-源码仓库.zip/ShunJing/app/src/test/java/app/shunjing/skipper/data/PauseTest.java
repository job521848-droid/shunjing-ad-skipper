package app.shunjing.skipper.data;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * 临时暂停的时间算术测试。
 *
 * <p>这几条边界看起来吹毛求疵，但都是会真实发生的事：到点那一毫秒还算不算暂停、
 * 剩余 30 秒该说"1 分钟"还是"不到 1 分钟"、暂停 0 分钟是不是等于恢复。
 */
public class PauseTest {

    @Test
    public void expiresExactlyAtTheDeadline() {
        assertTrue(Pause.active(1_000L, 5_000L));
        // 到点即结束：写成 >= 会让"暂停 15 分钟"变成 15 分零 1 秒还在跳广告
        assertFalse(Pause.active(5_000L, 5_000L));
        assertFalse(Pause.active(5_001L, 5_000L));
        assertFalse(Pause.active(5_000L, 0L));
    }

    @Test
    public void remainingNeverGoesNegative() {
        assertEquals(4_000L, Pause.remaining(1_000L, 5_000L));
        assertEquals(0L, Pause.remaining(5_000L, 5_000L));
        assertEquals(0L, Pause.remaining(9_000L, 5_000L));
    }

    @Test
    public void zeroMinutesMeansResume() {
        assertEquals(0L, Pause.until(1_000L, 0));
        assertEquals(0L, Pause.until(1_000L, -5));
        assertEquals(1_000L + 15L * Pause.MINUTE, Pause.until(1_000L, 15));
    }

    @Test
    public void labelRoundsUpSoItNeverLies() {
        assertEquals("", Pause.label(0L));
        assertEquals("", Pause.label(-1L));
        assertEquals("不到 1 分钟", Pause.label(1L));
        assertEquals("不到 1 分钟", Pause.label(Pause.MINUTE - 1L));
        // 剩 12 分 01 秒说 13 分钟：说 12 分钟会让人以为马上到点
        assertEquals("13 分钟", Pause.label(12L * Pause.MINUTE + 1_000L));
        assertEquals("1 分钟", Pause.label(Pause.MINUTE));
    }

    @Test
    public void labelSwitchesToHoursAtSixtyMinutes() {
        assertEquals("1 小时", Pause.label(60L * Pause.MINUTE));
        assertEquals("1 小时 15 分钟", Pause.label(75L * Pause.MINUTE));
        // 59 分 30 秒向上取整成 60 分，应该显示 1 小时而不是 60 分钟
        assertEquals("1 小时", Pause.label(59L * Pause.MINUTE + 30_000L));
        assertEquals("2 小时", Pause.label(120L * Pause.MINUTE));
    }
}
