package app.shunjing.skipper.engine;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * v1.5.4：一次误点被连拽好几个 App 时的回收逻辑。
 *
 * <p>真实场景（用户实测）：点击关闭 → 落地页 A → 应用商店 B → 浏览器 C → 另一个 App D，
 * 一条链四个包。1.5.1 的守卫只肯退一次，退完还锁 8 秒，于是用户被扔在 D 里，
 * 按一次返回只退一层，观感就是「退不回去了」。
 */
public class JumpChainGuardTest {

    private static final String ORIGIN = "com.xiaoyang.ydxy";

    @Test
    public void revertsEveryLayerOfAFourAppChain() {
        JumpChainGuard guard = newJumpChain();
        long now = 10_000L;
        String[] chain = {"com.ss.android.ugc.aweme", "com.oppo.market", "com.android.browser", "com.tencent.mm"};
        for (int i = 0; i < chain.length; i++) {
            now += 700L;
            assertEquals("第 " + (i + 1) + " 层必须退",
                    JumpChainGuard.Result.REVERT, guard.observe(chain[i], now, 0L));
        }
        assertEquals(4, guard.hops());
        assertTrue(guard.active(now));
    }

    @Test
    public void pausesAutoClickRightAfterEachRevert() {
        JumpChainGuard guard = newJumpChain();
        long now = 10_000L;
        guard.observe("com.oppo.market", now + 300L, 0L);
        // 刚退完的 1.4 秒内不允许自动点击，否则会在新 App 里再点出一条新链。
        assertTrue(guard.paused(now + 400L));
        assertFalse(guard.paused(now + 1_900L));
    }

    @Test
    public void stopsAtHopLimitInsteadOfFightingForever() {
        JumpChainGuard guard = newJumpChain();
        long now = 10_000L;
        for (int i = 0; i < 5; i++) {
            now += 600L;
            assertEquals(JumpChainGuard.Result.REVERT, guard.observe("app.target" + i, now, 0L));
        }
        now += 600L;
        assertEquals("第六层退不动了，必须收手",
                JumpChainGuard.Result.GIVE_UP, guard.observe("app.target9", now, 0L));
        assertFalse(guard.active(now));
    }

    @Test
    public void givesUpOnOneAppThatKeepsComingBack() {
        JumpChainGuard guard = newJumpChain();
        long now = 10_000L;
        assertEquals(JumpChainGuard.Result.REVERT, guard.observe("com.oppo.market", now + 600L, 0L));
        assertEquals(JumpChainGuard.Result.REVERT, guard.observe("com.oppo.market", now + 1_300L, 0L));
        assertEquals("同一个商店退两次还回来，说明它拦返回键",
                JumpChainGuard.Result.GIVE_UP, guard.observe("com.oppo.market", now + 2_000L, 0L));
    }

    @Test
    public void neverFightsTheUser() {
        JumpChainGuard guard = newJumpChain();
        long now = 10_000L;
        // 用户 0.9 秒内点过屏幕：整条链作废，一个返回都不许按。
        assertEquals(JumpChainGuard.Result.NONE, guard.observe("com.tencent.mm", now + 500L, now + 200L));
        assertFalse(guard.active(now + 600L));
    }

    @Test
    public void launcherIsNotAnAdJump() {
        JumpChainGuard guard = newJumpChain();
        long now = 10_000L;
        assertEquals(JumpChainGuard.Result.NONE,
                guard.observe("com.android.launcher3", now + 500L, 0L));
        assertFalse(guard.active(now + 600L));
    }

    @Test
    public void returningHomeKeepsTheChainOpenForTheNextPull() {
        JumpChainGuard guard = newJumpChain();
        long now = 10_000L;
        guard.observe("com.oppo.market", now + 500L, 0L);
        assertEquals(JumpChainGuard.Result.NONE, guard.observe(ORIGIN, now + 1_400L, 0L));
        // 回到广告页后窗口顺延：SDK 再拉一次，还能接住。
        assertEquals(JumpChainGuard.Result.REVERT, guard.observe("com.android.browser", now + 2_100L, 0L));
        assertEquals(2, guard.hops());
    }

    @Test
    public void expiresAfterNineSeconds() {
        JumpChainGuard guard = newJumpChain();
        long now = 10_000L;
        guard.observe("com.oppo.market", now + 400L, 0L);
        assertEquals(JumpChainGuard.Result.NONE, guard.observe("com.tencent.mm", now + 9_500L, 0L));
        assertFalse(guard.active(now + 9_500L));
    }

    @Test
    public void throttlesBackToBackReverts() {
        JumpChainGuard guard = newJumpChain();
        long now = 10_000L;
        guard.observe("com.oppo.market", now + 300L, 0L);
        assertTrue(guard.coolingDown(now + 500L));
        assertFalse(guard.coolingDown(now + 900L));
    }

    private static JumpChainGuard newJumpChain() {
        JumpChainGuard guard = new JumpChainGuard();
        guard.arm(ORIGIN, 10_000L);
        return guard;
    }
}
