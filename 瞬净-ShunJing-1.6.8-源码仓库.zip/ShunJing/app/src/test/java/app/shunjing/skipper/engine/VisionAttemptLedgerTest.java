package app.shunjing.skipper.engine;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * v1.5.5：开屏广告会重复出现，云端失败的记录不能是永久的。
 *
 * <p>真实场景：某个 App 的开屏广告只能靠云端定位（整树 c=0）。第一次问过云端两次都没成，
 * 旧实现把这一页永久拉黑；用户把 App 放后台、过一会再点开，广告重新加载、页面指纹一模一样，
 * 于是从那一刻起这个 App 就彻底「罢工」了 —— 而且用户完全不知道为什么。
 */
public class VisionAttemptLedgerTest {

    private static final String PKG = "com.xiaoyang.ydxy";
    private static final String FP = "splash-abc";

    @Test
    public void twoMissesThenBlockedWithinTheSamePage() {
        VisionAttemptLedger ledger = new VisionAttemptLedger();
        String key = VisionAttemptLedger.key(PKG, FP);
        long now = 1_000L;
        assertEquals(0, ledger.count(key, now));
        ledger.miss(key, now + 100L);
        ledger.miss(key, now + 200L);
        assertEquals(2, ledger.count(key, now + 300L));
    }

    @Test
    public void recordExpiresSoTheNextSplashIsNotBlocked() {
        VisionAttemptLedger ledger = new VisionAttemptLedger();
        String key = VisionAttemptLedger.key(PKG, FP);
        long now = 1_000L;
        ledger.miss(key, now);
        ledger.miss(key, now + 1_000L);
        assertEquals("同一轮里确实被拦住", 2, ledger.count(key, now + 1_100L));
        assertEquals("过了寿命就当没发生过：下一轮开屏还能问",
                0, ledger.count(key, now + 21_500L));
    }

    @Test
    public void missesInOneAppDoNotBlockAnother() {
        VisionAttemptLedger ledger = new VisionAttemptLedger();
        long now = 1_000L;
        String a = VisionAttemptLedger.key(PKG, FP);
        String b = VisionAttemptLedger.key("com.example.other", FP);
        ledger.miss(a, now);
        ledger.miss(a, now);
        assertEquals(2, ledger.count(a, now));
        assertEquals("指纹相同也不该串包", 0, ledger.count(b, now));
    }

    @Test
    public void leavingAnAppClearsItsHistory() {
        VisionAttemptLedger ledger = new VisionAttemptLedger();
        long now = 1_000L;
        String key = VisionAttemptLedger.key(PKG, FP);
        ledger.miss(key, now);
        ledger.miss(key, now);
        ledger.clearPackage(PKG);
        assertEquals("放后台再点回来 = 新会话，给它一次机会", 0, ledger.count(key, now + 50L));
    }

    @Test
    public void clearsOnlyTheAppThatLeft() {
        VisionAttemptLedger ledger = new VisionAttemptLedger();
        long now = 1_000L;
        String a = VisionAttemptLedger.key(PKG, FP);
        String b = VisionAttemptLedger.key("com.example.other", FP);
        ledger.miss(a, now);
        ledger.miss(b, now);
        ledger.clearPackage(PKG);
        assertEquals(0, ledger.count(a, now));
        assertEquals(1, ledger.count(b, now));
    }

    @Test
    public void neverGrowsWithoutBound() {
        VisionAttemptLedger ledger = new VisionAttemptLedger();
        for (int i = 0; i < 200; i++) {
            ledger.miss(VisionAttemptLedger.key(PKG, "fp-" + i), 10_000L + i);
        }
        assertTrue("条目数必须有上限", ledger.size() <= 60);
    }
}
