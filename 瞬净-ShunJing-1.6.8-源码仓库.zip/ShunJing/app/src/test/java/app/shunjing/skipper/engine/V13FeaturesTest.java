package app.shunjing.skipper.engine;

import static org.junit.Assert.*;

import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** v1.3: dynamic countdown, real success verification, adaptive and vision recovery safety. */
public class V13FeaturesTest {
    private final AdDecisionEngine engine = new AdDecisionEngine();
    private final List<Rule> defaults = DefaultRules.create();

    private static NodeModel node(int index, int parent, String text, String desc, String id,
                                  String className, boolean clickable, boolean visible,
                                  int left, int top, int right, int bottom) {
        return new NodeModel(index, parent, text, desc, id, className, clickable, visible,
                false, left, top, right, bottom);
    }

    private static EngineSettings settings() {
        return new EngineSettings(true, true, EngineSettings.RewardMode.PROTECT,
                Collections.<String>emptySet(), true, true, false);
    }

    @Test
    public void detectsSkipThatAppearsEarlyInsideCountdownPhrase() {
        ScreenModel screen = new ScreenModel("demo.campus", "demo.campus.SplashActivity", true,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, 1080, 2400),
                        node(1, 0, "3秒后可跳过", "", "", "android.widget.TextView", true, true,
                                840, 90, 1040, 170)));
        Decision decision = engine.evaluate(screen, defaults, settings());
        assertEquals(Decision.Type.CLICK, decision.type);
        assertEquals(1, decision.nodeIndex);
    }

    @Test
    public void findsSplitSkipCharactersWithoutClickingTheNumber() {
        ScreenModel screen = new ScreenModel("demo.campus", "demo.campus.SplashActivity", true,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, 1080, 2400),
                        node(1, 4, "跳", "", "", "android.widget.TextView", false, true,
                                900, 90, 940, 160),
                        node(2, 4, "过", "", "", "android.widget.TextView", false, true,
                                940, 90, 980, 160),
                        node(3, 4, "3", "", "", "android.widget.TextView", false, true,
                                990, 90, 1040, 160),
                        node(4, 0, "", "", "", "android.widget.LinearLayout", true, true,
                                890, 80, 1040, 170)));
        Decision decision = engine.evaluate(screen, defaults, settings());
        assertEquals(Decision.Type.CLICK, decision.type);
        assertEquals(4, decision.nodeIndex); // only clickable ancestor, never the "3" node
    }

    @Test
    public void countdownChangeIsNotTreatedAsClosed() {
        ScreenModel three = new ScreenModel("demo.campus", "demo.campus.SplashActivity", true,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, 1080, 2400),
                        node(1, 0, "跳过 3", "", "", "android.widget.TextView", true, true,
                                850, 90, 1040, 170)));
        ScreenModel two = new ScreenModel("demo.campus", "demo.campus.SplashActivity", true,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, 1080, 2400),
                        node(1, 0, "跳过 2", "", "", "android.widget.TextView", true, true,
                                850, 90, 1040, 170)));
        assertTrue(ScreenFingerprint.unchanged(three, two));
        ScreenModel dialog = new ScreenModel("demo.campus", "demo.campus.SplashActivity", true,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, 1080, 2400),
                        node(1, 0, "残忍离开", "", "", "android.widget.TextView", true, true,
                                350, 1400, 730, 1510)));
        assertFalse(ScreenFingerprint.unchanged(three, dialog));
    }

    @Test
    public void adaptiveLocatorFindsDifferentCornerCloseButNotOldTargetOrCta() {
        ScreenModel screen = new ScreenModel("demo.campus", "demo.campus.AdActivity", false,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, 1080, 2400),
                        node(1, 0, "", "", "", "android.widget.LinearLayout", false, true, 100, 400, 980, 2000),
                        node(2, 1, "", "", "", "android.widget.ImageView", true, true, 900, 410, 980, 490),
                        node(3, 1, "立即下载应用", "", "", "android.widget.Button", true, true, 180, 1800, 900, 1930),
                        node(4, 0, "广告", "", "", "android.widget.TextView", false, true, 980, 2300, 1050, 2360)));
        AdaptiveCloseLocator.Result result = AdaptiveCloseLocator.find(screen, -1, 1080, 2400);
        assertNotNull(result);
        assertEquals(2, result.nodeIndex);
        assertNotEquals(3, result.nodeIndex);
        assertNull(AdaptiveCloseLocator.find(screen, 2, 1080, 2400));
    }

    @Test
    public void adaptiveLocatorRefusesAmbiguousDuplicateIcons() {
        ScreenModel screen = new ScreenModel("demo.campus", "demo.campus.AdActivity", false,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, 1080, 2400),
                        node(1, 0, "", "", "", "android.widget.LinearLayout", false, true, 100, 400, 980, 2000),
                        node(2, 1, "", "", "", "android.widget.ImageView", true, true, 900, 410, 980, 490),
                        node(3, 1, "", "", "", "android.widget.ImageView", true, true, 100, 410, 180, 490)));
        assertNull(AdaptiveCloseLocator.find(screen, -1, 1080, 2400));
    }

    @Test
    public void adaptiveLocatorNeverWorksOnSensitivePage() {
        ScreenModel qr = new ScreenModel("demo.campus", "demo.campus.ScanActivity", false,
                Arrays.asList(
                        node(0, -1, "扫一扫 将二维码放入框内", "", "", "android.widget.FrameLayout",
                                false, true, 0, 0, 1080, 2400),
                        node(1, 0, "", "", "", "android.widget.ImageView", true, true, 900, 80, 990, 170)));
        assertNull(AdaptiveCloseLocator.find(qr, -1, 1080, 2400));
        assertTrue(AdDecisionEngine.isSensitive(qr));
    }

    @Test
    public void visionAnswerNeedsBoundsAndConfidence() {
        assertFalse(VisionRecoveryPolicy.validAnswer(false, 500, 500, 0.99f));
        assertFalse(VisionRecoveryPolicy.validAnswer(true, -1, 500, 0.99f));
        assertFalse(VisionRecoveryPolicy.validAnswer(true, 500, 500, 0.50f));
        assertTrue(VisionRecoveryPolicy.validAnswer(true, 500, 500, 0.88f));
        assertEquals(500, VisionRecoveryPolicy.toPixels(500, 1000));
    }

    @Test
    public void visionPointOnCtaIsRejectedButCloseNodeIsAccepted() {
        ScreenModel screen = new ScreenModel("demo.campus", "demo.campus.AdActivity", false,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, 1080, 2400),
                        node(1, 0, "", "", "", "android.widget.Button", true, true, 900, 80, 1000, 180),
                        node(2, 1, "关闭广告", "", "", "android.widget.TextView", false, true,
                                910, 90, 990, 160),
                        node(3, 0, "立即下载", "", "", "android.widget.Button", true, true,
                                200, 1900, 850, 2030)));
        assertEquals(1, VisionRecoveryPolicy.findSafeNode(screen, 950, 130, 1080, 2400));
        assertEquals(-1, VisionRecoveryPolicy.findSafeNode(screen, 500, 1960, 1080, 2400));
    }

    @Test
    public void visionCannotUnlockSensitivePages() {
        ScreenModel pay = new ScreenModel("demo.pay", "demo.pay.PayActivity", false,
                Arrays.asList(
                        node(0, -1, "确认支付 输入密码", "", "", "android.widget.FrameLayout",
                                false, true, 0, 0, 1080, 2400),
                        node(1, 0, "关闭", "", "", "android.widget.Button", true, true,
                                900, 80, 1000, 180)));
        assertEquals(-1, VisionRecoveryPolicy.findSafeNode(pay, 950, 130, 1080, 2400));
        assertFalse(VisionRecoveryPolicy.allowCoordinateOnly(pay, 1f, settings()));
    }
}
