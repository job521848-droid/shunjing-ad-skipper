package app.shunjing.skipper.engine;

import static org.junit.Assert.*;

import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * v1.4: overlay popups whose close icon floats OUTSIDE the card and carries no text.
 * Modelled on the 闪动 "每天有惊喜" red-packet popup.
 */
public class V14FeaturesTest {
    private final AdDecisionEngine engine = new AdDecisionEngine();
    private final List<Rule> defaults = DefaultRules.create();
    private static final int W = 1080, H = 2160;

    private static NodeModel node(int index, int parent, String text, String desc, String id,
                                  String className, boolean clickable, boolean visible,
                                  int left, int top, int right, int bottom) {
        return new NodeModel(index, parent, text, desc, id, className, clickable, visible,
                false, left, top, right, bottom);
    }

    private static EngineSettings settings() {
        return new EngineSettings(true, true, EngineSettings.RewardMode.PROTECT,
                Collections.<String>emptySet(), true, true, false);
    }

    /** 开屏图 + 居中红包卡片 + 悬浮在卡片右上角外侧的纯图 ×。 */
    private static ScreenModel redPacketPopup(String iconDesc) {
        return new ScreenModel("com.demo.campus", "com.demo.campus.MainActivity", false,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, W, H),
                        node(1, 0, "梦马创业园", "", "", "android.widget.ImageView", false, true,
                                0, 0, W, H),
                        node(2, 0, "每天有惊喜 摇动手机或点击查看详情", "", "",
                                "android.webkit.WebView", false, true, 140, 551, 950, 1879),
                        node(3, 2, "", iconDesc, "", "android.widget.ImageView", true, true,
                                840, 441, 931, 531)));
    }

    @Test
    public void findsFloatingCloseOutsideCardTopRight() {
        OverlayCloseLocator.Hit hit = OverlayCloseLocator.find(redPacketPopup(""), W, H);
        assertNotNull(hit);
        assertEquals(3, hit.nodeIndex);
    }

    @Test
    public void engineClicksOverlayCloseOnPromoPageWithoutTheWordAd() {
        // The popup never says "广告"; only "摇动手机" gives ad context.
        Decision decision = engine.evaluate(redPacketPopup(""), defaults, settings(), 
                Collections.<LayoutAnchorRule>emptyList(), W, H);
        assertEquals(Decision.Type.CLICK, decision.type);
        assertEquals(3, decision.nodeIndex);
        assertEquals("overlay_close", decision.ruleId);
    }

    @Test
    public void acceptsCloseDescriptionButRejectsMoreDescription() {
        assertNotNull(OverlayCloseLocator.find(redPacketPopup("关闭按钮"), W, H));
        assertNull(OverlayCloseLocator.find(redPacketPopup("更多"), W, H));
    }

    @Test
    public void neverTouchesQrScannerEvenWithIdenticalGeometry() {
        ScreenModel scan = new ScreenModel("com.demo.campus", "com.demo.campus.ScanActivity", false,
                Arrays.asList(
                        node(0, -1, "扫一扫 将二维码放入框内", "", "", "android.widget.FrameLayout",
                                false, true, 0, 0, W, H),
                        node(1, 0, "", "", "scan_card", "android.widget.FrameLayout", false, true,
                                140, 551, 950, 1879),
                        node(2, 1, "", "", "", "android.widget.ImageView", true, true,
                                840, 441, 931, 531)));
        assertNull(OverlayCloseLocator.find(scan, W, H));
        assertEquals(Decision.Type.NONE,
                engine.evaluate(scan, defaults, settings(), Collections.<LayoutAnchorRule>emptyList(), W, H).type);
    }

    @Test
    public void neverTouchesPaymentConfirmation() {
        ScreenModel pay = new ScreenModel("com.demo.campus", "com.demo.campus.PayActivity", false,
                Arrays.asList(
                        node(0, -1, "确认支付", "", "", "android.widget.FrameLayout", false, true, 0, 0, W, H),
                        node(1, 0, "", "", "", "android.widget.LinearLayout", false, true,
                                140, 551, 950, 1879),
                        node(2, 1, "", "", "", "android.widget.ImageView", true, true,
                                840, 441, 931, 531)));
        assertNull(OverlayCloseLocator.find(pay, W, H));
    }

    @Test
    public void ignoresLargeCtaButtonAtBottomOfCard() {
        ScreenModel screen = new ScreenModel("com.demo.campus", "com.demo.campus.MainActivity", false,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, W, H),
                        node(1, 0, "每天有惊喜 领取红包", "", "", "android.widget.LinearLayout",
                                false, true, 140, 551, 950, 1879),
                        node(2, 1, "", "", "", "android.widget.ImageView", true, true,
                                400, 1600, 700, 1760)));
        assertNull(OverlayCloseLocator.find(screen, W, H));
    }

    @Test
    public void refusesAmbiguousDuplicateCornerIcons() {
        ScreenModel screen = new ScreenModel("com.demo.campus", "com.demo.campus.MainActivity", false,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, W, H),
                        node(1, 0, "每天有惊喜", "", "", "android.widget.LinearLayout", false, true,
                                140, 551, 950, 1879),
                        node(2, 1, "", "", "", "android.widget.ImageView", true, true,
                                840, 441, 931, 531),
                        node(3, 1, "", "", "", "android.widget.ImageView", true, true,
                                850, 451, 921, 521)));
        assertNull(OverlayCloseLocator.find(screen, W, H));
    }

    @Test
    public void plainSettingsPageIsNotTreatedAsPopup() {
        ScreenModel settingsPage = new ScreenModel("com.demo.campus", "com.demo.campus.SettingsActivity", false,
                Arrays.asList(
                        node(0, -1, "选择语言", "", "", "android.widget.FrameLayout", false, true, 0, 0, W, H),
                        node(1, 0, "", "", "", "android.widget.LinearLayout", false, true,
                                140, 551, 950, 1879),
                        node(2, 1, "", "", "", "android.widget.ImageView", true, true,
                                840, 441, 931, 531)));
        // Geometry alone is not ad evidence: the engine must still refuse a plain page.
        assertEquals(Decision.Type.NONE,
                engine.evaluate(settingsPage, defaults, settings(),
                        Collections.<LayoutAnchorRule>emptyList(), W, H).type);
    }

    @Test
    public void overlayCloseCanBeDisabled() {
        EngineSettings off = settings().withOverlayClose(false);
        assertEquals(Decision.Type.NONE,
                engine.evaluate(redPacketPopup(""), defaults, off,
                        Collections.<LayoutAnchorRule>emptyList(), W, H).type);
    }
}
