package app.shunjing.skipper.engine;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;

/**
 * v1.5.2 回归：重点关注应用的 0 等待接管，以及"点了没关掉"之后复查链路依赖的阈值。
 *
 * <p>用户反馈有两件事必须同时成立：
 * <ul>
 *   <li>重点应用的广告页一出现就要问云端，不能等 0.3 秒——那点时间用户已经自己点完了；</li>
 *   <li>放宽的只是等待时间与置信度，敏感页、坐标危险词、系统页这些硬约束一条都不能松。</li>
 * </ul>
 */
public class V152FeaturesTest {
    private static final int W = 1272, H = 2772;
    private static final long NEVER = Long.MAX_VALUE;

    private static NodeModel node(int index, int parent, String text, String desc, String id,
                                  String className, boolean clickable, boolean visible,
                                  int left, int top, int right, int bottom) {
        return new NodeModel(index, parent, text, desc, id, className, clickable, visible,
                false, left, top, right, bottom);
    }

    @Test
    public void priorityTakesOverOnFirstScan() {
        // 0ms 等待、0 次空扫描也成立：页面一出现就问，而不是"再等等看"。
        assertTrue(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.PRIORITY, true, true, false, false,
                0L, 0, NEVER));
    }

    @Test
    public void eagerStillWaitsForTheAdPageToSettle() {
        // 同一时刻，普通「积极」档仍按 0.65 秒等待，重点标记不是全局提速。
        assertFalse(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.EAGER, true, true, false, false,
                0L, 0, NEVER));
        assertTrue(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.EAGER, true, true, false, false,
                650L, 2, NEVER));
    }

    @Test
    public void priorityAlsoAsksAboutSuspectPagesImmediately() {
        assertTrue(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.PRIORITY, true, false, true, false,
                0L, 1, NEVER));
    }

    @Test
    public void priorityNeverBypassesSensitivePages() {
        assertFalse(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.PRIORITY, true, true, true, true,
                0L, 0, NEVER));
        assertFalse(VisionTriggerPolicy.shouldTakeOver(
                VisionTriggerPolicy.Sensitivity.PRIORITY, false, true, true, false,
                0L, 0, NEVER));
    }

    @Test
    public void priorityAcceptsLowerConfidenceButStillHasAFloor() {
        assertTrue(VisionTriggerPolicy.allowsCoordinateOnly(
                VisionTriggerPolicy.Sensitivity.PRIORITY, 0.45f));
        // 0.3 仍低于重点档的 0.42 下限：模型自己都不确定时不点。
        assertFalse(VisionTriggerPolicy.allowsCoordinateOnly(
                VisionTriggerPolicy.Sensitivity.PRIORITY, 0.30f));
    }

    @Test
    public void priorityRetriesMuchSoonerThanEager() {
        assertTrue(VisionTriggerPolicy.Sensitivity.PRIORITY.pageCooldownMs
                < VisionTriggerPolicy.Sensitivity.EAGER.pageCooldownMs);
        assertTrue(VisionTriggerPolicy.shouldTakeOverAfterFailedClick(
                VisionTriggerPolicy.Sensitivity.PRIORITY, true, true, false, 1_250L));
        assertFalse(VisionTriggerPolicy.shouldTakeOverAfterFailedClick(
                VisionTriggerPolicy.Sensitivity.EAGER, true, true, false, 1_250L));
    }

    @Test
    public void priorityIsLastSoTheVisibleThreeKeepTheirOrdinals() {
        // 云端设置页用 ordinal 映射「保守 / 积极 / 激进」三个分段，重点档不能插在中间。
        VisionTriggerPolicy.Sensitivity[] values = VisionTriggerPolicy.Sensitivity.values();
        assertEquals(VisionTriggerPolicy.Sensitivity.CONSERVATIVE, values[0]);
        assertEquals(VisionTriggerPolicy.Sensitivity.EAGER, values[1]);
        assertEquals(VisionTriggerPolicy.Sensitivity.AGGRESSIVE, values[2]);
        assertEquals(VisionTriggerPolicy.Sensitivity.PRIORITY, values[3]);
        assertEquals("重点", VisionTriggerPolicy.Sensitivity.PRIORITY.label);
    }

    @Test
    public void priorityCoordinateStillRejectedOnDangerousControls() {
        // 支付页面：硬锁在最前面，重点档也不能过。
        ScreenModel pay = new ScreenModel("com.example.shop", "com.example.shop.PayActivity", true,
                Arrays.asList(
                        node(0, -1, "确认支付", "", "", "android.widget.FrameLayout", false, true, 0, 0, W, H),
                        node(1, 0, "确认支付", "", "", "android.widget.Button", true, true, 400, 2200, 900, 2350)));
        assertTrue(AdDecisionEngine.isSensitive(pay));
        assertFalse(VisionRecoveryPolicy.allowCoordinateOnly(pay, 650, 2275, 0.99f,
                VisionTriggerPolicy.Sensitivity.PRIORITY, 0f, false));
    }

    @Test
    public void landmarkStillRequiredEvenWhenPriority() {
        // 重点应用只在"允许更早发问"上更宽松，坐标兜底仍要求页面确实是广告位。
        ScreenModel plain = new ScreenModel("com.example.tool", "com.example.tool.MainActivity", false,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true, 0, 0, W, H),
                        node(1, 0, "设置", "", "", "android.widget.TextView", true, true, 100, 200, 400, 300)));
        assertFalse(VisionRecoveryPolicy.allowCoordinateOnly(plain, 1000, 100, 0.99f,
                VisionTriggerPolicy.Sensitivity.PRIORITY, 0f, false));
        assertFalse(VisionRecoveryPolicy.allowCoordinateOnly(plain, 1000, 100, 0.99f,
                VisionTriggerPolicy.Sensitivity.PRIORITY));
    }
}
