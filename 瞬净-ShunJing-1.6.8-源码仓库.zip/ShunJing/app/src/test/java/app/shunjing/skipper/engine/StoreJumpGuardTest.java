package app.shunjing.skipper.engine;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * v1.6.3 回归：广告跳进应用商店时的自动退回。
 *
 * <p>这个功能的代价不对称：漏退一次只是用户自己按一下返回；误退一次是把正在装 App 的人
 * 踢出商店。所以判定的每一道闸都要有测试盯着。
 */
public class StoreJumpGuardTest {

    @Test
    public void recognizesMainlandStores() {
        assertTrue(StoreJumpGuard.isStore("com.xiaomi.market"));
        assertTrue(StoreJumpGuard.isStore("com.huawei.appmarket"));
        assertTrue(StoreJumpGuard.isStore("com.heytap.market"));
        assertTrue(StoreJumpGuard.isStore("com.bbk.appstore"));
        assertTrue(StoreJumpGuard.isStore("com.tencent.android.qqdownloader"));
        assertTrue(StoreJumpGuard.isStore("com.android.vending"));
    }

    @Test
    public void storeSubPackageStillCounts() {
        assertTrue(StoreJumpGuard.isStore("com.xiaomi.market.detail"));
    }

    @Test
    public void normalAppIsNotStore() {
        assertFalse(StoreJumpGuard.isStore("com.tencent.mm"));
        assertFalse(StoreJumpGuard.isStore("com.example.shop"));
        assertFalse(StoreJumpGuard.isStore(""));
        assertFalse(StoreJumpGuard.isStore(null));
    }

    @Test
    public void revertsWhenAdPageJumpedToStore() {
        // 1.5 秒前这一页还是广告位，现在前台是小米商店 → 该退。
        assertTrue(StoreJumpGuard.shouldRevert("com.tencent.mm", "com.xiaomi.market",
                10_000L, 8_500L));
    }

    @Test
    public void doesNothingWithoutRecentAdContext() {
        // 刚看完一个视频，自己点广告位进了商店（没被我们识别成广告）→ 不动。
        assertFalse(StoreJumpGuard.shouldRevert("com.tencent.mm", "com.xiaomi.market",
                10_000L, 0L));
        // 广告上下文太旧，说明中间用户已经在干别的了。
        assertFalse(StoreJumpGuard.shouldRevert("com.tencent.mm", "com.xiaomi.market",
                30_000L, 8_500L));
    }

    @Test
    public void neverRevertsWhenLaunchedFromHome() {
        assertFalse(StoreJumpGuard.shouldRevert("com.android.launcher3", "com.xiaomi.market",
                10_000L, 9_900L));
        assertFalse(StoreJumpGuard.shouldRevert("com.miui.home", "com.xiaomi.market",
                10_000L, 9_900L));
    }

    @Test
    public void ignoresSamePackageOrNonStore() {
        assertFalse(StoreJumpGuard.shouldRevert("com.xiaomi.market", "com.xiaomi.market",
                10_000L, 9_900L));
        assertFalse(StoreJumpGuard.shouldRevert("com.tencent.mm", "com.tencent.mm",
                10_000L, 9_900L));
        assertFalse(StoreJumpGuard.shouldRevert("com.tencent.mm", "com.example.shop",
                10_000L, 9_900L));
    }

    @Test
    public void windowBoundaryIsInclusive() {
        // 正好卡在 6 秒上仍算广告带的；多 1ms 就放过。
        assertTrue(StoreJumpGuard.shouldRevert("com.tencent.mm", "com.xiaomi.market",
                10_000L, 10_000L - StoreJumpGuard.AD_WINDOW_MS));
        assertFalse(StoreJumpGuard.shouldRevert("com.tencent.mm", "com.xiaomi.market",
                10_000L, 10_000L - StoreJumpGuard.AD_WINDOW_MS - 1L));
    }
}
