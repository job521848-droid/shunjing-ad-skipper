package app.shunjing.skipper.engine;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.Arrays;

/**
 * v1.6.3 回归：把「敏感」的判定范围收窄到真正会花钱的页面。
 *
 * <p>用户现场：某些 App 的开屏广告页脚写着「用户协议 / 隐私政策」，旧词表因此把整页判死
 * ——引擎不动、云端不许截图，表现就是「广告关不掉，还弹系统禁止截图」。
 *
 * <p>同时必须守住底线：支付、扫码、密码、验证码一张都不能放开；系统危险操作（卸载确认）
 * 仍然禁止点击，只是不再阻止云端看一眼。
 */
public class SensitiveScopeTest {
    private static final int W = 1272, H = 2772;

    private static NodeModel node(int index, int parent, String text, String desc, String id,
                                  String className, boolean clickable, boolean visible,
                                  boolean password, int left, int top, int right, int bottom) {
        return new NodeModel(index, parent, text, desc, id, className, clickable, visible,
                password, left, top, right, bottom);
    }

    private static ScreenModel screen(String pkg, String activity, String... words) {
        NodeModel[] nodes = new NodeModel[words.length + 1];
        nodes[0] = node(0, -1, "", "", "", "android.widget.FrameLayout", false, true,
                false, 0, 0, W, H);
        for (int i = 0; i < words.length; i++) {
            nodes[i + 1] = node(i + 1, 0, words[i], "", "", "android.widget.TextView", false, true,
                    false, 60, 100 + i * 80, 900, 160 + i * 80);
        }
        return new ScreenModel(pkg, activity, true, Arrays.asList(nodes));
    }

    @Test
    public void legalFooterOnAdPageNoLongerLocksAnything() {
        ScreenModel ad = screen("com.example.news", "com.example.news.SplashActivity",
                "跳过 5", "广告", "用户协议", "隐私政策", "广告管理", "广告偏好");
        assertFalse("页脚的协议链接不该把广告页判死", AdDecisionEngine.isSensitive(ad));
        assertFalse("云端 AI 更不该被这几个词挡住", AdDecisionEngine.isPaymentOrScan(ad));
    }

    @Test
    public void paymentPageStillHardLocked() {
        ScreenModel pay = screen("com.example.shop", "com.example.shop.OrderActivity", "确认支付");
        assertTrue(AdDecisionEngine.isSensitive(pay));
        assertTrue(AdDecisionEngine.isPaymentOrScan(pay));
    }

    @Test
    public void scanPageStillHardLocked() {
        ScreenModel scan = screen("com.example.app", "com.example.app.MainActivity", "扫一扫");
        assertTrue(AdDecisionEngine.isSensitive(scan));
        assertTrue(AdDecisionEngine.isPaymentOrScan(scan));
    }

    @Test
    public void scanActivityNameAloneLocks() {
        ScreenModel scan = new ScreenModel("com.example.app", "com.example.app.ScanActivity", true,
                Arrays.asList(node(0, -1, "", "", "", "android.widget.FrameLayout", false, true,
                        false, 0, 0, W, H)));
        assertTrue(AdDecisionEngine.isPaymentOrScan(scan));
    }

    @Test
    public void passwordFieldAlwaysLocks() {
        ScreenModel login = new ScreenModel("com.example.app", "com.example.app.LoginActivity", true,
                Arrays.asList(
                        node(0, -1, "", "", "", "android.widget.FrameLayout", false, true,
                                false, 0, 0, W, H),
                        node(1, 0, "", "密码", "", "android.widget.EditText", true, true,
                                true, 100, 600, 1100, 740)));
        assertTrue(AdDecisionEngine.isPaymentOrScan(login));
    }

    @Test
    public void uninstallConfirmBlocksClickButNotCloud() {
        ScreenModel uninstall = screen("com.android.packageinstaller",
                "com.android.packageinstaller.UninstallerActivity", "确认卸载");
        assertTrue("危险操作仍然不许点", AdDecisionEngine.isSensitive(uninstall));
        assertFalse("但它不是支付页，不该拦住云端识别", AdDecisionEngine.isPaymentOrScan(uninstall));
    }

    @Test
    public void plainFunctionPageIsOpen() {
        ScreenModel plain = screen("com.example.tool", "com.example.tool.MainActivity",
                "首页", "发现", "我的", "设置");
        assertFalse(AdDecisionEngine.isSensitive(plain));
        assertFalse(AdDecisionEngine.isPaymentOrScan(plain));
    }
}
