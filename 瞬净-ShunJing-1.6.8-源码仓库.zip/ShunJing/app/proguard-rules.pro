-keep class app.shunjing.skipper.service.AdSkipService { *; }
-keepclassmembers class app.shunjing.skipper.engine.** { *; }
# Enum constant names are persisted in JSON (Rule.MatchType.valueOf / .name()).
-keepclassmembers enum app.shunjing.skipper.engine.Rule$MatchType {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}
-keepclassmembers enum app.shunjing.skipper.engine.Rule$Category {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}
# RewardMode name is persisted in SharedPreferences and read back with valueOf().
-keepclassmembers enum app.shunjing.skipper.engine.EngineSettings$RewardMode {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}
-dontwarn android.app.**
# v1.5：接管灵敏度以枚举名保存在 SharedPreferences，必须保留常量名。
-keepclassmembers enum app.shunjing.skipper.engine.VisionTriggerPolicy$Sensitivity {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}
